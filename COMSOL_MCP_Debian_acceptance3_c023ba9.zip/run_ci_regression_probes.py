"""Retain before/after startup and fresh-process schema regression evidence."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
baseline=Path('/workspace/COMSOL_MCP_debian_reacceptance_42f9e95')
target=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
jobs=[]
for label,repo in [('baseline',baseline),('target',target)]:
    jobs.append(('CI__BUG-053__'+label,[sys.executable,str(ROOT/'CI__BUG-053__semantic_startup_probe.py'),'--repository',str(repo)],repo))
    jobs.append(('CI__BUG-031__'+label+'_fresh_schema_tests',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',
        'development_kit/tests/test_tool_catalog.py::test_full_tool_schema_snapshot_is_stable',
        'development_kit/tests/test_tool_catalog.py::test_pre_h3_compatibility_snapshot_is_preserved',
        'development_kit/tests/test_tool_profiles.py::test_profile_name_and_schema_snapshots_are_exact',
        '--basetemp',str(ROOT/(label+'-schema-temp'))],repo))
jobs.append(('CI__BUG-031__real_schema_diff',[sys.executable,str(ROOT/'CI__BUG-031__schema_comparison.py')],target))
outcomes=[]
for name,command,repo in jobs:
    start=time.monotonic()
    result=subprocess.run(command,cwd=repo,capture_output=True,timeout=45,
                          env=dict(os.environ,PYTHONPATH=str(repo),PYTHONDONTWRITEBYTECODE='1'))
    folder=ROOT/'ci-local-results'
    (folder/(name+'__stdout.log')).write_bytes(result.stdout)
    (folder/(name+'__stderr.log')).write_bytes(result.stderr)
    if 'fresh_schema_tests' not in name and 'real_schema_diff' not in name and result.returncode==0:
        (ROOT/(name+'.json')).write_bytes(result.stdout)
    row={'name':name,'command':command,'repository':str(repo),
         'returncode':result.returncode,'seconds':round(time.monotonic()-start,3)}
    outcomes.append(row)
    print(json.dumps(row),flush=True)
(ROOT/'ci-regression-probes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
