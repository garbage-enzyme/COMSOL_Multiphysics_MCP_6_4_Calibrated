## ACC-008（CI 发布白名单）

**第三轮状态**：保持通过：57 个发布契约测试通过，远端 integration-contracts succeeded。



- **编号**：ACC-008
- **标题**：新增测试移动历史 planning-code 偏移，白名单精确指纹未更新
- **严重性/优先级**：中 / P2；发布契约门禁失败。
- **位置**：`development_kit/tests/test_durable_job_control_plane.py:32`；`development_kit/release/planning_code_allowlist.json:23`；`development_kit/scripts/planning_code_gate.py:45`；引入提交 `fc5da9a`。
- **内容/复现方法**：新增 17 行链接拒绝测试后，原有唯一 h1 token 的 start 从 11335 移到 11923，匹配数量与 token 未变。指纹包含 start，旧值 ff7f57cc…、目标值 811bb52b…；白名单未同步。精确 integration-contract 命令为 56 passed/1 failed，两分片也有同一失败。ci-planning-fingerprint.json 保存完整匹配及哈希对照。
- **可能的解决办法**：审阅该历史 token 语义未变后更新这条精确白名单指纹，保持枚举数量和 require_all_allowlisted 校验；重新运行 release engineering 和 CI 契约套件。


