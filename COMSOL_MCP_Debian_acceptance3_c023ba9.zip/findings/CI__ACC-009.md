## ACC-009（本轮发现，前一版本也可复现）

**第三轮状态**：本范围通过：watchdog 暂时空命令行有界重试；持续为空、错签名、退出拒绝；真实 adjoint 测试通过。



- **编号**：ACC-009
- **标题**：watchdog 刚启动时仅尝试一次进程身份读取，暂时为空的命令行使正常作业提交失败
- **严重性/优先级**：中 / P2；正常作业提交间歇失败，相关 CI 测试不稳定。
- **位置**：`comsol_mcp/jobs/manager.py:791`，`_arm_robust_wall_watchdog_if_required()`；`comsol_mcp/jobs/store.py:118`，`process_identity()`。
- **内容/复现方法**：本轮真实两分片中 `test_native_adjoint_worker_fails_closed_without_armed_watchdog` 在 manager.submit() 失败，尚未执行测试的 watchdog 删除断言。traceback 显示新启动的 watchdog PID 19305 的 cmdline 为空，status 不是 zombie，process_identity 抛 OSError。manager 将其记录为 launch_failed 并触发 exact-attempt cancel，最终抛 JobLaunchError。相同测试文件定向复验：目标 16 passed；上轮 bf9132e 为 15 passed/1 failed，在 `test_real_adjoint_submission_arms_the_wall_watchdog` 中出现同一调用链、同一 OSError。实际 watchdog Popen 后立即读取一次，无有界重试。此处进程身份读取失败有真实日志证明；空 cmdline 的具体内核时序未做跟踪，不声明每次执行必现。复验入口 `python recheck_adjoint.py`，完整日志见 `ci-dependency-shards/shard0.log` 和 `ci-local-results/adjoint_recheck_previous__stdout.log`。测试未安装或启动 COMSOL。
- **可能的解决办法**：为 watchdog 复用 worker 的有界身份确认机制；未到截止且子进程仍运行时，对暂时不可读/空命令行做短间隔重试，成功后仍严格核对 PID、创建时间和期望命令签名。截止、退出或身份不符继续拒绝并返回清理证据。增加首次为空、随后有效的测试及持续为空/退出负向测试；不要降低身份校验要求。

