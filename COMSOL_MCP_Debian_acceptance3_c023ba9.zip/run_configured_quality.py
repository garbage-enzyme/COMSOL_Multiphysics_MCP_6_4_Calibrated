import subprocess,os,sys,time,json,signal
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
command=[sys.executable,'development_kit/scripts/quality_gate.py','--defer-platform-coverage','--artifact-root',str(root/'quality-configured')]
env=dict(os.environ,PYTHONPATH=str(repo),PYTHONDONTWRITEBYTECODE='1',COMSOL_MCP_TEST_ASCII_ROOT=str(root/'quality-ascii'),PYTEST_ADDOPTS='-o cache_dir='+str(root/'quality-pytest-cache'))
start=time.monotonic();p=subprocess.Popen(command,cwd=repo,env=env,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
timed=False
try:out,err=p.communicate(timeout=600)
except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=5)
finally:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
for suffix,data in [('stdout',out),('stderr',err)]:
    (root/'ci-local-results'/('quality_configured__'+suffix+'.log')).write_bytes(data)
receipt={'command':command,'returncode':p.returncode,'seconds':round(time.monotonic()-start,3),'outer_timeout':timed,'configured_ascii_root':env['COMSOL_MCP_TEST_ASCII_ROOT'],'uses_local_four_worker_main_and_serial_tail':True}
(root/'quality-configured-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
