import subprocess,json,os,time
from pathlib import Path
root=Path(__file__).resolve().parent
command=['node','--test','--test-reporter=spec']
started=time.monotonic()
r=subprocess.run(command,cwd='/workspace/COMSOL_MCP_debian_acceptance_c023ba9/dsh_bridge',capture_output=True,timeout=180)
for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
    (root/'ci-local-results'/('DSH__full_bridge__'+suffix+'.log')).write_bytes(data)
receipt={'command':command,'cwd':'/workspace/COMSOL_MCP_debian_acceptance_c023ba9/dsh_bridge','returncode':r.returncode,'seconds':round(time.monotonic()-started,3)}
(root/'DSH__full_bridge.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
