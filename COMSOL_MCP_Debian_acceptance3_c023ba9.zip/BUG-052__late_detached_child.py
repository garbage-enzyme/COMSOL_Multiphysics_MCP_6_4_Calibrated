"""Real owned fake worker: detach child after ready, exit before reset."""
import sys,os,json,subprocess,time,tempfile
from pathlib import Path
import psutil
repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9');sys.path.insert(0,str(repo))
from comsol_mcp.knowledge.semantic_process import SemanticWorkerManager
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(dir=root,prefix='late-detach-') as folder:
    folder=Path(folder);go=folder/'go';pidfile=folder/'child.json';child=None
    code=f'''import sys,os,time,json,subprocess,psutil
from pathlib import Path
print(json.dumps({{'schema_version':'1','event':'ready','pid':os.getpid(),'host':'127.0.0.1','port':9}}),flush=True)
deadline=time.monotonic()+10
while not Path({str(go)!r}).exists():
 if time.monotonic()>deadline:sys.exit(3)
 time.sleep(.01)
c=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
Path({str(pidfile)!r}).write_text(json.dumps({{'pid':c.pid,'created':psutil.Process(c.pid).create_time()}}))
sys.exit(0)
'''
    manager=SemanticWorkerManager(startup_deadline=3)
    manager._command=lambda:[sys.executable,'-c',code]
    try:
        started=manager.start();assert started['success'],started
        tracked_at_ready=dict(manager._posix_descendants);go.write_text('go')
        deadline=time.monotonic()+5
        while not pidfile.exists():
            if time.monotonic()>deadline:raise RuntimeError('child not created')
            time.sleep(.01)
        identity=json.loads(pidfile.read_text());child=psutil.Process(identity['pid'])
        assert child.create_time()==identity['created']
        manager._process.wait(timeout=3)
        reset=manager.reset();alive=child.is_running() and child.status()!=psutil.STATUS_ZOMBIE
        result={'target':str(repo),'startup':started,'tracked_at_ready':tracked_at_ready,'leader_exited_before_reset':True,'child_identity':identity,'child_group':os.getpgid(child.pid),'reset':reset,'owned_detached_child_alive_after_reset':alive,'passed':not alive and reset['reset']['absent'] is True,'solver_started':False}
        print(json.dumps(result,indent=2))
    finally:
        manager.reset()
        if child is not None and child.create_time()==identity['created'] and child.is_running():child.kill()
