from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent;repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
name='development_kit/tests/snapshots/full_tool_schemas.json'
before=json.loads(subprocess.check_output(['git','show','42f9e95:'+name],cwd=repo))
after=json.loads((repo/name).read_text())
def changes(a,b,p=''):
    if isinstance(a,dict) and isinstance(b,dict):
        result=[]
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:result.append({'path':p+'/'+k,'before':a.get(k),'after':b.get(k)})
            else:result+=changes(a[k],b[k],p+'/'+k)
        return result
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return [r for i,(x,y) in enumerate(zip(a,b)) for r in changes(x,y,p+'/'+str(i))]
    return [] if a==b else [{'path':p,'before':a,'after':b}]
diff=changes(before,after);maps=[r for r in diff if r['path'].endswith('/additionalProperties')]
assert all(r['before'] is False and r['after'] is True for r in maps)
other=[r for r in diff if r not in maps]
result={'tool_count':len(after),'differences':diff,'map_false_to_true_count':len(maps),'other_changes':other,'new_or_removed_tools':sorted(set(after)^set(before))}
(root/'schema-snapshot-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='differences'},indent=2))
