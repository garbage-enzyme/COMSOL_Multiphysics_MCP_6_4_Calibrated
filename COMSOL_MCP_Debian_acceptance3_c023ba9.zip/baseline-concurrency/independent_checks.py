"""Independent Debian behavioral probes; real local IO, no COMSOL execution.

Each case runs in a bounded fresh process. Scheduling hooks pause real calls at
specified boundaries; no persistence routine is replaced with fake storage.
"""
import argparse
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/COMSOL_MCP_debian_reacceptance_42f9e95')
sys.path.insert(0,str(REPO))
from comsol_mcp.durable import io as durable
from comsol_mcp.jobs import tasks_bridge as tasks
from comsol_mcp import operation_arbiter as operation

OPT_IN = {'io.modelcontextprotocol/tasks':{}}
checks = []
details = {}
def check(condition, name):
    checks.append({'check':name,'passed':bool(condition)})
def row(name, owner='owner-a'):
    return tasks.TaskRow(name,'job-'+name,1000,None,1000,'a'*64,owner)
def save(name, value):
    path = ROOT/'fixtures'/case
    path.mkdir(parents=True,exist_ok=True)
    if isinstance(value,bytes): (path/name).write_bytes(value)
    else: (path/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def rejected(call):
    try: return {'rejected':False,'result':call()}
    except (OSError,ValueError,tasks.TasksMappingError) as exc:
        return {'rejected':True,'exception':type(exc).__name__,
                'code':getattr(exc,'code',None),'message':str(exc)}

class Engine:
    """Only the solver engine is substituted; the production store is real."""
    def __init__(self, status='running'):
        self.state = status
        self.cancels = []
    def submit(self,_spec):
        return {'job_id':'job-fixed','status':self.state,'duplicate':True}
    def status(self,job):
        return {'job_id':job,'status':self.state,'attempt':3}
    def cancel(self,job,**kwargs):
        self.cancels.append((job,kwargs))
        return {'status':'cancel_requested'}

def cleanup_case(root,kind):
    parent = root/'parent'
    parent.mkdir()
    target = parent/'owned'
    foreign = root/'foreign'
    foreign.write_bytes(b'caller-owned')
    target.write_bytes(b'owned')
    identity = (target.stat().st_dev,target.stat().st_ino)
    if kind in {'fifo_identity','fifo_content'}:
        target.unlink()
        os.mkfifo(target)
        value = (durable.unlink_if_identity(target,identity) if kind=='fifo_identity'
                 else durable.unlink_if_content(target,b'owned'))
        details.update(returned=value,file_type=stat.S_IFMT(target.lstat().st_mode))
        check(value is False and stat.S_ISFIFO(target.lstat().st_mode),'FIFO preserved and refused')
    elif kind=='fifo_race':
        real_open = os.open
        changed = []
        def swap(candidate,flags,**kwargs):
            if candidate == target.name and 'dir_fd' in kwargs and not changed:
                target.unlink()
                os.mkfifo(target)
                changed.append(flags)
            return real_open(candidate,flags,**kwargs)
        with patch.object(durable.os,'open',swap):
            value = durable.unlink_if_identity(target,identity)
        details.update(returned=value,flags=changed)
        check(value is False and stat.S_ISFIFO(target.lstat().st_mode),'raced FIFO refused')
        check(bool(changed) and bool(changed[0]&os.O_NONBLOCK),'open was nonblocking before fstat')
    elif kind in {'leaf_link','parent_link'}:
        if kind=='leaf_link':
            target.unlink()
            target.symlink_to(foreign)
        else:
            alias = root/'alias'
            alias.symlink_to(parent,target_is_directory=True)
            target = alias/'owned'
        result = rejected(lambda:durable.unlink_if_identity(target,identity))
        details.update(result)
        check(result['rejected'] or result.get('result') is False,'link path rejected')
        check(foreign.read_bytes()==b'caller-owned','foreign target bytes preserved')
        if kind=='parent_link': check((parent/'owned').read_bytes()==b'owned','linked parent file preserved')
    elif kind=='ordinary':
        check(durable.unlink_if_identity(target,(identity[0],identity[1]+1)) is False,'wrong inode refused')
        check(target.read_bytes()==b'owned','wrong identity did not mutate file')
        check(durable.unlink_if_identity(target,identity) is True and not target.exists(),'owned regular file removed')
    elif kind=='replacement_race':
        def replace(_descriptor,_stat):
            foreign.replace(target)
            return True
        result = durable._posix_unlink_opened_file_if(target,replace)
        details.update(returned=result)
        check(result is False,'raced replacement not deleted')
        check(target.read_bytes()==b'caller-owned','raced replacement bytes restored')
    check(not list(parent.glob('.unlink-*')),'no quarantine residue')

def journal_case(root,kind):
    store = tasks.TasksMappingStore(root/'tasks')
    store.append(row('first'))
    prefix = store.journal_path.read_bytes()
    fragment = b'{"task_id":"interrupted'
    store.journal_path.write_bytes(prefix+fragment)
    save('BUG-004__before.jsonl',store.journal_path.read_bytes())
    check([r.task_id for r in store.rows()]==['first'],'partial tail preserves first row before append')
    if kind=='serial':
        store.append(row('second'))
        data = store.journal_path.read_bytes()
        save('BUG-004__after.jsonl',data)
        report = durable.read_complete_jsonl(store.journal_path)
        code = ('import json,sys; from comsol_mcp.jobs.tasks_bridge import TasksMappingStore; '
                'print(json.dumps([r.task_id for r in TasksMappingStore(sys.argv[1]).rows()]))')
        child = subprocess.run([sys.executable,'-c',code,str(store.root)],
                               capture_output=True,text=True,timeout=5,env=os.environ)
        details.update(state=report['state'],reopened_stdout=child.stdout,
                       reopened_stderr=child.stderr,rows=[r.task_id for r in store.rows()])
        check(data.startswith(prefix),'acknowledged prefix bytes preserved')
        check(fragment not in data and data.endswith(b'\n'),'only partial suffix discarded')
        check(report['state']=='current_valid','journal is valid after recovery')
        check(child.returncode==0 and json.loads(child.stdout)==['first','second'],'new process sees both durable mappings')
    elif kind=='concurrent':
        from concurrent_checks import journal_concurrent
        journal_concurrent(root,store,check,details,save)
    elif kind=='leaf_link':
        data = store.journal_path.read_bytes()
        external = root/'external.jsonl'
        external.write_bytes(data)
        store.journal_path.unlink()
        store.journal_path.symlink_to(external)
        result = rejected(lambda:store.append(row('second')))
        details.update(result)
        check(result['rejected'],'linked journal append refused')
        check(external.read_bytes()==data,'external journal bytes unchanged')
    elif kind=='corrupt_middle':
        data = prefix+b'not-json\n'+fragment
        store.journal_path.write_bytes(data)
        store.append(row('second'))
        after = store.journal_path.read_bytes()
        save('BUG-004__corrupt_before.jsonl',data)
        save('BUG-004__corrupt_after.jsonl',after)
        details.update(state=durable.read_complete_jsonl(store.journal_path)['state'])
        check(after.startswith(data),'corrupt evidence not silently truncated')
        # Diagnostic case only: existing policy returns no rows for full corruption.
        check(details['state']=='corrupt','full corrupt record not misclassified as recoverable tail')

def owner_case(root,kind):
    store = tasks.TasksMappingStore(root/'tasks')
    engine = Engine()
    a = tasks.TasksBridge(engine=engine,store=store,owner='owner-a',new_task_id=lambda:'task-a')
    b = tasks.TasksBridge(engine=engine,store=tasks.TasksMappingStore(store.root),owner='owner-b',new_task_id=lambda:'task-b')
    if kind=='serial':
        first = a.submit_task({'spec':{}},client_extensions=OPT_IN)
        before = store.journal_path.read_bytes()
        result = rejected(lambda:b.submit_task({'spec':{}},client_extensions=OPT_IN))
        details.update(result,first=first)
        check(result['rejected'] and result.get('code')=='task_owner_conflict','cross-owner duplicate refused with owner conflict')
        check(store.journal_path.read_bytes()==before,'conflict does not append or change mapping bytes')
        check(a.get_task('task-a')['status']=='working','original owner retains access')
        for method in (b.get_task,b.cancel_task):
            value = rejected(lambda:method('task-a'))
            check(value['rejected'] and value.get('code')=='task_not_found','other owner cannot read or cancel original task')
        retry = a.submit_task({'spec':{}},client_extensions=OPT_IN)
        check(retry['taskId']==first['taskId'],'same-owner retry reuses task ID')
        a.cancel_task('task-a')
        check(engine.cancels==[('job-fixed',{'expected_attempt':3})],'only legitimate owner cancellation reaches engine')
        save('BUG-005__mapping.jsonl',store.journal_path.read_bytes())
    elif kind=='concurrent':
        from concurrent_checks import owner_concurrent
        owner_concurrent(root,store,check,details,save)
    elif kind=='restart':
        a.submit_task({'spec':{}},client_extensions=OPT_IN)
        restarted = tasks.TasksBridge(engine=engine,store=tasks.TasksMappingStore(store.root),owner='owner-a')
        check(restarted.get_task('task-a')['status']=='working','fresh store preserves original owner access')
        result = rejected(lambda:b.submit_task({'spec':{}},client_extensions=OPT_IN))
        check(result.get('code')=='task_owner_conflict','owner conflict preserved after store reopen')

def operation_case(root,kind):
    runtime = root/'container'/'runtime' if kind=='ancestor_replacement' else root/'runtime'
    arbiter = operation.OperationArbiter(runtime)
    arbiter.runtime_root.mkdir(parents=True)
    target = arbiter.lock_path
    claim, receipt = arbiter.try_acquire(tool_name='test-operation',side_effect_class='read_only')
    check(claim is not None and receipt['state']=='acquired','regular operation claim acquired')
    payload = claim.lock_bytes
    if kind=='ordinary':
        details.update(inspect=arbiter.inspect(),release=arbiter.release(claim))
        check(details['inspect']['state']=='active','real current process identity observed active')
        check(details['release']=={'released':True,'verified':True} and not target.exists(),'exact claim released without residue')
        return
    target.unlink()
    external = root/'external'
    external.mkdir()
    external_file = external/'operation.lock'
    external_file.write_bytes(payload)
    if kind=='fifo': os.mkfifo(target)
    elif kind=='directory': target.mkdir()
    elif kind=='oversized': target.write_bytes(b'x'*(8*1024*1024))
    elif kind=='leaf_link': target.symlink_to(external_file)
    elif kind=='fifo_link':
        external_file.unlink()
        os.mkfifo(external_file)
        target.symlink_to(external_file)
    elif kind=='dangling_link': target.symlink_to(external/'absent')
    elif kind=='parent_replacement':
        arbiter.runtime_root.rmdir()
        arbiter.runtime_root.symlink_to(external,target_is_directory=True)
    elif kind=='ancestor_replacement':
        # The final parent remains a regular directory, while an earlier path
        # component is replaced with a link after the arbiter was constructed.
        container = root/'container'
        container.rename(root/'old-container')
        external_nested = external/'runtime'
        external_nested.mkdir()
        external_file.rename(external_nested/'operation.lock')
        external_file = external_nested/'operation.lock'
        container.symlink_to(external,target_is_directory=True)
        target = arbiter.lock_path
    elif kind=='publication_fifo':
        real_fsync = os.fsync
        raced = []
        def replace_after_fsync(fd):
            result = real_fsync(fd)
            if not raced:
                target.unlink()
                os.mkfifo(target)
                raced.append(True)
            return result
        with patch.object(operation.os,'fsync',replace_after_fsync):
            new_claim, result = arbiter.try_acquire(tool_name='new',side_effect_class='read_only')
        details.update(claim_returned=new_claim is not None,publication=result)
        check(new_claim is None and result['state']=='uncertain','publication raced FIFO refused without blocking')
        check(stat.S_ISFIFO(target.lstat().st_mode),'raced FIFO not removed')
        return
    reads = []
    real_fdopen = durable.os.fdopen
    def trace_fdopen(fd,*args,**kwargs):
        reads.append({'fd':fd})
        return real_fdopen(fd,*args,**kwargs)
    started = time.monotonic()
    with patch.object(durable.os,'fdopen',trace_fdopen):
        inspected = arbiter.inspect()
        acquired, acquisition = arbiter.try_acquire(tool_name='new',side_effect_class='read_only')
        try:
            release = arbiter.release(claim)
        except OSError as exc:
            release = {'released':False,'verified':False,
                       'uncaught_exception':type(exc).__name__,'message':str(exc)}
    details.update(inspect=inspected,claim_returned=acquired is not None,acquire=acquisition,
                   release=release,io_seconds=time.monotonic()-started,fdopen_read_handles=len(reads))
    if kind in {'parent_replacement','ancestor_replacement'}:
        details['foreign_lock_exists_after_release']=external_file.exists()
        check(inspected['state']=='uncertain','replaced parent link refused before accepting foreign lock')
        check(not release['released'] and external_file.exists(),'release does not delete through replaced parent link')
    else:
        check(inspected['state']=='uncertain','abnormal lock inspect is uncertain')
        check(acquired is None and acquisition['state']=='uncertain','abnormal lock acquisition refused')
        check(not release['released'] and not release['verified'],'abnormal lock not reported released')
        check(len(reads)==0,'abnormal file rejected before any buffered read')
        if kind in {'leaf_link','dangling_link','fifo_link'}: check(target.is_symlink(),'link retained')
        elif kind=='fifo': check(stat.S_ISFIFO(target.lstat().st_mode),'FIFO retained')
        elif kind=='oversized': check(target.stat().st_size==8*1024*1024,'oversized input retained')
        if kind!='fifo_link': check(external_file.read_bytes()==payload,'foreign target preserved')

CASES = {
 **{'BUG-002__'+name:('cleanup',name) for name in
    ['fifo_identity','fifo_content','fifo_race','leaf_link','parent_link','ordinary','replacement_race']},
 **{'BUG-004__'+name:('journal',name) for name in ['serial','concurrent','leaf_link','corrupt_middle']},
 **{'BUG-005__'+name:('owner',name) for name in ['serial','concurrent','restart']},
 **{'BUG-041__'+name:('operation',name) for name in
    ['ordinary','fifo','directory','oversized','leaf_link','fifo_link','dangling_link','parent_replacement','ancestor_replacement','publication_fifo']},
}

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case',choices=CASES)
    parser.add_argument('--writer',nargs=2)
    parser.add_argument('--owner-writer',nargs=2)
    args = parser.parse_args()
    if args.owner_writer:
        store = tasks.TasksMappingStore(args.owner_writer[0])
        bridge = tasks.TasksBridge(engine=Engine(),store=store,owner=args.owner_writer[1],
                                   new_task_id=lambda:'task-b')
        handle = bridge.submit_task({'spec':{}},client_extensions=OPT_IN)
        print(json.dumps({'handle':handle,'can_query':bridge.get_task(handle['taskId'])['status'],
                          'row_acknowledged':store.latest_for_task(handle['taskId']) is not None}))
        raise SystemExit(0)
    if args.writer:
        store = tasks.TasksMappingStore(args.writer[0])
        store.append(row(args.writer[1]))
        print(json.dumps({'acknowledged':store.latest_for_task(args.writer[1]) is not None,
                          'task_id':args.writer[1]}))
        raise SystemExit(0 if store.latest_for_task(args.writer[1]) is not None else 1)
    if args.case:
        case = args.case
        started = time.monotonic()
        try:
            check(Path(durable.__file__).resolve().is_relative_to(REPO),'actual production source is the pinned worktree')
            with tempfile.TemporaryDirectory(prefix=case+'-',dir=ROOT) as directory:
                group,kind = CASES[case]
                {'cleanup':cleanup_case,'journal':journal_case,'owner':owner_case,
                 'operation':operation_case}[group](Path(directory),kind)
        except Exception:
            details['unexpected_exception']=traceback.format_exc()
            check(False,'case completed without unexpected exception')
        result = {'case':case,'passed':all(c['passed'] for c in checks),'checks':checks,
                  'details':details,'seconds':round(time.monotonic()-started,6)}
        print(json.dumps(result,ensure_ascii=False,indent=2))
        raise SystemExit(0 if result['passed'] else 1)
    outcomes = []
    environment = dict(os.environ,PYTHONPATH=str(REPO),PYTHONDONTWRITEBYTECODE='1')
    for case in CASES:
        command = [sys.executable,__file__,'--case',case]
        process = subprocess.Popen(command,cwd=ROOT,env=environment,start_new_session=True,
                                   stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        timed_out = False
        try: stdout,stderr = process.communicate(timeout=12)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid,signal.SIGKILL)
            stdout,stderr = process.communicate(timeout=5)
        finally:
            try: os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError: pass
        folder = ROOT/'independent-results'
        folder.mkdir(exist_ok=True)
        (folder/(case+'__stdout.log')).write_bytes(stdout)
        (folder/(case+'__stderr.log')).write_bytes(stderr)
        outcome = {'case':case,'returncode':process.returncode,'outer_timeout':timed_out,
                   'result':json.loads(stdout) if stdout.strip() and not timed_out else None}
        outcomes.append(outcome)
        print(json.dumps({'case':case,'returncode':process.returncode,'timeout':timed_out,
                          'passed':outcome['result'].get('passed') if outcome['result'] else None}),flush=True)
    (ROOT/'independent-results.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2)+'\n')
