"""Non-deadlocking cross-process acceptance of the new mapping transaction."""
import json,os,subprocess,sys,time
from pathlib import Path
from unittest.mock import patch
from comsol_mcp.jobs import tasks_bridge as tasks

def row(name):return tasks.TaskRow(name,'job-'+name,1000,None,1000,'a'*64,'owner-a')
class Engine:
    def submit(self,spec):return {'job_id':'job-fixed','status':'running','duplicate':True}
    def status(self,job):return {'job_id':job,'status':'running','attempt':3}
    def cancel(self,job,**kwargs):return {'status':'cancel_requested'}
OPT_IN={'io.modelcontextprotocol/tasks':{}}
def start_b(root,mode):
    p=subprocess.Popen([sys.executable,__file__,'--child',mode,str(root)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=os.environ)
    deadline=time.monotonic()+3
    while not (root/'B-entered').exists():
        if p.poll() is not None or time.monotonic()>deadline:raise RuntimeError('B did not enter independent process')
        time.sleep(.01)
    time.sleep(.15)
    return p
def finish(p,details):
    try:out,err=p.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        p.kill();out,err=p.communicate();raise
    details['B_receipt']={'returncode':p.returncode,'stdout':out.decode(),'stderr':err.decode()}
    return json.loads(out)
def journal_concurrent(root,store,check,details,save):
    real=tasks.read_complete_jsonl;child=None;entered=False
    def pause(path,**kw):
        nonlocal child,entered
        report=real(path,**kw)
        if not entered and report['state']=='incomplete':
            entered=True;child=start_b(store.root,'tail')
            check(child.poll() is None,'B cannot acknowledge while A holds recovery transaction')
            save('BUG-004__snapshot_while_A_locked.jsonl',store.journal_path.read_bytes())
        return report
    try:
        with patch.object(tasks,'read_complete_jsonl',pause):store.append(row('A'))
        ack=finish(child,details)
        ids=[r.task_id for r in tasks.TasksMappingStore(store.root).rows()]
        details['rows']=ids
        check(ack.get('acknowledged') is True,'B acknowledged its persisted row after A released transaction')
        check(ids==['first','A','B'],'recovery preserves prefix and both acknowledged rows')
        save('BUG-004__concurrent_final.jsonl',store.journal_path.read_bytes())
    finally:
        if child and child.poll() is None:child.kill();child.communicate()
def owner_concurrent(root,store,check,details,save):
    a=tasks.TasksBridge(engine=Engine(),store=store,owner='owner-a',new_task_id=lambda:'task-a')
    real=store.latest_for_job;child=None;entered=False
    def pause(job):
        nonlocal child,entered
        result=real(job)
        if not entered:
            entered=True;child=start_b(store.root,'owner')
            check(child.poll() is None,'B cannot admit owner while A holds lookup/admission transaction')
        return result
    try:
        with patch.object(store,'latest_for_job',pause):first=a.submit_task({'spec':{}},client_extensions=OPT_IN)
        result=finish(child,details)
        rows=store.rows();details.update(first=first,rows=[r.to_document() for r in rows])
        check(result.get('code')=='task_owner_conflict' and not result.get('acknowledged'),'B refuses cross-owner binding after A commits')
        check({r.owner for r in rows if r.job_id=='job-fixed'}=={'owner-a'},'one job has one acknowledged owner')
        check(a.get_task('task-a')['status']=='working','A keeps query access')
        save('BUG-005__concurrent_final.jsonl',store.journal_path.read_bytes())
    finally:
        if child and child.poll() is None:child.kill();child.communicate()
if __name__=='__main__':
    mode,root=sys.argv[2],Path(sys.argv[3]);store=tasks.TasksMappingStore(root)
    root.mkdir(parents=True,exist_ok=True);(root/'B-entered').write_text(str(os.getpid()))
    if mode=='tail':
        store.append(row('B'));result={'acknowledged':store.latest_for_task('B') is not None}
    else:
        b=tasks.TasksBridge(engine=Engine(),store=store,owner='owner-b',new_task_id=lambda:'task-b')
        try:result={'acknowledged':True,'handle':b.submit_task({'spec':{}},client_extensions=OPT_IN)}
        except tasks.TasksMappingError as e:result={'acknowledged':False,'code':e.code}
    print(json.dumps(result))
