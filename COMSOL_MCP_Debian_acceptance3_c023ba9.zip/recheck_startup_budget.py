import subprocess,os,sys,time,json
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for label,repo in [('previous','/workspace/COMSOL_MCP_debian_reacceptance_42f9e95'),('target','/workspace/COMSOL_MCP_debian_acceptance_c023ba9')]:
    command=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','development_kit/tests/test_control_plane_startup.py','--basetemp',str(root/(label+'-startup-budget-temp'))]
    env=dict(os.environ,PYTHONPATH=repo,PYTHONDONTWRITEBYTECODE='1',COMSOL_MCP_TEST_ASCII_ROOT=str(root/(label+'-startup-ascii')))
    start=time.monotonic();r=subprocess.run(command,cwd=repo,env=env,capture_output=True,timeout=90)
    for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
        (root/'ci-local-results'/('startup_budget_'+label+'__'+suffix+'.log')).write_bytes(data)
    row={'label':label,'repository':repo,'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)}
    results.append(row);print(json.dumps(row),flush=True)
(root/'startup-budget-recheck.json').write_text(json.dumps(results,indent=2)+'\n')
