"""Compare every real advertised schema against frozen snapshots without edits."""
import asyncio
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
sys.path.insert(0,str(REPO))
from comsol_mcp.server import create_server
from comsol_mcp.tools.catalog import snapshot_tool_schemas
from comsol_mcp.tools.profiles import resolve_profile
selection=resolve_profile('full',environ={'COMSOL_MCP_ENABLE_LEXICAL_DOCS':'true',
    'COMSOL_MCP_ENABLE_SEMANTIC_DOCS':'true','COMSOL_MCP_ENABLE_SHARED_SERVER':'true'})
actual=asyncio.run(snapshot_tool_schemas(create_server('acceptance-schema-probe',profile=selection)))
expected=json.loads((REPO/'development_kit/tests/snapshots/full_tool_schemas.json').read_text())
def differences(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        result=[]
        for key in sorted(set(a)|set(b)):
            if key not in a or key not in b:
                result.append({'path':path+'/'+key,'snapshot':a.get(key),'actual':b.get(key)})
            else: result+=differences(a[key],b[key],path+'/'+key)
        return result
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [item for i,(x,y) in enumerate(zip(a,b)) for item in differences(x,y,path+'/'+str(i))]
    return [] if a==b else [{'path':path,'snapshot':a,'actual':b}]
diff={name:differences(expected[name],actual[name]) for name in actual if expected[name]!=actual[name]}
receipt={'registered_tool_count':len(actual),'differing_tools':len(diff),'differences':diff,
         'every_difference_is_additionalProperties':all(d['path'].endswith('/additionalProperties') for ds in diff.values() for d in ds),
         'actual_source':str(REPO),'solver_started':False,
         'interpretation':'The structural map-preservation fix changes advertised schemas; frozen current schemas and compatibility expectations were not updated.'}
(ROOT/'CI__BUG-031__schema_actual.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n')
(ROOT/'CI__BUG-031__schema_comparison.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'registered_tool_count':len(actual),'differing_tools':len(diff),
                  'every_difference_is_additionalProperties':receipt['every_difference_is_additionalProperties'],
                  'sample':dict(list(diff.items())[:3])},ensure_ascii=False,indent=2))
