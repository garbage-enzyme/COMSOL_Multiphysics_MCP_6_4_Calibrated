import os,sys,json,copy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9');sys.path.insert(0,str(repo))
from comsol_mcp.shared_session.solver_owners import SolverOwnerRegistry,OwnerAdmissionError
from comsol_mcp.shared_session import process_probe
from comsol_mcp.settings import default_settings_document,normalize_settings_document,serialize_settings_document
root=Path(__file__).resolve().parent
results=[]
for value,label in [(float('nan'),'nan'),(float('inf'),'inf'),(float('-inf'),'-inf'),(10**1000,'oversized_int')]:
    registry=SolverOwnerRegistry();rejected=False
    try:registry.register(owner='owner',cores=1,process_id=123,process_create_time=value,lease_sha256='a'*64,session_id='session')
    except OwnerAdmissionError:rejected=True
    results.append({'bug':'BUG-061','input':label,'rejected':rejected,'registry_remains_empty':registry.owner_count()==0,'passed':rejected and registry.owner_count()==0})
for pid,address in [(None,SimpleNamespace(ip='127.0.0.1',port=2036)),(123,SimpleNamespace())]:
    connection=SimpleNamespace(status=process_probe.psutil.CONN_LISTEN,pid=pid,laddr=address)
    with patch.object(process_probe.psutil,'net_connections',return_value=[connection]):records,complete=process_probe._listener_records()
    results.append({'bug':'BUG-062','unknown_pid':pid is None,'records':records,'complete':complete,'passed':records==[] and complete is False})
doc=default_settings_document(environ={'HOME':str(root)},user_root=root/'models',program_root=root/'state')
doc['paths']['model_read_roots']=[str(root/'模型')]
for key in ['XDG_DATA_HOME','XDG_STATE_HOME']:
    environment={'HOME':str(root),key:str(root/'用户')}
    report=normalize_settings_document(doc,environ=environment)
    with patch.dict(os.environ,{key:environment[key]}):serialized=json.loads(serialize_settings_document(doc))
    results.append({'bug':'BUG-167','key':key,'errors':report['errors'],'runtime_preserved':report['settings']['runtime']==doc['runtime'],'paths_preserved':serialized['paths']==doc['paths'],'passed':not report['errors'] and serialized['paths']==doc['paths']})
receipt={'checks':results,'passed':all(r['passed'] for r in results),'solver_started':False}
(root/'BUG-061-062-167__linux_contracts.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
