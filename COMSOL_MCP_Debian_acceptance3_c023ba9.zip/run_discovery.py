import subprocess,os,sys,json,time
from pathlib import Path
root=Path(__file__).resolve().parent
cmd=[sys.executable,str(root/'BUG-190-191__debian_discovery.py')]
start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=90,env=dict(os.environ,PYTHONPATH='/workspace/COMSOL_MCP_debian_acceptance_c023ba9',PYTHONDONTWRITEBYTECODE='1'))
for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
    (root/'ci-local-results'/('BUG-190-191__stdio_discovery__'+suffix+'.log')).write_bytes(data)
if r.returncode==0:(root/'BUG-190-191__stdio_discovery.json').write_bytes(r.stdout)
receipt={'command':cmd,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)}
(root/'stdio-discovery-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
