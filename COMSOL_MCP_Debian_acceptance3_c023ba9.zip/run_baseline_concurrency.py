from pathlib import Path
import subprocess,os,sys,json,time
root=Path(__file__).resolve().parent;folder=root/'baseline-concurrency';folder.mkdir(exist_ok=True)
repo='/workspace/COMSOL_MCP_debian_reacceptance_42f9e95'
(folder/'independent_checks.py').write_text((root/'independent_checks.py').read_text().replace('/workspace/COMSOL_MCP_debian_acceptance_c023ba9',repo))
(folder/'concurrent_checks.py').write_bytes((root/'concurrent_checks.py').read_bytes())
results=[]
for case in ['BUG-004__concurrent','BUG-005__concurrent']:
    command=[sys.executable,str(folder/'independent_checks.py'),'--case',case]
    r=subprocess.run(command,capture_output=True,timeout=15,env=dict(os.environ,PYTHONPATH=repo,PYTHONDONTWRITEBYTECODE='1'))
    for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
        (folder/(case+'__'+suffix+'.log')).write_bytes(data)
    result={'case':case,'returncode':r.returncode,'result':json.loads(r.stdout)}
    results.append(result);print(json.dumps({'case':case,'returncode':r.returncode,'passed':result['result']['passed']}))
(root/'baseline-concurrency-results.json').write_text(json.dumps(results,indent=2)+'\n')
