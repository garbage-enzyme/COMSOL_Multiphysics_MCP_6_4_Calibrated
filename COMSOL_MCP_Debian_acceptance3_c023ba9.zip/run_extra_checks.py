import subprocess,os,sys,time,json,signal
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
env=dict(os.environ,PYTHONPATH=str(repo),PYTHONDONTWRITEBYTECODE='1',COMSOL_MCP_TEST_ASCII_ROOT=str(root/'extra-ascii'))
jobs=[('BUG-052__late_detached_child',[sys.executable,str(root/'BUG-052__late_detached_child.py')],30),
 ('linux_and_contract_focused',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',
 'development_kit/tests/test_adjoint_optimization.py','development_kit/tests/test_semantic_worker_protocol.py',
 'development_kit/tests/test_settings.py','development_kit/tests/test_shared_session_preflight.py','development_kit/tests/test_solver_owners.py',
 'development_kit/tests/test_surrogate_public_tools.py','development_kit/tests/test_surrogate_registry.py','development_kit/tests/test_surrogate_training_job.py',
 'development_kit/tests/test_thermal_material.py','development_kit/tests/test_thermal_radiation.py','development_kit/tests/test_integration_boundaries.py',
 '--basetemp',str(root/'extra-temp')],180),
 ('DSH__linux_plugin_tests',['node','--test','--test-reporter=spec','dsh_bridge/tests/plugin.test.mjs'],120)]
outcomes=[]
for name,command,bound in jobs:
    started=time.monotonic();p=subprocess.Popen(command,cwd=repo,env=env,start_new_session=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed=False
    try:out,err=p.communicate(timeout=bound)
    except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=5)
    finally:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
    for suffix,data in [('stdout',out),('stderr',err)]:
        (root/'ci-local-results'/f'{name}__{suffix}.log').write_bytes(data)
    if name.startswith('BUG-052') and p.returncode==0:
        (root/'BUG-052__late_detached_child.json').write_bytes(out)
    r={'name':name,'command':command,'returncode':p.returncode,'seconds':round(time.monotonic()-started,3),'outer_timeout':timed}
    outcomes.append(r);print(json.dumps(r),flush=True)
    (root/'extra-check-results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
