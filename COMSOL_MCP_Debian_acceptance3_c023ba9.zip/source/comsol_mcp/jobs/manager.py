"""Solver-free reference-power control plane for durable job submission and reconciliation."""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Protocol

import psutil

from .adjoint_optimization import expand_adjoint_optimization_manifest
from .attached_backend import normalize_attached_execution_backend
from .branch_continuation_campaign import normalize_branch_continuation_campaign_spec
from .convergence_campaign import normalize_convergence_campaign_spec
from .process_control import inspect_identity
from .resource_admission import normalize_resource_policy
from .robust_shape_optimization import expand_robust_shape_manifest
from .spectral_characterization import normalize_spectral_characterization_job_spec
from .store import (
    ACTIVE_STATES,
    JOB_SCHEMA_VERSION,
    TERMINAL_STATES,
    TRANSITIONS,
    JobLock,
    JobStore,
    atomic_write_json,
    cancel_request_targets_attempt,
    process_identity,
    process_identity_state,
    read_json,
)
from .surrogate_training import normalize_surrogate_training_spec
from .thermo_optomechanical_replay import normalize_thermo_optomechanical_replay_spec
from .validation_matrix import normalize_validation_matrix_spec


class _PollableProcess(Protocol):
    def poll(self) -> int | None: ...


def _wait_for_launched_identity(process: subprocess.Popen, command: list[str]) -> dict[str, Any]:
    expected = hashlib.sha256("\0".join(command).encode("utf-8", errors="replace")).hexdigest()
    deadline = time.monotonic() + 2.0
    while process.poll() is None:
        try:
            observed = process_identity(process.pid)
            if observed["pid"] == process.pid and observed["command_signature"] == expected:
                return observed
        except psutil.NoSuchProcess, psutil.ZombieProcess, OSError:
            pass
        if time.monotonic() >= deadline:
            break
        time.sleep(0.01)
    raise RuntimeError("Launched watchdog identity could not be verified before the deadline")


logger = logging.getLogger(__name__)

_DETACHED_PROCESS_LOCK = threading.Lock()
_DETACHED_PROCESS_WAKE = threading.Event()
_DETACHED_PROCESSES: set[_PollableProcess] = set()


class JobLaunchError(RuntimeError):
    """Bind a failed worker launch to the durable job that records its state."""

    def __init__(
        self,
        job_id: str,
        cause: Exception,
        *,
        state_record_error: Exception | None = None,
    ):
        super().__init__(str(cause))
        self.job_id = job_id
        self.cause_type = type(cause).__name__
        self.state_record_error = (
            None
            if state_record_error is None
            else f"{type(state_record_error).__name__}: {state_record_error}"
        )


_DETACHED_REAPER_STARTED = False


def _reap_detached_processes_once() -> int:
    """Reap completed detached children without waiting for active jobs."""
    with _DETACHED_PROCESS_LOCK:
        completed = []
        for process in _DETACHED_PROCESSES:
            try:
                if process.poll() is not None:
                    completed.append(process)
            except Exception:
                completed.append(process)
        _DETACHED_PROCESSES.difference_update(completed)
        return len(completed)


def _detached_process_reaper() -> None:
    while True:
        _DETACHED_PROCESS_WAKE.wait()
        _reap_detached_processes_once()
        with _DETACHED_PROCESS_LOCK:
            active = bool(_DETACHED_PROCESSES)
            if not active:
                _DETACHED_PROCESS_WAKE.clear()
        if active:
            time.sleep(0.05)


def _track_detached_process(process: _PollableProcess) -> None:
    """Retain and asynchronously reap a detached child's parent-side handle."""
    global _DETACHED_REAPER_STARTED
    with _DETACHED_PROCESS_LOCK:
        _DETACHED_PROCESSES.add(process)
        if not _DETACHED_REAPER_STARTED:
            threading.Thread(
                target=_detached_process_reaper,
                name="comsol-detached-process-reaper",
                daemon=True,
            ).start()
            _DETACHED_REAPER_STARTED = True
    _DETACHED_PROCESS_WAKE.set()


def _fingerprint(value: dict[str, Any]) -> str:
    canonical = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def validate_staged_sweep_spec(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("Job specification must be an object")
    spec = dict(raw)
    allowed = {
        "job_type",
        "source_model_path",
        "parameter_name",
        "parameter_values",
        "expressions",
        "parameter_unit",
        "study_name",
        "study_step_tag",
        "study_step_property",
        "study_step_unit",
        "study_step_unit_property",
        "physical_bounds",
        "max_retries",
        "continue_on_error",
        "checkpoint_every",
        "cores",
        "version",
        "smoke_points",
        "record_wavelength_controls",
        "strict_wavelength_policy",
        "resource_policy",
        "execution_backend",
    }
    unknown = sorted(set(spec) - allowed)
    if unknown:
        raise ValueError(f"Unsupported staged_sweep fields: {unknown}")
    if spec.get("job_type") != "staged_sweep":
        raise ValueError("Production jobs require job_type='staged_sweep'")
    if spec.get("strict_wavelength_policy") is not None:
        from comsol_mcp.strict_wavelength import normalize_policy, requested_metres

        spec["strict_wavelength_policy"] = normalize_policy(spec["strict_wavelength_policy"])
        if spec.get("parameter_name") not in {"wl", "wavelength"}:
            raise ValueError("strict wavelength mode requires a wavelength parameter")
        if not spec.get("study_name") or not spec.get("study_step_tag"):
            raise ValueError("strict wavelength mode requires study and step tags")
        if spec.get("record_wavelength_controls") is False:
            raise ValueError("strict wavelength mode requires recorded controls")
        if (
            spec.get("study_step_property", "plist") != "plist"
            or spec.get("study_step_unit_property", "punit") != "punit"
        ):
            raise ValueError("strict wavelength mode requires plist and punit controls")
        for value in spec.get("parameter_values", []):
            requested_metres(value, spec.get("parameter_unit"))
    required_strings = ("source_model_path", "parameter_name")
    for key in required_strings:
        if not isinstance(spec.get(key), str) or not spec[key].strip():
            raise ValueError(f"{key} must be a nonempty string")
    source = Path(spec["source_model_path"]).expanduser().resolve()
    if not source.is_file() or source.suffix.casefold() != ".mph":
        raise ValueError("source_model_path must name an existing MPH file")
    values = spec.get("parameter_values")
    if not isinstance(values, list) or not values:
        raise ValueError("parameter_values must be a nonempty list")
    for value in values:
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
        ):
            raise ValueError("parameter_values must contain only finite numbers")
    expressions = spec.get("expressions")
    if (
        not isinstance(expressions, list)
        or not expressions
        or not all(isinstance(item, str) and item.strip() for item in expressions)
    ):
        raise ValueError("expressions must be a nonempty string list")
    if len(set(expressions)) != len(expressions):
        raise ValueError("expressions must not contain duplicates")
    smoke_points = spec.get("smoke_points", 1)
    if smoke_points not in (1, 2) or smoke_points > len(values):
        raise ValueError("smoke_points must be 1 or 2 and no larger than the sweep")
    for key in ("max_retries",):
        value = spec.get(key, 0)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{key} must be a non-negative integer")
    checkpoint_every = spec.get("checkpoint_every", 1)
    if (
        isinstance(checkpoint_every, bool)
        or not isinstance(checkpoint_every, int)
        or checkpoint_every < 1
    ):
        raise ValueError("checkpoint_every must be a positive integer")
    cores = spec.get("cores")
    if cores is not None and (isinstance(cores, bool) or not isinstance(cores, int) or cores < 1):
        raise ValueError("cores must be a positive integer")
    for key in (
        "parameter_unit",
        "study_name",
        "study_step_tag",
        "study_step_property",
        "study_step_unit",
        "study_step_unit_property",
        "version",
    ):
        if key in spec and spec[key] is not None and not isinstance(spec[key], str):
            raise ValueError(f"{key} must be a string when provided")
    bounds = spec.get("physical_bounds")
    if bounds is not None:
        if not isinstance(bounds, dict):
            raise ValueError("physical_bounds must be an expression-to-[minimum, maximum] object")
        for expression, limits in bounds.items():
            if (
                expression not in expressions
                or not isinstance(limits, (list, tuple))
                or len(limits) != 2
            ):
                raise ValueError(
                    "physical_bounds keys must be requested expressions with two limits"
                )
            if any(
                isinstance(item, bool)
                or not isinstance(item, (int, float))
                or not math.isfinite(float(item))
                for item in limits
            ):
                raise ValueError("physical_bounds limits must be finite numbers")
            if float(limits[0]) > float(limits[1]):
                raise ValueError("physical_bounds minimum must not exceed maximum")
    if "resource_policy" in spec:
        normalized_policy = normalize_resource_policy(spec["resource_policy"])
        if normalized_policy is None:
            spec.pop("resource_policy")
        else:
            spec["resource_policy"] = normalized_policy
    spec["source_model_path"] = str(source)
    digest = hashlib.sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    spec["source_model_sha256"] = digest.hexdigest()
    if "execution_backend" in spec:
        spec["execution_backend"] = normalize_attached_execution_backend(spec["execution_backend"])
    spec["smoke_points"] = smoke_points
    spec["schema_version"] = JOB_SCHEMA_VERSION
    spec["spec_fingerprint"] = _fingerprint(
        {k: v for k, v in spec.items() if k != "spec_fingerprint"}
    )
    return spec


def _validate_test_spec(raw: dict[str, Any]) -> dict[str, Any]:
    spec = dict(raw)
    if spec.get("job_type") != "test_sequence":
        raise ValueError("Injected test manager accepts only job_type='test_sequence'")
    delays = spec.get("delays", [0.05])
    if (
        not isinstance(delays, list)
        or not delays
        or any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
            or float(value) < 0
            or float(value) > 30
            for value in delays
        )
    ):
        raise ValueError("test_sequence delays must be finite values between 0 and 30 seconds")
    spec = {"job_type": "test_sequence", "delays": [float(value) for value in delays]}
    spec["schema_version"] = JOB_SCHEMA_VERSION
    spec["spec_fingerprint"] = _fingerprint(spec)
    return spec


def _worker_module(job_type: str) -> str:
    modules = {
        "test_sequence": "comsol_mcp.jobs.sequence_worker",
        "staged_sweep": "comsol_mcp.jobs.worker",
        "validation_matrix": "comsol_mcp.jobs.validation_worker",
        "spectral_characterization": "comsol_mcp.jobs.spectral_worker",
        "convergence_campaign": "comsol_mcp.jobs.convergence_campaign_worker",
        "branch_continuation_campaign": "comsol_mcp.jobs.branch_continuation_campaign_worker",
        "thermo_optomechanical_replay": "comsol_mcp.jobs.thermo_optomechanical_replay_worker",
        "adjoint_optimization": "comsol_mcp.jobs.adjoint_optimization_worker",
        "robust_shape_optimization": "comsol_mcp.jobs.robust_shape_worker",
        "surrogate_training": "comsol_mcp.jobs.surrogate_training_worker",
    }
    try:
        return modules[job_type]
    except KeyError as exc:
        raise ValueError(f"Unsupported durable job type: {job_type}") from exc


def _point_count(spec: dict[str, Any]) -> int:
    if spec["job_type"] == "test_sequence":
        return len(spec["delays"])
    if spec["job_type"] == "validation_matrix":
        return len(spec["points"])
    if spec["job_type"] == "spectral_characterization":
        return int(spec["maximum_points"])
    if spec["job_type"] == "convergence_campaign":
        return int(spec["maximum_total_points"])
    if spec["job_type"] == "branch_continuation_campaign":
        return int(spec["maximum_total_points"])
    if spec["job_type"] == "thermo_optomechanical_replay":
        return int(spec["declared_stage_count"])
    if spec["job_type"] == "adjoint_optimization":
        return int(spec["optimizer"]["budget"]["max_iterations"])
    if spec["job_type"] == "robust_shape_optimization":
        return len(
            [
                row
                for row in spec["condition_table"]["conditions"]
                if row["active"] and row["objective_role"] == "objective"
            ]
        )
    if spec["job_type"] == "surrogate_training":
        return int(spec["maximum_epochs"])
    return len(spec["parameter_values"])


class JobManager:
    """Persist and reconcile jobs without importing or starting COMSOL."""

    def __init__(
        self,
        root: str | Path | None = None,
        *,
        allow_test_jobs: bool = False,
        preflight: Callable[..., dict[str, Any]] | None = None,
        cancel_grace_seconds: float = 10.0,
        cancel_terminate_seconds: float = 5.0,
        reconcile_on_start: bool = True,
    ):
        self.store = JobStore(root)
        self.allow_test_jobs = bool(allow_test_jobs)
        self._preflight = preflight
        self.cancel_grace_seconds = float(cancel_grace_seconds)
        self.cancel_terminate_seconds = float(cancel_terminate_seconds)
        if reconcile_on_start:
            self.reconcile_cancellations()

    def submit(self, raw_spec: dict[str, Any]) -> dict[str, Any]:
        job_type = raw_spec.get("job_type") if isinstance(raw_spec, dict) else None
        if job_type == "test_sequence":
            if not self.allow_test_jobs:
                raise ValueError("test_sequence jobs are disabled")
            spec = _validate_test_spec(raw_spec)
        elif job_type == "validation_matrix":
            spec = normalize_validation_matrix_spec(raw_spec)
        elif job_type == "spectral_characterization":
            spec = normalize_spectral_characterization_job_spec(raw_spec)
        elif job_type == "convergence_campaign":
            spec = normalize_convergence_campaign_spec(raw_spec)
        elif job_type == "branch_continuation_campaign":
            spec = normalize_branch_continuation_campaign_spec(raw_spec)
        elif job_type == "thermo_optomechanical_replay":
            spec = normalize_thermo_optomechanical_replay_spec(raw_spec)
        elif job_type == "adjoint_optimization":
            spec = expand_adjoint_optimization_manifest(raw_spec)
        elif job_type == "robust_shape_optimization":
            spec = expand_robust_shape_manifest(raw_spec)
        elif job_type == "surrogate_training":
            spec = normalize_surrogate_training_spec(raw_spec)
        else:
            spec = validate_staged_sweep_spec(raw_spec)
        worker_module = _worker_module(spec["job_type"])
        duplicate_job_types = {
            "validation_matrix",
            "spectral_characterization",
            "convergence_campaign",
            "branch_continuation_campaign",
            "thermo_optomechanical_replay",
            "adjoint_optimization",
            "robust_shape_optimization",
            "surrogate_training",
        }
        if spec["job_type"] in duplicate_job_types:
            with JobLock(self.store.root / ".submit.lock"):
                duplicate = self._find_exact_duplicate(spec["job_type"], spec["spec_fingerprint"])
                if duplicate is not None:
                    existing_state = self.store.read_state(duplicate)
                    return {
                        "success": True,
                        "job_id": duplicate,
                        "status": existing_state["status"],
                        "duplicate": True,
                        "action": (
                            "resume_existing"
                            if existing_state["status"] in {"failed", "interrupted", "cancelled"}
                            else "observe_existing"
                        ),
                    }
        if spec["job_type"] != "test_sequence":
            preflight = self._run_preflight(spec)
            if not preflight.get("ready", preflight.get("success", False)):
                raise RuntimeError(
                    f"Job preflight failed: {preflight.get('blockers') or preflight}"
                )
        now = time.time()
        total_points = _point_count(spec)
        state = {
            "schema_version": JOB_SCHEMA_VERSION,
            "status": "submitted",
            "attempt": 1,
            "created_at_epoch": now,
            "updated_at_epoch": now,
            "worker_pid": None,
            "worker_process_create_time": None,
            "worker_command_signature": None,
            "progress": {"completed": 0, "total": total_points},
            "last_error": None,
        }
        if spec["job_type"] in duplicate_job_types:
            with JobLock(self.store.root / ".submit.lock"):
                duplicate = self._find_exact_duplicate(spec["job_type"], spec["spec_fingerprint"])
                if duplicate is not None:
                    existing_state = self.store.read_state(duplicate)
                    return {
                        "success": True,
                        "job_id": duplicate,
                        "status": existing_state["status"],
                        "duplicate": True,
                        "action": (
                            "resume_existing"
                            if existing_state["status"] in {"failed", "interrupted", "cancelled"}
                            else "observe_existing"
                        ),
                    }
                job_id = self.store.create(spec, state)
        else:
            job_id = self.store.create(spec, state)
        try:
            self.store.append_event(
                job_id,
                "submitted",
                {"spec_fingerprint": spec["spec_fingerprint"]},
            )
            identity = self._launch_worker(job_id, worker_module)
            self.store.bind_worker_identity(job_id, identity)
        except Exception as exc:
            state_record_error = None
            try:
                self.store.update_state(
                    job_id,
                    "failed",
                    patch={
                        "last_error": {
                            "type": type(exc).__name__,
                            "message": str(exc),
                        }
                    },
                    event="launch_failed",
                )
            except Exception as record_exc:
                state_record_error = record_exc
            raise JobLaunchError(
                job_id,
                exc,
                state_record_error=state_record_error,
            ) from exc
        try:
            self._arm_robust_wall_watchdog_if_required(
                job_id,
                spec,
                attempt=1,
                worker_identity=identity,
            )
        except Exception as exc:
            cancellation = self.cancel(job_id, expected_attempt=1)
            raise JobLaunchError(
                job_id,
                RuntimeError(
                    "Licensed robust wall watchdog could not be armed; "
                    f"exact-attempt cancellation result: {cancellation}"
                ),
            ) from exc
        return {"success": True, "job_id": job_id, "status": "submitted"}

    def _find_validation_duplicate(self, spec_fingerprint: str) -> str | None:
        return self._find_exact_duplicate("validation_matrix", spec_fingerprint)

    def _find_exact_duplicate(self, job_type: str, spec_fingerprint: str) -> str | None:
        directories = sorted(
            path
            for path in self.store.root.iterdir()
            if path.is_dir() and path.name.startswith("job-") and (path / "spec.json").is_file()
        )
        if len(directories) > 1000:
            raise RuntimeError("Durable job root exceeds the duplicate-scan bound")
        for directory in directories:
            existing = read_json(directory / "spec.json")
            if (
                existing.get("job_type") == job_type
                and existing.get("spec_fingerprint") == spec_fingerprint
            ):
                return directory.name
        return None

    def _run_preflight(self, spec: dict[str, Any]) -> dict[str, Any]:
        if spec.get("job_type") == "surrogate_training":
            # A surrogate-training submission is bound to dataset and split
            # identities rather than a single MPH source, so it must not be
            # forced through the model-path preflight.  A caller-supplied
            # preflight still takes precedence when one is installed.
            if self._preflight is not None:
                return self._preflight(
                    model_path=None,
                    output_path=str(self.store.root / "probe"),
                    requested_version=None,
                    execution_backend=None,
                )
            return self._preflight_surrogate_training(spec)
        model_path = (
            spec["levels"][0]["spectral_job"]["source_model_path"]
            if spec.get("job_type") == "convergence_campaign"
            else spec["states"][0]["spectral_job"]["source_model_path"]
            if spec.get("job_type") == "branch_continuation_campaign"
            else spec["source_model_path"]
        )
        requested_version = (
            spec["levels"][0]["spectral_job"].get("version")
            if spec.get("job_type") == "convergence_campaign"
            else spec["states"][0]["spectral_job"].get("version")
            if spec.get("job_type") == "branch_continuation_campaign"
            else spec.get("version")
        )
        execution_backend = spec.get("execution_backend")
        if self._preflight is not None:
            return self._preflight(
                model_path=model_path,
                output_path=str(self.store.root / "probe"),
                requested_version=requested_version,
                execution_backend=execution_backend,
            )
        if execution_backend is not None:
            from comsol_mcp.jobs.attached_runtime import normalize_attached_execution_target
            from comsol_mcp.shared_session.lifecycle import SharedSessionManager
            from comsol_mcp.shared_session.preflight import classify_shared_server_preflight
            from comsol_mcp.shared_session.process_probe import (
                collect_shared_preflight_snapshot,
            )

            target = normalize_attached_execution_target(execution_backend)
            endpoint = {
                "host": target.server.endpoint.host,
                "port": target.server.endpoint.port,
            }
            first = collect_shared_preflight_snapshot()
            second = collect_shared_preflight_snapshot()
            preflight = classify_shared_server_preflight(
                endpoint=endpoint,
                first_probe=first,
                second_probe=second,
            )
            if not preflight.get("success"):
                return {
                    **preflight,
                    "ready": False,
                    "execution_backend": "attached_shared_server",
                }
            try:
                observed = SharedSessionManager._server_identity_from_snapshot(
                    target.server.endpoint, second
                )
            except Exception as exc:
                return {
                    "success": False,
                    "ready": False,
                    "state": "attached_server_identity_unavailable",
                    "blockers": [f"{type(exc).__name__}: {exc}"],
                    "execution_backend": "attached_shared_server",
                }
            if observed.identity_sha256 != target.server.identity_sha256:
                return {
                    "success": False,
                    "ready": False,
                    "state": "attached_server_identity_changed",
                    "blockers": ["attached_server_identity_changed"],
                    "expected_server_identity_sha256": (target.server.identity_sha256),
                    "observed_server_identity_sha256": observed.identity_sha256,
                    "execution_backend": "attached_shared_server",
                }
            return {
                "success": True,
                "ready": True,
                "state": "ready_for_attached_worker",
                "execution_backend": "attached_shared_server",
                "server_identity_sha256": observed.identity_sha256,
                "preflight": preflight,
                "mph_imported": False,
                "client_constructed": False,
            }
        from comsol_mcp.tools.ownership import SolverOwnership
        from comsol_mcp.tools.session import session_manager

        return SolverOwnership(self.store.root.parent).preflight(
            session_state=session_manager.get_status(),
            model_path=model_path,
            output_path=str(self.store.root / "probe"),
            requested_version=requested_version,
        )

    def _preflight_surrogate_training(self, spec: dict[str, Any]) -> dict[str, Any]:
        """Prove a surrogate-training submission is self-consistent and solver-free.

        A surrogate submission is bound to dataset, split, schema, transform, and
        architecture identities rather than a single MPH source.  This preflight
        therefore checks identity binding and the declared budgets, and records
        explicitly that no COMSOL client, lease, or solver is involved.
        """
        blockers: list[str] = []
        dataset = spec.get("dataset_manifest") or {}
        split_plan = spec.get("split_plan") or {}
        declared = {
            "dataset_manifest_sha256": dataset.get("manifest_sha256"),
            "split_manifest_sha256": split_plan.get("manifest_sha256"),
            "field_schema_sha256": (spec.get("field_schema") or {}).get("manifest_sha256"),
            "transforms_sha256": (spec.get("transforms") or {}).get("manifest_sha256"),
            "architecture_sha256": spec.get("architecture_sha256"),
        }
        for name, value in declared.items():
            if spec.get(name) != value:
                blockers.append(f"{name}_not_bound")

        ineligible = {item["row_id"] for item in (dataset.get("ineligible_rows") or [])}
        assignments = split_plan.get("assignments") or []
        holdout = [item for item in assignments if item.get("split") == "scientific_holdout"]
        if not assignments:
            blockers.append("split_plan_has_no_assignments")
        if not holdout:
            blockers.append("scientific_holdout_is_empty")
        if spec.get("maximum_epochs", 0) < 1:
            blockers.append("maximum_epochs_is_not_positive")
        if not spec.get("seeds"):
            blockers.append("seeds_are_empty")
        del ineligible  # retained for future eligibility enforcement

        return {
            "success": not blockers,
            "ready": not blockers,
            "state": "ready_for_solver_free_surrogate_worker" if not blockers else "blocked",
            "blockers": blockers,
            "solver_free": True,
            "mph_imported": False,
            "client_constructed": False,
            "acquires_solver_lease": False,
            "bound_identities": declared,
        }

    def _launch_worker(self, job_id: str, module: str) -> dict[str, Any]:
        directory = self.store.job_dir(job_id)
        command = [sys.executable, "-m", module, str(self.store.root), job_id]
        flags = 0
        if os.name == "nt":
            flags = (
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)
                | getattr(subprocess, "DETACHED_PROCESS", 0)
            )
        with (directory / "worker.log").open("ab", buffering=0) as log:
            process = subprocess.Popen(  # noqa: S603 - fixed interpreter/module argv
                command,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=log,
                close_fds=True,
                creationflags=flags,
                start_new_session=(os.name != "nt"),
            )
        _track_detached_process(process)
        expected_signature = hashlib.sha256(
            "\0".join(command).encode("utf-8", errors="replace")
        ).hexdigest()
        deadline = time.monotonic() + 2.0
        while True:
            try:
                observed = process_identity(process.pid)
                if os.name == "nt" or observed["command_signature"] == expected_signature:
                    return observed
            except psutil.NoSuchProcess, psutil.ZombieProcess, OSError:
                pass
            # A fast child can bind and exit before the parent samples /proc.
            # Use only its persisted, exact launched-command identity.
            state = self.store.read_state(job_id)
            if (
                state.get("worker_pid") == process.pid
                and state.get("worker_command_signature") == expected_signature
            ):
                created = state.get("worker_process_create_time")
                if (
                    isinstance(created, (int, float))
                    and not isinstance(created, bool)
                    and math.isfinite(created)
                ):
                    return {
                        "pid": process.pid,
                        "process_create_time": created,
                        "command_signature": expected_signature,
                    }
            if time.monotonic() >= deadline or process.poll() is not None:
                raise RuntimeError(
                    "Detached worker identity could not be verified before launch acknowledgement"
                )
            time.sleep(0.01)

    def _arm_robust_wall_watchdog_if_required(
        self,
        job_id: str,
        spec: dict[str, Any],
        *,
        attempt: int,
        worker_identity: dict[str, Any],
    ) -> dict[str, Any] | None:
        if spec.get("synthetic_mode") is not False:
            return None
        if spec.get("job_type") == "robust_shape_optimization":
            budget_seconds = int(spec["native_optimizer"]["budget"]["max_wall_time_seconds"])
            budget_source = "native_optimizer.budget.max_wall_time_seconds"
        elif spec.get("job_type") == "adjoint_optimization":
            budget_seconds = int(spec["optimizer"]["budget"]["max_wall_time_seconds"])
            budget_source = "optimizer.budget.max_wall_time_seconds"
        else:
            return None
        started_at = float(worker_identity["process_create_time"])
        deadline = started_at + budget_seconds
        directory = self.store.job_dir(job_id)
        artifact = directory / "wall-watchdog.json"
        launching = {
            "schema_name": "comsol_mcp.robust_wall_watchdog",
            "schema_version": "1.0.0",
            "job_id": job_id,
            "attempt": int(attempt),
            "budget_source": budget_source,
            "budget_seconds": budget_seconds,
            "worker_started_at_epoch": started_at,
            "deadline_epoch": deadline,
            "target_worker": worker_identity,
            "status": "launching",
            "updated_at_epoch": time.time(),
        }
        atomic_write_json(artifact, launching)
        command = [
            sys.executable,
            "-m",
            "comsol_mcp.jobs.robust_wall_watchdog",
            str(self.store.root),
            job_id,
            str(attempt),
            repr(deadline),
        ]
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(
                subprocess, "DETACHED_PROCESS", 0
            )
        try:
            with (directory / "worker.log").open("ab", buffering=0) as log:
                process = subprocess.Popen(  # noqa: S603 - fixed interpreter/module argv
                    command,
                    stdin=subprocess.DEVNULL,
                    stdout=log,
                    stderr=log,
                    close_fds=True,
                    creationflags=flags,
                    start_new_session=(os.name != "nt"),
                )
            _track_detached_process(process)
            watchdog_identity = _wait_for_launched_identity(process, command)
        except Exception as exc:
            atomic_write_json(
                artifact,
                {
                    **launching,
                    "status": "launch_failed",
                    "launch_error": {
                        "type": type(exc).__name__,
                        "message": str(exc)[:500],
                    },
                    "updated_at_epoch": time.time(),
                },
            )
            raise
        armed = {
            **launching,
            "status": "armed",
            "watchdog_identity": watchdog_identity,
            "armed_at_epoch": time.time(),
            "updated_at_epoch": time.time(),
        }
        atomic_write_json(artifact, armed)
        self.store.append_event(
            job_id,
            "robust_wall_watchdog_armed",
            {
                "attempt": int(attempt),
                "budget_seconds": budget_seconds,
                "deadline_epoch": deadline,
                "watchdog_pid": watchdog_identity["pid"],
            },
        )
        return armed

    def cancel(self, job_id: str, *, expected_attempt: int | None = None) -> dict[str, Any]:
        request = self.store.request_cancel(
            job_id,
            requester_identity=process_identity(os.getpid()),
            expected_attempt=expected_attempt,
        )
        state = request["state"]
        control = request["control"]
        if not request["accepted"]:
            if request["reason"] == "terminal":
                error = "Job was terminal before the cancellation request acquired the job lock"
            elif request["reason"] == "stale_control_attempt":
                error = "Existing cancellation request belongs to a different attempt"
            elif request["reason"] == "attempt_mismatch":
                error = "Job attempt changed before the cancellation request acquired the lock"
            else:
                error = f"Cancellation request refused: {request['reason']}"
            return {
                "success": False,
                "job_id": job_id,
                "status": state["status"],
                "error": error,
            }
        prior_launch_failed = bool(
            isinstance(state.get("cancel"), dict)
            and state["cancel"].get("coordinator_launch_error")
        )
        if not request["idempotent"] or prior_launch_failed:
            try:
                self._launch_cancel_coordinator(job_id, control["request_id"])
            except Exception as exc:
                self.store.update_state(
                    job_id,
                    patch={
                        "cancel": {
                            **state.get("cancel", {}),
                            "coordinator_launch_error": f"{type(exc).__name__}: {exc}",
                        }
                    },
                    event="cancel_coordinator_launch_failed",
                )
                return {
                    "success": False,
                    "job_id": job_id,
                    "status": state["status"],
                    "request_id": control["request_id"],
                    "target_attempt": control["target_attempt"],
                    "idempotent": bool(request["idempotent"]),
                    "error": "Cancellation coordinator could not be started",
                }
            if prior_launch_failed:
                self.store.update_state(
                    job_id,
                    patch={
                        "cancel": {
                            **state["cancel"],
                            "coordinator_launch_error": None,
                        }
                    },
                    event="cancel_coordinator_relaunched",
                )
        return {
            "success": True,
            "job_id": job_id,
            "status": state["status"],
            "request_id": control["request_id"],
            "target_attempt": control["target_attempt"],
            "idempotent": bool(request["idempotent"]),
        }

    def _launch_cancel_coordinator(self, job_id: str, request_id: str) -> None:
        directory = self.store.job_dir(job_id)
        command = [
            sys.executable,
            "-m",
            "comsol_mcp.jobs.cancel_worker",
            str(self.store.root),
            job_id,
            request_id,
            str(self.cancel_grace_seconds),
            str(self.cancel_terminate_seconds),
        ]
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(
                subprocess, "DETACHED_PROCESS", 0
            )
        with (directory / "worker.log").open("ab", buffering=0) as log:
            process = subprocess.Popen(  # noqa: S603 - fixed interpreter/module argv
                command,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=log,
                close_fds=True,
                creationflags=flags,
                start_new_session=(os.name != "nt"),
            )
        _track_detached_process(process)

    def reconcile_cancellations(self, *, limit: int | None = None) -> int:
        """Reconcile orphaned cancellation attempts without weakening cleanup proof."""
        reconciled = 0
        if not self.store.root.is_dir():
            return 0
        count = None if limit is None else max(1, min(int(limit), 100))
        directories = sorted(
            (
                path
                for path in self.store.root.iterdir()
                if path.is_dir()
                and path.name.startswith("job-")
                and (path / "state.json").is_file()
            ),
            key=lambda path: path.stat().st_mtime_ns,
            reverse=True,
        )
        if count is not None:
            directories = directories[:count]
        for directory in directories:
            job_id = directory.name
            try:
                action: tuple[str, dict[str, Any]] | None = None
                with self.store.lock(job_id, timeout=0.1):
                    state = self.store.read_state(job_id)
                    control = self.store.read_control(job_id)
                    if state.get("status") not in {"cancel_requested", "cancelling"}:
                        continue
                    if control.get("request") != "cancel_requested" or not control.get(
                        "request_id"
                    ):
                        continue
                    attempt = int(state.get("attempt", 1))
                    if not cancel_request_targets_attempt(control, attempt):
                        continue
                    cancel = dict(state.get("cancel") or {})
                    if cancel.get("request_id") not in (None, control.get("request_id")):
                        continue
                    coordinator = cancel.get("coordinator")
                    coordinator_verdict = (
                        inspect_identity(coordinator)
                        if isinstance(coordinator, dict)
                        else {
                            "identity": coordinator,
                            "state": "missing",
                            "reason": "coordinator identity is missing",
                        }
                    )
                    if coordinator_verdict["state"] == "active":
                        continue
                    request_id = str(control["request_id"])

                    worker = control.get("target_worker")
                    worker_verdict = (
                        inspect_identity(worker)
                        if isinstance(worker, dict)
                        else {
                            "identity": worker,
                            "state": "missing",
                            "reason": "worker identity is missing",
                        }
                    )
                    capture = cancel.get("descendant_capture")
                    capture_proved = (
                        isinstance(capture, dict)
                        and isinstance(cancel.get("descendants"), list)
                        and (
                            (
                                isinstance(capture.get("worker"), dict)
                                and capture["worker"].get("state") == "active"
                                and capture.get("capture_method", "live_enumeration")
                                == "live_enumeration"
                            )
                            or (
                                capture.get("capture_method") == "contained_worker_exit"
                                and capture.get("process_tree_contained") is True
                                and state.get("process_tree_contained") is True
                            )
                        )
                    )
                    if (
                        isinstance(capture, dict)
                        and capture.get("capture_method") == "controlled_leaf_worker"
                    ):
                        from .process_control import controlled_leaf_worker_proved

                        capture_proved = (
                            isinstance(worker, dict)
                            and cancel.get("descendants") == []
                            and controlled_leaf_worker_proved(
                                self.store.read_spec(job_id), state, worker
                            )
                        )

                    if (
                        state.get("status") == "cancelling"
                        and coordinator_verdict["state"] == "stale"
                        and worker_verdict["state"] == "stale"
                        and capture_proved
                    ):
                        action = ("relaunch", {"request_id": request_id})
                    elif "uncertain" in {coordinator_verdict["state"], worker_verdict["state"]}:
                        now = time.time()
                        cancel["reconciliation"] = {
                            "observed_at_epoch": now,
                            "outcome": "blocked_uncertain_identity",
                            "coordinator": coordinator_verdict,
                            "worker": worker_verdict,
                        }
                        state["cancel"] = cancel
                        state["updated_at_epoch"] = now
                        atomic_write_json(self.store.job_dir(job_id) / "state.json", state)
                        self.store._append_event_unlocked(
                            job_id,
                            "cancel_reconciliation_blocked",
                            {"request_id": request_id, "reason": "uncertain_identity"},
                            str(state["status"]),
                        )
                    elif (
                        state.get("status") == "cancelling"
                        and coordinator_verdict["state"] == "stale"
                        and worker_verdict["state"] == "stale"
                        and not capture_proved
                    ):
                        now = time.time()
                        cancel["reconciliation"] = {
                            "observed_at_epoch": now,
                            "outcome": "blocked_missing_descendant_capture",
                            "coordinator": coordinator_verdict,
                            "worker": worker_verdict,
                        }
                        state["cancel"] = cancel
                        state["updated_at_epoch"] = now
                        atomic_write_json(self.store.job_dir(job_id) / "state.json", state)
                        self.store._append_event_unlocked(
                            job_id,
                            "cancel_reconciliation_blocked",
                            {"request_id": request_id, "reason": "missing_descendant_capture"},
                            str(state["status"]),
                        )
                    else:
                        action = ("relaunch", {"request_id": request_id})

                if action is None:
                    continue
                _kind, payload = action
                self._launch_cancel_coordinator(job_id, payload["request_id"])
                reconciled += 1
            except FileNotFoundError, TimeoutError, ValueError, OSError:
                continue
        return reconciled

    def resume(self, job_id: str) -> dict[str, Any]:
        with self.store.lock(job_id):
            state = self.store.read_state(job_id)
            if state["status"] not in {"failed", "interrupted", "cancelled"}:
                raise ValueError("Only failed, interrupted, or cancelled jobs may be resumed")
            spec = self.store.read_spec(job_id)
            if spec["job_type"] == "test_sequence" and not self.allow_test_jobs:
                raise ValueError("test_sequence jobs are disabled")
            expected = spec.get("spec_fingerprint")
            actual = _fingerprint(
                {key: value for key, value in spec.items() if key != "spec_fingerprint"}
            )
            if expected != actual:
                raise ValueError("Refusing resume because immutable spec fingerprint changed")

        # Ownership status merges durable-job summaries, so preflight must run
        # outside this job's lock.  The second locked validation below prevents
        # two concurrent resume callers from both transitioning and launching.
        if spec["job_type"] in {
            "staged_sweep",
            "validation_matrix",
            "spectral_characterization",
            "convergence_campaign",
            "branch_continuation_campaign",
            "thermo_optomechanical_replay",
            "adjoint_optimization",
            "robust_shape_optimization",
            "surrogate_training",
        }:
            if self._preflight is None and spec.get("execution_backend") is None:
                from comsol_mcp.tools.ownership import SolverOwnership

                ownership = SolverOwnership(self.store.root.parent)
                lease = ownership.status()["lease"]
                if lease["state"] == "stale":
                    payload = lease.get("lease") or {}
                    if payload.get("owner") != f"job:{job_id}":
                        raise RuntimeError(
                            "Refusing to recover a stale lease that does not belong to this job"
                        )
                    recovered = ownership.recover_stale()
                    if not recovered.get("success"):
                        raise RuntimeError(f"Cannot recover this job's stale lease: {recovered}")
            preflight = self._run_preflight(spec)
            if not preflight.get("ready", preflight.get("success", False)):
                raise RuntimeError(
                    f"Resume preflight failed: {preflight.get('blockers') or preflight}"
                )

        with self.store.lock(job_id):
            state = self.store.read_state(job_id)
            if state["status"] not in {"failed", "interrupted", "cancelled"}:
                raise ValueError("Job state changed while resume preflight was running")
            current_spec = self.store.read_spec(job_id)
            current_expected = current_spec.get("spec_fingerprint")
            current_actual = _fingerprint(
                {key: value for key, value in current_spec.items() if key != "spec_fingerprint"}
            )
            if current_expected != expected or current_actual != expected:
                raise ValueError("Refusing resume because immutable spec changed during preflight")
            state["status"] = "starting"
            state["attempt"] = int(state.get("attempt", 1)) + 1
            state["worker_pid"] = None
            state["worker_process_create_time"] = None
            state["worker_command_signature"] = None
            state["last_error"] = None
            if isinstance(state.get("cancel"), dict):
                state["cancel"] = {
                    **state["cancel"],
                    "superseded_by_attempt": state["attempt"],
                }
            state["updated_at_epoch"] = time.time()
            atomic_write_json(self.store.job_dir(job_id) / "state.json", state)
            self.store.write_control(
                job_id,
                None,
                fields={"cleared_for_attempt": state["attempt"]},
            )
            self.store._append_event_unlocked(
                job_id, "resume_requested", {"attempt": state["attempt"]}, "starting"
            )
        module = _worker_module(current_spec["job_type"])
        try:
            identity = self._launch_worker(job_id, module)
            self.store.bind_worker_identity(job_id, identity)
        except Exception as exc:
            self.store.update_state(
                job_id,
                "failed",
                patch={"last_error": {"type": type(exc).__name__, "message": str(exc)}},
                event="resume_launch_failed",
            )
            raise
        try:
            self._arm_robust_wall_watchdog_if_required(
                job_id,
                current_spec,
                attempt=int(state["attempt"]),
                worker_identity=identity,
            )
        except Exception as exc:
            cancellation = self.cancel(job_id, expected_attempt=int(state["attempt"]))
            raise JobLaunchError(
                job_id,
                RuntimeError(
                    "Licensed robust wall watchdog could not be armed on resume; "
                    f"exact-attempt cancellation result: {cancellation}"
                ),
            ) from exc
        return {
            "success": True,
            "job_id": job_id,
            "status": "starting",
            "attempt": state["attempt"],
        }

    def status(self, job_id: str, *, refresh_probe: bool = False) -> dict[str, Any]:
        # A cancellation coordinator must be able to acquire the durable lock
        # promptly.  Atomic state replacement makes this terminal observation
        # safe without taking the polling lock, and it avoids status callers
        # starving the coordinator during the durable cancellation grace/verification window.
        try:
            observed = self.store.read_state(job_id)
        except RuntimeError:
            observed = None
        if isinstance(observed, dict) and observed.get("status") == "cancelling":
            return {"success": True, "job_id": job_id, **observed}
        with self.store.lock(job_id):
            state = self.store.read_state(job_id)
            if state.get("status") in ACTIVE_STATES and state.get("worker_pid") is not None:
                identity = {
                    "pid": state["worker_pid"],
                    "process_create_time": state.get("worker_process_create_time"),
                    "command_signature": state.get("worker_command_signature"),
                }
                process_state, reason = process_identity_state(identity)
                current = str(state["status"])
                if process_state == "stale" and current != "cancelling":
                    control = self.store.read_control(job_id)
                    attempt = int(state.get("attempt", 1))
                    if current == "cancel_requested" and cancel_request_targets_attempt(
                        control, attempt
                    ):
                        # A matching cancellation owns this attempt's terminal
                        # outcome.  Preserve the nonterminal state so the
                        # coordinator can prove process/port/lease cleanup.
                        state["worker_process_state"] = process_state
                        state["worker_process_reason"] = reason
                    else:
                        if "interrupted" not in TRANSITIONS[current]:
                            raise RuntimeError(f"Cannot reconcile state {current} as interrupted")
                        state["status"] = "interrupted"
                        state["last_error"] = {"type": "WorkerInterrupted", "message": reason}
                        state["updated_at_epoch"] = time.time()
                        atomic_write_json(self.store.job_dir(job_id) / "state.json", state)
                        self.store._append_event_unlocked(
                            job_id, "worker_interrupted", {"reason": reason}, "interrupted"
                        )
                else:
                    state["worker_process_state"] = process_state
                    state["worker_process_reason"] = reason
            spec = self.store.read_spec(job_id)
            if spec.get("job_type") == "validation_matrix":
                from .validation_rows import read_validation_rows

                rows = read_validation_rows(self.store.job_dir(job_id) / "matrix_rows.jsonl", spec)
                ok = [row for row in rows if row["status"] == "ok"]
                errors = [row for row in rows if row["status"] == "error"]
                state["matrix_summary"] = {
                    "total_declared": len(spec["points"]),
                    "rows": len(rows),
                    "complete": len(ok),
                    "errors": len(errors),
                    "pending": len(spec["points"]) - len({row["point_fingerprint"] for row in ok}),
                    "last_row_sha256": rows[-1]["row_sha256"] if rows else None,
                    "last_error_type": errors[-1]["error"]["type"] if errors else None,
                }
            elif spec.get("job_type") == "spectral_characterization":
                from .spectral_rows import read_spectral_rows
                from .spectral_stages import read_spectral_stage_plans

                directory = self.store.job_dir(job_id)
                rows = read_spectral_rows(
                    directory / "spectral_rows.jsonl",
                    spec,
                    artifact_root=directory,
                )
                stages = read_spectral_stage_plans(directory, spec)
                planned = sum(len(stage["requested_points"]) for stage in stages)
                state["spectral_progress"] = {
                    "maximum_points": spec["maximum_points"],
                    "planned_points": planned,
                    "complete_points": len(rows),
                    "pending_planned_points": planned - len(rows),
                    "stage_count": len(stages),
                    "last_stage_sha256": stages[-1]["stage_sha256"] if stages else None,
                    "last_row_sha256": rows[-1]["row_sha256"] if rows else None,
                }
            elif spec.get("job_type") == "convergence_campaign":
                from .convergence_campaign_rows import read_convergence_campaign_levels

                directory = self.store.job_dir(job_id)
                rows = read_convergence_campaign_levels(
                    directory / "convergence_levels.jsonl",
                    spec,
                    artifact_root=directory,
                )
                state["convergence_progress"] = {
                    "declared_levels": len(spec["levels"]),
                    "completed_levels": len(rows),
                    "pending_levels": len(spec["levels"]) - len(rows),
                    "completed_level_ids": [row["level_id"] for row in rows],
                    "last_level_row_sha256": rows[-1]["row_sha256"] if rows else None,
                    "maximum_total_points": spec["maximum_total_points"],
                }
            elif spec.get("job_type") == "branch_continuation_campaign":
                from .branch_continuation_campaign_rows import (
                    read_branch_continuation_campaign_states,
                )

                directory = self.store.job_dir(job_id)
                rows = read_branch_continuation_campaign_states(
                    directory / "continuation_states.jsonl",
                    spec,
                    artifact_root=directory,
                )
                state["branch_continuation_progress"] = {
                    "declared_states": len(spec["states"]),
                    "completed_states": len(rows),
                    "pending_states": len(spec["states"]) - len(rows),
                    "completed_state_ids": [row["state_id"] for row in rows],
                    "last_state_row_sha256": rows[-1]["row_sha256"] if rows else None,
                    "maximum_total_points": spec["maximum_total_points"],
                }
            elif spec.get("job_type") == "thermo_optomechanical_replay":
                from .thermo_optomechanical_replay_rows import (
                    read_thermo_optomechanical_stage_rows,
                )

                directory = self.store.job_dir(job_id)
                rows = read_thermo_optomechanical_stage_rows(
                    directory / "thermo_optomechanical_stages.jsonl",
                    spec,
                    artifact_root=directory,
                )
                state["thermo_optomechanical_progress"] = {
                    "declared_stages": len(spec["declared_stages"]),
                    "completed_stages": len(rows),
                    "pending_stages": len(spec["declared_stages"]) - len(rows),
                    "completed_stage_ids": [row["stage_id"] for row in rows],
                    "last_stage_row_sha256": rows[-1]["row_sha256"] if rows else None,
                    "declared_optical_points": spec["declared_optical_point_count"],
                }
            elif spec.get("job_type") == "robust_shape_optimization":
                from .robust_shape_rows import read_robust_shape_rows

                directory = self.store.job_dir(job_id)
                rows = read_robust_shape_rows(
                    directory / "robust_shape_rows.jsonl",
                    job_fingerprint=spec["spec_fingerprint"],
                )
                condition_rows = [row for row in rows if row["kind"] == "condition"]
                completed = {
                    row["payload"]["condition_id"]
                    for row in condition_rows
                    if row["payload"]["status"] in {"completed", "skipped"}
                }
                declared = _point_count(spec)
                state["robust_shape_progress"] = {
                    "declared_conditions": declared,
                    "completed_conditions": len(completed),
                    "pending_conditions": declared - len(completed),
                    "row_count": len(rows),
                    "last_row_sha256": rows[-1]["row_sha256"] if rows else None,
                    "cleanup_recorded": any(row["kind"] == "cleanup" for row in rows),
                }
            if state.get("status") in TERMINAL_STATES:
                # B13 warning-only post-run probe: cached after first terminal
                # scan; refresh_probe forces a re-hash. A failed `.mph` parse
                # is recorded here and never changes the job disposition.
                from ..evidence.inspection.probe import probe_mph_artifacts

                state["mph_artifact_probe"] = probe_mph_artifacts(
                    self.store.job_dir(job_id),
                    refresh=refresh_probe,
                )
            if (self.store.job_dir(job_id) / "bounded_steps.jsonl").is_file():
                # Warning-only bounded-step review surface: a failed journal
                # parse is recorded here and never changes the disposition.
                try:
                    from .bounded_steps import summarize_bounded_steps

                    state["bounded_steps"] = summarize_bounded_steps(self.store.job_dir(job_id))
                except Exception:
                    logger.warning("bounded step summary was unreadable", exc_info=True)
                    state["bounded_steps"] = {
                        "available": False,
                        "reason_code": "bounded_steps_unreadable",
                    }
            if (self.store.job_dir(job_id) / "observation.json").is_file():
                # Warning-only observation surface: a failed receipt read is
                # recorded here and never changes the job disposition.
                try:
                    from .observation import summarize_observation

                    state["observation"] = summarize_observation(self.store.job_dir(job_id))
                except Exception:
                    logger.warning("observation receipt was unreadable", exc_info=True)
                    state["observation"] = {
                        "available": False,
                        "reason_code": "observation_unreadable",
                    }
            return {"success": True, "job_id": job_id, **state}

    def tail(self, job_id: str, n: int = 20) -> dict[str, Any]:
        return {"success": True, **self.store.tail(job_id, n)}

    def summaries(self, limit: int = 20) -> dict[str, Any]:
        count = max(1, min(int(limit), 100))
        directories = sorted(
            (
                path
                for path in self.store.root.iterdir()
                if path.is_dir()
                and path.name.startswith("job-")
                and (path / "state.json").is_file()
            ),
            key=lambda path: path.stat().st_mtime_ns,
            reverse=True,
        )[:count]
        jobs = []
        for directory in directories:
            try:
                state = self.status(directory.name)
                jobs.append(
                    {
                        "job_id": directory.name,
                        "status": state["status"],
                        "attempt": state.get("attempt"),
                        "progress": state.get("progress"),
                        "worker_pid": state.get("worker_pid"),
                        "updated_at_epoch": state.get("updated_at_epoch"),
                        "last_error": state.get("last_error"),
                    }
                )
            except Exception as exc:
                jobs.append(
                    {
                        "job_id": directory.name,
                        "status": "unreadable",
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )
        active = [job for job in jobs if job["status"] in ACTIVE_STATES]
        return {
            "available": True,
            "root": str(self.store.root),
            "count_returned": len(jobs),
            "active_count": len(active),
            "active": active,
            "recent": jobs,
        }
