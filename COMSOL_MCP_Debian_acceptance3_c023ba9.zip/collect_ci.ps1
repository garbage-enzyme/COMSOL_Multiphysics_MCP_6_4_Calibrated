$ErrorActionPreference = 'Stop'
$root = '/workspace/code-review/debian-acceptance3-c023ba9'
$html = Get-Content -LiteralPath (Join-Path $root 'ci-run-37919936572.html') -Raw
$matches = [regex]::Matches($html, '/actions/runs/37919936572/job/([0-9]+)')
$jobIds = @($matches | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
foreach ($jobId in $jobIds) {
    Invoke-WebRequest -Uri ('https://github.com/garbage-enzyme/COMSOL_Multiphysics_MCP_6_4_Calibrated/actions/runs/37919936572/job/' + $jobId) -OutFile (Join-Path $root ('ci-job-' + $jobId + '.html')) -TimeoutSec 30
}
$env:PYTHONDONTWRITEBYTECODE='1'
& /workspace/.cloud-onboarding/venv/bin/python (Join-Path $root 'summarize_ci_pages.py')
if ($LASTEXITCODE -ne 0) { throw 'CI annotation summary failed' }

