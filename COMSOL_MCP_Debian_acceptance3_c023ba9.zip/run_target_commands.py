"""Preserve raw focused-test, original-probe and CI-check outputs."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9')
PY = sys.executable
env = dict(os.environ,PYTHONPATH=str(REPO),PYTHONDONTWRITEBYTECODE='1')
adapted = ROOT/'adapted-original-probes'
adapted.mkdir(exist_ok=True)
names = {'BUG-002':'repro_fifo_cleanup.py','BUG-004':'repro_tasks_journal.py',
         'BUG-005':'repro_tasks_owner.py','BUG-041':'repro_operation_linux.py'}
for name in names.values():
    original = Path('/workspace/code-review')/name
    text = original.read_text().replace('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated',str(REPO))
    (adapted/name).write_text(text)
pytest = [PY,'-m','pytest','-q','-p','no:cacheprovider']
jobs = [
 ('BUG-001__cold_single',pytest+['development_kit/tests/test_platform_support.py::test_registered_linux_preflight_is_refused_before_callback','--basetemp',str(ROOT/'cold-single-temp')],REPO,90),
 ('BUG-001__cold_platform_posix',pytest+['development_kit/tests/test_platform_support.py','development_kit/tests/test_posix_platform.py','--basetemp',str(ROOT/'cold-platform-temp')],REPO,90),
 ('BUG-001__reverse_order',pytest+['development_kit/tests/test_posix_platform.py','development_kit/tests/test_platform_support.py','--basetemp',str(ROOT/'reverse-order-temp')],REPO,90),
 ('focused_unit_suite',pytest+['development_kit/tests/test_durable_primitives.py','development_kit/tests/test_tasks_extension.py','development_kit/tests/test_operation_arbiter.py','--basetemp',str(ROOT/'focused-temp')],REPO,120),

]
jobs += [(bug+'__original_probe',[PY,str(adapted/name)],ROOT,15) for bug,name in names.items()]
outcomes = []
for name,command,cwd,bound in jobs:
    start = time.monotonic()
    process = subprocess.Popen(command,cwd=cwd,env=env,start_new_session=True,
                               stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed_out = False
    try: stdout,stderr = process.communicate(timeout=bound)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGKILL)
        stdout,stderr=process.communicate(timeout=5)
    finally:
        try: os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError: pass
    logs=ROOT/'target-command-results'
    logs.mkdir(exist_ok=True)
    (logs/(name+'__stdout.log')).write_bytes(stdout)
    (logs/(name+'__stderr.log')).write_bytes(stderr)
    receipt={'name':name,'command':command,'cwd':str(cwd),'returncode':process.returncode,
             'seconds':round(time.monotonic()-start,3),'outer_timeout':timed_out,'timeout_seconds':bound}
    outcomes.append(receipt)
    print(json.dumps(receipt),flush=True)
(ROOT/'target-command-results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
