"""Exercise actual stdio discovery for the portable semantic acceptance entry."""
import sys,os,asyncio,json,tempfile
from pathlib import Path
repo=Path('/workspace/COMSOL_MCP_debian_acceptance_c023ba9');sys.path.insert(0,str(repo))
from development_kit.tests.integration import semantic_feature_acceptance as gate
for key in ['COMSOL_SEMANTIC_ROOT','COMSOL_SEMANTIC_LEXICAL_INDEX','COMSOL_SEMANTIC_MODEL_PATH']:
    os.environ.pop(key,None)
root=Path(__file__).resolve().parent
async def run():
    outcomes=[]
    with tempfile.TemporaryDirectory(dir=root,prefix='stdio-discovery-') as directory:
        for profile in gate.PROFILE_COUNTS:
            runtime=Path(directory)/profile
            parameters=gate._server(profile,runtime)
            assert not any(k.startswith('COMSOL_SEMANTIC_') for k in parameters.env)
            result=await gate._discover(profile,runtime)
            outcomes.append({'profile':profile,'tool_count':result['tool_count'],'expected':gate.PROFILE_COUNTS[profile]})
    print(json.dumps({'checks':outcomes,'passed':True,'solver_started':False,'hybrid_model_loaded':False},indent=2))
asyncio.run(run())
