# COMSOL MCP 0.7.7 bug list

目标提交：`da9f168baedfcca28d04d93369ef711240011d73`。
逐文件审查已完成：780 / 780 个 Git 跟踪文件已检查或按用户要求记录可再生二进制生成入口。以下 203 条问题已确认，均尚未修复。原生 COMSOL 与 DeepSeek 模型推理未运行；每条复现明确说明真实代码、替身及验证范围。

## BUG-001

- **编号**：BUG-001
- **标题**：Linux 平台测试依赖导入顺序，独立运行失败
- **严重性/优先级**：中 / P2；测试可靠性问题。
- **位置**：`development_kit/tests/test_platform_support.py:100`；关联 `comsol_mcp/tools/session.py:126`。
- **内容/复现方法**：新进程中独立运行平台测试时，测试用只有 `preflight()` 方法的 `Forbidden` 替换 `ownership_manager`。`create_server()` 首次导入 `session` 并创建单例，读取替身不存在的 `runtime_dir`，抛出 `AttributeError`。测试没有到达平台拒绝逻辑。其他测试预先导入模块时可能掩盖缺陷。复现命令：`python -m pytest -q development_kit/tests/test_platform_support.py development_kit/tests/test_posix_platform.py --basetemp /tmp/a77posix`。证据：`/workspace/.cloud-onboarding/a77-posix.log`，20 passed / 1 failed，异常为 `'Forbidden' object has no attribute 'runtime_dir'`。安装后的 stdio 探针正确拒绝原生 preflight，此条是测试缺陷。
- **可能的解决办法**：使替身满足初始化接口，或在替换对象前显式完成无求解器初始化；增加独立新进程运行的测试验证。

## BUG-002

- **编号**：BUG-002
- **标题**：POSIX 身份清理可被 FIFO 无限阻塞
- **严重性/优先级**：中 / P2；鲁棒性与拒绝服务问题。
- **位置**：`comsol_mcp/durable/io.py`，`_posix_unlink_opened_file_if()` 的 `read_flags` 和 `os.open(path.name, ...)`。
- **内容/复现方法**：待清理路径是 FIFO，或普通文件在打开前被替换为 FIFO，且没有写端时，阻塞式 `O_RDONLY` 打开无限等待，尚未执行 `fstat()` 普通文件检查。失败回滚、取消或所有权清理可能卡住。前提是有权限创建或替换该路径。复现：`python /workspace/code-review/repro_fifo_cleanup.py`。该脚本在 `/tmp` 建立 FIFO，并在三秒后终止、回收子进程。实测输出 `CONFIRMED: unlink_if_identity blocks on a FIFO before regular-file validation`。
- **可能的解决办法**：使用非阻塞描述符打开，再验证文件类型和身份；保留现有隔离恢复语义，增加 FIFO 与文件替换回归测试。

## BUG-003

- **编号**：BUG-003
- **标题**：已安装生产入口没有注册声称提供的 MCP Tasks 扩展
- **严重性/优先级**：高 / P1；公开功能缺失，生产与测试不一致。
- **位置**：`comsol_mcp/server.py:29` 的全局 `mcp`、`main()`；对照 `create_server()`。
- **内容/复现方法**：已安装的 `comsol-mcp` 使用未传入 extensions 的全局服务器，`_tasks_extensions()` 仅被 `create_server()` 调用。客户端用 `2026-07-28` 协议和正确 Tasks capability 调用 `tasks/get` 时，生产入口返回 `-32601 Method not found`。查询、取消、更新和任务拦截器均没有安装。现有 wire fixture 使用 `create_server().run()`，掩盖生产入口差异。在仓库外运行 `python /workspace/code-review/repro_tasks_entrypoint.py`：同一安装包的 console 返回 `-32601`，工厂入口返回 `-32602 unknown or expired task id`，证明工厂入口实际注册了方法。复现没有创建作业或启动 COMSOL。
- **可能的解决办法**：统一生产入口与工厂的服务器构建流程；针对真实 console 入口增加 Tasks wire 验收，核对扩展声明与普通工具回退行为。

## BUG-004

- **编号**：BUG-004
- **标题**：Tasks 日志遇到中断尾行后，下一次追加会丢失全部可读映射
- **严重性/优先级**：高 / P1；崩溃恢复与持久状态可用性问题。
- **位置**：`comsol_mcp/jobs/tasks_bridge.py:235` 的 `append()`，以及 `rows()`；关联 `comsol_mcp/durable/io.py` 的 `read_complete_jsonl()`。
- **内容/复现方法**：任务映射日志末尾存在未完成 JSON 行时，读取暂时保留此前完整映射。但 `append()` 未截断不完整尾行便追加新 JSON，新行与旧残片粘连成非法 JSON。随后解析器将日志整体归为 corrupt 并返回空记录，此前已确认的任务也全部变为 unknown。与模块声称“崩溃只损失最新行，不抹除已有映射”不符。运行 `python /workspace/code-review/repro_tasks_journal.py`：中断追加后读到 `['first']`，下一次正常追加后变为 `[]`，`first mapping survived: False`。复现只使用 `/tmp` 中的测试日志。
- **可能的解决办法**：在配合进程锁内，检查日志恢复状态，截断到已确认的完整行边界后再追加；对损坏行和恢复操作保留证据。增加“完整行 + 半行 + 正常追加 + 重启读取”的回归测试。

## BUG-005

- **编号**：BUG-005
- **标题**：重复提交可以转移另一个 owner 的 Tasks 映射所有权
- **严重性/优先级**：中 / P2；多 owner 隔离与任务可控性问题。
- **位置**：`comsol_mcp/jobs/tasks_bridge.py:409` 附近，`submit_task()` 中 `latest_for_job()`、既有 taskId 复用及新 row 的 `owner=self._owner`。
- **内容/复现方法**：两个不同 owner 共用映射目录，底层引擎对相同规格返回同一作业。owner-b 最初无法读取 owner-a 的 taskId，但提交相同规格后，bridge 无所有者检查地复用旧 taskId 并追加 owner-b 的映射行。owner-b 获得读/控制权限，owner-a 反而被拒绝。复现：`python /workspace/code-review/repro_tasks_owner.py`；输出 `owner-b initially refused`、`owner-b reused owner-a task id: True`、`owner-a lost access after identical owner-b submission`。这是配置层 owner 隔离失效，不能据此声称突破操作系统用户权限。
- **可能的解决办法**：复用映射前检查 owner；拒绝跨 owner 复用，或按 `(job_id, owner)` 建立独立映射并保持原 owner 的可访问性。增加双 owner 重复提交和取消测试。

## BUG-006

- **编号**：BUG-006
- **标题**：已结束任务的重复提交仍返回 working 状态
- **严重性/优先级**：中 / P2；Tasks 状态一致性问题。
- **位置**：`comsol_mcp/jobs/tasks_bridge.py:443` 附近，`submit_task()` 返回值的硬编码 `status: working`。
- **内容/复现方法**：底层引擎为重复规格返回已经 completed/cancelled/failed 的现有作业时，bridge 仍返回相同 taskId 的 working handle。随后 `tasks/get` 立即报告真实终态。违反“终态不再转换”的任务契约，客户端可能错误地恢复轮询或显示运行中。复现：`python /workspace/code-review/repro_tasks_owner.py` 的首行输出 `submitted handle status: working actual status: completed`；该脚本使用不启动工作进程的假引擎。
- **可能的解决办法**：返回与已持久化任务和底层作业一致的状态；对重复提交已结束任务的语义作明确规定，并覆盖三种终态。

## BUG-007

- **编号**：BUG-007
- **标题**：重建过大设置文件绕过基线检查，移动并替换外部写入的文件
- **严重性/优先级**：中 / P2；设置所有权与并发写入保护问题。
- **位置**：`settings_gui/storage.py`，`SettingsStore.rebuild()` 的过大/空文件分支：`os.replace(self.target, backup)` 和 `self.ownership.baseline = None`。
- **内容/复现方法**：编辑器取得过大设置文件的基线后，其他进程持续替换该文件。`rebuild()` 在移动现有文件之前未检查当前身份与基线是否一致，直接将外部文件移至备份，然后将 baseline 清空并写入默认设置。应检测到的外部替换被当作正常恢复。复现：`python /workspace/code-review/repro_settings_rebuild.py`，输出 `rebuild succeeded despite persistent external replacement` 和 `external target preserved: False`。外部内容仍保存在备份中，因此本复现证明目标被未经冲突处理地替换，不声称字节不可恢复。
- **可能的解决办法**：恢复/备份前验证基线；为过大文件提供受限的身份比较方式，避免读取全部内容。移动和保存期间检测替换并保留冲突结果，不通过重置基线掩盖外部修改。

## BUG-008

- **编号**：BUG-008
- **标题**：Linux 新用户首次打开设置 GUI 会在启动前失败
- **严重性/优先级**：高 / P1；首次安装的核心配置流程不可用。
- **位置**：`comsol_mcp/settings_gui_launcher.py`，`SettingsGuiInstanceLock.acquire()` 与 `launch_settings_gui()` 的先行实例检查；`settings_gui/app.py` 的 `run()` 也在准备目录之前取得实例锁。
- **内容/复现方法**：默认 `$XDG_CONFIG_HOME/comsol-mcp` 尚不存在时，POSIX 实例锁直接在设置目标旁创建锁文件，但未准备父目录，抛出 FileNotFoundError。`settings.start` 返回 launch_failed，甚至没有启动 GUI 子进程；直接 GUI 入口也在首次设置目录准备流程前取得同类锁。复现：在仓库外运行 `python /workspace/code-review/repro_gui_first_run.py`，输出 fresh-user 的 success=false、state=launch_failed、child launched=False、settings directory exists=False。脚本没有构造 Tk 或启动 COMSOL。
- **可能的解决办法**：在安全准备用户设置目录之后取得实例锁，或把首次启动实例锁放在已安全创建的用户运行目录；保留首次运行的用户确认流程。增加全新 XDG 目录的安装后 GUI 启动回归检查。

## BUG-009

- **编号**：BUG-009
- **标题**：GUI 握手文件的 2048 字节上界没有约束实际读取和内存分配
- **严重性/优先级**：中 / P2；输入上界与内存耗尽问题。
- **位置**：`comsol_mcp/settings_gui_handshake.py`，`read_handshake()` 的 `path.read_bytes()` 后置长度检查。
- **内容/复现方法**：函数先把整个文件读入内存，再拒绝大于 MAX_HANDSHAKE_BYTES 的内容。异常/外部替换造成的大握手文件可让 MCP 主进程分配远超 2048 字节的内存，且读取时间不受 GUI 轮询截止时间限制。复现：`python /workspace/code-review/repro_handshake_bound.py` 使用 8 MiB 临时稀疏文件，输出 declared byte bound=2048、allocated peak=8389010、result=None。需要能够写入或替换握手路径；并非已证实的无文件访问权远程攻击。
- **可能的解决办法**：使用已有的描述符有限读取函数，最多读取上界加一字节，并验证普通文件与身份；在打开前后防止链接/特殊文件替换导致阻塞。

## BUG-010

- **编号**：BUG-010
- **标题**：模型资源响应没有条数或字节上界
- **严重性/优先级**：中 / P2；响应大小与运行内存的鲁棒性问题。
- **位置**：`comsol_mcp/resources/model_resources.py`，`get_model_tree()`、`get_model_parameters()` 和 `get_model_physics()` 的完整遍历及字符串拼接。
- **内容/复现方法**：资源处理函数直接遍历模型返回的所有项目并包含完整值，没有限制项目数、单项长度或最终响应大小。与 AGENTS.md 第 8 条要求的有界响应不一致；大模型或异常模型字段可造成大响应和多份字符串分配。复现：`python /workspace/code-review/repro_resource_bound.py` 用无求解器假模型返回一个 2 MiB 参数值，实际资源响应为 2097255 字节，完整值全部包含。这是资源响应缺少上界的验证，不代表真实 COMSOL 接受任意大小参数，也不声称已验证远程攻击。
- **可能的解决办法**：给资源定义并实施项目数、单项字符串长度和总响应字节预算；返回明确的截断提示并提供分页或有界工具入口。增加大列表与长字段的无求解器回归检查。

## BUG-011

- **编号**：BUG-011
- **标题**：设置中的模型读取根目录为 null 或数字时，GUI 崩溃而非提供修复入口
- **严重性/优先级**：中 / P2；损坏配置的恢复路径不可用。
- **位置**：`settings_gui/app.py`，`_load_startup_document()` 与 `SettingsApplication._add_field()` 的 `list(value)`；`settings_gui/model.py` 的 `from_raw()` 保留无效值。
- **内容/复现方法**：把合法设置文件的 `paths.model_read_roots` 改成 null。启动预检将其视为可在字段中修复的错误，模型也正确记录校验错误并保留 null。但构造 roots 控件时直接调用 list(None)，抛 TypeError；run() 清理后重新抛出异常，用户无法打开 GUI 修复。数字也同样失败，字符串则被拆成字符列表。复现：`python /workspace/code-review/repro_gui_invalid_roots.py` 输出 startup accepted document=True、字段校验错误及 TypeError。脚本使用控件替身避免依赖图形显示服务，执行真实启动预检、表单模型和字段构造代码。
- **可能的解决办法**：对非列表原始值提供安全的错误表示和修复操作，或在启动时进入明确的损坏配置恢复流程；不能在控件构造时假定未通过校验的值已经是列表。

## BUG-012

- **编号**：BUG-012
- **标题**：手册索引启动期间的取消请求被遗漏，任务完成后却报告 cancelled
- **严重性/优先级**：中 / P2；取消语义与现有索引保护问题。
- **位置**：`settings_gui/manual_index.py`，`cancel()`、`_run()` 的 Popen 到 `_process` 注册区间及请求写入前；`settings_gui/app.py` 的窗口关闭路径。
- **内容/复现方法**：后台线程启动后，若用户在 Popen 返回和 `_process` 注册之前取消，cancel() 只设置事件，因为尚无已登记子进程可终止。_run() 随后仍启动/登记子进程、发送完整请求，并等待正常完成；只在结束时检查取消事件并发布 cancelled。真实索引 worker 不接收该事件，因此可以继续构建并替换索引，而界面却宣称此前索引被保留。复现：`python /workspace/code-review/repro_index_cancel_race.py` 在进程创建处设置确定性同步点、先取消再放行短时测试子进程，输出 worker exited normally after cancellation=True，reported events=[cancelled]。复现不读取 PDF 或写入真实索引。关闭 GUI 的 daemon 线程也没有等待该清理路径完成，需要一起处理。
- **可能的解决办法**：把取消检查与进程注册协调在同一锁下；注册后立即处理已存在的取消请求，在发送任务前终止并回收子进程。只有确认没有发布新索引或已安全取消时才报告 cancelled；关闭 GUI 时完成有界清理。

## BUG-013

- **编号**：BUG-013
- **标题**：COMSOL 6.4 安装目录校验接受明确标为 6.3 的元数据
- **严重性/优先级**：中 / P2；安装发现和配置可靠性问题。
- **位置**：`settings_gui/comsol_discovery.py:54`，`validate_comsol_root()` 的正则 `(?:COMSOL|Multiphysics|6\.4)`。
- **内容/复现方法**：正则把产品名和版本号作为任意一个匹配即可的候选，文件只要包含 COMSOL 或 Multiphysics 就通过，因此 COMSOL Multiphysics 6.3 也被接受为受支持的 6.4 安装。仅含 unrelated application 6.4 的元数据也通过。复现：`python /workspace/code-review/repro_discovery_version.py` 建立临时安装形状（空占位文件，不安装或启动 COMSOL），以上两种元数据均输出 accepted=True。这不能建立真实 6.4 身份，会误导 GUI 发现并保存错误安装路径。
- **可能的解决办法**：校验有明确来源的产品身份与版本字段，要求同时符合产品及受支持版本；元数据不足时返回无法确认，不能仅凭产品名称或版本字样通过。补充旧版本及非 COMSOL 元数据检查。

## BUG-014

- **编号**：BUG-014
- **标题**：空 FrozenDict 可以通过再次初始化改变，违反递归不可变快照契约
- **严重性/优先级**：低 / P3；内部对象契约缺陷。
- **位置**：`comsol_mcp/utils/immutability.py:17`，`FrozenDict.__init__()` 的 `if self` 判断。
- **内容/复现方法**：初始化保护以字典是否非空判断是否已构造。已冻结的空字典为 false，仍允许再次调用自身 __init__ 填入数据。复现：`python /workspace/code-review/repro_frozen_empty.py` 将 deep_freeze({'empty': {}}) 的子字典调用 __init__({'changed': True})，快照从空对象变为包含 changed=True。这不需要直接调用文档明确排除的 dict 基类方法；是自身公开方法绕过保护。当前未证明外部 MCP 客户端可直接利用该 Python 对象操作。
- **可能的解决办法**：用独立的构造完成标记阻止再次初始化，包括空字典；补充顶层及嵌套空快照的重复初始化检查。

## BUG-015

- **编号**：BUG-015
- **标题**：JSONL 尾部恢复先读取整个异常尾部，max_row_bytes 无法限制内存
- **严重性/优先级**：中 / P2；损坏日志恢复的资源上界缺陷。
- **位置**：`comsol_mcp/jobs/journal.py`，`recover_jsonl_tail()` 的逐窗口反向扫描和 `tail = handle.read(end - record_start)`。
- **内容/复现方法**：扫描虽然分块，但找到最近换行或文件开头后，仍把整个未终止尾部读入内存，再判断是否大于 max_row_bytes。若日志由大块无换行内容组成，恢复过程内存与文件大小成正比，之后才截断；调用方的整体文件大小校验也在恢复之后。复现：`python /workspace/code-review/repro_journal_tail_bound.py` 使用 8 MiB 临时稀疏文件及 1024 字节行上界，输出 allocated peak=8520862，最终文件被截断为 0。需要损坏或被替换的日志，不声称公开客户端可任意写入日志路径。
- **可能的解决办法**：先按 end-record_start 判定尾部长度；超限时直接截断而不读取整个尾部，必要的 JSON 校验只读取限制内的字节。还应限制反向扫描工作量，并在恢复前验证普通文件与整体大小策略。

## BUG-016

- **编号**：BUG-016
- **标题**：中英文设置指南仍将旧 schema 1.2.0 宣称为当前写入与恢复格式
- **严重性/优先级**：低 / P3；公开配置契约过期。
- **位置**：`docs/setting_guide/README.md` 与 `README_CN.md` 的适用版本、schema_version 表格、默认 JSON 模板和恢复说明；对照 `comsol_mcp/settings.py:16`。
- **内容/复现方法**：目标包为 0.7.7，SETTINGS_VERSION 为 1.3.0，当前公开契约测试也明确要求默认及迁移写入使用 1.3.0。但两份指南仍标为适用于 0.6.5，并称新保存/恢复写入 1.2.0。完整默认模板也未列出已经在同页表格描述的 model_manager 开关。阅读者不能据此得到当前完整设置契约。旧 1.2.0 仍可读取，所以不声称复制旧模板必然导致启动失败。
- **可能的解决办法**：同步两种语言的当前版本、可读取版本、恢复说明和默认模板；从权威默认配置生成或校验文档模板，避免 schema 更新后再次漂移。

## BUG-017

- **编号**：BUG-017
- **标题**：手册检索失败把配置的私有索引绝对路径返回给 MCP 客户端
- **严重性/优先级**：中 / P2；错误脱敏缺口。
- **位置**：`comsol_mcp/knowledge/lexical_worker.py` 的 `error: str(exc)`；`comsol_mcp/knowledge/lexical_manual.py` 的缺失索引错误和 `run_bounded()` 返回未过滤 worker 错误。
- **内容/复现方法**：为公开手册工具配置不存在的 SQLite 索引后，读取或搜索返回包含该本机绝对路径的 FileNotFoundError 字符串。路径来自服务器配置，不是调用者输入；可能暴露用户名和私有目录布局。复现：`python /workspace/code-review/repro_lexical_public.py` 调用真实注册的 manual_read_pages 处理函数并运行实际 worker，输出 missing index error reveals configured path=True。路径泄漏并不等于索引文件内容泄漏。
- **可能的解决办法**：worker 输出稳定的错误码及路径无关消息，详细异常仅写入受控日志；父进程不能把任意 stderr 或异常原文作为公共 error 返回。

## BUG-018

- **编号**：BUG-018
- **标题**：手册页读取只限制页数，未限制文本或子进程输出字节
- **严重性/优先级**：中 / P2；有界检索和内存保护缺陷。
- **位置**：`comsol_mcp/knowledge/lexical_manual.py`，`read_index_pages()` 返回完整 SQLite text；`run_bounded()` 使用 `capture_output=True` 后解析完整 JSON；`lexical_worker.py` 整体序列化结果。
- **内容/复现方法**：最多 20 页的限制不能约束每页文本长度，损坏/异常索引或大文本页面会在 worker、父进程和 MCP 响应中产生大量数据。硬超时不限制这段时间内的内存分配。复现：`python /workspace/code-review/repro_lexical_public.py` 构造一页 2 MiB 的临时合法索引，通过真实公开处理函数和 worker 得到 success=True、one-page text bytes=2097152、response bytes=2097910，无截断或拒绝。不需要求解器或 PDF 手册。
- **可能的解决办法**：规定每页及累计文本预算，并在 SQLite 查询/读取阶段限制过大内容；对子进程 stdout/stderr 使用实际有限读取和有界进程清理。超限时返回明确结果，不依赖页数或超时替代字节上界。

## BUG-019

- **编号**：BUG-019
- **标题**：MPH 条目上界在 ZIP 中央目录完整解析后才生效
- **严重性/优先级**：中 / P2；不可信离线归档的内存保护缺口。
- **位置**：`comsol_mcp/evidence/inspection/archive.py`，`inspect_archive_inventory()` 的 ZipFile 构造与随后 max_entries 检查。
- **内容/复现方法**：ZipFile 初始化已经读取中央目录并为全部条目建立对象，之后才检查条目数。攻击者可在仍低于默认归档字节上界的 .mph 文件中放入大量空条目，使内存分配随未获许可的条目数增长；配置 max_entries 无法阻止该分配。复现：`python /workspace/code-review/repro_mph_central_dir_bound.py`，约 1.92 MB、20000 个空条目的 ZIP，设 max_entries=1，虽然最终返回 mph_too_many_entries，但此前 allocated peak=11700639。公开离线工具允许读取许可根目录中的不可信模型文件；尚未复现系统级内存耗尽。
- **可能的解决办法**：在完整 ZipFile 解析前有界检查 EOCD/ZIP64 计数和中央目录大小，并在实际解析时执行条目预算；不能只信任声明计数。保留最终一致性及输入不可变性检查。

## BUG-020

- **编号**：BUG-020
- **标题**：UTF-16 XML 可以绕过 MPH 的 DTD/实体拒绝规则
- **严重性/优先级**：中 / P2；不可信归档解析策略绕过。
- **位置**：`comsol_mcp/evidence/inspection/summary.py`，`_parse_xml()` 对原始 bytes 的 doctype/entity 子串检查。
- **内容/复现方法**：拒绝规则只搜索连续 ASCII 字节，而 ElementTree 接受 UTF-16 XML。在 UTF-16 编码下，DOCTYPE 和 ENTITY 字节间存在零字节，检查未匹配，解析器随后展开内部实体。复现：`python /workspace/code-review/repro_mph_utf16_dtd.py` 构建两个内容相同的临时 MPH，UTF-8 返回 mph_marker_dtd_rejected，UTF-16 却成功输出实体展开后的 title=entity-was-expanded。实际执行完整 summary builder，无求解器。未验证外部实体访问，且 Python Expat 自带放大限制；不声称任意文件读取或无上界实体炸弹。
- **可能的解决办法**：在解析前严格执行 XML 编码策略并按解码文本拒绝 DTD/ENTITY，或使用真正禁止声明和实体的解析器；对所有支持编码覆盖同一拒绝检查，保留字节和节点预算。

## BUG-021

- **编号**：BUG-021
- **标题**：损坏的 MPH 探测缓存能使终态任务状态查询抛异常
- **严重性/优先级**：中 / P2；警告型辅助功能破坏主状态读取。
- **位置**：`comsol_mcp/evidence/inspection/probe.py`，`_cache_is_current()` 仅检查 probe 非 null，命中分支随后 `**cached_probe`；`comsol_mcp/jobs/manager.py:1359` 未隔离该调用异常。
- **内容/复现方法**：缓存包含匹配的 file_fingerprints，但 probe 为数字/字符串/列表时，缓存验证通过，字典展开抛 TypeError。该函数声明不会抛出，终态 JobManager.status() 又直接调用它，破坏了探测失败不影响主任务状态的契约。复现：`python /workspace/code-review/repro_probe_cache.py` 的 malformed cache escaped=TypeError；不启动求解器。此问题由损坏或外部修改的缓存触发。
- **可能的解决办法**：完整验证缓存与 probe 类型/schema，不可信缓存一律视为 miss；主状态查询也应将辅助探测异常转换成 warning/unavailable，不能改变状态查询的可用性。

## BUG-022

- **编号**：BUG-022
- **标题**：超过四个 MPH 产物时，终态探测缓存永远无法命中
- **严重性/优先级**：中 / P2；重复状态轮询的 IO 和时延缺陷。
- **位置**：`comsol_mcp/evidence/inspection/probe.py`，缓存保存仅记录 candidates[:4]，`_cache_is_current()` 却与全部 candidates 比较长度。
- **内容/复现方法**：目录含五个或更多 MPH 时，即使文件完全未变，保存的 fingerprints 数量为四，后续校验要求等于全部候选数量，导致每次查询重新读取和解析前四个模型。与 B13 声称普通状态读取复用缓存不符，大文件会反复阻塞控制面。复现：`python /workspace/code-review/repro_probe_cache.py` 输出 five-file unchanged cache states=miss miss，第二次没有命中；使用小型无效 MPH 避免大 IO。
- **可能的解决办法**：在保存和验证时使用一致的候选集合，并记录总数/截断状态，使新增、删除或排序变化也能失效；增加五文件和更多文件的缓存命中检查。

## BUG-023

- **编号**：BUG-023
- **标题**：MPH 探测缓存写入跟随符号链接，能覆盖任务目录外文件
- **严重性/优先级**：中 / P2；文件写入和所有权边界缺陷。
- **位置**：`comsol_mcp/evidence/inspection/probe.py`，`cache_path.write_text()` 和未验证链接的缓存读取路径。
- **内容/复现方法**：若 job/mph_probe_summary.json 是指向外部文件的符号链接，探测器读取它，缓存 miss 后直接 write_text，跟随链接覆盖外部文件。JobManager 终态状态查询会调用该探测器，不验证此缓存的文件类型或所有权。复现：`python /workspace/code-review/repro_probe_cache.py` 在 /tmp 中建立任务目录与外部文本文件，输出 external symlink target overwritten=True，同时 probe 返回 available=True。需要能够在任务目录创建/替换链接，不声称无本机文件访问权的远程攻击。
- **可能的解决办法**：缓存使用安全的有界普通文件读取及同目录原子写入，拒绝链接/特殊文件，写前后验证任务目录身份；不直接截断未知身份的现有目标。对清理及替换冲突保留明确结果。

## BUG-024

- **编号**：BUG-024
- **标题**：MPH 探测缓存大小上界在全量读取后检查
- **严重性/优先级**：中 / P2；终态状态查询的内存上界缺陷。
- **位置**：`comsol_mcp/evidence/inspection/probe.py`，`raw = cache_path.read_bytes()` 后的 `_MPH_PROBE_CACHE_BYTES` 检查。
- **内容/复现方法**：声明缓存最大 262144 字节，但先将整个文件读入内存才判断长度。损坏或外部替换的缓存可使任务状态查询分配远超该预算的内存；与 JSON 无效、最终重新生成正常缓存无关。复现：`python /workspace/code-review/repro_probe_cache_bound.py` 使用 8 MiB 临时稀疏缓存，allocated peak=8524240，而返回 probe available=True。没有读取真实模型或启动求解器。
- **可能的解决办法**：打开安全的普通文件描述符后最多读取上界加一字节，对过大缓存直接降级为 miss，并沿用 BUG-023 所需的链接/特殊文件保护。

## BUG-025

- **编号**：BUG-025
- **标题**：模型身份的源/检查点哈希读取不检查读取期间增长，能超过声明字节预算
- **严重性/优先级**：中 / P2；有界 IO 与并发修改的鲁棒性问题。
- **位置**：`comsol_mcp/evidence/model_identity.py`，`_bounded_file_sha256()` 只检查初始 stat，循环累计 digest_bytes 后没有与 max_bytes 比较。
- **内容/复现方法**：文件在 stat 后、打开或读取期间增长时，函数继续读至 EOF，并接受超过预算的字节。公开 profile 的读取固定检查可能在返回前拒绝持续修改，但不能限制已经发生的 IO，持续追加还可能拖延读取结束。复现：`python /workspace/code-review/repro_identity_edges.py` 在真实文件 rb 打开处模拟追加，初始 1 字节通过 max_bytes=8 检查，最终接受 1025 字节。没有启动求解器，也不声称绕过了外层持续变更检测。
- **可能的解决办法**：每次读取前按剩余预算限制块长度，最多读取预算加一字节；增长超限立即返回 source/checkpoint_over_declared_byte_limit，并保留描述符身份及外层读取固定检查。

## BUG-026

- **编号**：BUG-026
- **标题**：被动模型身份把显示名/追踪键当成 Java tag，返回错误身份或拒绝合法模型
- **严重性/优先级**：中 / P2；模型身份准确性和可用性缺陷。
- **位置**：`comsol_mcp/tools/model_identity.py`，`_passive_live_session_provider()` 从 current_model/name 推导 active_model_tag、bound_model_tag；对照 `tools/session.py:1026` 附近的独立 java_tag 字段。
- **内容/复现方法**：SessionManager 状态已明确区分 label、tracking_key 和 java_tag，但被动 provider 忽略 java_tag，直接将 tracking key 当成 ClientAPI tag。追踪键为 FriendlyModel、真实 tag 为 Model1 时，工具错误返回 active_model_tag=FriendlyModel；键为 My Model 时又被 tag 正则拒绝，使原本有效的离线身份请求失败。复现：`python /workspace/code-review/repro_identity_edges.py` 使用真实公开处理函数与无求解器状态替身，输出这两种情况。状态替身包含真实实现提供的 java_tag 字段。
- **可能的解决办法**：用 current_model 定位状态行后读取已缓存的 java_tag，显示名另存 label；tag 不可得时返回结构化 unavailable，不能把显示名猜成 tag。覆盖带空格/Unicode 标签及不同追踪键的情形。

## BUG-027

- **编号**：BUG-027
- **标题**：离线导出封闭 schema 接受未知字段和非法 false 参数对象，原有封印仍通过
- **严重性/优先级**：中 / P2；格式与完整性校验缺口。
- **位置**：`comsol_mcp/evidence/offline_export.py`，`_normalize_structure()` 只检查必需字段子集；`_normalize_artifact()` 的 `raw['parameter_values'] or {}`。
- **内容/复现方法**：向已封印 manifest 添加未知顶层字段，或把合法 parameter_values={} 改成 false，normalize 会分别忽略未知字段或把 false 转成 {}，原有 manifest_sha256 仍通过，validator 返回 valid=True。与其封闭合同及非法字段拒绝的声明不符。复现：`python /workspace/code-review/repro_offline_export_edges.py` 输出 unknown top field accepted with original seal=True 和 false parameters accepted with original seal=True。结果的输入字节绑定仍能反映文件字节不同，因此不声称整个证据链都无法检测变化。
- **可能的解决办法**：顶层只允许合同字段和 manifest_sha256；参数对象只允许 Mapping 或明确的 null，不按真假值进行类型归一化。对非法输入先拒绝，再计算规范哈希。

## BUG-028

- **编号**：BUG-028
- **标题**：CSV 离线验证不核对实际列顺序或单位，却给出 valid 结果
- **严重性/优先级**：中 / P2；声称的导出完整性验证范围没有实现。
- **位置**：`comsol_mcp/evidence/offline_export.py`，artifact 文本分支只检查 UTF-8 和非空；`_ordering_fingerprint()` 只封印 manifest 自己声明的 columns。
- **内容/复现方法**：文件列为 T[K],wl[nm]，manifest 却声明 wl[m],T[K]。两者显然顺序及单位不一致，只要 manifest 内的声明指纹与文件哈希各自正确，就返回 valid=True，没有比较文件表头。模块声明会从产物字节重新推导可检查事实并拒绝单位/顺序漂移，但实际仅检测 manifest 声明被单独改动而未更新其指纹。复现：`python /workspace/code-review/repro_offline_export_edges.py` 输出 CSV contradictory order/units accepted=True。仍明确不是 FEM/科学验证；问题在于没有实现所称的离线表格完整性检查。
- **可能的解决办法**：为支持的 CSV/TXT 格式解析有界列及单位声明，并和 manifest 逐项比对；不支持该文件布局时明确返回 hash-only/unsupported，不能把声明一致性和字节哈希通过表述为已验证实际列语义。

## BUG-029

- **编号**：BUG-029
- **标题**：离线导出 manifest 字节限制在全量读取后才检查
- **严重性/优先级**：中 / P2；不可信产物读取的内存保护缺陷。
- **位置**：`comsol_mcp/evidence/offline_export.py`，路径输入分支 `path.read_bytes()` 后的 max_manifest_bytes 检查。
- **内容/复现方法**：许可产物目录中的 manifest 即使远超声明预算，仍先全量读入内存再返回 manifest_too_large。有效路径固定检查不能替代字节上界。复现：`python /workspace/code-review/repro_offline_export_edges.py` 使用 8 MiB 临时稀疏文件、1024 字节上界，allocated peak=8396854。不读取真实证据或启动求解器。
- **可能的解决办法**：在已固定的描述符上做限制读取，最多读预算加一字节；超限立即拒绝。产物哈希也应采用流式累计上界，避免 stat 后增长导致全量分配。

## BUG-030

- **编号**：BUG-030
- **标题**：离线导出拒绝回执在哈希后追加字段，封印与返回内容不一致
- **严重性/优先级**：中 / P2；错误结果的证据完整性缺陷。
- **位置**：`comsol_mcp/evidence/offline_export.py`，`_invalid_verdict()` 先计算 validation_sha256，多个早退分支随后追加 detail/path_evidence。
- **内容/复现方法**：例如过大 manifest 分支先取得已封印拒绝回执，再写入 path_evidence 后直接返回。调用者按与正常回执相同的规则重算除 validation_sha256 外的内容，哈希不匹配，导致合法拒绝结果被判为损坏。路径拒绝、无效 JSON 和部分 schema 失败也有同类顺序。复现：`python /workspace/code-review/repro_offline_export_edges.py` 输出 rejection verdict seal matches returned body=False，reason=manifest_too_large。
- **可能的解决办法**：统一在所有字段、错误详情及路径证据构造完后封印；正常和拒绝结果使用同一最终化步骤。覆盖各早退分支的返回体哈希一致性。

## BUG-031

- **编号**：BUG-031
- **标题**：公共 schema 收紧把动态字典变成只能为空，禁止运行时合法的作业参数
- **严重性/优先级**：高 / P1；协议发现契约与可用输入不一致，影响多个工作流。
- **位置**：`comsol_mcp/contracts/structural.py`，`bounded_public_schema()` 把 additionalProperties=True 改为 False；`contracts/job_submission.py` 的 BoundedObject 字段和 `tools/profiles.py` 的发布 schema 调用。
- **内容/复现方法**：dict[str, Any] 的 Pydantic schema 本应允许动态键。收紧后变成 type=object、additionalProperties=False，却没有 properties/patternProperties，所以所有非空字典都非法。运行时仍接受物理边界、资源策略、矩阵点等动态键；遵循发现 schema 的客户端会拒绝或无法生成这些必要输入。复现：`python /workspace/code-review/repro_schema_map.py` 对真实 create_server('core') 的 job_spec_preview schema 和同一作业运行时合同做对照，runtime 接受非空 physical_bounds，而发布 schema 输出 {'additionalProperties': False, 'maxProperties': 256, 'type': 'object'}，非空键均被禁止。未提交任务或启动求解器。
- **可能的解决办法**：区分有固定字段的封闭对象与动态映射；对映射保留受限的 additionalProperties 值 schema、propertyNames 和 maxProperties，或改成可精确描述的类型合同。用同一批合法/非法输入交叉验证发布 JSON Schema 和运行时合同，不能只检查所有对象都闭合。

## BUG-032

- **编号**：BUG-032
- **标题**：Debian 上既有 FIFO 锁文件使 JobLock 超时失效并永久等待
- **严重性/优先级**：中 / P2；状态、取消和恢复操作的阻塞风险。
- **位置**：`comsol_mcp/jobs/store.py`，`JobLock.acquire()` 的 FileExistsError 分支使用 `self.path.read_bytes()`。
- **内容/复现方法**：已有路径为 FIFO 且没有写者时，read_bytes 在打开时阻塞，后续 deadline 检查无法执行。相关 JobLock 保护任务状态与资源日志，状态查询或取消可能因此无限等待。复现：`python /workspace/code-review/repro_job_store_edges.py` 创建临时 FIFO，在隔离子进程中以 timeout=0.2 获取锁，2 秒后仍未结束；脚本随后杀死并回收该子进程。需要能够替换锁路径或遗留特殊文件。
- **可能的解决办法**：使用非阻塞、拒绝链接的描述符打开并立即验证普通文件，再做有界读取和身份比较；对不合类型的路径拒绝而非进入正常旧锁恢复。覆盖没有写者的 FIFO。

## BUG-033

- **编号**：BUG-033
- **标题**：job_tail 只限制行数，单行日志仍可产生任意大的响应
- **严重性/优先级**：中 / P2；控制面响应和读取工作量没有有效字节上界。
- **位置**：`comsol_mcp/jobs/store.py`，`JobStore.tail()` 顺序扫描整个 events.jsonl/worker.log 并保留完整尾行。
- **内容/复现方法**：n 即使为 1，只要 worker.log 含一条巨长行，返回内容仍全部包含；它还从头扫描全文件才能得到末尾，轮询成本随日志总长度增长。公开 job_tail 的 200 行上界不能满足仓库要求的有界响应。复现：`python /workspace/code-review/repro_job_store_edges.py` 创建不启动 worker 的正常存储任务，写一条 2 MiB 日志，输出 one-line tail response log bytes=2097152。没有改动真实任务或模型。
- **可能的解决办法**：增加每行与总响应字节预算，明确截断信息；从文件尾部按有限窗口读取，并限制事件解析/扫描工作量。对追加中的半行和多字节文本定义稳定行为。

## BUG-034

- **编号**：BUG-034
- **标题**：JobStore 只校验任务路径的父目录，链接任务目录可把读取/写入导向运行根外
- **严重性/优先级**：中 / P2；运行目录所有权与文件边界缺陷。
- **位置**：`comsol_mcp/jobs/store.py`，`JobStore.job_dir()` 比较 path.parent.resolve()，没有验证任务目录自身；`write_control()`、`read_state()` 和 `tail()` 直接使用该路径。
- **内容/复现方法**：在 jobs 根内创建合法 job ID 名称的目录链接，指向根外目录。job_dir 校验通过；write_control 随后在外部目录原子替换 control.json，tail/read_state 同样可读取外部对应文件。部分带锁路径有额外 POSIX 锁祖先检查，但这些直接读写方法没有得到同等保护。复现：`python /workspace/code-review/repro_job_store_edges.py` 在临时根外文本上验证 symlink job directory wrote outside root=True。需要能在运行根内放置目录链接；不声称所有 MCP 写操作均可绕过其他锁检查。
- **可能的解决办法**：验证任务目录自身与所有祖先为许可根下的真实普通目录，拒绝链接/junction，并在操作期间固定目录身份；直接方法也必须沿用同一边界，不能只依赖调用者是否取得锁。

## BUG-035

- **编号**：BUG-035
- **标题**：任务错误包装返回原始存储异常，泄漏配置的运行目录
- **严重性/优先级**：中 / P2；公共错误脱敏缺口。
- **位置**：`comsol_mcp/tools/jobs.py`，`_job_call()` 的 `error: str(exc)`；`jobs/store.py` 的 read_json() 将绝对 artifact path 拼入 RuntimeError。
- **内容/复现方法**：job_status 查询不存在的合法 job ID 时，真实 JobManager 的存储错误包含服务配置的 jobs 根路径；公共包装原样发送给 MCP 客户端，暴露本机目录/用户名。复现：`python /workspace/code-review/repro_job_store_edges.py` 调用真实注册的 job_status 与无 worker JobManager，输出 job error reveals configured runtime path=True。运行目录不是此次请求中用户提交的路径。
- **可能的解决办法**：将存储和任务异常映射到稳定错误码与路径无关消息；详细异常仅进入日志，避免公共 job_submit/status/resume/cancel 及 handoff recovery 重复使用 str(exc)。

## BUG-036

- **编号**：BUG-036
- **标题**：证据设置重复读取可把无效的新配置报告为可严格验证
- **严重性/优先级**：中 / P2；配置错误的 fail-closed 判定存在竞态。
- **位置**：`comsol_mcp/evidence/integrity_controls.py:208`，先调用 settings_status()，再调用 load_settings()，两者各自读取配置文件。
- **内容/复现方法**：第一次读取有效配置后，外部配置写入者原子替换为错误 JSON；第二次读取返回安全默认值，但该次读取的 errors 被丢弃。结果依据第一次的无错误状态报告 configuration_state=valid、strict_verification_active=True。相同文件随后正常调用则报告 degraded、False。复现：`python /workspace/code-review/repro_integrity_settings_race.py` 使用真实配置读取函数，只在两个读取之间原子替换临时配置，不启动 COMSOL。这会在配置错误时违反正式验证应阻断的约定；不声称能伪造具体物理证据。
- **可能的解决办法**：只调用一次 load_settings_report()，用同一个 report 同时计算有效 checks、错误状态和 fingerprint，避免把不同快照混成一份回执；加入原子配置替换的回归场景。

## BUG-037

- **编号**：BUG-037
- **标题**：证据完整性指南宣称所有 profile 均有 guard 工具，与无 COMSOL profile 不符
- **严重性/优先级**：低 / P3；Linux 离线操作指南不可执行。
- **位置**：`docs/evidence_integrity/README.md:41`；实际选择表为 `comsol_mcp/tools/catalog.py:1132`。
- **内容/复现方法**：指南声明 evidence_integrity_status 和 evidence_integrity_verify 在 every static profile 可用，并要求先调用这些工具。实际 comsolless_read_only 仅注册 mph_inspect、mph_diff、model_identity、runtime_compatibility_status、offline_export_validate，没有上述两个工具。Linux 离线用户按该指南无法完成验证。直接对照静态 profile 表即可确认，不需要求解器。指南的默认 artifact root 描述也需随当前平台默认值核对。
- **可能的解决办法**：明确列出适用 profile 和离线 profile 的限制；如设计确实要求所有 profile 支持，则增加 solver-free 注册及相应 profile/安装入口测试。按实际平台更新默认路径说明。

## BUG-038

- **编号**：BUG-038
- **标题**：正式验证 MCP 适配器在封存后修改回执，返回的验证哈希不覆盖完整回执
- **严重性/优先级**：中 / P2；离线重验和回执完整性契约不一致。
- **位置**：`comsol_mcp/tools/evidence_integrity.py`，两处向 verify_evidence_integrity() 已封存结果追加 artifact_root_validation；`evidence/integrity_verifier.py` 的 _finalize() 对整个 body 求哈希。
- **内容/复现方法**：调用真实注册的 evidence_integrity_verify，返回 strictly_verified=True，但去除 verification_sha256 后计算 canonical_sha256 与返回 digest 不符；再删除适配器添加的 artifact_root_validation 才匹配。阻断分支也在封存后追加字段。复现：`python /workspace/code-review/repro_integrity_receipt.py` 使用既有有效 portfolio fixture、临时 owned root 和真实工具函数，不启动 COMSOL。当前返回结构没有声明这个字段位于 hash scope 之外，客户端按原始 body 算法不能验证最终回执。
- **可能的解决办法**：先构造完整回执再统一封存，或明确以独立 envelope 包装未修改的 sealed receipt；约定哈希范围，并测试生产适配器返回内容的可重验性。

## BUG-039

- **编号**：BUG-039
- **标题**：单独启用 summary 验证时，引用文件在字节数检查前被无界读取
- **严重性/优先级**：中 / P2；探索模式仍启用的检查存在内存上界缺口。
- **位置**：`comsol_mcp/evidence/portfolio_verifier.py`，_read_cited_artifact() 的 path.read_bytes()；verify_portfolio_evidence_checks() 在 chain 检查关闭时使用该分支。
- **内容/复现方法**：显式关闭 artifact_chain_verification 而保留 summary_claim_verification 属于支持的探索模式。manifest 虽限制声明大小，真实文件被替换为巨型文件时，此分支先读入全部字节，再检查 byte_count/hash。复现：`python /workspace/code-review/repro_integrity_receipt.py` 把原本小型 raw JSON 换为 8 MiB，结果在拒绝字节数之前峰值分配约 8.43 MB。默认同时启用 chain 的分支有有界读取；缺陷只针对该支持的 opt-out 路径，不声称修改文件能通过哈希验证。
- **可能的解决办法**：引用读取复用有界文件快照函数，按 artifact.byte_count 和 MAX_ARTIFACT_BYTES 限制累计读取量；拒绝异常文件类型并保留读取身份校验。关闭某项完整性检查不应关闭 IO 上界。

## BUG-040

- **编号**：BUG-040
- **标题**：operation arbiter 缓存对 Linux 路径做 casefold，混淆不同运行目录
- **严重性/优先级**：中 / P2；Linux 运行目录隔离和锁身份错误。
- **位置**：`comsol_mcp/operation_arbiter.py:312`，get_operation_arbiter() 用 str(default_runtime_dir().resolve()).casefold() 构造缓存键。
- **内容/复现方法**：POSIX 上 Runtime 与 runtime 是不同真实目录。同一进程先后按这两个配置请求 arbiter，会复用第一个实例，使第二次仍读取/写入 Runtime/operation.lock，无法体现当前配置或正确隔离状态。复现：`python /workspace/code-review/repro_operation_linux.py` 创建两个临时真实目录，输出 distinct POSIX roots shared arbiter=True、second arbiter points to requested root=False。没有启动或操作 COMSOL；不声称两个独立进程一定共享该进程内缓存。
- **可能的解决办法**：保留 POSIX 路径大小写，以平台适当的路径身份构建键；若允许运行根变化，确保缓存实例与请求根一致。加入大小写不同真实目录的 Debian 测试。

## BUG-041

- **编号**：BUG-041
- **标题**：operation lock 普通读取没有类型和字节上界，Debian FIFO 使 fail-fast 状态永久阻塞
- **严重性/优先级**：中 / P2；控制面与 COMSOL 操作门禁的可用性风险。
- **位置**：`comsol_mcp/operation_arbiter.py`，_read_lock()、发布验证与 release() 的 lock_path.read_bytes()。
- **内容/复现方法**：inspect()/既有锁的 try_acquire() 直接 read_bytes；锁路径是没有写者的 FIFO 时，打开就无限阻塞，无法返回所宣称 fail-fast 的 uncertain/busy 回执。普通大文件则全部读入、解码后才拒绝。复现：`python /workspace/code-review/repro_operation_linux.py` 隔离子进程的 inspect 在 2 秒后仍阻塞，随后杀死并回收；8 MiB malformed lock 的内存峰值约 16.78 MB。需要能替换运行目录内锁路径或出现异常残留；与 BUG-002 的 unlink 和 BUG-032 的 JobLock 是独立入口。
- **可能的解决办法**：在打开时使用非阻塞、拒绝链接的描述符，验证普通文件并有界读取；inspect/acquire/publication/release 复用同一安全快照原语；对异常路径即时返回 uncertain，测试 FIFO 与巨型文件。

## BUG-042

- **编号**：BUG-042
- **标题**：runtime compatibility 工具遗漏已启用的 model_manager feature
- **严重性/优先级**：中 / P2；公开运行配置与 registry 身份不一致。
- **位置**：`comsol_mcp/tools/compatibility_registry.py:66`，enabled_features 使用固定三个旧 feature 名称而非 FEATURE_NAMES。
- **内容/复现方法**：以 COMSOL_MCP_ENABLE_MODEL_MANAGER=true 创建真实 core server，启动选择包含 model_manager 并注册对应工具；调用 runtime_compatibility_status 却返回 registry.profile.enabled_features=[]。registry_sha256 因而也没有绑定这项实际启用的配置。复现：`python /workspace/code-review/repro_registry_features.py` 输出真实注册数量与 startup/registry features 对照；不启动 COMSOL。原有测试只验证 lexical_docs 等旧 gate，未覆盖新增 gate。
- **可能的解决办法**：从唯一 feature 名称表和已验证 ProfileSelection 获取全部 enabled_features，避免重复写静态列表；测试每个 gate 和组合的真实公开 dispatch。

## BUG-043

- **编号**：BUG-043
- **标题**：适配器矩阵大小限制在复制全部单元后才执行
- **严重性/优先级**：中 / P2；转换内存与读取工作量缺少有效上界。
- **位置**：`comsol_mcp/adapter/conversion.py:86`，to_matrix_rows() 先 rows.append(list(row))，最后才检查 MAX_MATRIX_ELEMENTS；normalize_evaluation_result() 也会提前 tolist/list。
- **内容/复现方法**：模块声称 oversized matrix 在 materialize 前拒绝，但传入长 Sequence 时会复制整个输入再报错。复现：`python /workspace/code-review/repro_adapter_conversion.py` 使用轻量 CountingRow，长度 MAX_MATRIX_ELEMENTS+1，输出拒绝前已读取并复制 1048577 个单元。限制无法阻止更大的懒序列被分配到内存。公开 structural guard 可限制部分直接请求，但不能代替后端返回值转换自己的预算。
- **可能的解决办法**：根据 Sequence 长度先验证行数、宽度和累计预算；逐行转换前检查预算并拒绝 ragged；numpy 等后端先检查 shape/size 再 tolist，避免预处理阶段绕过限制。

## BUG-044

- **编号**：BUG-044
- **标题**：声称精确的 int 到 float 转换会静默改变大整数
- **严重性/优先级**：中 / P2；严格数值转换与回读一致性风险。
- **位置**：`comsol_mcp/adapter/conversion.py:57`，require_float() 直接 float(value)，仅检查 finite；文档称 int widening is exact。
- **内容/复现方法**：convert_explicitly(2**53+1, form='float') 成功，却将 9007199254740993 变为 9007199254740992.0，没有拒绝或精度损失标记。复现：`python /workspace/code-review/repro_adapter_conversion.py` 输出 conversion changed numeric value=True。Python 任意精度 int 并不总能由 IEEE double 精确表达；本转换层的“不隐式掩盖数值差异”承诺不成立。不声称本场景已造成真实 COMSOL 科学结果错误。
- **可能的解决办法**：对 int 检查转换后是否保持精确值，不可表达则以 conversion_not_representable 拒绝；或定义显式允许舍入的独立转换模式并记录损失，不能作为精确转换静默接受。

## BUG-045

- **编号**：BUG-045
- **标题**：浮点转换溢出逃逸为原始 OverflowError，未返回适配器稳定错误
- **严重性/优先级**：低 / P3；异常契约与鲁棒性缺口。
- **位置**：`comsol_mcp/adapter/conversion.py:65`，require_float() 的 float(value) 没有处理 OverflowError。
- **内容/复现方法**：convert_explicitly(10**400, form='float') 在 finite 校验之前抛原始 OverflowError，而非该转换模块承诺的 AdapterError(conversion_not_representable)。复现：`python /workspace/code-review/repro_adapter_conversion.py` 输出 overflow raised stable AdapterError=False。调用方只处理 AdapterError 时不会沿正常拒绝路径返回；不把外层可能捕获原始异常表述为整个 MCP 必然崩溃。
- **可能的解决办法**：在 float 转换处捕获溢出并映射稳定 AdapterError，覆盖正负超大 int；让不可表达数值的所有拒绝沿统一契约返回。

## BUG-046

- **编号**：BUG-046
- **标题**：MPh 后端调用不存在的 Client.versions，丢弃已知 COMSOL 版本
- **严重性/优先级**：中 / P2；session identity 和运行兼容性事实缺失。
- **位置**：`comsol_mcp/adapter/mph_backend.py:239`，session_identity() 调用 client.versions() 并在异常时返回 comsol_version=None。
- **内容/复现方法**：已安装 MPh Client 的版本通过 self.version 保存，类中没有 versions() 方法。正常客户端也总会触发这个异常分支，已知版本被标为未知。复现：`python /workspace/code-review/repro_adapter_backend.py` 静态解析已安装 MPh client.py 确认方法不存在，再以相同接口的被动 client 验证 version='6.4' 时 adapter COMSOL version=None；没有构造真实 client/JVM。其他 session 工具可有独立版本读取，不把本缺陷扩展为全服务器均无版本。
- **可能的解决办法**：使用实际 MPh Client.version 接口读取活动版本，并明确该值是否包含完整 build；无法证明的 build 保留 unknown。用真实 dependency API shape 校验 adapter，而非仅测试 fake backend。

## BUG-047

- **编号**：BUG-047
- **标题**：MPh typed property read 对任何 form 都调用 getString，使非字符串类型无法正常读取或规划写入
- **严重性/优先级**：中 / P2；声称的数值与矩阵属性转换功能不成立。
- **位置**：`comsol_mcp/adapter/mph_backend.py:491`，read_property() 无条件 java.getString(name)；plan_write() 用该函数捕获 previous。
- **内容/复现方法**：getString 的正常结果是字符串，严格 convert_explicitly 对 form=float/int/bool/matrix 会拒绝字符串。因此有合法 getDouble 等 typed accessor 的数值属性也无法通过该入口读取；plan_write 同样无法捕获数值 previous。复现：`python /workspace/code-review/repro_adapter_backend.py` 使用遵守 typed accessor 语义的替身，getString 返回 '0.1'、getDouble 返回 0.1，实际后端 read_property(form='float') 报 property_type_mismatch。既有数值 parity/rollback 测试使用 FakeComsolBackend，并未覆盖生产实现；未进行 licensed COMSOL 验收。
- **可能的解决办法**：按请求 form 分派对应 ClientAPI accessor，再显式转换/解包；矩阵和数组需保持形状与预算。测试生产 MphBackendBase 与真实 accessor 返回类型的一致性，保留字符串表达式和数值属性的区别。

## BUG-048

- **编号**：BUG-048
- **标题**：后台求解启动或有限等待返回后即释放 operation lock，模型修改可与仍在运行的求解并发
- **严重性/优先级**：高 / P1；COMSOL 单操作串行化与模型状态一致性缺陷。
- **位置**：`comsol_mcp/operation_arbiter.py`，guard_tool_call() 的 finally 立即 release；`comsol_mcp/tools/study.py` 的 solve_study(wait=False/finite timeout) 与 study_solve_async()；`async_handler/solver.py` 的 worker 没有继承该 claim。
- **内容/复现方法**：guard 只保护启动调用的持续时间，后台 study.run 尚未结束，launch 已返回并释放锁。下一次 param_set 等 COMSOL-bound 调用可获得同一锁；这些工具不会统一检查 async_solver.is_running。有限等待超时也存在同样路径。复现：`python /workspace/code-review/repro_async_operation_gate.py` 使用真实 solve_study、AsyncSolver 和 durable guard，仅把 Java study.run 替换为有界 Event 等待；输出 background solve still running=True、lock=idle、concurrent guarded mutation accepted=True，最后释放并回收线程。没有在 Debian 绕过平台守卫启动真实 COMSOL；证明的是支持宿主上的门禁生命周期逻辑错误。
- **可能的解决办法**：后台求解必须持有 operation claim 至实际 native 调用终止，并在完成/失败回调中验证释放；有限等待返回不得释放 worker 的执行所有权。或取消该后台路径，统一使用具备生命周期所有权的 durable job。测试 solve 返回后及超时后模型修改仍被拒绝，而控制面查询/取消可响应。

## BUG-049

- **编号**：BUG-049
- **标题**：场图渲染失败清理会删除并发写入者的输出，worker 发布也缺少独占保护
- **严重性/优先级**：中 / P2；已有证据文件保留与输出所有权风险。
- **位置**：`comsol_mcp/evidence/field_render.py` 的 png_path.exists() 预检及 except 后无条件 unlink；`field_plot_worker.py` 使用 os.replace(temporary, output)。
- **内容/复现方法**：预检仅证明输出当时不存在，没有为本次渲染保留名字或绑定文件身份。其他写入者在预检后发布同名文件，即使 worker 根本没启动，异常清理也会删除该文件；若 worker 成功则 os.replace 可覆盖该并发文件。复现：`python /workspace/code-review/repro_field_render_cleanup.py` 在真实协调器 Popen 边界模拟一次并发发布及创建进程失败，输出 concurrently published output survived=False；没有启动 renderer/COMSOL。需要同一 output root 的并发写入，不能从此推断远程任意文件删除。
- **可能的解决办法**：输出使用本次运行独占命名空间，或先取得独占保留并按精确身份发布；清理仅删除由本次操作创建且身份一致的文件。worker 发布不可无条件替换预检后出现的外部文件。

## BUG-050

- **编号**：BUG-050
- **标题**：操作账本在半行后继续追加会丢失全部 replay 状态，损坏账本还允许已接受产物再次接受/恢复
- **严重性/优先级**：中 / P2；持久记录恢复和幂等决策失效。
- **位置**：`comsol_mcp/durable/operation_ledger.py`，append()、_read_report()、replay()、evaluate_acceptance()/evaluate_resume()；append_jsonl_record() 不处理 trailing partial row。
- **内容/复现方法**：正常成功记录后模拟崩溃留下未换行 JSON；账本识别 incomplete，但允许直接追加，导致半行与新行拼成损坏行。read_complete_jsonl 返回 corrupt/records=[]，_read_report 只拒绝 oversized，于是所有历史 accepted/latest 状态消失；evaluate_acceptance 返回 accept=True、verified=True，evaluate_resume 返回 no_prior_attempt。复现：`python /workspace/code-review/repro_operation_ledger_recovery.py` 重开同一临时账本，输出 replayed rows=0 和上述错误允许决策。账本用于 Model Manager 记录；目前没有证据说明生产调用者实际调用这些决策 helper 重复执行 native 操作，影响表述限定为账本记录与决策 API。
- **可能的解决办法**：损坏账本必须拒绝正常追加和任何肯定接受/恢复结论；半行需在保持完整前缀、验证文件身份并持锁的恢复流程中隔离，再允许追加。保留 corruption/uncertainty 证据，不得把不可读历史等价为空历史。测试半行之后再 append/reopen，而非只测试单次 partial-tail 读取。

## BUG-051

- **编号**：BUG-051
- **标题**：冷 semantic_status 未校验部署标识长度，可远超公开响应预算
- **严重性/优先级**：中 / P2；语义服务冷状态的内存与协议上界缺口。
- **位置**：`comsol_mcp/knowledge/semantic_runtime.py`，_lightweight_deployment_identity() 的无界 read_text/read_bytes 与非空字符串检查；SemanticService.status() 原样返回 build_id 等字段。
- **内容/复现方法**：semantic_contracts 声明 maximum_response_bytes=65536 且 build ID 有 80 字符模式，但冷 status 不使用这些验证/预算。配置部署的 pointer/manifest 含相同 2 MiB build_id、正确 manifest hash，semantic_status(warm=False) 就返回约 2.098 MB JSON，且未启动任何 worker。复现：`python /workspace/code-review/repro_semantic_status_bound.py` 调用真实注册的公开 tool 和真实 Service；仅使用临时损坏部署 fixture，不下载模型/手册。即使 available=False，响应仍全量复制超大标识；不把该 fixture 说成可通过完整 worker index 验证。
- **可能的解决办法**：lightweight identity 读取也应用独立文件字节上界和部署身份字段校验，错误返回固定短消息；公开 status/search 的错误、deployment 与 configuration 分支都检查最终响应预算，不能只依赖 worker query 的限额。

## BUG-052

- **编号**：BUG-052
- **标题**：Debian semantic worker reset 仅终止主进程，却报告完整清理，遗留子进程
- **严重性/优先级**：中 / P2；Linux 子进程所有权和资源回收缺陷。
- **位置**：`comsol_mcp/knowledge/semantic_process.py`，_terminate_owned()/_terminate_unverified_spawn()；POSIX 分支没有进程组或后代身份清理，仅 Popen.terminate()/kill()/poll()。
- **内容/复现方法**：公开 reset 声称停止 exact recorded worker tree，但 POSIX 上 absent 只检查主 worker。worker 派生一个子进程时，reset 返回 success=True、absent=True，子进程仍运行。复现：`python /workspace/code-review/repro_semantic_process_edges.py` 使用真实 manager 启动本审查的有界测试 worker，子进程为最多 20 秒的 Python 等待，输出 recorded descendant still alive=True；随后按 PID/create_time 清理测试子进程。Windows Job Object 分支独立；不把 Windows 机制当作 Linux 验证。未下载 ML 模型或启动 COMSOL。
- **可能的解决办法**：Linux 启动时建立拥有的进程组/session，并持久捕获/校验后代身份；reset、启动失败和超时路径清理整棵拥有树并验证无残留，保留无法证明的 uncertain 状态。不得仅用主进程退出推导 tree absent。

## BUG-053

- **编号**：BUG-053
- **标题**：semantic worker 启动握手 readline 无字节上界，巨型握手被完整读入并接受
- **严重性/优先级**：中 / P2；启动协议的内存上界缺口。
- **位置**：`comsol_mcp/knowledge/semantic_process.py`，start() 中 startup_reader 的 stdout.readline()、json.loads()，未限定握手大小。
- **内容/复现方法**：普通请求/响应 socket 有字节限额，但初始 stdout 握手没有。具备正确 schema/event/PID/host/port 的 2 MiB 握手包含巨大 padding 字段，会被完整读取、解析并视为 startup success。缺少换行的异常 worker 则可持续向 readline 内存累积直到时间超限。复现：`python /workspace/code-review/repro_semantic_process_edges.py` 启动本审查的有界测试 worker，输出 2 MiB startup handshake accepted=True；随后 reset 回收。仅证明 worker 异常输出时的父进程上界失效，不声称需要网络攻击才能触发。
- **可能的解决办法**：使用独立且较小的握手字节预算，以 bounded readline/增量读取拒绝超限和未终止记录；验证闭合握手字段。读取线程及超时清理必须在拒绝后可靠结束，加入 stdout 巨型半行与完整巨型行测试。

## BUG-054

- **编号**：BUG-054
- **标题**：cosine 索引未强制向量归一化，检索按点积错误排序并返回负距离
- **严重性/优先级**：中 / P2；语义检索结果和距离含义错误。
- **位置**：`comsol_mcp/knowledge/semantic_index.py:457`，build_index 直接保存 encoder 值，validate_index_directory 仅检查有限值；`comsol_mcp/knowledge/semantic_retrieval.py:249`，_vector_candidates 只归一化 query 后计算点积。
- **内容/复现方法**：Encoder 协议允许有限 float32-compatible 矩阵，没有单位长度要求；构建结果声明 distance_metric=cosine，却接受不同范数甚至零向量。复现：`python /workspace/code-review/repro_semantic_cosine.py` 通过真实 pin/build/validate/HybridRetriever 流程保存 [1,0] 与 [10,10]，query=[1,0]。实际第 2 页排第一、similarity=10、distance=-9；正确 cosine 应第 1 页在前，相似度分别 1 与约 0.7071。测试 encoder 不加载 ML 或 COMSOL。默认 SentenceTransformerEncoder 当前主动归一化，因此该正常默认路径不受此次非单位向量复现影响；公开 encoder 接口及已验证外部索引仍存在缺口。
- **可能的解决办法**：构建时检查非零范数并统一归一化；验证 cosine 索引所有向量单位长度，或检索时按两侧范数计算 cosine。根据 manifest metric 明确选择算法，不能接受 l2/inner_product 后仍套用 cosine 含义。

## BUG-055

- **编号**：BUG-055
- **标题**：激活和加载索引未核对词法语料引用，不存在的手册页仍被标为 validated
- **严重性/优先级**：中 / P2；检索引用验证声明不成立。
- **位置**：`comsol_mcp/knowledge/semantic_index.py` 的 switch_current()/read_current()；`comsol_mcp/knowledge/semantic_retrieval.py` 的 HybridRetriever.__init__() 与 fuse_candidates()。
- **内容/复现方法**：build_index 调用 validate_index_against_lexical，但独立激活与运行时只检查索引内部 hash、chunk ID 和词法数据库 hash，不检查 chunk 的 source/page 是否存在于该数据库。复现：`python /workspace/code-review/repro_semantic_cosine.py` 第二部分用临时部署修改 chunk 引用为 AbsentManual.pdf 第 999 页，并更新该索引内部 hash/ID。独立 lexical proof 正确拒绝；真实 switch_current 接受，新 HybridRetriever 却返回该不存在引用且 citation_integrity=validated。需要部署中出现内部自洽但引用错误的索引；正常 build_index 生成路径有独立校验，不声称任意 bit corruption 可绕过 hashes，也不把人为更新 manifest 说成破解 hash。
- **可能的解决办法**：在加载或激活阶段调用跨语料引用校验，并把校验绑定到当前词法数据库和索引身份；查询时引用的 pinned proof 应来自该跨语料校验，不能仅来自待验证索引自身。加入内部 hash 正确但 source/page 不在词法语料中的加载测试。

## BUG-056

- **编号**：BUG-056
- **标题**：电静力快速指南返回不存在的工具名 physics_add_electrostatic
- **严重性/优先级**：低 / P3；公开知识接口的可执行指引错误。
- **位置**：`comsol_mcp/knowledge/embedded.py`，TOPIC_GUIDES["electrostatics"]["physics"] 与 get_physics_guide() 的 tool_to_add 拼接。
- **内容/复现方法**：physics_get_guide("electrostatics") 返回 success=True、tool_to_add=physics_add_electrostatic；实际注册函数和 catalog 名称为 physics_add_electrostatics。复现：`python /workspace/code-review/repro_embedded_guide.py` 调用真实 helper 并解析实际函数，推荐名称存在性 False、正确名称存在性 True。basic_fem/full 中也没有该单数别名，依照返回指南调用会失败。
- **可能的解决办法**：知识指南显式保存真实工具名称，或修正 electrostatics 映射；核对所有 tool_to_add 与实时注册 catalog，避免通过不受校验的拼接推导名字。

## BUG-057

- **编号**：BUG-057
- **标题**：adapter 直接调用清单错误排除 integration probes，全面扫描声明有遗漏
- **严重性/优先级**：中 / P2；迁移门禁覆盖缺口。
- **位置**：`comsol_mcp/adapter/migration_inventory.py`，PROBE_ROOTS、EXCLUDED_PREFIXES 与 measure_repository()；`development_kit/tests/test_adapter_migration_inventory.py` 的范围测试。
- **内容/复现方法**：模块声明扫描 development_kit/tests/integration，_scanned_files 也收集它，但随后 relative.startswith("development_kit/tests/") 将所有 integration 文件排除。实际 wave_optics_preflight_acceptance.py 单文件测量有 4 个直接位点，却不出现在仓库清单。复现：`python /workspace/code-review/repro_inventory_scope.py`，临时 integration/probe.py 有 2 个位点、inventory=()，结果 measured_module_count=0、violations=[]。范围测试用 scripts OR integration，且仅比较前缀字符串的反向关系，因此不能发现 integration 未被扫描。此条是声明范围和质量门禁问题，不说明这些显式 licensed probes 本身不应直调 COMSOL。
- **可能的解决办法**：普通测试排除规则明确豁免 integration 根；每个声明扫描根分别要求实际被测量。以 integration synthetic tree 验证缺失 disposition 会报错，并验证真实已知 probe 被纳入清单。

## BUG-058

- **编号**：BUG-058
- **标题**：Model Manager 读取不存在的会话身份字段，已连接会话仍被判定无连接
- **严重性/优先级**：高 / P1；公开 Model Manager 操作入口不可用。
- **位置**：`comsol_mcp/tools/model_manager.py:69`，_runtime()；`comsol_mcp/shared_session/lifecycle.py` 的 SharedSessionManager.status()。
- **内容/复现方法**：生产 status 输出 server_identity_sha256/session_acquisition_id，没有 model_tag/server_identity；_runtime 只读后两者，始终得到 None，_require_session 因而拒绝所有操作。复现：`python /workspace/code-review/repro_model_manager_wiring.py` 保留真实 manager/status 和公开 adapter，只替换本地内存连接状态，不创建客户端。status attached=True 且 server hash 有值，runtime session_identity=null，open 抛 no_attached_session。没有执行真实 COMSOL 或网络连接；接口字段不匹配可静态确认，与 licensed host 无关。
- **可能的解决办法**：从真实 status 的稳定身份字段构造会话上下文，绑定 acquisition 和 server 身份；用生产 manager.status 形状测试公开工具，不能只向纯 runtime 注入人为 session-1。

## BUG-059

- **编号**：BUG-059
- **标题**：Model Manager 生产 transport 未实现，修正身份后仍没有任何可用操作
- **严重性/优先级**：高 / P1；README 声称的 open/run/download/upload 功能只有策略层。
- **位置**：`comsol_mcp/tools/model_manager.py:59`，_resolve_dispatch()；生产 SharedSessionManager 未定义 model_manager_dispatch，整个 comsol_mcp 仅此处引用它。
- **内容/复现方法**：生产 adapter 尝试从 shared_session_manager 取得 model_manager_dispatch，但没有实现、赋值或其他生产注入点，必定 None；runtime 返回 no_dispatch_available。复现：`python /workspace/code-review/repro_model_manager_wiring.py` 的 identity-only 部分绕开 BUG-058，只补正确身份，仍返回 outcome=refused/reason=no_dispatch_available。既有 ModelManagerRuntime 测试用自造 Dispatch 证明策略行为，不能证明真实 Model Manager 功能。README 中英文明确声称 enabled 后 open/run/download 可用，未说明 transport 尚缺失。
- **可能的解决办法**：完成实际受 ownership/path/resource/revision 保护的 COMSOL Model Manager transport，并接入真实会话；补生产接线的无求解器测试及独立 licensed 功能验收。在实现和验收之前收紧可用性与文档声明，不能把 callable 替身的策略测试等价真实功能。

## BUG-060

- **编号**：BUG-060
- **标题**：Model Manager gate 或无会话拒绝不写账本，违反每次尝试均记录的声明
- **严重性/优先级**：中 / P2；拒绝证据与恢复记录不完整。
- **位置**：`comsol_mcp/shared_session/model_manager.py:267`，_run() 在 _refuse/_journal_raw 之前调用 _require_gate/_require_session 并直接抛错。
- **内容/复现方法**：模块声明 Every attempt is journalled, including a refusal，README 同样声明每次操作包括拒绝会持久记录。配置有效账本时，关闭 gate 或无有效 attached identity 会直接异常，ledger row_count=0。复现：`python /workspace/code-review/repro_model_manager_wiring.py`，公开接线的 no_attached_session 与纯 runtime 的 feature_gate_closed 均输出零记录。BUG-058 解决后，真实 detached 会话仍可独立触发此次缺口；公开未注册的关闭 gate 工具无法调用，不把纯 runtime gate 分支说成已公开暴露。
- **可能的解决办法**：统一把前置拒绝转为有界拒绝回执并在合法账本中记录；保留明确未知 owner，区分配置/账本不可用与正常拒绝。测试 gate/session/request/dispatch 各阶段拒绝都产生应有记录。

## BUG-061

- **编号**：BUG-061
- **标题**：solver owner 接受 NaN/Infinity 进程时间，回执失败且 NaN owner 无法正常释放
- **严重性/优先级**：中 / P2；身份验证和容量恢复缺陷。
- **位置**：`comsol_mcp/shared_session/solver_owners.py`，normalize_owner_identity() 的 positive 检查、register()/evaluate_release()/owner_receipt()。
- **内容/复现方法**：仅检查 float(value)<=0，没有 isfinite；NaN 和正 Infinity 均 admitted=True 并进入 registry。回执 canonical JSON 拒绝非有限数而抛 ValueError；NaN 与自身不相等，随后使用同一身份、两种 absence 均 True 的 release 仍报 process_identity_mismatch，容量槽被永久占用到重建 registry。复现：`python /workspace/code-review/repro_solver_owner_nonfinite.py`，纯内存 registry，无进程创建。当前未找到生产 runtime 使用此 registry，不声称已证明真实 solver slot 泄漏；确认范围是已公开 Python admission/receipt API 与相应契约。
- **可能的解决办法**：转换后必须 finite 且严格为正，转换溢出统一为 OwnerAdmissionError；release 和文档恢复也用一致身份校验。测试 NaN、正负 Infinity 和超大整数，确认拒绝发生在 registry 变更之前。

## BUG-062

- **编号**：BUG-062
- **标题**：共享 preflight 丢弃 owner PID 未知的监听器，却仍报告完整监听清单
- **严重性/优先级**：中 / P2；主机观察完整性声明错误。
- **位置**：`comsol_mcp/shared_session/process_probe.py`，_listener_records() 中 connection.pid is None 直接 continue，返回 complete=True；collect_shared_preflight_snapshot() 合并该标志。
- **内容/复现方法**：psutil 的监听记录允许 PID=None，例如进程身份无法取得。真实读取逻辑将这一正在监听的 socket 静默删掉，同时报告 listener inventory complete，公开 snapshot 也 inventory_complete=True。复现：`python /workspace/code-review/repro_listener_completeness.py` 仅替换 psutil 的观察结果为 1 个 loopback LISTEN/PID=None，保留真实 provider/collector；输出 listeners=[] 和 complete=True。未发送网络请求或启动 COMSOL。只有未知监听器时 preflight 后续通常拒绝 server absent/starting，不能从此推断已经证明可错误 attach；确认问题是缺失信息被表述为完整观察。
- **可能的解决办法**：未知 owner 的本地监听器必须保留为不确定记录或令完整性 False；后续判定应区分没有监听与监听存在但身份不可取得。测试 PID=None 和不完整 laddr 的观察路径。

## BUG-063

- **编号**：BUG-063
- **标题**：热材料分段常数插值在表格末端节点返回前一个节点
- **严重性/优先级**：中 / P2；输出可用且已哈希绑定，但材料数值错误。
- **位置**：`comsol_mcp/evidence/thermal_material.py`，_bracket() 和 _interpolate_pair() 的 piecewise_constant 分支。
- **内容/复现方法**：末端坐标的 bracket 为倒数第二、最后一项且 fraction=1；piecewise_constant 无条件返回 left。复现 `python /workspace/code-review/repro_thermal_material_edges.py`：波长 [1e-6,2e-6]、温度 [300,400]、温度优先 n=[2,3,4,5]；三个末端节点预期 n=3/4/5，实际均为 2，available=True。完整使用生产 evaluator，不启动 COMSOL。分段常数的区间边界约定需要说明，但表格最终样本本身应可恢复；当前末端值在整个有效范围内从未被选择。
- **可能的解决办法**：精确网格节点直接返回其样本；规定区间左右连续性和越界策略，在波长与温度两个轴分别验证最初、中间、最后节点及其两侧。

## BUG-064

- **编号**：BUG-064
- **标题**：热材料有限参数算术溢出绕过公开工具的稳定拒绝契约
- **严重性/优先级**：中 / P2；合法类型的输入造成内部错误。
- **位置**：`comsol_mcp/evidence/thermal_material.py`，_evaluate_model() 的参数平方；`comsol_mcp/tools/thermal_material.py`，thermal_material_evaluate() 只捕获 ValueError。
- **内容/复现方法**：PositiveFloat 接受有限 plasma_angular_frequency_rad_s=1e200，随后 **2 抛 OverflowError，后续非有限检查不可达且工具不转为 thermal_material_evaluation_rejected。复现 `python /workspace/code-review/repro_thermal_material_edges.py`，真实 typed request 和注册工具函数输出 accepted_finite_input_tool_exception OverflowError。无原生调用；不将真正的内部 TypeError 等程序错误混为输入拒绝。
- **可能的解决办法**：对模型数值计算捕获明确的 OverflowError/ZeroDivisionError 并转为有界 ValueError；增加物理或计算上界、检查中间量，保持其他内部错误独立。覆盖极大参数、极小正波长和零阻尼奇点。

## BUG-065

- **编号**：BUG-065
- **标题**：热辐射输入统一限制非负数，拒绝物理有效的负 Stokes Q/U/V
- **严重性/优先级**：中 / P2；声称支持的 Stokes 偏振只接受部分象限。
- **位置**：`comsol_mcp/contracts/thermal_radiation.py`，ThermalRadiationRequest.values_flat 的 Field(ge=0.0,le=1.0)。
- **内容/复现方法**：Stokes I 非负，但 Q/U/V 可正可负，限制应为其极化模不超过 I。生产 evaluator 已有模长验证，typed request 却先拒绝负分量。复现 `python /workspace/code-review/repro_thermal_radiation_channels.py`：I=.8,Q=-.3,U=.4,V=-.1 的模长约 .51<I，仍报四个 validation errors；同模长的全正分量通过。无需 COMSOL。既有 Stokes 测试只用正分量，通用 bounds 测试没有区分模式。
- **可能的解决办法**：按 polarization.mode 分别验证：标量与 TE/TM 在 [0,1]，Stokes I 在 [0,1]、Q/U/V 有符号并满足模长约束；同步 schema 描述，覆盖相反线偏振和左右旋分量。

## BUG-066

- **编号**：BUG-066
- **标题**：Kirchhoff 评估回执未绑定当前辐射方向和吸收证据
- **严重性/优先级**：中 / P2；不适用于当前通道的吸收证据被用作发射率。
- **位置**：`comsol_mcp/evidence/thermal_radiation.py`，_validate_assessment()、evaluate_thermal_radiation()；ThermalRadiationRequest 缺少可比较的 channel identity。
- **内容/复现方法**：仅验证回执自身 hash、verified checks 和 applicable，没有比较回执 propagation_direction/polarization_basis/handedness 与当前请求，也没有绑定 absorptivity_evidence_sha256 到输入来源。复现 `python /workspace/code-review/repro_thermal_radiation_channels.py`：真实 builder 生成 positive_z applicable 回执，当前请求 negative_z，来源也不含该吸收证据 hash；真实 evaluator 仍返回辐射功率和 evidence hash。内部 hash 校验正常，问题是合法旧回执可跨对象重用，不声称改内容后能绕过 hash。
- **可能的解决办法**：明确当前吸收证据与 channel identity 字段，并与回执逐项严格比较；验证方向、频率通道、偏振和旋向一致性。添加有效但来自不同来源、方向或偏振的回执拒绝测试。

## BUG-067

- **编号**：BUG-067
- **标题**：代理数据集校验接受 field_schema_path 却完全忽略其内容
- **严重性/优先级**：中 / P2；调用方提供的字段约束没有执行。
- **位置**：`comsol_mcp/tools/surrogate.py`，surrogate_dataset_validate() 构造 request 后调用 validate_dataset_document() 时未传字段 schema；evidence helper 没有 schema 参数。
- **内容/复现方法**：路径被 containment 检查且保存在 typed request，但实际没有读取 schema、绑定 schema hash 或执行字段约束。复现 `python /workspace/code-review/repro_surrogate_public_validation.py`：真实 server.call_tool 提供有效 CSV 和内容为 {invalid-json 的 schema.json，path_policy accepted=True，仍 success=True/valid=True，checks 全为 not_checked。生产 contract 声称 against its declared field schema，却未报告 schema 未检查。
- **可能的解决办法**：有界读取并严格校验声明的 schema，绑定 hash，执行名称、顺序、角色及其他已有字段契约；若功能未实现则显式拒绝该参数。测试坏 JSON、schema 不匹配和合法 schema 三种实际公开调用。

## BUG-068

- **编号**：BUG-068
- **标题**：公开代理模型校验忽略 schema 版本和导出清单一致性，错误报告 verified
- **严重性/优先级**：中 / P2；与规范验证器结果相矛盾。
- **位置**：`comsol_mcp/evidence/surrogate_evidence.py`，validate_export_manifest_document()、verify_surrogate_document()；model_card/registry document 分支同样缺少版本约束。
- **内容/复现方法**：公开实现重算文档内部 hash 后只做少量字段检查，未调用 surrogate/export.py 的规范验证器。复现 `python /workspace/code-review/repro_surrogate_public_validation.py`：从真实 builder 生成清单，将 schema_version 改 999.0.0、artifact format 改 bogus、保留 onnx_available=True，再重算 manifest hash。规范 validator 拒绝 unsupported schema_version，但真实公开 inspect success=True/hash_verified=True，verify(require_consistent_export=True) verified=True。hash 并未被绕过；自洽 hash 不能代替 schema/format/availability 的语义校验。
- **可能的解决办法**：复用并补齐规范文档验证器，严格校验已支持版本、关闭字段、每种 artifact 格式和 availability 一致性；require_consistent_export 应建立在完整语义校验后。测试内部 hash 正确但语义无效的各类文档。

## BUG-069

- **编号**：BUG-069
- **标题**：代理模型 drift guard 忽略材料、网格、物理和 adapter 身份变化
- **严重性/优先级**：中 / P2；纯身份策略未兑现函数声明。
- **位置**：`comsol_mcp/surrogate/registry.py`，DRIFT_IDENTITY_FIELDS、detect_drift()、assert_no_contract_drift()。
- **内容/复现方法**：函数说明这些身份变化是 contract drift，但字段白名单只有 dataset/split/schema/transforms/architecture/comsol_build/objective。复现 `python /workspace/code-review/repro_surrogate_registry_contract.py`：真实 builder 生成 material_identity_sha256、mesh_identity_sha256、physics_identity_sha256、adapter_identity_sha256 各变更的两张卡；guard 全部正常返回，drift_detected=True 却 requires_new_lineage=False。当前未找到生产调用此 guard，不将纯 Python 缺口声称为已证明 native continuation 放行。
- **可能的解决办法**：规定并共享全部契约身份的规范字段；纳入这四类科学/实现身份。保留 campaign 等明确非契约元数据的区别，测试每个契约身份的变化、增加和删除。

## BUG-070

- **编号**：BUG-070
- **标题**：把 COMSOL trained_chksum 当 SHA256，真实训练校验和无法写卡或继续训练
- **严重性/优先级**：中 / P2；真实权重身份与 Python 契约不匹配。
- **位置**：`comsol_mcp/surrogate/registry.py`，build_model_card() 的 trained_chksum；`comsol_mcp/jobs/surrogate_training.py:278`，continue_from.trained_chksum。
- **内容/复现方法**：仓库 capability matrix 的原生验收记录给出 trained_chksum=-8938453606443985335，export 模块与对应测试接受这一有符号整数文本。model card builder 和 durable continuation 却要求 64 字符十六进制。复现 `python /workspace/code-review/repro_surrogate_registry_contract.py`：同一实际记录的 checksum 可创建 export manifest，却被 card 拒绝为 must be a 64-character hex digest；continue_from 路径同样静态调用该错误 validator。无真实 COMSOL 运行；结论来自代码与仓库已有原生记录的明确契约冲突。
- **可能的解决办法**：为 COMSOL 原生 checksum 定义单独的有界规范文本类型，与 artifact SHA256 分离；card、readback、export、continuation 一致使用。用已有 native receipt 的真实 checksum 做跨模块回归。

## BUG-071

- **编号**：BUG-071
- **标题**：代理模块用 int(value,16) 验证 SHA256，允许符号、空格和下划线
- **严重性/优先级**：低 / P3；声称严格 64 位 hex 的身份字段接受非法表示。
- **位置**：`comsol_mcp/surrogate/registry.py`、`comsol_mcp/surrogate/export.py`、`comsol_mcp/evidence/surrogate_evidence.py`、`comsol_mcp/jobs/surrogate_training.py` 的 _require_hex64()。
- **内容/复现方法**：Python int 的合法语法比 hex digest 宽；长度 64 不能排除前导 +/-/空格及数字间下划线。复现 `python /workspace/code-review/repro_surrogate_registry_contract.py`：真实 build_model_card 接受上述四类 architecture_sha256，原样写入卡并封 hash。各已读模块使用相同验证逻辑。未证明因此能伪造已有文件内容 hash；确认是输入/身份规范不一致。
- **可能的解决办法**：用 fullmatch `[0-9a-fA-F]{64}` 后统一小写，集中复用 digest validator；测试符号、空白、下划线、Unicode 和正常大小写。

## BUG-072

- **编号**：BUG-072
- **标题**：失败预测虽从总体评分排除，却进入分组 MAE 产生 NaN
- **严重性/优先级**：中 / P2；指标回执无法规范序列化或持久化。
- **位置**：`comsol_mcp/surrogate/training.py`，compute_metrics() 的 grouped 分支。
- **内容/复现方法**：总体 finite-pair 分支正确计数并跳过非有限预测；分组循环无同等过滤，直接计算 abs(nan-truth) 和 max(group means)。复现 `python /workspace/code-review/repro_surrogate_training_metrics.py`：predicted=[[nan],[1]]、actual=[[1],[1]]、group_ids=['bad','ok'] 返回 failed_prediction_count=1、rmse=0、worst_group_mae=nan；真实 canonical JSON 拒绝该回执。此 API 明确支持计数失败预测，不能简单认为 NaN 输入均应先被拒绝。
- **可能的解决办法**：使用一致的可评分 pair 集合计算总体及分组指标；无可评分值的组标记 unavailable 并保留失败数，不返回 NaN。测试失败组在第一/最后位置、全失败组和部分失败组。

## BUG-073

- **编号**：BUG-073
- **标题**：偶数 seed 使用上中位数，低估指标 spread 并错误判定稳定
- **严重性/优先级**：中 / P2；多 seed 稳定性判定数值错误。
- **位置**：`comsol_mcp/surrogate/training.py`，evaluate_seed_stability() 的 sorted(values)[len(values)//2]。
- **内容/复现方法**：偶数样本 median 应为中央两项均值，当前取较大一项，缩小非负指标的 spread=(worst-best)/median。复现 `python /workspace/code-review/repro_surrogate_training_metrics.py`：两 seed RMSE 1 和 3、阈值 .8，真实 median=2、spread=1 应不稳定；当前 median=3、spread=.6667、stable=True。公开训练 spec 支持 1..8 seeds，偶数数量有效。
- **可能的解决办法**：使用 statistics.median，或明确实现奇偶规则；覆盖 2/4/8 seed 及判定阈值边界。如果设计确实要求上分位数，需更名并明确这一科学策略，不能报告普通 median。

## BUG-074

- **编号**：BUG-074
- **标题**：continuation guard 将两边缺失的全部身份视为精确匹配
- **严重性/优先级**：中 / P2；纯 continuation API 在无任何身份时放行。
- **位置**：`comsol_mcp/surrogate/training.py`，evaluate_continuation() 和 assert_continuation_allowed()。
- **内容/复现方法**：用 prior.get(field)!=current.get(field) 比较，双侧缺失均为 None，且没有身份类型/hash/schema 校验。复现 `python /workspace/code-review/repro_surrogate_training_metrics.py`：prior={}、current={} 得 continuation_allowed=True/reason=identical_continuation；assert wrapper 亦正常返回。纯 helper 缺陷；durable spec 有独立字段要求，不声称空对象可绕过所有生产 admission。
- **可能的解决办法**：双方必须具有所有规定身份并各自通过严格规范验证，再比较其精确值；缺失、null、非法 digest 均拒绝。增加双方同时缺同一字段和全空输入测试。

## BUG-075

- **编号**：BUG-075
- **标题**：DNN 回滚把 study step 当 study 删除，可能删除同名既有 study
- **严重性/优先级**：高 / P1；失败清理可修改不属于本次操作的模型树。
- **位置**：`comsol_mcp/surrogate/dnn_adapter.py`，apply_surrogate_configuration() 的 created study_step 记录及 rollback else: backend.remove_study(tag)；dnn_clientapi_backend.remove_study() 真正删除 study container 下的节点。
- **内容/复现方法**：创建 std1 下的 smt1 step 后将 ('study_step','smt1') 放入 created。回滚把非 function 的所有记录都送给 remove_study，因而删除根 study smt1，而非 std1 的 step。复现 `python /workspace/code-review/repro_dnn_rollback.py`：预存用户 study smt1，用真实 applier 创建 std1/smt1 并注入首次属性写失败；实际调用序列 remove_function:dnn1、remove_study:smt1、remove_study:std1，原用户 study 消失，仍 reported_rolled_back=True。只用内存后端，无真实模型破坏；生产 backend 的 container 路由静态确认同一错误删除对象。现有空树 rollback 测试不含同名既有 study，pop(None) 掩盖此问题。
- **可能的解决办法**：回滚记录包含完整 node kind/parent/tag；删除新建 parent study 时其 steps 自动清理，无需以 step 标签删除根 study。逐项证明 owned identity，仅清理本次创建对象。添加同名不同 container 的既有节点保护测试。

## BUG-076

- **编号**：BUG-076
- **标题**：DNN 更新既有节点失败不恢复属性，却报告 rolled_back=True
- **严重性/优先级**：中 / P2；失败原子性和回执内容错误。
- **位置**：`comsol_mcp/surrogate/dnn_adapter.py`，apply_surrogate_configuration(create_nodes=False) 与 except 返回的 rolled_back=not rollback_errors。
- **内容/复现方法**：该路径逐项写入既有 function，没有保存原属性或逆向恢复。created=[] 导致清理循环为空、rollback_errors=[]，无论已发生多少写入均报告 True。复现 `python /workspace/code-review/repro_dnn_rollback.py`：既有 activation=['none','relu']，先成功写新 activation，再注入 layertype 写失败；最终 activation 留为 ['none','tanh','tanh','tanh']，success=False 且 reported_rolled_back=True。现有测试只覆盖此复用路径成功情况。
- **可能的解决办法**：在写入之前读取并保存需要变更的 typed 属性，失败时恢复并验证；无法恢复时明确 partial_application/rollback_failed。不能因没有创建新节点就将属性回滚说成成功。

## BUG-077

- **编号**：BUG-077
- **标题**：ONNX Gemm 接受 alpha/beta 属性却忽略缩放，静默返回错误预测
- **严重性/优先级**：中 / P2；已支持 operator 的合法属性计算不正确。
- **位置**：`comsol_mcp/surrogate/onnx_runtime.py`，evaluate_onnx_model() 的 Gemm 分支及 _dense()。
- **内容/复现方法**：Gemm 规范为 alpha*A*B+beta*C；decoder 读取属性，但执行只处理 transB。复现 `python /workspace/code-review/repro_onnx_semantics.py`：真实 protobuf loader 读取 input=2、W=4、B=5、alpha=2、beta=3 的单节点图；预期 31，实际 13。此图与当前 COMSOL 默认属性不同，不能说已有默认 COMSOL 导出一定错；问题是非默认属性被接受且静默近似，违反 unsupported graph 应拒绝的声明。
- **可能的解决办法**：实现 alpha/beta 与 transA 等合法属性的精确规则，或明确拒绝未支持的属性组合；用独立 ONNX oracle 对属性变体做回归。

## BUG-078

- **编号**：BUG-078
- **标题**：ONNX 求值返回最后一个节点，忽略模型声明的 graph output
- **严重性/优先级**：中 / P2；有效图的输出对象错误。
- **位置**：`comsol_mcp/surrogate/onnx_runtime.py`，evaluate_onnx_model() 末尾 values.get(target)，target 为最后遍历 node 的首个 output。
- **内容/复现方法**：loader 保留 graph_outputs，但 evaluator 从不使用。复现 `python /workspace/code-review/repro_onnx_semantics.py`：图先 Identity(input)->output，后 Add(output,10)->dead，声明 graph output='output'；input=2 预期返回 2，实际返回 12。额外不被导出的有效节点不应改变模型输出。当前测试图都把最后节点设为 output，未触发此差异。
- **可能的解决办法**：按声明 graph_outputs 顺序收集结果；若只支持一个输出则严格验证并显式拒绝其他形状。覆盖尾部无关节点、输出在 initializer/input、多个输出和缺失输出引用。

## BUG-079

- **编号**：BUG-079
- **标题**：ONNX Sigmoid 对极大负有限数溢出，正常饱和值不能求出
- **严重性/优先级**：中 / P2；合法网络输入导致内部异常。
- **位置**：`comsol_mcp/surrogate/onnx_runtime.py`，Sigmoid 分支的 math.exp(-item)。
- **内容/复现方法**：真实 loader/evaluator 读取单 Sigmoid 图，有限 input=-1000 引发 OverflowError: math range error；正确双精度值应饱和为 0。复现 `python /workspace/code-review/repro_onnx_semantics.py`。同类中间激活可由有界原始输入和较大权重形成，不依赖 NaN 或 Infinity 输入。未启动求解器。
- **可能的解决办法**：分正负区间使用稳定 sigmoid：负数以 exp(x)/(1+exp(x)) 求值；覆盖 ±1000、零点及普通区间，并明确处理中间非有限量。

## BUG-080

- **编号**：BUG-080
- **标题**：ONNX 节点和 initializer 数量上界在全部解码后才检查
- **严重性/优先级**：中 / P2；声明的解码资源上界没有约束实际工作量。
- **位置**：`comsol_mcp/surrogate/onnx_runtime.py`，_decode_graph() 的完整列表推导和 load_onnx_model() 后置 MAX_NODES/MAX_INITIALIZERS 检查。
- **内容/复现方法**：图里全部 node/tensor 的字段与内容都先解码再计数；超限 initializer 还可各分配 MAX_TENSOR_ELEMENTS 数值。复现 `python /workspace/code-review/repro_onnx_semantics.py` 保留实际 loader，仅计数 _decode_node 调用，512 上界的图含 514 个小节点，拒绝前已解码 514 个。复现输入很小，不制造资源耗尽；512MiB 总字节上界不能证明每类对象数或 Python 展开内存有界。read_bytes 本身也依赖先 stat 而无读取中 byte cap，增长风险待独立证据，不从本复现扩张结论。
- **可能的解决办法**：字段流式解码，在超出各类计数之前停止；声明总 tensor 元素/总解码内存预算，并使用真正有界读取。测试超限时 decoder 调用和已分配元素不会先超过限额。

## BUG-081

- **编号**：BUG-081
- **标题**：拆分计划的 group_counts 未绑定摘要，也未在校验时重算
- **严重性/优先级**：中 / P2；通过验证的统计可与真实分组分配矛盾。
- **位置**：`comsol_mcp/surrogate/splits.py`，assign_group_disjoint_split() 封印后添加 group_counts；validate_split_plan() 排除此字段且只比较重建摘要。
- **内容/复现方法**：运行 `python /workspace/code-review/repro_surrogate_manifest_edges.py`。生成 3 组的真实计划后，仅将 group_counts 改为 train=99999、validation=-1、test='invalid'；原摘要完全不变，validate_split_plan 仍返回这些计数。这是完整性校验遗漏，不需要构造新摘要。
- **可能的解决办法**：把计数纳入封印正文，或作为派生数据严格重算并逐字段比较；检查四个 split 键、非负整数与总和。

## BUG-082

- **编号**：BUG-082
- **标题**：泄漏检测回执宣称检查了规范化与冻结前测试访问，实际没有相应检测
- **严重性/优先级**：中 / P2；科学验收检查范围被夸大。
- **位置**：`comsol_mcp/surrogate/splits.py`，LEAKAGE_CLASSES、detect_leakage() 返回 classes_checked。
- **内容/复现方法**：上述脚本输出 classes_checked 包含 normalization_from_non_train、test_access_before_freeze。函数仅接收 assignments/group_members/candidate_ids，没有训练变换来源或模型冻结/测试访问记录；代码仅实现另外三种分组/候选重复检测。这两种检查不可能由当前输入完成。仅确认纯检测 API 的回执错误，不据此声称已有训练流程实际发生数据泄漏。
- **可能的解决办法**：将未执行项标为 not_checked，或增加可验证的变换来源、冻结和访问事件输入，落实对应判定后才报告 checked。

## BUG-083

- **编号**：BUG-083
- **标题**：行来源校验未限制 eligible 布尔类型，也未验证核心身份与特征
- **严重性/优先级**：中 / P2；非 verified 行可被台账计为合格训练行。
- **位置**：`comsol_mcp/surrogate/rows.py`，validate_row_provenance() 的 is True/is False 分支与 summarize_row_ledger() 的真值筛选。
- **内容/复现方法**：上述脚本从真实 builder 行生成内部摘要一致的输入，设置 evidence_state='unknown'、eligible=1、source_model_sha256=''、study_identity=''、features={}。validator 接受，summary 报 eligible_count=1。builder 本来拒绝这些状态/缺失字段；摘要只能证明内容一致，不能替代语义验证。未把本纯 helper 复现扩张为真实 FEM 来源伪造或生产训练已接线的结论。
- **可能的解决办法**：要求 eligible 为严格 bool，复用 builder 全部身份、有限数和非空字段检查；重建规范正文并比较派生资格字段，统一消费端的类型约束。

## BUG-084

- **编号**：BUG-084
- **标题**：schema 和训练变换的读取校验弱于 builder，接受重复字段与空标准化列
- **严重性/优先级**：中 / P2；内部自洽的导入 manifest 不满足构建契约。
- **位置**：`comsol_mcp/surrogate/manifests.py`，validate_schema_manifest()、validate_training_transforms()。
- **内容/复现方法**：上述脚本将合法 schema 的 feature_names 改为 ['x1','x1'] 并重算摘要，校验通过；把标准化变换改为 columns=[] 且添加 arbitrary=True 后也通过。相应 builder 分别拒绝重复字段、空标准化列。校验仅检查摘要/维度或 kind，遗漏字段规范与列表上界；不是 SHA256 算法被绕过。
- **可能的解决办法**：读取时复用 builder 规范化及完整约束，并比较重建结果；对变换项使用封闭字段与列数/去重规则。

## BUG-085

- **编号**：BUG-085
- **标题**：变换往返验证把 NaN 还原误报为零误差，空输入还会跳过 manifest 校验
- **严重性/优先级**：中 / P2；数值保真回执可报告虚假通过。
- **位置**：`comsol_mcp/surrogate/fields.py`，apply_transforms()/invert_transforms() 的 minmax 算术与 verify_transform_roundtrip()。
- **内容/复现方法**：上述脚本提供合法有限 low=-1e308、high=1e308 和原值 -1e308；差值溢出为 Infinity，forward 得 0，inverse 的 0*Infinity 得 NaN。delta > allowed 与 delta > worst 均为 False，结果 roundtrip_verified=True、worst_absolute_error=0。另 verify_transform_roundtrip({},[]) 对无效 manifest 直接报告通过，未进行任何验证。
- **可能的解决办法**：在算术中间量、还原值和误差上检查有限性，采用稳定的范围计算或拒绝不可表示范围；循环前验证 manifest 和有限正容差，并将无数据标为未检查或拒绝。

## BUG-086

- **编号**：BUG-086
- **标题**：campaign summary 未验证 FEM 结果来源和候选去重，能报告负数的预测剩余量
- **严重性/优先级**：中 / P2；纯汇总 API 的科学状态和预算统计错误。
- **位置**：`comsol_mcp/surrogate/campaign.py`，summarize_campaign() 的 fem_results 状态计数与 predicted_only=len(records)-verified。
- **内容/复现方法**：`python /workspace/code-review/repro_surrogate_campaign_summary.py`：1 个 screened 候选、FEM 预算 1、used=0，传入 2 条同名 unscreened 的 {'candidate_id':'not-screened','state':'verified'}。没有 FEM evidence/测量/摘要，summary 仍 reported verified_count=2、predicted_only_count=-1、verified_requires_fresh_fem=True。独立 assert_no_prediction_promotion 会拒绝同样输入，但 summary 未调用它；licensed gate 另行调用该 gate，因此本结论限定到 summary helper，不能说已有 licensed gate 放行。
- **可能的解决办法**：汇总入口校验每条 FEM 结果及其候选关联、唯一性、证据字段和摘要，按唯一 candidate 状态汇总；核对结果数与 escalation 使用量，并复用独立 invariant gate。

## BUG-087

- **编号**：BUG-087
- **标题**：dataset discovery 把派生 CutPlane 标为可提取，实际 adapter 和 MPh 都不支持该路径
- **严重性/优先级**：中 / P2；发现结果的可用性标志错误。
- **位置**：`comsol_mcp/evidence/field_discovery.py`，resolve_solution()/field_evaluation_eligible；`comsol_mcp/evidence/field_dataset.py`，硬编码 dataset.getString('solution')。
- **内容/复现方法**：`python /workspace/code-review/repro_field_dataset_contract.py`：真实 discovery 遍历 base Solution→CutPlane(data='base')，CutPlane 被标为 field_evaluation_eligible=True。真实 adapter 遇到仅含 data 引用的派生 dataset，则在 evaluate 前报 solution readback is unavailable。已安装 MPh 1.4.0 evaluate 文档还明确说明 Derived datasets are not supported；本复现使用小内存替身，没有启动 COMSOL。
- **可能的解决办法**：discovery 将计算解可达性与当前提取支持分别标示，仅支持的 solution dataset 报 eligible；若要支持派生数据，增加有界 ClientAPI 提取实现与独立原生验收。

## BUG-088

- **编号**：BUG-088
- **标题**：field dataset 提取忽略声明的坐标和数量单位，可能选不到切片或给数据贴错单位
- **严重性/优先级**：中 / P2；科学结果的数值/单位对应不可靠。
- **位置**：`comsol_mcp/evidence/field_dataset.py`，model.evaluate(evaluation_expressions,dataset=...,inner=...) 未传 unit 或转换；`field_bundle.py` 接受任意一致的 slice/bounds 单位标签。
- **内容/复现方法**：上述脚本调用真实 adapter，提供按米表示的模型坐标，request 使用 um、z=0.5；物理对应 z=5e-7m 的样点被直接与 0.5 比较，报 slice selection contains no field samples。读取已安装 MPh evaluate 源码与文档：未传 unit 时使用默认单位；adapter 从未提供 expression.unit 或坐标 unit，却在 artifact 报请求标签。数量使用非默认单位时也缺少任何转换机制。复现替身只模拟默认坐标结果；没有把它表述为已完成 native 数值验收。
- **可能的解决办法**：为全部求值表达式传递对应声明单位（包括局部和 component 坐标），或统一转换到已验证的规范单位；对不支持的单位在求值前拒绝。测试默认 SI 与 um、mV/kV 等不同单位下的物理等价结果。

## BUG-089

- **编号**：BUG-089
- **标题**：field manifest 接受远离请求切片的坐标范围，仍标为 measurement_complete
- **严重性/优先级**：中 / P2；导入的测量描述与绑定请求自相矛盾。
- **位置**：`comsol_mcp/evidence/field_manifest.py`，_coordinate_ranges() 仅检查 coordinate_bounds，没有检查 slice axis/value/tolerance。
- **内容/复现方法**：`python /workspace/code-review/repro_field_manifest_slice.py` 直接调用真实 builder/validator；请求 z=0.5um、tolerance=0.01um，提供 z range=[0.75,0.75]，仍构建并通过规范验证，measurement_status=measurement_complete。无需篡改摘要，builder 自行封印了矛盾信息。正常 sampling/interpolation 会检查切片，问题限定到 transported manifest/独立 builder 的语义约束。
- **可能的解决办法**：manifest 中 slice 轴的范围必须位于请求的值±容差之内；若描述的是重采样网格坐标则严格要求退化范围等于 slice.value，明确区分原始样点范围与输出网格范围。

## BUG-090

- **编号**：BUG-090
- **标题**：内部吸收一致性把合法零吸收当作无效输入
- **严重性/优先级**：中 / P2；无损/透明极限不能得到一致性结果。
- **位置**：`comsol_mcp/evidence/power_audit.py`，normalize_internal_absorption_consistency() 对 value_m2 和 value_w 使用 _positive()。
- **内容/复现方法**：`python /workspace/code-review/repro_power_zero_absorption.py`：吸收截面和体损耗均为有限 0，unit_cell_area_m2=1e-12、incident_power_w=2 都严格正，归一化应均为 0、残差为 0；却报 value_m2 must be strictly positive。零分子没有除零风险，是正常无损结果。函数后面的 denominator==0 相对残差分支也因前置严格正约束不可达；现有测试只检查正分母与负损耗，没有零分子用例。
- **可能的解决办法**：吸收分子采用有限非负校验，面积/入射功率分母保留严格正；为两侧零与仅一侧零分别给出稳定残差与分类。

## BUG-091

- **编号**：BUG-091
- **标题**：旧证据迁移缺少平面方向与介质声明，仍自行认证 convention_complete
- **严重性/优先级**：中 / P2；迁移把不完整声明升级为可通过严格 flux policy 的证据。
- **位置**：`comsol_mcp/evidence/contracts.py`，_legacy_declared_flux_is_complete()、_point_audit_envelope()。
- **内容/复现方法**：`python /workspace/code-review/repro_physical_evidence_boundaries.py` 提供三组 raw/directed power、sign、expression、selection，完全没有 normal、medium_id、plane_coordinate_m。迁移却添加 flux.convention_complete=True、physical_flux_closure_eligible=True，并使 example declared_flux_closure policy 报 pass。真实 normalization builder 要求这些声明；迁移的 preserved_without_reinterpretation 不应补认证未存在的物理约定。仅复现纯迁移/策略，无原生求解。
- **可能的解决办法**：迁移时完整验证 legacy plane metadata，并保留声明来源；缺失约定标 unknown/ineligible。不要通过硬编码 True 填补旧文件没有的信息。

## BUG-092

- **编号**：BUG-092
- **标题**：严格 wavelength synchronization 策略可通过两个相同的负波长
- **严重性/优先级**：中 / P2；物理无效的测量被报告为严格通过。
- **位置**：`comsol_mcp/evidence/contracts.py`，_rule_outcome() 的 wavelength_synchronization 分支。
- **内容/复现方法**：上述脚本使用真实 evidence builder，令 evaluated_parameter_m 和 solved_frequency_m 均为有限 -1m；example policy 两种容差均 0，结果 overall=pass。分支只检查有限数和差异，没有要求物理波长严格正。当前点审计 producer 自身有正值约束，但导入的 solver-free physical evidence/policy 没有此语义保护，故结论限定到策略。
- **可能的解决办法**：要求两侧有限且严格正，校验测量单位/语义后再算误差；零、负数和单位不符应得到 missing/fail，不能仅因相等而通过。

## BUG-093

- **编号**：BUG-093
- **标题**：非均匀光谱拟合用固定 ±1 区间求交点，窗口外外推被标为 bracketed
- **严重性/优先级**：中 / P2；谱宽和 Q 的支持范围判定错误。
- **位置**：`comsol_mcp/evidence/spectral_characterization.py`，_fit_candidate() 的 scale=max(left/right span)、peak_z 范围和 _model_crossings(left_bound=-1,right_bound=1)。
- **内容/复现方法**：`python /workspace/code-review/repro_spectral_fit_support.py` 使用真实 SciPy，7 个有序但非均匀点 [4.97,4.98,4.99,5,5.1,5.2,5.3]um，响应来自中心 5um、半宽 0.1um 的解析 Lorentzian。实际支持窗口 [4.97,5.3]um，左半高点 4.9um 根本不在窗口，仍报告 fwhm.state='bracketed'、missing_sides=[]、left_crossing_m=4.9e-6。窗口左侧只有 0.03um，归一化实际左界为 -0.1，代码却允许到 -1，凭模型外推制造括定。等间隔对称测试没有触发。
- **可能的解决办法**：所有 peak/crossing/参数中心边界使用实际 min(z)/max(z)，只在已测支持内判定 bracketed；窗口外推单独标示，不据此自动计算有测量括定含义的 Q。

## BUG-094

- **编号**：BUG-094
- **标题**：field review NPZ 校验先完整解压数组再检查形状，压缩文件上界不能约束展开内存
- **严重性/优先级**：中 / P2；本地证据审查可被异常压缩数组拖垮。
- **位置**：`comsol_mcp/jobs/field_review.py`，_verify_descriptor() 只限制压缩文件字节；_verify_field_array() 的 archive[key] 在 shape 验证之前分配数组。
- **内容/复现方法**：`python /workspace/code-review/repro_field_npz_decode_bound.py` 构造小 NPZ，manifest 规定 [128,96]，quantity 实为 [256,256] 零数组。真实 np.load 解压调用观测显示先生成 524288 字节 quantity，再抛 shape 错误；归档只有数 KiB。复现刻意很小，没有制造资源耗尽。同一顺序允许极高压缩比/巨大 NPY 声明先展开，256MiB 压缩上界无法证明内部展开预算，allow_pickle=False 也不限制这种资源分配。
- **可能的解决办法**：读取有界 ZIP/NPY header，先验证 member 数、未压缩 byte count、dtype、shape 与预计总元素预算，再准许读取；或隔离进程并设置明确内存上界。以解码前拒绝作为验收条件。

## BUG-095

- **编号**：BUG-095
- **标题**：public field extract 只按整个 request 目录判缓存命中，第二个 view 永远被跳过
- **严重性/优先级**：中 / P2；合法 paired 请求返回成功却缺少一半产物。
- **位置**：`comsol_mcp/tools/field_evidence.py`，wave_optics_field_extract() 的 artifact_root.exists() 分支；根由 request_fingerprint 选取，没有使用 view_fingerprint 校验命中。
- **内容/复现方法**：`python /workspace/code-review/repro_field_public_cache.py`：真实公共工具接线、实际 extraction/pipeline、仓库小 dataset fake；请求含 on(solution_number=1) 与 off(solution_number=2)。第一次 on 提取成功创建 request 根，第二次 off 返回 success=True、already_present=True、evaluation_skipped=True，但 off 的 view 目录完全不存在，模型只求值一次。任意空 request 根同样会触发成功，现有测试甚至只创建空目录就断言命中；这里不需要 native COMSOL。
- **可能的解决办法**：以具体 view identity 为缓存单位，验证该 view 的 manifest/array 数量、摘要和完成状态后才命中；允许在同 request 中独立发布其他 view，残缺根不能报告成功。

## BUG-096

- **编号**：BUG-096
- **标题**：visual review receipt 不核对 reviewer 的 byte/media 能力与具体请求
- **严重性/优先级**：中 / P2；超出已声明能力的审查可报告 complete。
- **位置**：`comsol_mcp/evidence/visual_review.py`，build_visual_review_receipt()。
- **内容/复现方法**：`python /workspace/code-review/repro_visual_capability_boundaries.py` 构建真实 Codex capability，max_total_bytes=1；request 的两个 PNG 总 2300 字节。host/calibration/ref 声明正常时 receipt 仍 visual_review_complete、incomplete_reasons=[]。receipt 核对 hash/ref 和 delivery，却完全不使用 capability.max_total_bytes 或 supported_media_types。这是声明内部矛盾，不声称实际主机未看到图像；复现只运行纯 contract。
- **可能的解决办法**：receipt 对请求逐项核对图片数、总字节、media type 及必要原始分辨率能力；超限或类型不支持加入具体 incomplete reason，不允许报告完成。

## BUG-097

- **编号**：BUG-097
- **标题**：opencode provider metadata 的字符串 false 被真值转换为图像输入支持
- **严重性/优先级**：中 / P2；异常元数据会错误开放科学审查资格。
- **位置**：`comsol_mcp/evidence/visual_review.py`，normalize_opencode_capability() 的 bool(inputs.get('image'))。
- **内容/复现方法**：上述脚本提供 capabilities.input.image='false'，匹配 model identity、附件与校准声明。normalizer 输出 image_input=True、host_capability_confirmed=True、scientific_review_eligible=True；后续 validator 只看到转换后的 bool，不能发现原输入不是布尔值。provider_metadata 在公开 MCP schema 为任意 JSON object，字符串不会由顶层 bool 参数解析纠正。
- **可能的解决办法**：读取 metadata 时严格要求 image 为 JSON bool，缺失/错误类型保持 unavailable 或明确拒绝；不以任意非空值作为 host 能力证据。

## BUG-098

- **编号**：BUG-098
- **标题**：exact observation ownership 忽略 target_files，缺失或变化仍报告 owned
- **严重性/优先级**：中 / P2；身份校验契约未覆盖声称的全部字段。
- **位置**：`comsol_mcp/jobs/observation.py`，verify_exact_ownership()。
- **内容/复现方法**：`python /workspace/code-review/repro_observation_contract.py` 令 expected 的 target_files 指向 expected.mph，observed 完全删除该字段或改成 other.mph，其他 PID/time/executable/signature 相等；两次均得到 owned=True、reason_codes=[]。doc 明确要求每个身份字段可读且一致，normalize_process_identity 也把 target_files 列为 required，但只对 expected 调用。当前没发现 production 调用此 helper；不声称本复现执行任何 kill。
- **可能的解决办法**：严格规范化 observed 的全部字段，并按定义核对 target_files；缺失、错误类型和不同目标分别拒绝；保持真实进程动作与纯校验分离。

## BUG-099

- **编号**：BUG-099
- **标题**：observation summary 只核对部分键和摘要，接受布尔 attempt 与虚构状态
- **严重性/优先级**：中 / P2；warning-only 状态回执可能给出不真实的恢复信息。
- **位置**：`comsol_mcp/jobs/observation.py`，summarize_observation()。
- **内容/复现方法**：上述脚本写入只有部分 required 键的内部摘要一致 JSON，没有 schema/process identity/时钟等 builder 字段；attempt=True、terminal_state='running'、cleanup_outcome='invented'、resume_disposition='magical'。expected_attempt=1 时仍 available=True（True==1），并输出 solver_terminal 与虚构恢复建议。声明的 closed shape 和语义没有实际落实。此路径显式 warning_only=True，不据此声称 durable terminal 状态被覆盖。另文件上界在 read_bytes 后才检查，保留资源风险疑点。
- **可能的解决办法**：增加完整 receipt validator，要求封闭字段、严格类型、schema、枚举与派生状态一致性，加载前用 bounded reader；摘要校验不能替代内容语义验证。

## BUG-100

- **编号**：BUG-100
- **标题**：checkpoint 回执未声明源文件摘要时仍可被认证为 usable
- **严重性/优先级**：中 / P2；纯恢复验证无法证明声明的源文件一致性。
- **位置**：`comsol_mcp/jobs/bounded_steps.py`，verify_checkpoint_usability() 的 source_sha 比较条件。
- **内容/复现方法**：`python /workspace/code-review/repro_checkpoint_and_process_edges.py` 使用仓库真实 fixture builder 构造字节、model fingerprint 和 revision 都匹配的 checkpoint 回执，但 source_identity.file_sha256=None。传入任意 current_source_file_sha256='f'*64 后返回 usable=True、reason_codes=[]。builder 允许 null，verifier 只在两端非 null 时比较，漏掉回执端缺失。函数契约明确要求源身份全部匹配；目前 production 只展示 summary，未发现真实恢复调用，不声称已导致原生模型错误恢复。
- **可能的解决办法**：同时要求回执和当前源文件摘要存在且合法，再比较；任何一端缺失返回 source_identity_undeclared；补充回执端 null 的测试。

## BUG-101

- **编号**：BUG-101
- **标题**：exact termination 接受 NaN 创建时间并进入进程终止分支
- **严重性/优先级**：高 / P1；终止边界未完整验证进程身份。
- **位置**：`comsol_mcp/jobs/process_control.py`，_inspect_open_process()、terminate_exact()。
- **内容/复现方法**：上述脚本用无真实进程动作的 FakeProcess 调用生产 terminate_exact()，PID 与命令摘要匹配，expected process_create_time=NaN，actual=123；abs(actual-NaN)>tolerance 为 False，返回 state=active、acted=True，fake.terminate 被调用。store.process_identity_state 会拒绝非有限时间，但该终止入口直接使用不同的内部 verifier，因此并未继承保护。实际 durable lease 的提前校验可能挡住部分输入；问题是终止入口自身违反 exact identity 契约，不声称复现杀死了任何真实进程。
- **可能的解决办法**：行动前严格要求 PID 为正整数、时间为有限合法数字、摘要格式正确，并复用同一身份规范化函数；对 NaN、Infinity、bool 与字符串身份确保 acted=False。

## BUG-102

- **编号**：BUG-102
- **标题**：staged sweep 规范化接受错误布尔类型，并将字符串 false 转为继续执行
- **严重性/优先级**：中 / P2；输入含义与实际停止策略相反。
- **位置**：`comsol_mcp/jobs/manager.py` validate_staged_sweep_spec()；`comsol_mcp/jobs/worker.py` _runner_kwargs()。
- **内容/复现方法**：`python /workspace/code-review/repro_staged_worker_edges.py` 给真实 spec validator 传 continue_on_error='false'、smoke_points=True；两者均通过。worker 将前者 bool() 转成 True，后者在计数时转成 1，无法发现类型错误。公开 job_submit 的 spec 是 object，不会替嵌套字段提供严格 bool 校验。record_wavelength_controls 也没有类型校验，尚未将该字段的后续影响计作独立问题。
- **可能的解决办法**：规范化时逐项严格校验所有布尔字段，禁止 bool 充当整数计数；后续 worker 使用已验证值而非 truthiness 转换。

## BUG-103

- **编号**：BUG-103
- **标题**：owned staged/robust worker 启动时未核对 immutable source SHA-256
- **严重性/优先级**：高 / P1；绑定到旧源模型的作业可加载变化后的文件。
- **位置**：`comsol_mcp/jobs/worker.py` _run()，owned 分支 client.load() 前；`comsol_mcp/jobs/manager.py` resume()；`robust_shape_worker.py` _run_licensed() 与 `robust_shape_native_runtime.py` execute_lin2025_conditions()。
- **内容/复现方法**：上述脚本使用真实 validator 将原始文件摘要绑定到 spec，再修改源文件，用真实 JobStore 和 worker.run()、纯 ownership/MPh 替身执行。即使加载文件 SHA 与 source_model_sha256 不同，worker 仍进入 FakeClient.load()；脚本立即抛出停止异常，不运行求解器。仅 attached 分支有启动摘要比较，owned 分支只有环境 preflight；resume 只核对 spec 自身摘要而非源文件内容。workflow 会把当前文件身份写入结果 manifest，因此不能认为旧 spec identity 已保证源模型一致；既有 worker mock 测试甚至以 source_model_sha256='0'*64 跑到 completed。
- **补充复现（内容）**：`repro_robust_startup_budget_source.py` 使用真实 Lin2025 manifest expander 冻结 SHA 后更改源文件。真实 robust worker 在纯 native 替身下进入条件批次，既未与 spec.source_model_sha256 比较，也不拒绝变更；它仅保存启动时 bytes 并在结束时比较。再调用真实 execute_lin2025_conditions 与 load sentinel，实际调用 client.load 读取了变化后的源 SHA。source 在整个本次运行保持变化后的内容时，cleanup 的 source_unchanged 仍为 True。这证明 robust lane 同样缺少启动 pin 校验，无 native solver。
- **可能的解决办法**：所有 backend 在获取求解资源和加载前核对绑定源摘要，resume preflight 同时检查源身份；读取/复制成作业私有 immutable snapshot，避免检查与 load 之间文件变化。

## BUG-104

- **编号**：BUG-104
- **标题**：staged sweep 接受重复参数值，但终态按原列表长度判定永远无法完成
- **严重性/优先级**：中 / P2；合法提交会在完成求解后被错误标为失败。
- **位置**：`comsol_mcp/jobs/manager.py` validate_staged_sweep_spec()；`comsol_mcp/jobs/worker.py` _valid_row_count() 与末端计数核对。
- **内容/复现方法**：上述脚本传 parameter_values=[1.0,1.0]，validator 接受并声明 2 个点。用真实 run_staged_parametric_sweep 和仓库 FakeModel 执行，runner 返回 success=True，但真实 _valid_row_count() 对 parameter_value 集合计数仅为 1。worker 要求 completed == len(parameter_values)=2，否则抛出失败；smoke_points=2 时更早失败。没有启动 COMSOL。
- **可能的解决办法**：在提交前按实际格式化参数 token 拒绝重复值，或规范化为唯一点列表并让所有 budget/progress/终态判断采用相同唯一性定义。

## BUG-105

- **编号**：BUG-105
- **标题**：worker 在 native grace 中先退出时，已捕获的活后代永远不进入清理分支
- **严重性/优先级**：中 / P2；取消停在 cancelling，已确认 owned 后代仍存活。
- **位置**：`comsol_mcp/jobs/cancel_worker.py`，native_grace 的 worker 非 active 分支与后续提前 verifying 分支。
- **内容/复现方法**：`python /workspace/code-review/repro_cancel_orphan.py` 使用仓库 FakeClock/FakeProcesses、真实 JobStore 与 coordinator.run()：Linux 对应的 process_tree_contained=False，先完整捕获 1 个活后代，然后 worker 在 grace=1s 内 0.5s 退出。coordinator 只等待 worker+后代 absent，超时记录 blocked 并返回，从不调用已知后代的 terminate_exact。再次运行仍 status=cancelling、phase=blocked、活后代=1、actions=[]。这是身份已知且验证 active 的后代，不是缺失 capture 或 uncertain identity；复现没有真实进程动作。
- **可能的解决办法**：worker 已退出但已捕获后代仍 active 时，保留完整 capture 并推进后代精确终止/强杀和验证；只对 uncertain 身份保持 blocked；重启时恢复该清理阶段而非反复等待自然退出。

## BUG-106

- **编号**：BUG-106
- **标题**：durable cancellation 原生验收硬编码 14 cores，忽略调用者声明的资源上限
- **严重性/优先级**：中 / P2；小型 Linux/Windows 主机与用户设置的验收资源不一致。
- **位置**：`development_kit/tests/integration/durable_cancel_acceptance.py`，main() 提交 spec 的 cores。
- **内容/复现方法**：`python /workspace/code-review/repro_cancel_acceptance_cores.py` 设置 COMSOL_MCP_ACCEPTANCE_CORES=1，注入纯 fixture/manager 替身执行真实 main()，在 submit 边界截获 spec 的 cores=14。没有求解器动作。仓库已提供 required_acceptance_cores() 要求显式声明并按 live os.cpu_count 上限验证，其他 native probe 使用该 helper；这个入口完全绕过，既有 test_acceptance_resources 的文本扫描也漏掉数字 cores 字段。可能在不足 14 核或明确限用 1 核的机器上产生资源超用或验收失败。
- **可能的解决办法**：使用 required_acceptance_cores() 获取本次调用的资源配置，并在创建 job 前校验；补充真实入口捕获 spec 的无求解器测试。

## BUG-107

- **编号**：BUG-107
- **标题**：多候选分支已用测量证据消歧后，选定峰不会传递到下一个 continuation transition
- **严重性/优先级**：中 / P2；连续分支被错误标为 residual，停止策略可能提前终止。
- **位置**：`comsol_mcp/evidence/branch_continuation.py`，_one_transition() 与 plan_branch_continuation()；_normalize_continuation_policy() 的 preceding measured peak 检查。
- **内容/复现方法**：`python /workspace/code-review/repro_branch_continuation_edges.py` 使用仓库真实三状态 fixture：单峰 → 多峰（提供绑定 raw row 的测量证据选 4.95µm）→ 单峰 5.1µm。guard=0.5µm，两者距离 0.15µm；第一 transition branch_followed=True，第二 False，整体 residual。原因是后一 transition 从原始多候选 summary 读取 peak_wavelength_m=None，忽略上一 transition 已验证的 selected_candidate_wavelength_m。连续多个多峰状态也无法据上一选择提供 continuity evidence，因为 normalizer 要求原 summary 中的 previous_peak 非 null。纯科学规划，无 COMSOL。
- **可能的解决办法**：按顺序维护已测量并消歧的有效 branch peak，连同 supporting row/evidence hash 传递至后续 transition 和证据验证；不得把未经消歧的多峰自行选成一个峰。

## BUG-108

- **编号**：BUG-108
- **标题**：continuation state validator 接受负 FWHM 和负 Q，并允许规划为 accepted
- **严重性/优先级**：中 / P2；导入状态的科学语义校验弱于从光谱测量构建的状态。
- **位置**：`comsol_mcp/evidence/branch_continuation.py`，_validate_state_summary() candidate 数值校验。
- **内容/复现方法**：上述脚本从真实 builder 生成正常 states，将每个 candidate 的 fwhm_m=-1、quality_factor=-2，并用真实 canonical 算法重算两层摘要。validate_continuation_states() 接受，plan_branch_continuation() 返回 scientific_disposition=accepted。并非篡改摘要未被发现，而是摘要一致但内容不可能的输入通过语义校验；公开工具允许直接 continuation_states 路径。正常谱宽应为正，Q 应与 peak/FWHM 关系一致。原生 worker 从原始光谱重算的路径未据此声称被绕过。
- **可能的解决办法**：要求有限正谱宽与 Q、成对声明和 peak/FWHM 一致关系；必要时要求原始 characterization 验证绑定；在现有 self-rehashed malformed-state 测试中补充科学数值边界。

## BUG-109

- **编号**：BUG-109
- **标题**：campaign 允许不同 child resource policies，但共用账本按单一 policy 重放导致第二状态失败
- **严重性/优先级**：中 / P2；有效的逐状态资源策略无法执行。
- **位置**：`comsol_mcp/jobs/spectral_level_execution.py` ResourceStageAdapter 构造；`comsol_mcp/jobs/resource_admission.py` _next_sequence()/replay_resource_journal()；`comsol_mcp/jobs/branch_continuation_campaign.py` 规范化。
- **内容/复现方法**：`python /workspace/code-review/repro_campaign_resources_progress.py` 第一段用真实 campaign normalizer/worker/store、仓库纯 collector/client 替身，令状态 0 max_mesh_elements=1000、状态 1=2000，两者都高于假观测 12。normalizer 接受，第一谱完成，第二状态 pre_solve 报 resource admission policy does not match the bound job policy，最终 failed、client_loads=2。因为 child 使用同一主 job resource.jsonl，Adapter 用当前 child policy 重放包括之前 child 的全部记录，而 journal 强制所有 admission 绑定一个 policy。脚本完整运行断言通过；没有 COMSOL。
- **可能的解决办法**：给各 child 分离资源账本或在条目中绑定 child identity 并按各自 immutable policy 验证；若暂不支持不同策略，提交前明确拒绝并记录限制，不能在完成第一状态后才失败。
- **补充证据**：convergence_campaign.py 同样允许各 level 策略不同，convergence_campaign_worker.py 同样给 child 使用主作业资源账本。`repro_convergence_campaign_edges.py` 第一段真实 normalizer/worker 与纯 client/collector 证明第二 level max_mesh_elements=2000（第一为 1000）时第二次 load 后失败，错误完全相同。

## BUG-110

- **编号**：BUG-110
- **标题**：partial continuation state 恢复会隔离全部有效点并重复求解，进度投影也重复累计
- **严重性/优先级**：中 / P2；恢复消耗重复计算并输出错误的完成点数。
- **位置**：`comsol_mcp/jobs/branch_continuation_campaign_runner.py`，state_dir.exists() 的 append failure quarantine；`comsol_mcp/jobs/branch_continuation_campaign_worker.py`，completed_points 初始化与增量投影。
- **内容/复现方法**：上述脚本第二段用真实 worker/store/runner 与纯 collector 替身，在第 3 个 spectral row 已持久化、progress 更新前注入一次 OSError。worker failed，投影保留 completed=2，目录中有 3 个可验证点。attempt=2 恢复时 append_state 因整个 child spectrum 尚未 complete 而拒绝，runner 把包含有效部分 rows 的整个目录当 invalid quarantine，再从头求解。最终 durable points=29、collector calls=32，其中 3 个 fingerprint 重复；状态却 progress={completed:31,total:31}，因为旧投影 2 被加到新一轮 29 点上。所有断言通过，无 COMSOL。已有恢复测试仅覆盖完整子状态，未覆盖子状态内部部分完成。
- **可能的解决办法**：区分可验证的 partial spectrum 和真正损坏的 artifacts；让 child runner 在原目录从已验证 rows 继续，仅隔离无法验证的产物；progress 始终由各 child durable rows 重建，避免旧投影累加。
- **补充证据**：convergence_campaign_runner.py 的 level_dir.exists() 分支有同样 quarantine；worker 虽从 durable rows 初始化 completed_points，随后删除原目录语义并重算仍重复累计。`repro_convergence_campaign_edges.py` 第二段在第 3 行投影前中断，恢复最终实际 27 行、30 次 collector 调用、3 个重复点，progress 却为 30/30。

## BUG-111

- **编号**：BUG-111
- **标题**：spectral job 忽略重试/继续策略，validation matrix 也忽略 max_retries
- **严重性/优先级**：中 / P2；调用者设置的错误恢复策略不生效。
- **位置**：`comsol_mcp/jobs/spectral_characterization.py` 规范化；`comsol_mcp/jobs/spectral_runner.py` point_executor 调用；`comsol_mcp/jobs/spectral_worker.py` 与 spectral_level_execution.py 组合。
- **内容/复现方法**：`python /workspace/code-review/repro_spectral_worker_edges.py` 第一段用真实 normalizer 设置 max_retries=3、continue_on_error=True，然后调用真实谱 runner，pure point executor 第一次抛临时 RuntimeError；runner 仅调用 1 次立即退出，后续点也不执行。代码检索确认这两个字段只在谱 spec builder 校验/存储，所有谱 worker/runner 都没有消费；普通 staged sweep 的同名字段会传给 workflow，不能据此认为谱作业也实现了它们。无 COMSOL。
- **可能的解决办法**：在完整预算、取消和副作用约束下实现有界重试及明确的后续点处理；若谱证据契约不支持继续错误点，应在提交时拒绝这些非默认策略或删除字段，避免静默忽略。
- **补充证据**：validation_matrix.py 也规范化并绑定 max_retries=0..3，但 validation_runner.py/validation_worker.py 没有消费；`repro_validation_resume.py` 用真实 matrix normalizer/runner 与纯 collector，设置 3 后遇到临时异常仍只调用 1 次。该作业的 continue_on_error 已消费，不能把谱作业的两个忽略字段笼统套用到 matrix。

## BUG-112

- **编号**：BUG-112
- **标题**：spectral worker 的 driver startup 校验发生在异常持久化范围外
- **严重性/优先级**：中 / P2；旧 build 作业启动失败后没有 durable 原因记录。
- **位置**：`comsol_mcp/jobs/spectral_worker.py`，_run() 开头 validate_spectral_driver_identity()。
- **内容/复现方法**：上述脚本第二段用真实 JobStore 保存含不匹配 package_content_sha256 的 spec，再调用真实 _run()。直接抛 ValueError，state 仍 submitted、last_error=None，未调用 native factory。实际脱离进程启动时可能仅在 worker.log 留 traceback，随后被 status 泛化成 interrupted；与分支 campaign worker 在 try 内记录 driver mismatch 为 failed 不一致。拒绝旧 build 是正确行为，问题是丢失 durable 失败原因和状态。
- **可能的解决办法**：把 spec/type/driver/startup 检查纳入 attempt 绑定的统一异常处理；失败时保存 bounded last_error 并保持取消协调器对终态的所有权。

## BUG-113

- **编号**：BUG-113
- **标题**：spectral/staged/validation worker 未等待 native cancel 调用退出便 clear client 和释放 solver lease
- **严重性/优先级**：高 / P1；仍访问 Java 的线程与清理并发，资源所有权被过早释放。
- **位置**：`comsol_mcp/jobs/spectral_worker.py`、`comsol_mcp/jobs/worker.py`、`comsol_mcp/jobs/validation_worker.py` 的 finally：join(timeout=1.0) 后未检查 is_alive()。
- **内容/复现方法**：上述脚本第三段用真实 spectral worker/store，native_cancel 纯替身在 Event 上阻塞，collector 请求取消并确认该线程已进入调用。worker join 超时后返回 0，同时在 native_call_active=True 时调用 FakeClient.clear() 和 ownership.release()；所有断言通过，最后主动释放 Event，没有 Java/COMSOL。普通 staged worker 有同样结构；branch campaign worker 已明确检测线程仍活跃、保留 client/lease 并记录 cleanup failure，证明这些路径需要同样保护。
- **可能的解决办法**：join 后核对线程是否退出；仍活跃时保留资源和所有权、记录 nonterminal/失败的清理回执，交由精确进程取消协调器验证；不得将 join 超时当作 native 调用结束。

## BUG-114

- **编号**：BUG-114
- **标题**：durable spectral row 验证未将数值绑定到已验证的原始 measurement
- **严重性/优先级**：中 / P2；完整性门允许原始证据与参与光谱分析的数据不一致。
- **位置**：`comsol_mcp/jobs/spectral_rows.py`，_verify_artifact_bytes()、_normalize_row_body()、append_spectral_row()/read_spectral_rows()。
- **内容/复现方法**：`python /workspace/code-review/repro_spectral_row_measurement.py` 用真实 normalizer、audit extractor 和 rows API，生成 A=0.2、波长 4 µm 的完整假 collector 产物；随后将 append 参数改为 A=0.9、R=0.05、evaluated_wavelength_m=8 µm，保持原始文件及其摘要不变。append 和带 artifact_root 的完整 replay 均接受，输出 A=0.9、evaluated=8 µm。验证仅检查物理回执 producer/source/config_id、文件摘要和 audit_status，没有比较 measurement 的 R/T/A、三个波长、mesh 和 solve 字段，也没有重放 wrapper 与 inner descriptor 的绑定。正常 extractor 会正确提取，问题发生在持久层接受错误参数或重封装的导入数据时；不是声称任意字节损坏均可绕过 SHA。无 COMSOL。
- **可能的解决办法**：持久验证复用严格 audit extraction，并将重提取的完整数值与 row 逐字段比较；校验 wrapper 身份及 inner descriptor，拒绝不能由原始证据确定的完整点。

## BUG-115

- **编号**：BUG-115
- **标题**：validation matrix 恢复不重新验证 artifacts，文件全部丢失后仍跳过并报告成功
- **严重性/优先级**：中 / P2；已失效的物理证据被作为完整 durable 点复用。
- **位置**：`comsol_mcp/jobs/validation_rows.py`，completed_point_fingerprints()/read_validation_rows()；`comsol_mcp/jobs/validation_runner.py` 的 completed skip；`comsol_mcp/jobs/validation_worker.py` 的 startup/completion 检查。
- **内容/复现方法**：`python /workspace/code-review/repro_validation_resume.py` 先用真实 matrix normalizer/runner 写入 2 个 ok rows 和有摘要的纯 collector manifests，删除这两个文件后 attempt=2 再运行。runner 不调用 collector，返回 success=True、skipped_completed=2、remaining=0。rows reader 仅校验描述符字段和行摘要，既不验证 manifest 存在/字节摘要，也不验证 wrapper 引用的 inner/array。生产 worker 的初始和最终完成检查同样仅调用 completed_point_fingerprints，因此文件删除或改变不会使点变为不可恢复。复现用 repo 测试替身，无 COMSOL。
- **可能的解决办法**：为完整点恢复增加 containment、文件存在、上界、摘要及 wrapper/inner/array 链验证；无法验证时保留损坏证据并将该点作为明确待重试项，不能凭 ok 标签跳过。

## BUG-116

- **编号**：BUG-116
- **标题**：convergence campaign 的追加账本没有 partial-tail 恢复，尾部断写后不能自动继续
- **严重性/优先级**：中 / P2；崩溃恢复需要手动修复账本，与子谱逐点恢复行为不一致。
- **位置**：`comsol_mcp/jobs/convergence_campaign_rows.py`，_read_convergence_campaign_levels_unlocked() 与 _append_convergence_campaign_level_unlocked()。
- **内容/复现方法**：`python /workspace/code-review/repro_convergence_campaign_edges.py` 第三段用真实规范化 campaign spec，将 JSONL 尾部设为一次 append 断写可产生的 `{"schema_name":`，调用真实 reader 后直接 JSONDecodeError，文件仍保留原来的 partial bytes。reader 不调用已有 recover_jsonl_tail，append 又先调用同一 reader，故重启后读取/追加都被永久阻塞。生产 append 用普通 ab write+fsync，崩溃在 write 中途不能保证整行；已有测试只覆盖完整 level row 或完整 spectrum 之后的故障，不覆盖正在追加行的中断。探针模拟断写，不声称执行过真实进程 crash/COMSOL。
- **可能的解决办法**：在 journal 锁内用已有有界尾恢复机制，仅修复最终不完整记录，保留并验证此前完整链；完整但损坏的行仍应拒绝并记录明确原因。

## BUG-117

- **编号**：BUG-117
- **标题**：thermo-optomechanical 作业接受资源与时间预算，却没有执行资源 admission
- **严重性/优先级**：中 / P2；声明的 mesh/memory/wall 等限制不能阻止后续昂贵阶段。
- **位置**：`comsol_mcp/jobs/thermo_optomechanical_replay.py` 的 resource_policy 规范化；`thermo_optomechanical_replay_worker.py`、`thermo_optomechanical_replay_runner.py` 的阶段调度。
- **内容/复现方法**：`python /workspace/code-review/repro_thermo_edges.py` 第一段将提交 manifest 的 resource_policy.max_mesh_elements=1，通过真实 normalizer/worker 与仓库纯 stage/client/owner 替身执行。state_evidence 记录 element_count=100，worker 仍 completed/scientifically accepted，资源账本有 0 项。代码检索确认 worker/runner/executor 没有消费 resource_policy 或 wall_time_budget_seconds，也没有 telemetry/admission/watchdog；normalizer 只是存储预算并校验字段相互大小。脚本最初误认为资源账本不存在，实际 JobStore 建立空文件；已改为断言真实账本为空并完整重跑通过。无 COMSOL。
- **可能的解决办法**：在每个可安全停止的阶段/光学点前后接入真实资源 telemetry 与 ResourceStageAdapter，并落实总 wall budget；无法支持的策略在提交时拒绝，不能静默接受。

## BUG-118

- **编号**：BUG-118
- **标题**：thermo-optomechanical 的体热源和对流系数不应用也不读取校验
- **严重性/优先级**：中 / P2；不同的已声明热负载产生相同的 native 配置，convection control 仅检查输入为正。
- **位置**：`comsol_mcp/contracts/thermo_optomechanical.py` ThermalLoad/ModelContract；`comsol_mcp/jobs/thermo_optomechanical_replay_execution.py`，_apply_positive_parameters() 与 _optical_replay() controls。
- **内容/复现方法**：上述脚本第二段分别规范化两份合法 manifest，将 volumetric_heat_source_W_per_m3 从 0 改为 10000、convection_coefficient_W_per_m2_K 从 10 改为 999。真实 executor 的 _apply_positive_parameters() 通过纯 _parameter 替身记录调用，两份调用完全一样。全文件检索显示体热源从未读取，对流系数唯一使用是 `> 0` 然后报告 convection_is_explicit；ModelContract 也没有对应参数/feature 路径。源 MPH 可能已有固定热源/对流值，但执行器没有证明它们等于提交值，故该声明无法保证实际模拟负载。未启动 Java/COMSOL。
- **可能的解决办法**：为体热源和 convection feature 建立明确参数/tag/property 契约，应用单位明确的值并读回；若期望它们只是源模型声明，也必须校验源模型设置，不能仅把输入标签作为 control 成功证据。
- **补充静态证据**：已完整阅读 `development_kit/scripts/thermo_optomechanical_licensed_gate.py`：fixture 定义 hconv 参数为 10，但没有创建使用该参数的 convection/heat-flux feature，所有 thermal 边界是固定温度；QoutH1 固定为 0[W]。因此该 native gate 的 convection pass 标签也没有证明实际对流边界。没有在 Debian 执行 native gate。

## BUG-119

- **编号**：BUG-119
- **标题**：thermo 阶段 evidence 允许矛盾能量余额与负位移比例，summary 仍接受
- **严重性/优先级**：中 / P2；导入/恢复证据可带自洽摘要却通过错误的科学验收。
- **位置**：`comsol_mcp/jobs/thermo_optomechanical_replay_rows.py` _validate_stage_payload() thermal_structural_solve/state_evidence；`thermo_optomechanical_replay_runner.py` build_thermo_optomechanical_summary()。
- **内容/复现方法**：上述脚本第三段用真实 stage evidence builder/runner，pure stage payload 设置 source_W=100、loss_W=0，同时 residual_W=0、relative_residual=0，并令 displacement_to_length=-100。所有 evidence、durable rows 和最终 summary 均接受，scientific_disposition=accepted。余额验证只要求各值有限，没有重算 residual；位移比例也只要求有限，summary 的 `> maximum` 判断让负值通过。正常 native executor 重算余额并取 abs displacement，问题是 evidence 入口/恢复校验没有保留这些科学约束；不声称已证明 native 计算会产生这种数据。无 COMSOL。
- **可能的解决办法**：从 source/loss 重算绝对及相对余额并比较，拒绝负 residual ratio、deformation/displacement ratio；绑定位移与 reference_length、deformation scale 和前序 stage 值，最终验收消费重算结果。

## BUG-120

- **编号**：BUG-120
- **标题**：thermo native 波长容差与 durable evidence 精确相等冲突，合法末位误差仍导致失败
- **严重性/优先级**：中 / P2；可接受的浮点读回在完成求解后被持久化阶段拒绝。
- **位置**：`comsol_mcp/jobs/thermo_optomechanical_replay_execution.py` _wavelength_readback_matches()/_optical_replay()；`thermo_optomechanical_replay_rows.py` optical_replay payload 的 requested != solved。
- **内容/复现方法**：`python /workspace/code-review/repro_thermo_edges.py` 最后一段将 solved_wavelength_m 设为 requested=1.5e-6 的 math.nextafter 向上值。真实 executor helper 返回 True（与仓库既有 test_wavelength_readback_accepts_last_ulp... 的预期一致），但真实 build_stage_evidence 抛 optical replay wavelength readback is not exact。native executor 会把实际 solved 值原样存入 payload，故前一门接受的回执在后一门必失败；不需要真正 COMSOL 产生该舍入值即可确认契约矛盾。无 native 运行。
- **可能的解决办法**：两个门复用同一单位明确的容差校验，保留 actual/requested 原始值与差值；若业务坚持精确坐标，验证容差后另存 canonical coordinate，不能让两层校验相互矛盾。

## BUG-121

- **编号**：BUG-121
- **标题**：adjoint journal reader 未执行声明的最大记录数
- **严重性/优先级**：低 / P3；导入/恢复读取上限与追加上限不一致。
- **位置**：`comsol_mcp/jobs/adjoint_rows.py`，_read_adjoint_rows_unlocked()。
- **内容/复现方法**：`python /workspace/code-review/repro_adjoint_edges.py` 用真实 domain_sha256_v2 生成 4097 个完整、身份/顺序/前向摘要链正确的 iteration rows，调用真实 read_adjoint_rows 返回全部 4097 行，尽管 MAX_ADJOINT_ROWS=4096。reader 仅把 max_rows*max_row_bytes（1 GiB）作为整体读取上限，既没有 entry count 检查也没有逐行字节检查。正常 append 达到 4096 会拒绝，问题是 imported/recovered journal 不遵循同一个上限；脚本约数 MiB，不做大内存耗尽实验，无 COMSOL。
- **可能的解决办法**：在解析前/逐行过程中执行 entry count 与每行 bytes 上限，使用 bounded binary readline，并保留部分最终行的锁内恢复策略。

## BUG-122

- **编号**：BUG-122
- **标题**：adjoint manifest 接受 initial_values，但 native 初始化一直使用 support.baseline
- **严重性/优先级**：中 / P2；调用者指定的优化初始点不生效。
- **位置**：`comsol_mcp/jobs/adjoint_optimization.py` initial_values 校验/存储；`comsol_mcp/jobs/native_adjoint_runtime.py` execute_native_adjoint_optimization()、_freeze_wavelength()；native configure 对 support 的调用。
- **内容/复现方法**：上述脚本第二段用真实 manifest expander 设置 synthetic_mode=False、initial_values=[749]（合法 bound 内），support baseline=856 nm。真实 _freeze_wavelength() 通过纯 Java feature/_set_vector 替身记录 initval=['856[nm]']，没有使用 749。完整 runtime 只传 support/optimizer 给 configure_native_adjoint，后续也没有读取 spec.initial_values；initial_values 唯一运行消费在 synthetic worker 的 candidate fingerprint，不能认为 native 已接线。没有启动 COMSOL，也不声称已观察到最终优化轨迹。
- **可能的解决办法**：将提交初始值明确传入 native controls/optimizer initval 并读取校验，保留 support baseline 作为参考身份；若必须固定 baseline，应在提交时拒绝不同初始值。

## BUG-123

- **编号**：BUG-123
- **标题**：native adjoint adapter 接受 differentiable_scalar constraints 却没有配置或验证它们
- **严重性/优先级**：中 / P2；优化结果可能违反调用者明确约束而仍作为 accepted 输出。
- **位置**：`comsol_mcp/research/adjoint_adapter.py` configure_native_adjoint()；`comsol_mcp/jobs/native_adjoint_runtime.py` finalist 校验。
- **内容/复现方法**：`python /workspace/code-review/repro_adjoint_constraints.py` 使用仓库 two-variable trusted support，添加合法 differentiable_scalar constraint `patch_length_x <= 700 nm`，调用真实 adapter 与纯 backend。调用成功，initval 为 856 nm，原生只设置 variable bounds=642..1070 nm；全部 feature properties 没有该约束，receipt 也没有 constraint readback。完整配置函数不消费 support.constraints，native finalist 只检查 objective/mesh/closure，没有复核约束。现有 variable bounds 仍生效；问题是另一个已被接受的 scalar constraint 被忽略。无 COMSOL，不声称已观察真实优化结果违反约束。
- **可能的解决办法**：给支持的 scalar constraints 配置 native expression/unit/bounds 并读回，在最终 forward 再验证；不支持的 constraint kind 或表达式在任何模型副作用前拒绝。

## BUG-124

- **编号**：BUG-124
- **标题**：native objective direction=match 被静默解释为 minimization
- **严重性/优先级**：中 / P2；已接受的目标语义被替换。
- **位置**：`comsol_mcp/research/derivative_support.py` _DIRECTIONS/normalize_derivative_objective()；`comsol_mcp/research/adjoint_adapter.py` optimization objectivetype。
- **内容/复现方法**：上述脚本第二段把合法 trusted support 的 objective.direction='match'，真实 adapter 调用成功，但 objectivetype 的 requested/readback 都是 minimization；代码使用 maximize ? maximization : minimization，没有 match 分支，也没有目标值/差值转换。正常 maximize/minimize 可配置，问题限于被声明为合法的第三种方向。纯 backend 复现，无 native 求解。
- **可能的解决办法**：若当前 lane 不实现 matching objective，明确拒绝该方向；若实现，应定义 target、单位和误差表达式并完整绑定、读回，不能当原表达式最小化。

## BUG-125

- **编号**：BUG-125
- **标题**：directional gradient 的朴素范数溢出会将非零方向变为零并错误通过
- **严重性/优先级**：中 / P2；有限且方向相同的输入缩放改变科学验证结果。
- **位置**：`comsol_mcp/research/gradient_validation.py` _norm() 与 compare_directional_gradient()。
- **内容/复现方法**：`python /workspace/code-review/repro_gradient_norm.py` 用真实 gradient/support normalizer 和 directional comparator，native gradient=0.002、plus/minus objective 同为 0.8。direction=[1] 输出 predicted=0.002、observed=0、passed=False；仅改为同方向有限 [1e200]，平方和变 inf，归一化输出 direction=[0]、predicted=0、passed=True。输入检查允许该有限值，但归一化没有检查 norm/normalized 非零。没有 COMSOL；不是针对网络输入的攻击探针。
- **可能的解决办法**：使用 math.hypot 或按最大分量缩放的稳定范数，验证归一化后仍非零且范数接近 1；以同方向的大/小有限缩放做科学不变性检查。

## BUG-126

- **编号**：BUG-126
- **标题**：native finite-difference gate 的最终 source hash 异常会覆盖原错误并丢失回执
- **严重性/优先级**：中 / P2；模型文件删除/读取失败时，失败验收无法保留可靠诊断。
- **位置**：`development_kit/scripts/native_gradient_fd_licensed_gate.py` _run() finally 与 main() 回执写入。
- **内容/复现方法**：`python /workspace/code-review/repro_native_fd_cleanup.py` 调用真实 _run()，注入纯 MPh client：load 抛 RuntimeError('review original load failure')，clear 成功；source hash 第一次成功，cleanup 时抛 OSError。finally 的 try 内 hash 抛出后 except 又不受保护地再次调用相同 _sha，直接向外传播 OSError，覆盖已有 error evidence，_run 不返回，main 后置的 atomic_write_json 无法执行，receipt 文件不存在。脚本第一次遗漏模拟 spec.native_receipt 而提前 KeyError，已补齐并完整运行断言通过。没有真实 solver/JVM。
- **可能的解决办法**：复用结构 gate 的 _cleanup_source_entry 式受保护单次校验，保留原始错误，将最终 hash 错误作为 cleanup evidence；无论清理哪一步失败，都尽量持久化明确失败回执。

## BUG-127

- **编号**：BUG-127
- **标题**：三个 native gradient gates 启动时不再核对输入 source pin，换源后仍加载模型并替换回执身份
- **严重性/优先级**：中 / P2；验收可能比较不同来源的 forward 与已有 native gradient，破坏同源验证。
- **位置**：`development_kit/scripts/native_gradient_licensed_gate.py`、`native_gradient_fd_licensed_gate.py`、`native_gradient_directional_licensed_gate.py` 的 _run() source_before 与 client.load()。
- **内容/复现方法**：`python /workspace/code-review/repro_gradient_source_binding.py` 对三个真实 _run() 提交旧 source_sha256，在输入校验后把文件替换为不同内容；只注入资源门、support 和纯 MPh client（load 记录文件 SHA 后抛 sentinel，不运行求解）。三者都调用 load 加载新内容，并把 receipt.source_sha256 设为新 SHA，未拒绝 spec.source_sha256 的不匹配。FD/directional 的 native receipt 仍绑定旧 source，这会使已声明的 exact successful full-vector source 保证失效。相对地 structural adjoint gate 有启动前明确比较。无 COMSOL，不声称已完成真实错误梯度比较。
- **可能的解决办法**：在任何模型加载/输出覆盖前重新校验 source SHA 与冻结 spec/manifest/native receipt 一致，并将冻结身份和实际身份分别记录；异常 fail closed。对多个输入文件的重新校验采用一致的生命周期策略。

## BUG-128

- **编号**：BUG-128
- **标题**：robust soft minimum 的权重求和溢出，等权有限缩放使合法目标无法计算
- **严重性/优先级**：低 / P3；极大但合法的有限权重导致数值鲁棒性失败。
- **位置**：`comsol_mcp/research/robust_objectives.py` evaluate_robust_absolute_contrast() 的 weighted_terms、total_weight、partition。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_weight_scaling.py` 采用仓库 24-condition/12-pair fixture，正常等权目标为 0.20100000000248758；把全部条件权重等比设为 1e308，真实 condition normalizer 接受，但目标计算产生 inf/inf 的 NaN，在 receipt hashing 抛 ValueError('JSON numbers must be finite')。归一化 weighted soft minimum 的数学结果应不受所有权重共同缩放影响，而且该目标有限。没有产生错误成功回执，问题是支持范围内的输入无法稳定计算；无 COMSOL。
- **可能的解决办法**：先按最大权重缩放或使用 log weights/log-sum-exp，稳定计算分区函数与 softmin weights，并显式验证所有派生值有限。

## BUG-129

- **编号**：BUG-129
- **标题**：robust condition 回执恢复只验身份与摘要，没有重新执行科学及 mesh 约束
- **严重性/优先级**：中 / P2；导入或恢复证据可绕过首次运行的科学验收。
- **位置**：`comsol_mcp/jobs/robust_condition_runtime.py` execute_robust_conditions() receipt_path.exists() 分支。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_recovery_and_optional.py` 第一段使用真实 condition runtime 与仓库纯 backend，在 receipt 已写、row 未写处模拟中断。将回执改为负 reflectance=-0.2、solved 波长偏离 requested、mesh elements=1001 超过 cap=1000、quality=0.01 小于阈值 0.2、错误 dataset，并重算真实 domain fingerprint（模拟错误的导入/恢复回执）。attempt 2 不调用 backend，直接接受回执、追加 completed row、返回 measured observation。正常首次路径 _normalize_receipt 会拒绝这些值；这不是声称原生正常 producer 生成错误数据。恢复分支缺少 schema_version、字段全集、波长/功率/mesh/dataset 的语义重验；gradient runtime 的恢复已有重建校验。无 COMSOL。
- **可能的解决办法**：恢复时从保存字段重建并调用同一个 _normalize_receipt，比较 canonical receipt 与保存内容；绑定完整 spec、控制和 mesh 策略，不能只凭自洽 fingerprint 认定有效。

## BUG-130

- **编号**：BUG-130
- **标题**：finalist 允许 off_design=not_requested，但执行仍构造空条件表并失败
- **严重性/优先级**：中 / P2；合法可选配置在完成基线与细网格批次后必失败。
- **位置**：`comsol_mcp/jobs/robust_finalist_runtime.py` run_licensed_finalist() 无条件调用 _off_design_table()；`research/robust_finalist_validation.py` optional modes。
- **内容/复现方法**：上述脚本第二段用真实 Lin2025 spec fixture，真实 policy normalizer 接受 off_design 的 not_requested、空 offsets、validation_only=False。调用真实 run_licensed_finalist，仅替换 native execute 和 shape readback为纯替身；真实 objective/candidate/table normalization 保留。先执行 baseline/finer 各 24 个条件，随后 _off_design_table 构造 conditions=[]，normalize_optimization_condition_table 抛 ValueError('conditions must be a bounded nonempty list')，没有跳过未请求阶段。仓库 policy 测试也明确允许该模式；无 COMSOL，不声称执行了真实 48 solves。
- **可能的解决办法**：按 policy.mode 分支执行，not_requested 用空 off_design_rows 且不创建条件表/模型；总 solve bound 与 evidence 保持该模式一致。

## BUG-131

- **编号**：BUG-131
- **标题**：覆盖完整条件表的 execution limit 在 worker 被视为完整，梯度 runtime 却拒绝
- **严重性/优先级**：中 / P2；合法明确上限触发跨层契约冲突。
- **位置**：`comsol_mcp/jobs/robust_shape_worker.py` _requests_full_condition_gradients()/_run_licensed()；`robust_gradient_runtime.py` execute_native_condition_gradients()。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_gradient_policy.py` 第一段用真实 manifest fixture，24 个 active conditions，condition_execution_limit=24。真实 worker helper 返回 True，真实 gradient runtime 却立即抛 'native aggregate gradients require the complete condition table'，因为它拒绝所有非 None limit。worker 没有在 include_gradients=True 时移除/规范化该字段；源码路径会先完成 forward 再到此处失败。脚本只调用纯 helper/runtime，不启动 COMSOL。
- **可能的解决办法**：两层复用同一个 active condition count 判断；覆盖全集的上限规范化为完整请求，只有严格小于全集才拒绝 aggregate gradients。

## BUG-132

- **编号**：BUG-132
- **标题**：robust native gradient 行未执行独立验收就宣称 gradient_validated
- **严重性/优先级**：中 / P2；证据状态和 acceptance fingerprint 不能证明调用者的梯度阈值已经满足。
- **位置**：`comsol_mcp/jobs/robust_shape_worker.py` _append_native_gradient_row()、_run_licensed() 的 baseline/accepted candidate 路径。
- **内容/复现方法**：上述脚本第二段用真实 gradient policy normalizer，把误差限设 0、cosine floor=1、要求 sign。真实 row helper 接受只含 complete=True 与 receipt_fingerprint 的 aggregate（无分量/方向检查），写 evidence_state='gradient_validated'，acceptance_fingerprint 实际等于 policy_fingerprint。完整 worker 也只检查 aggregate.complete，再使用该函数和梯度进行优化；没有调用 assess_robust_gradient_acceptance/assess_licensed_gradient_ladder 或消费相应 passed receipt。首次 native producer 会产生完整梯度，但 complete 表示条件覆盖，不能替代独立 FD/方向验证。无 COMSOL，不声称 native 数值本身已证明错误。
- **可能的解决办法**：没有绑定且通过的梯度验收回执时记录 native_unchecked；需要 gradient_validated 的 lane 应执行/验证独立检查，存 acceptance receipt 指纹并核对同一 gradient、condition table、candidate 与 policy。

## BUG-133

- **编号**：BUG-133
- **标题**：robust worker 首个完整 forward/gradient 批次在 solve budget 检查之前启动
- **严重性/优先级**：中 / P2；合法小预算不会在昂贵原生批次前拒绝。
- **位置**：`comsol_mcp/jobs/robust_shape_worker.py` _run_licensed() 首个 execute_lin2025_conditions() 与后置 _optimizer_state_from_spec()/propose_gcmma_candidate()。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_startup_budget_source.py` 用真实 expander 接受 Lin2025 licensed manifest、显式 mmapy outer backend、max_solves=1、24 个 active conditions。真实 worker/JobStore/row 写入保持，ownership、watchdog、遥测、MPh 和 native 批次使用纯替身；worker 先进入 include_gradients=True 的完整 24-condition 批次，随后才创建 optimizer state并以 condition_solves=48 调用真实 propose，此时才抛 'GCMMA condition solve budget is exhausted'。没有实际执行 48 solves，但源码的调用顺序明确无法在批次前执行该预算。初次复现使用 compiler 默认 comsol_native backend，后置检查先报不支持；已改为明确支持的 outer backend 后完整断言通过。
- **可能的解决办法**：在原生启动前创建/验证 optimizer state 并计算完整起始批次所需预算，预算不足立刻拒绝；将 shape application、基线、梯度、候选、finalist 的实际 solve 计数统一纳入明确预算范围。

## BUG-134

- **编号**：BUG-134
- **标题**：finalist 允许 external_fidelity=not_requested，但仍生成回执并被自身验收拒绝
- **严重性/优先级**：中 / P2；合法可选配置在完成所有 finalist 条件批次后失败。
- **位置**：`comsol_mcp/jobs/robust_finalist_runtime.py` run_licensed_finalist() external_body/evidence；`research/robust_finalist_evidence.py` _external_fidelity()。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_optional_fidelity.py` 用真实 Lin2025 spec 与真实 policy normalizer 接受 not_requested、primary_backend=None、fallback_mode=not_requested。复用仓库 solver-free orchestration test 的纯 execute 替身，运行真实 finalist runner、目标和 evidence 评估，完成 baseline/finer/off-design 全集后依然写 external-validation.json，并把非空 external receipt 交给 assessor；后者抛 'not-requested external fidelity must not supply a receipt'。独立于 BUG-130，off-design 在此保持 required。无 COMSOL，批次均为 mock。
- **可能的解决办法**：按 external policy.mode 决定是否生成/比较独立 fidelity evidence；not_requested 必须传 None 并保持明确不声明该项验证。

## BUG-135

- **编号**：BUG-135
- **标题**：manager 为 native adjoint 启动的 wall watchdog 会把该作业判为 inapplicable 并退出
- **严重性/优先级**：高 / P1；原生 adjoint 可能失去墙钟预算监控，或因调度竞态无法启动。
- **位置**：`comsol_mcp/jobs/manager.py` _arm_robust_wall_watchdog_if_required() 的 adjoint_optimization 分支；`robust_wall_watchdog.py` run() job_type 检查；`adjoint_optimization_worker.py` _await_licensed_wall_watchdog()。
- **内容/复现方法**：`python /workspace/code-review/repro_adjoint_watchdog_dispatch.py` 使用真实 JobStore/current process identity 和 adjoint spec，生成 manager 同款 armed 绑定记录。真实 adjoint startup helper 接受它；随后调用 manager 实际指定的同一 watchdog.run()，后者把 job_type=adjoint_optimization 判为 'not_a_licensed_robust_job'，写 status=inapplicable、返回 2，从未进入取消循环。manager 已明确为 adjoint 提供 optimizer wall budget，但 watchdog 只支持 robust。若 worker 先看到 armed 则进入 native 后监控退出；反序则 helper 不接受 inapplicable并超时报未 armed。无 COMSOL、无进程终止。
- **可能的解决办法**：watchdog 显式支持两种 job type，按 discriminator 读取对应 budget 字段并核对 budget_source；启动确认应来自已完成适用性/绑定校验的 watchdog。

## BUG-136

- **编号**：BUG-136
- **标题**：robust material binding 不执行 optical mapping 的有效波长范围与禁止外推约束
- **严重性/优先级**：中 / P2；条件可在声明无效的材料区间被接受为有效绑定。
- **位置**：`comsol_mcp/research/robust_material_tensor_rows.py` bind_robust_material_tensor_rows()；`robust_conditions.py` material state/table normalization。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_material_range.py` 用仓库现有 mapping/condition/tensor fixture 和真实 normalizers/binder。所有材料 mapping 的 source_unit='nm'、valid_min=500、valid_max=1500、extrapolation='forbidden'；条件与精确 tensor samples 却在 8/9/10 µm（8000/9000/10000 nm）。binder 成功返回 binding_fingerprint。当前只查 source SHA、温度、exact sample coverage，没有转换源单位并检查 declared valid range；提供区间外的样本不能自动扩大已经冻结的 mapping 有效范围。无 COMSOL。
- **可能的解决办法**：在提交/绑定时按明确支持的 wavelength units 转换并验证全部 active/finalist wavelengths 位于每个状态的 valid range；需扩大范围时要求显式更新和重新绑定材料来源与 mapping。

## BUG-137

- **编号**：BUG-137
- **标题**：Lin2025 原生梯度用 SI 控制单位求导，却原样贴上 support 声明的导数单位
- **严重性/优先级**：中 / P2；非 SI support 单位下，持久 gradient evidence 的数值/单位不一致。
- **位置**：`comsol_mcp/jobs/robust_shape_native_runtime.py` _prepare_native_sensitivity() 的 punit=['m']；evaluate_condition_gradient() 的 accepted_gradients 与 gradient_unit。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_gradient_units.py` 调用真实 native gradient evaluator，model/Java/study 使用纯替身，提供 native fsens 值 [1e6,2e6]（配置的控制单位为 m），support.result_identity.derivative_units='1/nm'。返回数值仍是 [1e6,2e6]，单位却为 1/nm；正确换算应为 [.001,.002]。完整 source 中 sensitivity 统一将 punit/initval/scale 转为 m，却没有在 receipt 输出按声明转换。worker 的 _gradient_in_declared_units 会另对优化器转换，因此本条限于错误标注的 condition/native gradient 回执与 downstream evidence，不声称已证明 worker 优化步用了错误倍率。无 COMSOL。
- **可能的解决办法**：native 证据固定记录实际 SI 单位并明确 raw/converted 字段；如支持不同单位，按显式单位映射转换后验证/持久化，禁止只替换 unit 标签。

## BUG-138

- **编号**：BUG-138
- **标题**：Lin2025 mesh admission 在 shape/首个条件求解后才执行，与 pre-solve 策略冲突
- **严重性/优先级**：中 / P2；超限网格仍会进入本应拒绝的昂贵求解阶段。
- **位置**：`comsol_mcp/jobs/robust_shape_native_runtime.py` prepare()、run_shape_application()、execute_lin2025_conditions()；`robust_condition_runtime.py` _normalize_receipt() 后置 mesh 检查。
- **内容/复现方法**：`python /workspace/code-review/repro_robust_mesh_presolve.py` 用真实 shape policy normalizer 接受 max_elements_per_model=1、check_after_build/check_after_remesh/check_before_solve=True。调用真实 execute_lin2025_conditions/真实 run_shape_application，只有 MPh、Java/model、控制创建和条件评价换成仓库纯替身，mesh stat 报 18985 elements。shape study.run 已到达，随后首个 condition backend 也到达，才在真实 receipt normalizer 抛 mesh cap exceeded。source 中 backend.prepare mesh.run 后不验 cap/quality，shape application 也先 study.run 后读 stat；约束未在承诺的 pre-solve 边界生效。无实际求解。
- **可能的解决办法**：统一 mesh policy adapter，在每次 build/remesh 后及 shape/forward/sensitivity study.run 前采样并执行 elements/quality/measure 检查；持久化 admission receipt 后再进入求解。

## BUG-139

- **编号**：BUG-139
- **标题**：整数候选经 float 规范化改变设计点并错误去重
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/records.py:_candidate_values`（整数分支）；`comsol_mcp/research/coordinator.py:evaluate`（按候选摘要去重）
- **内容/复现方法**：设计空间合同和既有测试明确支持精确的 2**53 以上整数边界，但候选规范化统一先 float(raw)，再 int(number)。执行 `python /workspace/code-review/repro_research_integer_and_external.py`：真实合同接受 [2**53, 2**53+1024]；requested=9007199254740993 被转换为 9007199254740992，并与相邻合法整数得到相同 candidate_fingerprint。coordinator 将两个设计点视为同一点评估，且 evaluator 收到改变后的整数。无 COMSOL 运行。与 BUG-044 的 adapter 显式浮点转换属于不同入口。
- **可能的解决办法**：整数输入直接保留 int；对于 float 输入仅接受有限且精确可表示的整数，再用整数边界比较。补充大整数相邻点、边界和 candidate fingerprint 不碰撞的验证。

## BUG-140

- **编号**：BUG-140
- **标题**：独立验证误差超阈值仍允许 finalist 晋升
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/external_validation.py:normalize_external_validation_receipt`；`comsol_mcp/research/robust_finalist_evidence.py:_external_fidelity`
- **内容/复现方法**：外部回执分别规范化 metrics 与 tolerances，但不检查键对应、容差非负或实际比较结果；finalist assessor 仅凭 disposition='validated' 和 backend mode 判 external_fidelity 通过。执行 `python /workspace/code-review/repro_research_integer_and_external.py`，在仓库完整合法 finalist fixture 中将 maximum_absolute_delta 改为 100、阈值保持 0.02，实际 assessor 仍 accepted=True。再将容差换成无关键 unrelated=-1，同样接受。回执重新正规封印，其他证据保持原样；这是输入/恢复证据的独立审核缺口，不声称正常 native producer 已输出错误结果。
- **可能的解决办法**：为支持的比较指标声明明确判定方向，要求指标与容差对应且容差合法，从数值重算 disposition；finalist 独立审核使用重算结果而非信任字符串。

## BUG-141

- **编号**：BUG-141
- **标题**：混合设计空间的重复提案使 campaign loop 提前崩溃
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/optimizers.py:DeterministicRandomOptimizer.tell`；`comsol_mcp/research/campaign_loop.py:step`
- **内容/复现方法**：`python /workspace/code-review/repro_research_loop_admission.py` 使用合法整数空间 [0,1]、真实 compiler/coordinator/random optimizer/loop，固定 seed=17001。第二次提案重复第一点评估，coordinator 正常返回 duplicate_terminal，但 tell 将新的 proposal_index/fingerprint 与原 observation 比较，抛出 conflicting result。只启动 1 次注入 evaluator，预算仍剩 31；循环没有返回受控的终止结果。LHS 在有限离散域也可重复。无求解器运行。
- **可能的解决办法**：将提案身份与设计点评估身份分开；同一候选已有相同评估时关联新提案或跳过重复，确保有限域耗尽受控退出，并保留评估预算去重。

## BUG-142

- **编号**：BUG-142
- **标题**：目标缺少成功阈值时 campaign loop 仍可报告 success
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/campaign_loop.py:step`；`comsol_mcp/research/compiler.py:success_claim_allowed`
- **内容/复现方法**：`python /workspace/code-review/repro_research_loop_admission.py` 将一个真实 goal objective 的 tolerance 置空；compiler 明确冻结 success_claim_allowed=False。真实 loop 使用返回 success=True 的注入 score evaluator，仍返回 success=True、stop_reason=success 并保存 checkpoint。loop 未检查 manifest 的禁止成功声明字段，也未检查所有 objective 阈值。正常 scorer 若自行拒绝则不触发，本问题是执行协调层未落实冻结的合同。
- **可能的解决办法**：在接受 scorer 的成功结果前检查 manifest 允许声明成功，并验证评分完整覆盖冻结目标；未设阈值时保留排名但返回未验证成功的状态。

## BUG-143

- **编号**：BUG-143
- **标题**：研究 coordinator 接受被修改的 manifest 而保留旧 campaign 身份
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/coordinator.py:ResearchCampaignCoordinator.__init__`
- **内容/复现方法**：`python /workspace/code-review/repro_research_loop_admission.py` 先真实编译 manifest，再将 max_fem_evaluations 从 32 改为 4096，保留 goal_fingerprint 和 campaign_fingerprint。实际 coordinator 在新 root 接受并保存它，旧 campaign 身份下实际使用新预算。入口仅检查 schema_name 和摘要文本格式，未重算 goal/design/manifest 摘要。原 root 的逐字文件比较能阻止随后替换，但不能验证首次接收已漂移的数据；影响身份与审批绑定。无 COMSOL 运行。
- **可能的解决办法**：在创建 root/运行文件前规范化所有冻结子合同并重算 manifest 摘要；要求版本与完整字段一致、审批和预算与摘要严格绑定。

## BUG-144

- **编号**：BUG-144
- **标题**：研究 campaign 恢复未绑定 evaluator 身份，重放旧驱动结果
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/coordinator.py:_initialize_identity`、`_evaluation_records`、`evaluate`
- **内容/复现方法**：`python /workspace/code-review/repro_research_resume.py`：同一 manifest/root 先用 evaluator_identity=a*64 完成候选，再以 b*64 和返回不同结果的新 evaluator 重开。构造器正常接受；evaluate 返回 duplicate_terminal 及旧 evaluator 的 response，完全没有调用新 evaluator。started/terminal 记录包含 evaluator_identity，但过滤恢复记录只看 candidate_fingerprint，runtime 也只固定 campaign 身份。违反精确驱动身份恢复要求；可在同一 journal 混入不同驱动的不同点。纯注入 evaluator，无 COMSOL 运行。
- **可能的解决办法**：把 evaluator_identity 冻结进运行身份，在恢复和去重时严格比较；驱动改变应要求新 campaign/root 或显式迁移，避免隐式重放旧结果。

## BUG-145

- **编号**：BUG-145
- **标题**：GP optimizer 恢复改变观测窗口，下一次提案不再确定一致
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/adaptive_acquisition.py:checkpoint`、`restore`、`ask`
- **内容/复现方法**：ask 使用 observations 字典插入顺序的最后 256 条 completed；checkpoint 按候选摘要排序，restore 依该排序重建字典，丢失完成时序。执行 `python /workspace/code-review/repro_research_resume.py`：创建合法 300 点池的 257 个已完成观察，checkpoint 前后 state 完全相等，但实际用于 GP 的 256 点集合改变；真实数值 acquisition 给出的下一点分别为 (92.879885157783,99.352128873048) 与 (106.277640164964,64.669907636197)。历史构建阶段仅替换昂贵 acquisition 为固定首选，checkpoint/restore 和两次最终 GP/EI 为真实生产代码。既有测试的两条观察或递增摘要不能暴露窗口差异。无求解器。
- **可能的解决办法**：持久化完成序号，按完成时序选择窗口，或在运行和恢复中统一使用明确的排序；验证超过 256 条、随机摘要和乱序 tell 的精确下一步恢复。

## BUG-146

- **编号**：BUG-146
- **标题**：公开 optimizer advance 接受其他 campaign 的 checkpoint 与反馈
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/research.py:research_optimizer_advance`
- **内容/复现方法**：`python /workspace/code-review/repro_research_public_campaign.py` 通过实际 MCP 注册工具函数，先为 campaign=a*64 得到正规 checkpoint，再在 campaign=f*64 调用 advance，传入旧 checkpoint 与其精确反馈。实际 success=True，新 checkpoint 标记 f*64，却继承旧 campaign 的候选 c*64 和分数。restore 校验 backend/space，但 public dispatch 未比较 checkpoint.campaign_fingerprint 与当前 campaign 参数。在持久恢复入口隐式跨 campaign 混用结果；无 COMSOL 或文件副作用。
- **可能的解决办法**：恢复前比较冻结 campaign 身份并拒绝不一致；若支持迁移，设计独立显式迁移接口，保留来源和授权，避免普通 advance 重贴身份。

## BUG-147

- **编号**：BUG-147
- **标题**：licensed gradient ladder 未重算导数一致性，也未核对 native 回执绑定
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/research/robust_gradient_acceptance.py:assess_licensed_gradient_ladder`；`development_kit/scripts/verify_robust_gradient_ladder_receipt.py:verify`
- **内容/复现方法**：该函数声称重算 canonical robust acceptance，实际使用 FD/directional 回执的 relative_error、sign_agreement 和 cosine_similarity，仅比较 source revision/hash。执行 `python /workspace/code-review/repro_gradient_ladder_consistency.py`：真实 gate._gradient_checks 接受两份子回执 native_receipt_sha256=f*64，而实际 native receipt SHA=a*64。进一步提供 native_1_per_m=999、central_derivative=-999、方向预测 999/观测 -999、绝对误差 1998，保留原来小相对误差/符号一致声明，仍 passed=True。独立文件 verifier 也调用同一函数，检查外层文件哈希并不能补上数值/跨回执绑定。纯仓库 fixture 与实际验收函数复现；正常子 gate 正确计算时不触发，不声称真实梯度已有误差。
- **可能的解决办法**：要求子回执绑定实际 native receipt SHA；逐变量比较 native 值并从中心差分原始点/导数重算误差、符号和 cosine，从方向及观测重算 directional check；缺原始字段应失败。

## BUG-148

- **编号**：BUG-148
- **标题**：原生 optimizer gate 的 max_solves 不包含 baseline 与 finalist 求解
- **严重性/优先级**：中 / P2
- **位置**：`development_kit/scripts/native_optimizer_licensed_gate.py:run`
- **内容/复现方法**：`python /workspace/code-review/repro_native_optimizer_budget.py` 用真实 run、合法规范化 optimizer budget 和纯 MPh/Java 替身，max_solves=1 时实际执行 baseline std1.run、optimizer std2.run、fresh finalist std1.run 三个求解入口，返回 success=True。nsolvemax 仅设在优化 study；没有预留前后两次 forward solve。ladder 将 optimizer_max_solves 纳入总求解上限时因此低估至少两次。替身只记录入口，不声称已执行 COMSOL 或测量内部迭代次数。
- **可能的解决办法**：定义并落实整个 gate 的总求解预算，预留 baseline/finalist 和内部求解，预算不足在 native 启动前拒绝；若字段仅指 optimizer 内部次数，另设并在 ladder 绑定总 cap。

## BUG-149

- **编号**：BUG-149
- **标题**：原生 optimizer gate 在 fresh finalist 超过墙钟上限后仍报告成功
- **严重性/优先级**：中 / P2
- **位置**：`development_kit/scripts/native_optimizer_licensed_gate.py:run`（final_fresh_forward 到 success）
- **内容/复现方法**：`python /workspace/code-review/repro_native_optimizer_budget.py` 实际 run 仅在 std2.run 前后检查墙钟；baseline 和后续 finalist/物理提取/清理没有统一终态检查。替身 monotonic 在 fresh finalist study.run 时从 0 跳至 10 秒，规范化 max_wall_time_seconds=1，最终 success=True、elapsed_seconds=10。这是 post-optimization 阶段超限未被失败判定的确定复现；不声称 mock 能验证硬中断能力。
- **可能的解决办法**：所有求解阶段共用开始时间/截止时间，前后检查且最终 success 必须满足总墙钟预算；长 native call 用已有 watchdog/受控子进程实现硬截止。

## BUG-150

- **编号**：BUG-150
- **标题**：原生 optimizer gate 不执行声明的磁盘预算
- **严重性/优先级**：中 / P2
- **位置**：`development_kit/scripts/native_optimizer_licensed_gate.py:run`（derived copy save/receipt）
- **内容/复现方法**：`python /workspace/code-review/repro_native_optimizer_budget.py` 真实 budget normalizer 接受 max_disk_bytes=1；run 保存 base/configured 模型替身共 48 字节，另生成两份 JSON 回执，仍 success=True。代码只把 budget 写入回执，对磁盘用量没有任何检查。由 ladder 调用时事后累计检查能发现已超限，但单独 gate 不限制，且不能防止真实大模型写爆预算。无真实模型或求解器运行。
- **可能的解决办法**：在创建复制文件前做预计占用准入，执行中跟踪限定 artifact 目录用量，并在终态检查 cap；磁盘超限应保留明确失败和清理证据。

## BUG-151

- **编号**：BUG-151
- **标题**：禁用 Python 整数转文本限制时 property transport 拒绝所有整数
- **严重性/优先级**：低 / P3
- **位置**：`comsol_mcp/tools/property_transport.py:_normalize_scalar`
- **内容/复现方法**：`python /workspace/code-review/repro_property_integer_boundaries.py` 临时设置标准 Python 配置 sys.set_int_max_str_digits(0)，finally 恢复。json.dumps(1) 正常，但 normalize_property_value(1) 抛出 at most -1 decimal digits。0 按 Python 规范表示禁用解释器限制，代码却执行 digits>=0；所以客户端在 PYTHONINTMAXSTRDIGITS=0 下所有 int property get/set 被拒绝，浮点/字符串不受此原因影响。现有自身字节上界仍有效，因此不应拒绝普通整数。
- **可能的解决办法**：仅在 digit_limit>0 时比较解释器限制；边界使用 > 而非 >=，保留独立 MAX_SCALAR_BYTES/aggregate 限制。验证默认、禁用及自定义合法限制。

## BUG-152

- **编号**：BUG-152
- **标题**：property setter 将大整数舍入后的 readback 判为精确成功
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/properties.py:_exact_json_value_equal`、`set_existing_property`
- **内容/复现方法**：`python /workspace/code-review/repro_property_integer_boundaries.py` 调用真实 constrained setter 与仓库 FakeModel，Double feature 替身按 float 存储请求。请求 int 9007199254740993，readback 为 9007199254740992.0，仍 success=True。比较函数对 int/float 双方都 float()，丢失请求的整数精度，与模块和既有 coercion 测试宣称的 readback 精确证明冲突；可同样影响回滚证明。无真实 COMSOL。与 BUG-044 的 adapter conversion 及 BUG-139 的候选规范化不同入口。
- **可能的解决办法**：使用 Python 的精确 int/float 数值比较或显式验证整数是否可无损转换；不一致时返回失败并证明回滚，矩阵和向量逐元素应用同一校验。

## BUG-153

- **编号**：BUG-153
- **标题**：results export 在模型中留下已删除的 staging 文件路径
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/results.py:export_result_file`
- **内容/复现方法**：已安装 MPh 的 Model.export(node,file) 会先修改 export node 的 filename（Animation 还改 type/movietype/其他文件字段），再运行 node。仓库 helper 将随机 staging 路径传给它，发布后删除 staging，却没有恢复/改回 node 配置。`python /workspace/code-review/repro_result_export_state.py` 使用真实已安装 Model.export 方法与仅 node.run 文件写入替身：目标 result.csv 已存在，而模型 node 记住另一条不存在的 staging 路径。以后原生导出/保存模型再打开将使用无效临时目标；失败同样可能留下变化。公开 path policy 会拒绝覆盖已存在 source，因此没有将源文件覆盖疑点记录为缺陷。无 COMSOL 启动。
- **可能的解决办法**：快照并恢复 export node 的相关配置，或发布后明确设置为 caller 目标并记录模型修订；异常路径也要证明恢复，包含 Animation 的格式控制字段。

## BUG-154

- **编号**：BUG-154
- **标题**：独立 C# launcher 的 4 MiB 日志上限在无界内存读取后才生效
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/standalone/assets/Launcher.cs:RunOwnedProcess`（约 738–774 行）
- **内容/复现方法**：静态路径确认：stdout/stderr 分别调用 ReadToEndAsync()，等待子进程退出和两条流结束，再拼接两个完整 string 并 UTF-8 GetBytes，最后才比较 MaximumLogBytes。任一编译/求解子进程在许可的 60/600 秒内输出超过 4 MiB，内存已经按完整输出分配多次；持续日志可在终止检查前耗尽 launcher 内存。已有 Python builder 有界测试不覆盖 C# 原生路径。复现方法是在 Windows 测试宿主以输出 8 MiB 的有限假子进程调用该方法，观察完整 stdout/stderr 字符串已物化后才抛 owned_process_log_exceeds_bound；此 Debian 环境只完成源代码确认，未运行 Windows EXE 或 COMSOL。
- **可能的解决办法**：并发分块排空两条流，维护共享累计字节数；达到上限时保留有限诊断并取消受控进程树，同时确保流和 Windows Job 清理。不要用完整 ReadToEndAsync 字符串作为日志缓存。

## BUG-155

- **编号**：BUG-155
- **标题**：派生几何 apply 未比较请求与 readback，设置未落实仍返回成功
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/derived_geometry.py:apply_blocks,apply_fin`
- **内容/复现方法**：成功路径虽读取 after snapshot，却不核对所请求 size/pos 或 fin action/imprint/createpairs。`python /workspace/code-review/repro_derived_geometry_readback.py` 使用仓库原有几何 fixture 和真实 preview/apply，仅注入不改变属性且不抛异常的 setter：请求 blk1 size=2[mm] 实际仍是 1[mm]；请求 assembly/imprint=on 实际仍 union/off。两次均 success=true、dirty=false。对于底层静默忽略/规范化成不同值的情况，调用者将误把编辑当作完成，后续验证也被允许。相邻 incidence_config 明确检查 planned/readback 并在不一致时回滚。此复现验证检测缺口，不声称已在真实 COMSOL 观察到 silent setter。
- **可能的解决办法**：成功回执前比较所有计划字段与实测属性；允许的原生规范化应有明确的等价规则。不一致进入已有回滚路径，并在恢复无法证明时将 record 标记 dirty。

## BUG-156

- **编号**：BUG-156
- **标题**：启动取消/超时路径在 client 清理失败后仍释放 solver lease 并宣称清理完成
- **严重性/优先级**：高 / P1
- **位置**：`comsol_mcp/tools/session.py:SessionManager._start_worker` 的 finally cancelled 分支
- **内容/复现方法**：普通 disconnect 在 clear/disconnect 失败时保留 client 与 lease；启动 worker 的 cancelled 分支却在 _retire_client 返回 cleanup_errors 后仍无条件 _client=None、release lease、cleanup_pending=False，记录 cleanup_completed。`python /workspace/code-review/repro_session_cancel_cleanup.py` 运行真实 worker、phase persistence 和 retirement，仅注入 MPh client/ownership：在构造完成时请求取消，client.clear 抛 injected model-clear failure；最终 receipt state=cancelled、cleanup_errors 非空、lease_release_success=true，当前 client 消失且 cleanup_pending=false。残留模型/客户端无法通过普通 disconnect 重试清理，租约也不再保护未验证的 solver 状态。无 COMSOL 启动。超时使用同一 cancelled finally 分支。
- **可能的解决办法**：只在清理得到证明后释放租约。失败时保留确切 client、connected_uncertain/cleanup_pending 与 lease，提供可重试的 retirement；终态回执区分 cancellation requested、cleanup pending 和 verified cleanup completed。

## BUG-157

- **编号**：BUG-157
- **标题**：SolverOwnership 漏检原生 COMSOL batch/clusterbatch 进程
- **严重性/优先级**：高 / P1
- **位置**：`comsol_mcp/tools/ownership.py:SolverOwnership._external_solver_processes`
- **内容/复现方法**：分类只识别 mphserver、COMSOL Java server 和 Python MPh client，不识别已知会求解的 comsolbatch/comsolclusterbatch 名称。`python /workspace/code-review/repro_ownership_batch_collision.py` 使用真实 SolverOwnership.status 与有界注入完整进程表；独立于 MCP 的 comsolbatch.exe、comsolclusterbatch.exe、Linux 名称 comsolbatch 均得到 process_inventory.complete=true、external_solver_processes=[]、collision=false。随后 acquire 的前后 collision 检查沿用该分类，无法遵守单 solver owner 策略。standalone C# launcher 已明确拒绝同类进程。无真实进程创建/COMSOL 求解；此复现证明通用分类缺口，不代表 Linux licensed readiness 已通过。
- **可能的解决办法**：将已知原生 batch/cluster/desktop solver 宿主纳入分类；保留 exact owned/attached 身份的豁免，对未分类的 COMSOL 候选提供 fail-closed 证据。覆盖 Windows exe 和 POSIX 名称，避免只靠脚本文本判断。

## BUG-158

- **编号**：BUG-158
- **标题**：Java/Matlab/VBA model_save 的 staging 后缀导致所有格式发布失败及临时文件残留
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/model.py:_save_model_file`
- **内容/复现方法**：非 MPH 分支以 .save staging 调用 model.save(path,format)。实际 MPh Model.save 会用 with_suffix 将路径变为 .java/.m/.vba；helper 却检查原 .save 路径，始终抛 model save did not create the staging artifact，并只删除不存在的 .save 文件。`python /workspace/code-review/repro_model_code_export.py` 调用真实已安装 Model.save，仅替换 Java.save 为有限文件写入；三种格式目标均未发布，各留下带正确格式后缀的隐藏 staging 文件。现有 test_model FakeModel.save 直接写传入路径，掩盖 MPh 的后缀规则。未启动 COMSOL。
- **可能的解决办法**：临时名称保留真实格式后缀，明确映射 COMSOL/MPh 支持的格式与扩展名，再发布实际产物；失败清理覆盖真正生成的文件。用真实 MPh Model.save 边界行为验证替身契约。

## BUG-159

- **编号**：BUG-159
- **标题**：model_load 在加载后哈希读取或注册异常时泄漏未跟踪的 native model
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/model.py:register_model_tools.model_load`
- **内容/复现方法**：仅 source_hash_after 与 before 不同的显式分支调用 client.remove；若 client.load 已成功，后续第二次哈希读取抛 OSError 或 add_model 注册失败，则直接进入大范围 except 返回失败，没有回滚 native load。`python /workspace/code-review/repro_model_load_cleanup.py` 调用真实注册工具函数，第一轮哈希通过、load 返回模型、第二轮抛有限注入读取异常：success=false，client.remove 调用数=0，模型未注册也不能由 model_remove 定位。可由源文件在加载后删除、权限变化/IO 异常触发。未启动 COMSOL。
- **可能的解决办法**：把 load 与身份捕获/注册做成事务；记录确切已加载对象，任何提交前异常都尝试移除，若清理失败返回 cleanup_pending 并保留可重试的对象身份。提交后响应元数据失败应明确实际注册状态。

## BUG-160

- **编号**：BUG-160
- **标题**：同显示名模型注册覆盖已有追踪对象，旧模型失去管理且 revision token 不变
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/session.py:SessionManager.add_model,_initialize_model_revision`
- **内容/复现方法**：add_model 把 model.name() 直接作为字典 key。若两个不同原生 tag 具有相同 label，第二次注册通知移除 listener 并覆盖 _models，没有移除第一个 native model。revision 清空后只按 name/sequence/source_path_present 重建，得到与旧对象相同 token。`python /workspace/code-review/repro_session_duplicate_label.py` 使用真实 add_model/get_model_revision/clear_models、两个 tag=Model1/Model2 label=Same Label 的有限替身：第二个覆盖第一个，revision 完全相等；clear_models 宣称成功却仍有 Model1 存于 client。不同文件的模型允许相同显示 label，不能用它作唯一原生身份。与 BUG-026 的被动 provider 错报 tag 属于不同实际故障。无 COMSOL 启动。
- **可能的解决办法**：分开唯一 tracking key、native tag 和显示 label；拒绝冲突或生成明确唯一 key，不能静默替换。revision 初始身份须绑定对象/source/session generation，重载和替换应使旧 token 失效；已有 clone backing 清理要等旧 native 对象确认退休。

## BUG-161

- **编号**：BUG-161
- **标题**：MIM build 失败回滚只移除几何 feature，却将已修改的 BC/material/fin 状态报告为 rolled_back
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/mim_patch.py:register_mim_patch_tools.mim_patch_build`
- **内容/复现方法**：构建会修改既有 fin action、LayeredTransition/LayeredImpedance/PeriodicStructure selections 和 air material domains；except 只删除新建 patch/difference 并 rerun geometry，未快照/恢复既有设置。`python /workspace/code-review/repro_mim_partial_rollback.py` 使用真实注册 build、真实 topology/side-pair 分类、仓库 geometry fixtures，注入 native boundary probe：ltr 从 [6] 改为 patch boundary [31] 后因缺少 lib1 失败，返回 rolled_back=true；新几何确已删除，但 ltr 仍 [31]，成为错误/失效 selection。更晚的 mesh failure 可留下更多 BC/material 改动。现有 rollback 测试在 topology 阶段提前失败，未覆盖既有 BC 被写入之后。无 COMSOL 启动。
- **可能的解决办法**：全部输入、既有 feature/material 存在性先预检；快照并事务恢复 fin、所有 BC 和 material selections，重新读取证明恢复。无法证明完整恢复时返回 rolled_back=false 并阻止该派生模型验证，或在独立 provenance clone 内完成构建。

## BUG-162

- **编号**：BUG-162
- **标题**：ElectrodeSurface 的实体维度固定为 2，二维电化学边界配置使用了域维度
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/electro_chemistry.py:configure_electrode_reaction` 的 feature.create(feature,"ElectrodeSurface",2)
- **内容/复现方法**：ElectrodeSurface 是边界条件，2D 模型边界实体应为 1、1D 为 0；实现始终给 2，只有 3D 才正确。同模块 set_electrolyte 与通用 physics/acoustics boundary helpers 已按 component dimension 推导。`python /workspace/code-review/repro_electrode_dimension.py` 用仓库 fixture、真实 _component_sdim 和配置 helper，将 geometry 明确为 2D，有限 create 替身检查边界维度：helper 仍调用 dimension=2，因此请求失败。现有 fake feature.create 不检查 dim，geometry fake 还缺 tags() 导致默认3D，未覆盖此错误。未启动 COMSOL，未声称二维 native gate 已运行。
- **可能的解决办法**：从目标 physics 绑定的 geometry 读取空间维度，边界维度为 sdim-1；不能读取时拒绝而非猜3D。补充2D/1D与多geometry归属检查，不将 native topology 问题描述为许可证缺失。

## BUG-163

- **编号**：BUG-163
- **标题**：复合 flow/heat 边界配置遇到 feature.create 异常时跳过全部回滚
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/physics.py:add_boundary_condition,setup_flow_boundaries,setup_heat_boundaries`
- **内容/复现方法**：add_boundary_condition 的 feature_list.create 位于异常转换/回滚 try 外。复合 setup 只在返回 success=false 时回滚先前节点，不捕获直接抛出的 create 异常；公开 wrapper 最后捕获并返回失败但已创建节点留下。`python /workspace/code-review/repro_physics_transactions.py` 用真实注册工具和仓库 fixtures，在第二次 create 抛有限异常：physics_setup_flow_boundaries 残留 inl_1，physics_setup_heat_boundaries 残留 hf_1，均返回 success=false 且无 rollback 说明。已有测试只在创建后的 selection/property 设置抛错，因此覆盖不到此路径。无 COMSOL 启动。
- **可能的解决办法**：将创建步骤也放进 helper 的异常边界，复合事务同时处理异常与失败回执；保留确切创建列表，任何失败均反向删除并返回可证明的完整回滚状态。

## BUG-164

- **编号**：BUG-164
- **标题**：physics_remove 对跨组件重复 tag/label 不拒绝歧义，直接删除第一个接口
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/physics.py:remove_physics_interface`
- **内容/复现方法**：查找/修改 helpers 的 _find_physics_context 会对跨组件多个匹配拒绝歧义，但 remove helper 边遍历边删除第一个。`python /workspace/code-review/repro_physics_transactions.py` 构造 comp1/comp2 各有合法 ewfd 接口：同一个标识在真实 _find_physics_context 被判 ambiguous；remove_physics_interface('ewfd') 却 success=true，删除 comp1，保留 comp2。caller 未提供组件无法表达要删哪一个，可能丢失模型设置。无 COMSOL 启动。
- **可能的解决办法**：先枚举全部匹配再决定；多个匹配时返回结构化 ambiguous 并要求 component_tag 或确切复合身份，确保执行删除前没有副作用。复用统一解析器保持各修改工具规则一致。

## BUG-165

- **编号**：BUG-165
- **标题**：physics_set_material 省略 domain_selection 时未落实声明的 all domains，却返回 all
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/physics.py:assign_material,physics_set_material`
- **内容/复现方法**：公开文档声明默认 all domains for this physics。对已有 material，省略/空 domain_selection 变为空列表，if domains 跳过 selection 设置，继续保留原来的子集，但结果 domain_selection='all'。`python /workspace/code-review/repro_physics_transactions.py` 用真实 assign_material 和 repository fixture：Silicon 原 selection=[2]，默认调用 success=true、reported=all，actual=[2]。caller可能据此认为所有物理域已有材料而实际未赋值。未调用 COMSOL。
- **可能的解决办法**：明确省略参数的语义：若默认是所有目标 physics 域，则解析并设置/读回该域集合；若设计为保留既有 selection，就把 schema/doc/receipt 改为 preserve_existing 并报告实测集合。不要把未写入的选择报告为 all。

## BUG-166

- **编号**：BUG-166
- **标题**：当前版本配置的五个对象组类型错误被 migration 吞掉，校验错误列表为空
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/settings.py:_migrate_legacy_document,_normalize`
- **内容/复现方法**：_migrate_legacy_document 在当前1.3.0文档也将非 dict 的 semantic_docs/lexical_docs/manuals/shared_server/model_manager 替换为空对象，先于 _object 类型检查。因此字符串/列表等错误组被静默默认化，configuration_state 可报告 valid，serialize 可保存为默认禁用而丢失输入。`python /workspace/code-review/repro_settings_shape_and_unicode.py` 分别将完整当前配置的五个组置为字符串；真实 normalize_settings_document 均 errors=[] 并转换成默认对象。其他如runtime错误组会报告错误，规则不一致。此为配置诊断/保存问题，不宣称启用了危险功能；无需 COMSOL。
- **可能的解决办法**：迁移只补全缺失的合法 legacy 字段，不吞掉显式错误类型；保留原值给统一 _object 校验。按 readable legacy版本限定迁移，并验证 current version错误组产生结构化错误且不能序列化保存。

## BUG-167

- **编号**：BUG-167
- **标题**：Linux 显式合法 ASCII 配置仍因 Unicode 默认 XDG data root 无法保存
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/settings.py:_normalize,default_settings_document,serialize_settings_document`
- **内容/复现方法**：_normalize 无条件生成全部默认配置；default_settings_document 会要求默认 data_root/artifacts ASCII，随后把该默认环境错误计入已有完整文档。即使 caller 已显式提供 ASCII runtime/state/artifact paths 且只把 model_read_roots 设为 Unicode，仍被视为 invalid，serialize拒绝保存。`python /workspace/code-review/repro_settings_shape_and_unicode.py` 在 Debian 用有效完整1.3.0文档，将 XDG_DATA_HOME 指向审查目录的用户/data（仅字符串，不创建），runtime/artifact仍ASCII：normalized paths 与输入相等，但 errors含 settings.environment；在相同真实环境变量下 serialize_settings_document 抛 settings document contains invalid values。用户不能通过配置覆盖不适合 solver 的默认artifact位置。未安装 COMSOL。
- **可能的解决办法**：仅在字段缺失、需要回退时计算/验证对应默认值；显式设置有效路径时不因未使用的默认路径拒绝完整文档。允许Unicode model/data路径，独立验证真正使用的 ASCII runtime/原生产物根，并覆盖中文 HOME/XDG 与显式 override。

## BUG-168

- **编号**：BUG-168
- **标题**：两个标记 read_only 的 geometry inspection 工具实际调用 geom.run，绕过模型 revision 规则
- **严重性/优先级**：中 / P2
- **位置**：`comsol_mcp/tools/physics.py:geometry_get_boundaries`；`comsol_mcp/tools/mim_patch.py:geometry_probe_domains`；`comsol_mcp/tools/catalog.py:_SIDE_EFFECTS`
- **内容/复现方法**：两个工具在读取 topology 前无条件 geom.run()，却在 core/其他profile被分类为 read_only，requires_model_revision=false、advances_model_revision=false。geom.run 是原生 geometry build，可将尚未构建的参数/feature变更落实并改变 topology/selection/solution适用性；inspection调用无需 expected revision 且不会更新token。`python /workspace/code-review/repro_readonly_geometry_rebuild.py` 用真实注册的两工具、真实 ToolMetadata 和仓库几何fixture，只替换 native probe：两次调用都 success=true且各调用一次 geom.run，同时metadata仍只读、两项revision标志false。无 COMSOL启动，未声称native topology具体变化已实测。真正 wave_optics_preflight 使用只读探针而不build。
- **可能的解决办法**：只读取已构建几何，不隐式运行；未built时明确返回未知并要求独立 geometry_build。若必须build，应改为model_mutation、要求和推进revision，明确副作用，并处理失败后模型状态。

## BUG-169

- **编号**：BUG-169
- **标题**：空气参考审计生成的 reference.json 无法被单点审计的 air-reference reader 读取
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/tools/wave_optics_audit.py:_load_air_reference,run_wave_optics_reference_audit
- **内容/复现方法**：README 声称 preflight -> optional reference audit -> point audit。reference audit 返回的唯一参考文件是 artifacts.manifest/reference.json，其中 config_id 在 config_spec/reference 中、component_statistics 在 reference.field 中。point audit 的 air_reference_artifact_path reader 却只接受根级 config_id 和 component_statistics/field_statistics。python /workspace/code-review/repro_reference_artifact_and_zero_transverse.py 第一段用真实 reference runner 和仓库有限 clone/field fixture 完成审计，再把生成文件交给真实 _load_air_reference：带正确 config_id 仍报 air_reference_config_mismatch(actual=null)；不提供 expected id 则报 air_reference_field_statistics_missing。无法直接串联两工具，单点审计只得 structure_total_field 而失去入射参考证据。无 COMSOL；手工构造 reader 专用平铺文件的既有测试通过，未覆盖 producer-consumer 往返。
- **可能的解决办法**：定义统一、版本化的参考 artifact，producer 返回可供 reader 使用的明确路径；reader 验证 method/cleanup/source/config 身份后读取生成的 field statistics，或 producer 同时输出 reader 要求的参考文件。验证真实产物往返而非手写不同结构。

## BUG-170

- **编号**：BUG-170
- **标题**：纯线性有限场的参考偏振比值溢出，并留下永久 running 审计文件
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/tools/wave_optics_audit.py:run_wave_optics_reference_audit 的 target_to_transverse_ratio 计算及 finally 后构建证据
- **内容/复现方法**：ratio=target_amplitude/max(transverse,sys.float_info.min)。有限 Ex=10、Ey=Ez=0 时得到 Infinity。try 内没有检查派生比值；clone 清理后 build_physical_evidence 拒绝非有限数，该构建位于异常处理外，未写终态。python /workspace/code-review/repro_reference_artifact_and_zero_transverse.py 第二段用真实 runner/证据 builder/仓库 clone fixture，只把有限场 x 振幅从1改为10：抛 contains a non-finite number，clone确已移除、backing已删除，但 reference.json 仍 audit_status=running。理想线偏振及相同场的幅度缩放本应得到可解释的比值证据，不能将其当作非有限 native field。无 COMSOL；既有零横向测试 x=1 产生有限极大比值，掩盖此边界。
- **可能的解决办法**：对零横向功率采用显式状态/零 cross fraction，或有界比值及下界语义，避免最小正数除法溢出。把 source 后验 hash、证据构建、policy 和持久化纳入统一 terminalization 处理，任何失败都写完整失败/完整性终态及真实 cleanup 回执。

## BUG-171

- **编号**：BUG-171
- **标题**：mesh convergence 将 NaN/Infinity 结果持久化为 success，恢复时直接跳过该 level
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/tools/workflow.py:run_mesh_convergence,_resume_mesh_levels
- **内容/复现方法**：与同文件 staged sweep 不同，mesh convergence 在 evaluate 后未调用 _validate_evaluated_values；_scalarize 接受非有限 float，CSV 写为 nan/inf，row.status=success、工具 success=true。恢复只验 schema/config/level fingerprint/status，未检查数据列。python /workspace/code-review/repro_mesh_workflow_and_path_guard.py 第一段使用真实 runner/CSV/manifest/resume 及仓库模型 fixture，仅把 evaluate 返回设为 np.array([nan])：首次 success=true且 A=nan；第二次 resume success=true、n_skipped=1、solve_count=0。不需要修改持久数据即可出现无效科学结果被长期视为完成。无 COMSOL。
- **可能的解决办法**：写 success 前对所有 expression 执行统一有限数/形状校验；恢复也用同一语义校验，非有限/缺列/异常数据不得进入 completed_levels，应明确拒绝或重算。

## BUG-172

- **编号**：BUG-172
- **标题**：experimental 的 mesh convergence 漏校验 source_model_path 和 manifest_path，可读取/覆盖配置根外文件
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/path_policy.py:_MODEL_READ_ARGUMENTS,_ARTIFACT_WRITE_ARGUMENTS；comsol_mcp/tools/workflow.py:mesh_convergence_study
- **内容/复现方法**：mesh 工具公开接受 source_model_path/manifest_path，但 path policy 只列其 csv/checkpoint/save，既未将 source 列入 model-read，也未将 manifest 列入 artifact-write。experimental 中 enforced=true 仍原样放行。python /workspace/code-review/repro_mesh_workflow_and_path_guard.py 第二段用真实注册函数/真实 validate_tool_paths/真实 runner，给 PathPolicy 配置独立 allowed-models/allowed-artifacts；source 和一个已有 manifest 均位于这些根外。validated_input_count=0；runner读取根外 source 并用 JSON 覆盖根外已有 manifest，返回成功。所有文件都是本复现临时目录内的有限假数据，无 native 求解；不是 full profile 刻意支持的 legacy broad paths。
- **可能的解决办法**：补全 mesh 两项 path mapping，并将输入 signature/path schema 作为一致性检查来源；已有文件写入使用明确的 owned resume 规则和身份验证，不能让遗漏字段绕过 pin/containment/no-overwrite。

## BUG-173

- **编号**：BUG-173
- **标题**：experimental 公开 sweep/mesh 的 resume_csv 和 append_csv 被统一 no-overwrite path guard 拒绝
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/path_policy.py:PathPolicy._validate_write_under_root,validate_tool_paths；comsol_mcp/tools/workflow.py:study_staged_parametric_sweep,mesh_convergence_study
- **内容/复现方法**：两个公开工具提供 resume_csv/append_csv，内部要求读取已有 CSV及其 manifest；experimental 的 csv_path/checkpoint/save/manifest 却统一作为新 artifact 写入校验，任何已存在的文件都报 caller-selected artifact targets must not already exist，runner 无法执行恢复。python /workspace/code-review/repro_mesh_workflow_and_path_guard.py 第三段用真实注册 sweep 的 signature 和真实 path policy，将 existing.csv 放在合法 owned artifact root，resume_csv=true 仍被拒绝。mesh 的 csv 使用相同 guard；append 同样触发。full profile 绕过该 guard，纯 runner 测试因此不能验证 experimental 公共恢复功能。无 COMSOL。
- **可能的解决办法**：为 owned journal resume/append 定义精确路径操作类型，在完整 manifest/source/config 身份匹配、文件类型/根/pin 校验后允许恢复写入；保留一般 export 的 no-overwrite 规则。增加经真实公共 guard 的首次执行->恢复验收。

## BUG-174

- **编号**：BUG-174
- **标题**：差分线圈 recipe 成功保存后在 finally 删除 staging，随后发布必然失败
- **严重性/优先级**：高 / P1
- **位置**：recipes/acdc_2d_differential_coils.py:main，save_staged_model 后 finally 与 publish_staged_model
- **内容/复现方法**：正常构建将 save_staged_model 返回的真实文件放入 staging；finally 在没有 build/remove 错误时仍无条件 unlink(staging)。退出 finally、source hash 校验后再 os.link/replace 同一已删除路径，必然 FileNotFoundError，无输出模型。python /workspace/code-review/repro_recipe_staging_and_nan.py 第一段运行真实 main/save/hash/publish，只有 native client/model/build 换有限替身；java.save 确写完整非空文件，cleanup 删除它，main 失败、output不存在、baseline不变。现有 main-order 测试 save 只返回一个未创建的路径，publish 也被替换为事件记录，因此掩盖成功路径错误。无 COMSOL。
- **可能的解决办法**：只在失败/清理失败/源完整性失败时删除未发布 staging；成功路径在 native 模型释放及 source hash 验证后保留文件供原子 publish。增加真实临时文件串联 save->cleanup->publish 的成功路径验证。

## BUG-175

- **编号**：BUG-175
- **标题**：声学管道 recipe 将 NaN pressure/relative error 当作 verified 并发布科学验收回执
- **严重性/优先级**：中 / P2
- **位置**：recipes/acoustic_duct_2d.py:_field_columns,validate_solution,_atomic_json,main
- **内容/复现方法**：采样没有有限数校验，relative_error=NaN 后条件 NaN > maximum_relative_error 为 false，于是返回 status=verified。JSON writer 默认 allow_nan=true，main 将 verified 模型和含 NaN 的 receipt 发布。python /workspace/code-review/repro_recipe_staging_and_nan.py 第二段使用真实 main/validation/save/publish/hash/receipt，仅注入 finite native build/client 和 evaluate 在中心位置的 NaN pressure：模型确发布、两级 status=verified、relative_error为NaN、receipt含非标准JSON NaN。无 native 求解；相邻 capacitor recipe 会拒绝非有限结果，声学现有 lifecycle 测试替换整个 validate_solution，未覆盖这项科学验收。
- **可能的解决办法**：验证采样数组形状、坐标/pressure实部虚部和所有派生误差均有限；非有限数作为科学/完整性失败且不可报告 verified。JSON 使用 allow_nan=false 作最后防线，失败回执写可解释的终态。

## BUG-176

- **编号**：BUG-176
- **标题**：DSH bridge 声称的 Ubuntu 测试通道含硬编码 Windows 路径，Debian 直接失败 11 项
- **严重性/优先级**：中 / P2
- **位置**：dsh_bridge/tests/plugin.test.mjs 的 normalizeConfig assertion 及 mkdtemp/cwd；dsh_bridge/.github/workflows/ci.yml test.matrix.os
- **内容/复现方法**：Debian13 在 dsh_bridge cwd 原样运行 node --test --test-reporter=spec：69项中58 pass/11 fail，日志 /workspace/code-review/tests-dsh-bridge.log。1项把平台 path.join 结果强制比较为反斜杠字符串；10项 mkdtempSync(join('D:\mcp_tests',...))，Linux将其解释为不存在的相对父目录，报ENOENT，且spawn cwd也硬编码Windows。README/CI明确声明 Ubuntu lane，不能归为未装COMSOL或许可证缺失。未创建假 D: 目录或改代码掩盖失败。
- **可能的解决办法**：用 os.tmpdir()/配置的ASCII根并先创建父目录；fake server cwd使用平台真实绝对目录；expected stateFile 由同一平台 path.join构造，只有Windows-specific junction测试使用平台skip。

## BUG-177

- **编号**：BUG-177
- **标题**：DSH bridge 的独立 CI workflow 放在嵌套目录，GitHub Actions 不会执行
- **严重性/优先级**：中 / P2
- **位置**：dsh_bridge/.github/workflows/ci.yml；dsh_bridge/README.md 测试与CI/当前状态；仓库根 .github/workflows
- **内容/复现方法**：README 声称主仓库集成后由自身 Node CI 执行 Windows+Ubuntu 回归；但唯一 bridge workflow 位于 dsh_bridge/.github/workflows。GitHub Actions只发现仓库根 .github/workflows 下的workflow，嵌套该文件不会注册。检查全部根workflows，未引用/运行 dsh_bridge 或Node bridge suite。即使原样移到根，workflow 的 lib/... tests/... install.ps1 相对路径也缺 dsh_bridge 工作目录。BUG-176 的实际Debian11失败因此没有被该声明的CI拦截。这是配置/触发静态确认，未访问或推断具体GitHub历史运行结果。
- **可能的解决办法**：把 bridge workflow 放到根 .github/workflows 并设置 defaults.run.working-directory=dsh_bridge，安装smoke同样指定子目录；若独立仓库CI才是真实边界，应删除主仓库自动执行的错误声明，并将主仓库接入明确的bridge job。

## BUG-178

- **编号**：BUG-178
- **标题**：DSH initialize 超时后 single-flight occupancy 永不释放，健康 replacement 无法完成重连
- **严重性/优先级**：高 / P1
- **位置**：dsh_bridge/lib/mcp-client-core.mjs:rpc,startChild,connectOnce,onChildLost
- **内容/复现方法**：initialize 超时只settle waiter并保留 pending/occupancy；catch将alive=false，connectOnce也alive=false再kill child。随后exit调用onChildLost，但其 if(!alive)return 导致未rejectAllPending，旧队列slot永久占用。reconnect生成健康child，却将initialize排在旧请求之后；排队请求的timer在真正发送时才创建，因此无限挂起且不耗尽剩余budget。node /workspace/code-review/repro_bridge_startup_and_persistence.mjs 第一段用真实connection和有限fakechild：boot1记录initialize后不响应，150ms超时；boot2健康可响应，却700ms后仍未收到initialize，connected=false、budgetExhausted=false。现有no-initialize测试禁用reconnect并马上dispose，未覆盖恢复。无 COMSOL。
- **可能的解决办法**：在每次 transport teardown 无条件settle/reject全部pending并释放occupancy，与alive flag分离；区分进程generation避免旧child回调影响新连接。重连启动预算应覆盖排队、初始化和发现全部阶段。

## BUG-179

- **编号**：BUG-179
- **标题**：DSH plugin 忽略 stateStore 持久化失败，启动不可恢复镜像且工具响应不报告跟踪丢失
- **严重性/优先级**：中 / P2
- **位置**：dsh_bridge/lib/index.js:createExecutor 的 stateStore.add/update；dsh_bridge/lib/job-mirror.mjs:createStateStore
- **内容/复现方法**：store明确返回boolean报告持久化是否成功，plugin却不检查add/update结果；即使disk/权限/path失败，仍startMirror并置mirrored，原样返回job_submit成功。日志虽警告，DSH用户/工具调用没有durability状态，且restart只能从已不存在的文件读取[]，丢失job/owner/attempt恢复入口。node /workspace/code-review/repro_bridge_startup_and_persistence.mjs 第二段用真实apply/store/mirror/connection和仓库finite fake MCP，stateFile父组件为普通文件：记录persist failure日志，但submit success=true、mirrors_started=1、tracking_file_exists=false，响应无跟踪失败。没有改变服务端durable job，仅bridge恢复数据丢失；不应重新submit补救。
- **可能的解决办法**：检查所有持久化返回值；提交已成功时向调用者返回原job_id及明确tracking/recovery failure，保留有界内存retry并在durable跟踪后才标记已恢复镜像。不得重复服务端submit；对更新/移除失败同样报告可恢复状态。

## BUG-180

- **编号**：BUG-180
- **标题**：DSH 旧 attempt 镜像在首次 status 返回前取消，会取消同 job_id 的新 attempt
- **严重性/优先级**：高 / P1
- **位置**：dsh_bridge/lib/job-mirror.mjs:createJobMirror 的 cancel hook 与 poll attempt check
- **内容/复现方法**：mirror知道attempt=1，但cancel立即排队 job_cancel(job_id)，没有expected attempt也不等待绑定确认。首次status报告attempt=2时poll正确将镜像settle为unconfirmed，已排队的cancel仍随后发出并取消replacement。node /workspace/code-review/repro_bridge_attempt_cancel.mjs 使用真实connection(single-flight)/mirror和仓库finite MCP fixture（仅status加入attempt=2）：startMirror(attempt=1)立即cancel，镜像终态failed/confirmedTerminal=false且detail=attempt differs，随后查询current attempt2状态已cancelled。既有test等status mismatch/done后才cancel，不能覆盖这项竞态。无 COMSOL。
- **可能的解决办法**：cancel绑定并验证exact attempt，服务端支持expected_attempt并在事务内原子拒绝变化；在发送前检查镜像仍有效且身份未变。只轮询确认无法消除TOCTOU，应将身份校验带到实际取消执行边界。

## BUG-181

- **编号**：BUG-181
- **标题**：DSH 0.2.0-rc.2 的作业 owner 契约已变为 SessionId，bridge 传 Agent 对象导致镜像无法启动
- **严重性/优先级**：中 / P2（指定新版本接入兼容缺口）
- **位置**：dsh_bridge/lib/job-mirror.mjs:createJobMirror；dsh_bridge/lib/index.js:startMirror/rehydrateOnce
- **内容/复现方法**：node /workspace/.cloud-onboarding/dsh-rc2/acceptance-boot.mjs 启动 npm 精确安装的官方 0.2.0-rc.2 Web profile、真实 Cordis/tools/jobs/agents 及实际 comsol-mcp 0.7.7。56 个工具注册及 capabilities/catalog 调用成功；创建真实 agent id=debian-dsh-acceptance，再让真实 createJobMirror 使用该 Agent 作为 owner，实际 jobs.start 抛 session "[object Object]" has no live agent。rc.2 JobSpec.owner 明确是 SessionId 字符串；bridge 却沿用历史 Agent 对象契约，submit 和恢复都无法建立 owned mirror。服务端作业状态由仓库有限 fake MCP 提供，没有启动 COMSOL。日志 dsh-bridge-rc2.log；仓库只声称历史 0.1.6-alpha.2 接入，不能将该缺口反推为历史版本已验证失败。
- **可能的解决办法**：明确支持的 DSH 版本并加入实际宿主验收；为 rc.2 从已注册 Agent 获取准确 session identity，向 jobs.start 传 SessionId，恢复时仍核对原会话存活及控制器可达；保留历史版本适配边界。

## BUG-182

- **编号**：BUG-182
- **标题**：DSH 0.2.0-rc.2 不再消费 hooks.readOutput，COMSOL 镜像完成但输出环为空
- **严重性/优先级**：中 / P2（指定新版本接入兼容缺口）
- **位置**：dsh_bridge/lib/job-mirror.mjs:createJobMirror run/readOutput
- **内容/复现方法**：同一真实 rc.2 宿主验收中挂接明确的 read/wait/kill controller，使用无 owner 镜像隔离 BUG-181。实际 jobs.wait 得到 comsol-1 completed，readAt(id,0) 返回 chunks=[]、next=0，job.output.total=0；同一有限 fake MCP 的真实 job_tail 返回 point 1 done 到 point 7 done。bridge 把轮询 tail 保存在内部 outputBuffer，仅提供旧 hooks.readOutput；rc.2 的 JobSpec.run(job) 提供 JobHandle.append/updateProgress 或 JobSpec.output pull sources，忽略该旧钩子，故所有进度文本丢失。日志 dsh-bridge-rc2.log 与 dsh-acceptance-rc2.json。无真实求解；仅证明新版本宿主输出接线失败，不反推旧版本失败。
- **可能的解决办法**：按 rc.2 公共接口通过 JobHandle.append 发布 tail 增量，或注册有 UTF-8 offset 的 JobSpec.output；加入真实 registry 的 live/terminal 输出验收，并维持单请求串行与有界输出。

## BUG-183

- **编号**：BUG-183
- **标题**：Launcher 用 complete 子串优先判成功，not_completed 和失败状态会显示绿色完成并禁止 resume
- **严重性/优先级**：高 / P1
- **位置**：launcher/powershell/DurableLauncher.psm1:Get-DurableTerminalDisposition / Show-DurableJobMonitor
- **内容/复现方法**：pwsh -NoProfile -File /workspace/code-review/repro_launcher_terminal.ps1 导入原始模块，只运行纯判定函数，无 CIM/COMSOL/真实进程。Running=false、Completed=Planned=3 时 completed、not_completed、incomplete_failed、completed_gate_failed 均返回 success；成功分支的 $Status -match 'complete' 在 fail/gate_failed 检查之前。monitor 随后显示 COMPLETED SUCCESSFULLY，并在 resume 命令拒绝继续。用户提供的项目 driver 可在完成所有点后报告科学 gate failed，不能因计数已满把非成功科学状态改成成功。现有 acceptance tests 的有限状态集合未覆盖否定/混合 terminal token。
- **可能的解决办法**：按明确的 terminal state 枚举精确匹配；失败/科学不接受优先且不被完成计数覆盖；只有正式 completed 状态且持久完成证据一致才展示成功，未知状态保持 stopped。

## BUG-184

- **编号**：BUG-184
- **标题**：DSH 刷新工具清单先注册新代再释放旧代，重复名称导致整个新清单被丢弃
- **严重性/优先级**：中 / P2
- **位置**：dsh_bridge/lib/index.js:syncGeneration
- **内容/复现方法**：node /workspace/.cloud-onboarding/dsh-rc2/repro-generation.mjs 使用官方 rc.2 的真实 Web/profile loader/ToolRuntime 与原样 bridge；唯一 MCP 侧为仓库外有限 fixture。首次 tools/list 为 same_tool+removed_tool，150ms 后发送正式 list_changed，第二次 list 为 same_tool+added_tool。journal确认实际收到两次 tools/list；真实 registry 最后仍只有 same_tool+removed_tool。syncGeneration 在旧注册仍有效时 register same_tool，被同一layer重复名称保护拒绝；catch吞掉异常并保留旧generation。新工具不可见，已移除工具仍暴露；服务器正常握手与更新不能修复该错误。日志 dsh-generation-rc2.log。已在用户指定rc.2证实，历史宿主版本未单独重跑该场景；无 COMSOL。
- **可能的解决办法**：使用真实宿主支持的原子工具代替换或独立scoped layer；在注册前有序处理旧项并对失败提供明确回滚/失效状态；加入真实 registry 的重连、清单变化和新增/删除/同名更新验收，不能只用允许重复register的测试替身。

## BUG-185

- **编号**：BUG-185
- **标题**：installed_stdio_probe 在同一工作目录重复执行会因残留 modern 子目录失败
- **严重性/优先级**：低 / P3
- **位置**：development_kit/scripts/installed_stdio_probe.py:main modern_root.mkdir
- **内容/复现方法**：在 Debian 对真实已安装 console 运行 python development_kit/scripts/installed_stdio_probe.py --command /workspace/.cloud-onboarding/venv/bin/comsol-mcp --workdir /workspace/code-review/repeat-installed-stdio --output /workspace/code-review/repeat-installed-stdio-1.json，首次完整旧/新协议检查 exit=0。用同一 workdir 和新 output 再运行，旧协议检查已完成后 modern_root.mkdir() 抛 FileExistsError，exit=1，未执行这轮现代协议验证或写新结果。主 workdir 创建使用 exist_ok=True，而固定 modern 子目录首次运行后保留、不允许复用。复现日志 repeat-installed-stdio-1.log / repeat-installed-stdio-2.log；无 COMSOL。用户指南或云启动指令重复使用固定 workdir 时无法重复验证，不能误记成 MCP 不兼容。
- **可能的解决办法**：为每轮分配明确独立的 modern probe 目录，或在核对目录归属与旧证据隔离后允许安全复用；不删除调用者已有文件，并在输出回执中绑定本轮运行身份。

## BUG-186

- **编号**：BUG-186
- **标题**：study_mesh 原生探针在两项客户端清理都失败时仍正常退出、验收可通过
- **严重性/优先级**：中 / P2；验收可靠性和资源清理证据问题。
- **位置**：development_kit/tests/integration/probes/study_mesh.py:42；关联 development_kit/tests/integration/test_real_comsol.py:100。
- **内容/复现方法**：study_mesh.main() 在输出 study+mesh OK 后，finally 对 client.clear/disconnect 的异常只打印 warning，没有失败返回或重新抛出。外层原生测试以 returncode==0 判成功，JobObject 回收进程也不能证明模型/client 清理已成功。运行 python /workspace/code-review/repro_study_mesh_cleanup.py，用有限内存 clientapi 替身分别注入 clear 和 disconnect 的 OSError，实际原探针返回 None、正常退出，stdout 含 OK，stderr 同时含两条清理失败。证据 /workspace/code-review/repro_study_mesh_cleanup.log。没有安装或启动 COMSOL，没有声称本机原生验收。
- **可能的解决办法**：使用仓库 CleanupRecorder 或收集清理错误后使探针返回非零/抛异常；保留原主异常和各清理步骤证据。增加清理失败用例，不能仅凭构造/网格成功日志通过验收。

## BUG-187

- **编号**：BUG-187
- **标题**：Wave Optics point-audit 验收忽略客户端和租约清理失败，仍写 success=true 并 exit(0)
- **严重性/优先级**：中 / P2；原生验收结果可信度和清理证据问题。
- **位置**：development_kit/tests/integration/wave_optics_point_audit_acceptance.py:234 的 main finally。
- **内容/复现方法**：成功主体设置 output.success=True/exit_code=0 后，finally 对 client.clear 异常直接 pass；owner.release 结果虽然写入 receipt，但不影响 success 和退出码。运行 python /workspace/code-review/repro_point_audit_finalizer.py：从原文件 AST 提取且不修改 finally 语句，给出成功主体状态、clear 抛 OSError、release 返回 success=false/released=false，真实分支写出的 JSON 仍 success=true，调用 os._exit(0)。证据 /workspace/code-review/repro_point_audit_finalizer.log。仅执行 cleanup 分支，不导入/启动 COMSOL，也不声称测量主体已原生验收。与 BUG-186 的独立 study_mesh 探针类似，但这里另有公开 JSON 收据和 lease 失败漏计。
- **可能的解决办法**：采用 CleanupRecorder 或明确核对清理步骤和实际 released；任一步清理失败将整体验收标为失败、非零退出，保存 cleanup_pending/错误，不吞掉 client.clear 异常。对成功测量加清理失败的组合覆盖回归。

## BUG-188

- **编号**：BUG-188
- **标题**：Convergence 验收收据声称拒绝覆盖，但原子替换会覆盖检查后发布的同名收据
- **严重性/优先级**：中 / P2；并发运行数据保留与收据归属问题。
- **位置**：development_kit/tests/integration/convergence_campaign_acceptance.py:40，_write_json()。
- **内容/复现方法**：_write_json 先 path.exists 检查，再写固定 .json.tmp 并 os.replace(temporary,path)。两个运行使用相同 output，后一个在前一个检查后发布时，前一个无条件覆盖它；固定临时名还会使两个写入竞争同一中间文件。python /workspace/code-review/repro_convergence_receipt_race.py 调用真实函数，仅在 os.replace 边界先写另一发布者的有限收据，然后执行真实 replace；无异常，concurrent_receipt_preserved=false，原收据消失。证据同名 .log。仅临时目录，无 COMSOL 或既有用户文件操作。不同于 BUG-173 的公开审查 CSV guard 遗漏，这里是独立验收输出的非独占发布。
- **可能的解决办法**：使用仓库 atomic_write_json_exclusive（spectral 验收已有此用法），独立唯一临时名并保证最终目标独占；两个同 output 运行只能一个成功，另一个失败并保留既有收据。

## BUG-189

- **编号**：BUG-189
- **标题**：reference-power 原生 worker 调用 point audit 缺少 loaded-source attestation，必然在测量前被完整性门阻断
- **严重性/优先级**：高 / P1；声称的物理 reference-power 验收路径无法完成。
- **位置**：development_kit/tests/integration/reference_power_acceptance.py:353，_run_worker 中 run_wave_optics_point_audit 调用；对照 comsol_mcp/tools/wave_optics_preflight.py:1271。
- **内容/复现方法**：worker 自己 client.load 源文件并传入 expected_source_sha256，但没有给 point audit 传 loaded_source_identity。真实 preflight 只接受加载时 attested identity，不从当前磁盘 hash 推断内存加载身份，所以任何有效源都生成 source_path_mismatch/source_hash_mismatch，audit_status=integrity_blocked，不进行物理测量。run_wave_optics_point_audit 的 success=true 此时仅表示证据收集完成，不能成为 physical pass。python /workspace/code-review/repro_reference_worker_attestation.py 用真实 point audit/preflight、有限 metadata-only 模型和干净 ownership 替身复现该调用条件，结果精确为 integrity_blocked，actual path/hash 都为 null，native API 未访问。日志同名 .log。专用 point-audit/periodic gate 已显式传该身份，此 worker 未同步。没有运行 COMSOL；与 BUG-169 的 air-reference 文件格式互操作错误为独立阻断点。
- **可能的解决办法**：加载前验证 caller source pin、加载后复核字节身份，保存并传入明确的 source_path/source_sha256/capture attestation；验收组合测试使用真实 preflight 而不是完全替换 audit，核对实际进入测量及 physical verdict。

## BUG-190

- **编号**：BUG-190
- **标题**：semantic-feature 无求解器验收即使关闭功能仍注入 Windows 语义路径，Debian MCP 进程在启动时退出
- **严重性/优先级**：中 / P2；Debian 无求解器验收兼容性问题。
- **位置**：development_kit/tests/integration/semantic_feature_acceptance.py:75，_server() 的 COMSOL_SEMANTIC_ROOT/LEXICAL_INDEX/MODEL_PATH。
- **内容/复现方法**：_discover 在 semantic_enabled=false 的基础 profile 阶段仍由 _server 无条件设置 D:/comsol_semantic 等路径；Linux Path 认为 D:/... 是相对路径，get_capabilities 初始化 SemanticService 时 semantic_configuration 抛 COMSOL_SEMANTIC_ROOT must be absolute，stdio 初始化收到 Connection closed。python /workspace/code-review/repro_semantic_profile_counts.py 首段运行真实原 _discover/_server；完整首次失败日志 repro_semantic_profile_counts-original-debian.log 保存生产 traceback，重跑日志也保留启动失败。还未进入需要模型/授权手册的语义阶段，未启动 COMSOL。用户目标包含 Debian 错误，因此记录该验收入口缺陷；不由此声称 Windows 原生求解必须支持 Linux。
- **可能的解决办法**：通过参数/平台默认根传入语义部署配置；基础 discovery 关闭功能时不要注入无关部署路径，使用配置的绝对 ASCII root。Linux 可在无语义模型时完成 base profile 检查，真实语义验收缺少模型则明确报告外部前提。

## BUG-191

- **编号**：BUG-191
- **标题**：semantic-feature 验收仍使用旧 profile 工具数量，当前 core 56 个工具被判失败
- **严重性/优先级**：中 / P2；公开语义功能验收不可运行。
- **位置**：development_kit/tests/integration/semantic_feature_acceptance.py:29 PROFILE_COUNTS；_discover() 和 _semantic_flow() 的 tool_count 断言。
- **内容/复现方法**：常量仍为 core=47/basic_fem=109/wave_optics=76/experimental=97/full=150；当前冻结 profile 为 56/118/85/110/166。开启 manuals+semantic_docs 的 core 断言仍为55，当前 core 基础56再加8工具应64。python /workspace/code-review/repro_semantic_profile_counts.py 在独立外部探针仅把 BUG-190 的语义路径替换为绝对 ASCII 后，真实原 _discover(core) 抛 AssertionError；真实 stdio list 与 capabilities 均报告56，脚本期待47。session.connected/starting 均false。证据 repro_semantic_profile_counts.log。没有更改仓库或启动 COMSOL，也未把缺少本机模型的语义查询当成通过。
- **可能的解决办法**：更新本版本独立 profile/feature 数量期望，并添加与冻结快照的一致性检查（live_profile_acceptance 已有类似模式）；保留真实 stdio、功能 gate 和完整分页检查以避免仅同源自比较。

## BUG-192

- **编号**：BUG-192
- **标题**：Lin2025 manifest 编译失败的重复运行会覆盖上次有效 manifest，使保留 envelope 的 hash 失配
- **严重性/优先级**：高 / P1；既有有效提交对被失败运行破坏。
- **位置**：development_kit/scripts/lin2025_robust_manifest.py:131，compile_lin2025_robust_submission() 的 manifest_preexisting/atomic_write_json/expand 顺序；关联 test_lin2025_robust_manifest.py:306。
- **内容/复现方法**：函数声称只在严格展开通过后写规范 manifest/envelope，但先无条件覆盖 manifest，后才 expand 验证。失败时仅新建 manifest 会删除，已存在 manifest 不恢复；旧 envelope 虽保留，却绑定已被覆盖前的 hash。python /workspace/code-review/repro_lin_manifest_failed_rerun.py 使用仓库真实 solver-free fixture/编译器/expander：第一次成功生成24条件提交；第二次把 gradient_policy 改为非法字段，同一路径运行按预期抛 ValueError。实际 previous_manifest_preserved=false、previous_envelope_preserved=true、previous_envelope_matches_manifest=false。证据同名 .log。现有 failed-rerun 测试只有孤立 envelope sentinel，没有此前有效 manifest/envelope 对，漏掉此破坏。未运行 COMSOL。
- **可能的解决办法**：先在独立临时/新generation文件中完成展开、自校验与hash绑定，通过后才发布成对产物；失败保留旧两文件内容，避免非事务性单文件替换。增加真实成功提交后失败重跑、envelope发布失败等状态保持回归。

## BUG-193

- **编号**：BUG-193
- **标题**：Settings GUI visual capture 子进程失败会递归删除调用者已有的整个 output-root
- **严重性/优先级**：高 / P1；失败路径丢失既有文件与证据。
- **位置**：development_kit/scripts/settings_gui_visual_capture.py:301，capture_matrix() 的 mkdir(exist_ok=True) 和失败分支 shutil.rmtree(output_root)。
- **内容/复现方法**：函数接受任意已有 output-root，没有独占目录或产物归属检查。任何一个 capture 子进程非零退出（例如 Debian 无显示器/Tk错误）都会 rmtree 整个目录，包含此前验收截图、日志及用户放入的其他文件。python /workspace/code-review/repro_visual_capture_cleanup.py 创建临时已有目录及 previous-evidence.txt，调用真实 capture_matrix，只把第一个 subprocess.run 换成有限 display-failure 返回；抛 RuntimeError 后 existing_evidence_preserved=false/output_root_preserved=false。证据同名 .log。未创建 Tk 窗口、未删除任何真实用户目录、没有运行 COMSOL。
- **可能的解决办法**：每次运行创建独占新目录/UUID子目录，并只清理本次创建且身份确认的文件；失败应保存已生成截图/子进程诊断供审查。若必须指定空root，执行前拒绝已存在非空目录，不能在失败后删整个调用者路径。

## BUG-194

- **编号**：BUG-194
- **标题**：live-profile 清理声明30秒绝对上限，但模型revision查询使用300秒独立超时，耗尽后跳过移除和断开
- **严重性/优先级**：中 / P2；清理时限和失败恢复鲁棒性问题。
- **位置**：development_kit/tests/integration/live_profile_acceptance.py:260 _cleanup_live_session()；_model_revision()/_call() 的 deadline=None 默认300秒。
- **内容/复现方法**：cleanup 为整体设 deadline，但传 model_remove 参数前 await _model_revision，后者调用 _call(comsol_status) 不继承 deadline。当控制面该读取慢于剩余清理时限时，可以等待300秒才回来，随后 model_remove 和 comsol_disconnect 都因绝对deadline已耗尽而仅记录 TimeoutError，没有发送清理请求。python /workspace/code-review/repro_live_cleanup_deadline.py 调用真实helper，把声明上限缩放为0.02秒、有限状态响应延迟0.08秒（缩放以避免长等待）；实测elapsed约0.080秒，实际调用只有comsol_status，read_timeout_seconds=300.0，移除/断开均未调用。证据同名 .log。没有COMSOL，未声称实际300秒hang已经运行。
- **可能的解决办法**：revision读取同样传递统一绝对deadline，在每个nested call之前检查剩余时限；清理策略为必要disconnect保留预算，明确记录deadline耗尽后的cleanup_pending，避免将外层有限预算绕过为独立长等待。

## BUG-195

- **编号**：BUG-195
- **标题**：工程 fixture 保存中断或空产物失败时 staging 路径未返回，main 无法清理本次残留文件
- **严重性/优先级**：中 / P2；失败清理、磁盘占用及验收残留问题。
- **位置**：development_kit/scripts/build_engineering_fixture.py:472 _save_staged()；main 的 staging赋值及 finally 条件。
- **内容/复现方法**：_save_staged 在内部生成唯一staging后直接 java.save；save在创建/部分写文件后抛异常，或返回空文件使后续验证抛异常，函数不会返回路径。main 的 staging=_save_staged(...) 未完成赋值，staging仍None，finally跳过staging清理，receipt.cleanup可能仍称passed。python /workspace/code-review/repro_fixture_partial_save.py 调用真实 helper，有限java替身先写19字节再抛OSError，并按原main的赋值/清理条件处理；caller_received_staging_path=false，owned_partial_files_left有本次.staging。证据同名.log。现有save-failure替身在写文件前就抛错，empty-staging测试仅检查最终目标缺失，没有检查孤立staging。未运行COMSOL，未留下真实模型。
- **可能的解决办法**：调用者先分配并记录staging路径，再传给保存函数；或helper在受控finally中清理自己分配的确切路径，清理失败将身份与错误交还caller供重试。覆盖部分写后异常和空文件返回两类路径。

## BUG-196

- **编号**：BUG-196
- **标题**：Python兼容性验收重复poll循环的首个循环无sleep，持续刷新磁盘租约并扫描全机网络
- **严重性/优先级**：中 / P2；原生验收性能和资源干扰。
- **位置**：development_kit/scripts/python_compatibility_licensed_gate.py:550 与563，_run_parent 的两个连续 while process.poll() is None。
- **内容/复现方法**：第一个循环没有sleep，每轮 owner.heartbeat(refresh_server_processes=True)、owned descendants观察及psutil.net_connections listener扫描。它一直运行到worker退出或deadline超时，因此第二个包含time.sleep(0.25)的循环通常永远没有运行迭代。这使原本应4Hz的监测变成无间隔的磁盘/进程/全机网络扫描，给兼容性验收和solver制造无关资源负担。python /workspace/code-review/repro_python_compat_polling.py 从原_run_parent抽取两段完整未修改AST循环，有限虚拟process返回100次running后退出；真实loop执行heartbeat/descendants/listeners各100次，sleep=0。日志同名.log。未执行网络扫描、进程终止或COMSOL；不声称测量了真实native速度。
- **可能的解决办法**：删除重复的首个busy循环，保留一个统一deadline/heartbeat/观察/有限sleep循环；对观测次数和poll间隔做solver-free回归，避免监测本身影响兼容性结论。

## BUG-197

- **编号**：BUG-197
- **标题**：两个shape licensed gate未区分immutable源与固定输出路径，合法base.mph源在启动前被删除
- **严重性/优先级**：高 / P1；不可变源模型丢失。
- **位置**：development_kit/scripts/lin2025_pedot_shape_licensed_gate.py:185；development_kit/scripts/robust_shape_adapter_licensed_gate.py:323；各_spec的base_copy/configured_copy/rollback_copy。
- **内容/复现方法**：_spec允许source_model位于test_root内并取名base.mph或其他固定输出名，fixture/manifest源hash正确时dry-run报告success=true。_run在获取租约后，对固定base/configured/rollback路径无归属检查地unlink，再构造Client和load源；当source与输出同路径时，自己的不可变源被删除。python /workspace/code-review/repro_shape_gate_source_alias.py 使用仓库真实fixture、真实_spec/_dry_run/_run：两个gate的base.mph源均dry-run_success=true/source_aliases_base_copy=true；只以有限ownership替身授权并在mph.Client构造边界禁止native启动，immutable_source_preserved=false。日志同名.log。源为临时模拟文件，没有COMSOL、没有真实用户模型损坏。普通既有固定输出也被直接删除。
- **可能的解决办法**：分配本次运行独占输出路径，运行前验证所有源/manifest/receipt/output的规范化路径及文件identity不相同；拒绝覆盖已有artifact，尤其禁止cleanup或初始化删除输入。添加source恰为base.mph/configured.mph/rollback.mph和硬链接别名的保护回归。

## BUG-198

- **编号**：BUG-198
- **标题**：shared licensed gate允许receipt与immutable源同路径，最终JSON发布覆盖受保护模型
- **严重性/优先级**：高 / P1；不可变源文件破坏。
- **位置**：development_kit/scripts/shared_interactive_licensed_gate.py:142 _spec() 的receipt校验；main()的atomic_write_json(args.receipt,result)。
- **内容/复现方法**：saved/saved_readback校验只要求working与immutable_source路径不同，receipt仅检查绝对ASCII，没有排除两项模型输入。_run可能完整确认源bytes未变，但main最后以可覆盖writer写receipt，不再核对输入身份；失败结果同样发布。python /workspace/code-review/repro_shared_receipt_source_alias.py 用真实_spec/main/writer，传入--immutable-source-path source.mph --receipt source.mph及不同working.mph；spec接受。只将原生_run换有限失败sentinel，避免任何attach；真实main exit1后 immutable_source_preserved=false，原MPH字节变成失败JSON。日志同名.log。未连接COMSOL、未操作真实用户模型。与BUG-197的固定copy初始化删除为不同路径/原因。
- **可能的解决办法**：规范化并验证receipt与所有模型/immutable输入路径及文件identity互斥，receipt使用新独占目标发布；发布前再确认源pin，失败回执也不可覆盖源。覆盖receipt==source、receipt==working及硬链接别名回归。

## BUG-199

- **编号**：BUG-199
- **标题**：surrogate campaign licensed gate将坐标/结果字符串摘要伪装为FEM产物哈希，没有保存可复核产物
- **严重性/优先级**：高 / P1
- **位置**：development_kit/scripts/surrogate_campaign_licensed_gate.py:_run_worker fem_results.append；_run_parent phase_passed
- **内容/复现方法**：gate没有保存各candidate的FEM模型、原始结果文件或测量收据，只对candidate_id:a1:a2:fem_value字符串计算SHA256后填入fem_artifact_sha256。父进程仅检查该字段非空，仍把结果视为verified FEM evidence；无法按哈希定位/验证实际产物，不满足自身docstring的artifact hash合同。python /workspace/code-review/repro_surrogate_campaign_artifact.py 执行原文件未修改的完整AST结果发布语句及真实record_fem_result；得到state=verified/is_fem_evidence=true、actual_artifacts=[]，claimed hash精确等于坐标/结果字符串摘要。日志同名.log。有限测量值替身，没有COMSOL；这证明产物证据绑定缺失，不代表实际FEM测量值已被证实错误。
- **可能的解决办法**：将每个候选的源身份、参数、求解状态及原始测量持久化为独占且不可变的收据/模型产物，再对文件字节计算摘要；父进程重新核对产物存在、内容身份与candidate绑定，并将数值摘要与产物摘要使用不同字段。

## BUG-200

- **编号**：BUG-200
- **标题**：surrogate导出验收复用既有workspace，当前export全部失败仍接纳上一轮产物并判定hash稳定
- **严重性/优先级**：高 / P1
- **位置**：development_kit/scripts/surrogate_export_licensed_gate.py:_run_parent/_run_worker；development_kit/scripts/surrogate_campaign_licensed_gate.py:_run_worker export_path
- **内容/复现方法**：父进程只要求receipt使用新路径，workspace固定为output.parent/workspace并允许已存在。worker export异常被捕获后，仅检查固定路径文件是否存在；export gate忽略internal_errors/extension_error，旧的两个ONNX和extension文件可使hash_stable和identical_to_onnx仍为true，并被登记为本轮artifacts。campaign gate同样在export失败后继续加载旧campaign_surrogate.onnx。python /workspace/code-review/repro_surrogate_stale_export.py 执行export gate原始完整AST导出阶段，临时workspace预放三个同内容旧文件，有限exporter三次均OSError；实际hash_stable=true/extension_identical=true、accepted_artifacts包含旧hash。日志同名.log。此复现仅验证导出阶段误接纳，不声称24字节占位文件可通过后续ONNX解析或完整native gate。有效旧ONNX仍会进入后续训练一致性检查；确定性同数据同种子重跑尤其容易掩盖本轮导出失败。
- **可能的解决办法**：为每次run建立唯一且排他workspace和导出文件名，不允许使用既有文件作为当前结果；本轮export抛异常必须拒绝相应阶段，即使路径有文件也不能认证；保存run身份及产物生成证据，完整验收增加旧有效ONNX加当前export失败的回归测试。

## BUG-201

- **编号**：BUG-201
- **标题**：surrogate DNN licensed gate记录重载身份和拒绝后tags却不比较，身份已变或节点丢失仍可通过
- **严重性/优先级**：中 / P2
- **位置**：development_kit/scripts/surrogate_dnn_licensed_gate.py:_run_worker save/reload/refusal；_run_parent phase_passed
- **内容/复现方法**：docstring和dry-run声称证明save/reload preserves identity及refusal不修改既有树。worker只读取reload的seed、DNN/step type和post_refusal_tags，没有与保存前值比较；父进程phase_passed完全不引用这些字段。python /workspace/code-review/repro_surrogate_reload_gate.py 执行原文件完整未修改AST验收表达式，有限收据将seed从17改成999、重载类型变WrongType、拒绝后tags全部消失；original_phase_passed仍true。日志同名.log。无COMSOL；这是验收门未检测合同违例的证明，不声称真实COMSOL重载已经产生这些变化。
- **可能的解决办法**：保存完整关键配置和节点身份基线；重载后比较tag/type和全部声明的受控属性，拒绝操作前后也比较相同快照；父进程独立检查比较结果及原始证据，加入变seed/变type/删除tag的负面验收用例。

## BUG-202

- **编号**：BUG-202
- **标题**：旧 profile 迁移覆盖显式 false，静默开启语义检索或共享 Server 功能
- **严重性/优先级**：中 / P2
- **位置**：comsol_mcp/settings.py:330-335，_migrate_legacy_document；docs/profile_migration.md 的显式 Boolean 优先契约；development_kit/tests/test_settings.py:test_legacy_synthetic_profiles_migrate_to_independent_feature_gates
- **内容/复现方法**：迁移指南明确要求已存在的显式 Boolean 保持权威，但 semantic_docs/desktop_shared 分支无条件把对应 enabled 写为 True；只有 full 分支使用 setdefault。python /workspace/code-review/repro_settings_explicit_false_migration.py 调用真实 normalize_settings_document：在 1.1.0 和当前 1.3.0 文档中，两个旧 profile 均将请求 false 转成 true，errors=[]，输入对象本身未改写。现有 shared migration 测试甚至预设 enabled=False 并期待 True，固化了与指南冲突的行为。无 COMSOL/网络连接；开启 feature 仅改变暴露/配置，不代表已自动 attach 或下载模型。日志同名 .log。
- **可能的解决办法**：按可读旧版本限定迁移，旧 alias 仅在 feature enabled 缺失时填 True；显式 false/非法值保留给规范化验证。使测试同时覆盖缺失、false、true、错误类型和当前版本 alias，并统一文档与实际兼容语义。

## BUG-203

- **编号**：BUG-203
- **标题**：owned staged worker 在租约释放失败时仍持久化 completed 并返回成功，缺失清理失败状态
- **严重性/优先级**：中 / P2；执行终态与资源清理证据不一致，失败租约只能从 stderr 发现。
- **位置**：comsol_mcp/jobs/worker.py:703-710、789-806；development_kit/tests/test_durable_job_control_plane.py:test_production_worker_bridges_smoke_broad_and_lease_with_mocks。
- **内容/复现方法**：python /workspace/code-review/repro_staged_cleanup_terminal.py 调用仓库既有 solver-free 测试，使用真实 JobStore 和 production worker，仅 ownership、MPh client 和 sweep runner 为原测试替身；release 抛 injected ownership release failure。实测 exit_code=0、status=completed、last_error=null、cleanup_fields={}，stderr 有 release warning。该测试显式要求 release_raises=True 时仍 completed，因而固化此行为。owned 分支先提交不可改写的 completed，finally 对 clear/disconnect/release 的失败仅打印，不能持久记录 cleanup_pending 或清理证据。复现确认的是租约异常丢失，不声称有真实 COMSOL 进程泄漏。与 BUG-113 的活 native cancel 线程竞态不同，此处不涉及线程。证据同名 .log。
- **可能的解决办法**：先完成并验证 owned 清理，再提交终态；或单独持久化不可变 execution outcome 与可继续恢复的 cleanup outcome，保证成功测量可保留但未验证清理明确可见。把 release 异常/返回 success=false 以及 clear/disconnect 失败加入状态回归测试，避免仅检查 worker 退出码。
