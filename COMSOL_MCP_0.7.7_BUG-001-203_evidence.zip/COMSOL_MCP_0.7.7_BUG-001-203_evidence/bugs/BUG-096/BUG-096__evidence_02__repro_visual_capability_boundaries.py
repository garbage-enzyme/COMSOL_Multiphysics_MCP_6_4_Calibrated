"""Pure declared capability/request consistency probes; no host messages."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_visual_review_contracts import _calibration, _refs, _receipt, _request
from comsol_mcp.evidence.visual_review import normalize_codex_capability, normalize_opencode_capability
capability = normalize_codex_capability(view_image_available=True,
    view_image_results=[{**ref,'image_content_returned':True} for ref in _refs()],
    calibration=_calibration(), max_total_bytes=1)
request = _request()
receipt = _receipt(capability,request=request)
print('declared_byte_limit', capability['max_total_bytes'],
      'request_bytes',sum(a['byte_count'] for a in request['artifacts']))
print('receipt', receipt['status'], receipt['incomplete_reasons'])
metadata = {'id':'provider/model','capabilities':{'input':{'image':'false'}}}
bad = normalize_opencode_capability(provider='provider', model='model',provider_metadata=metadata,
    cli_attachment_supported=True,attachment_part_confirmed=True,
    delivered_artifacts=_refs(),calibration=_calibration())
print('text_false_metadata', bad['image_input'],bad['host_capability_confirmed'],bad['scientific_review_eligible'])
