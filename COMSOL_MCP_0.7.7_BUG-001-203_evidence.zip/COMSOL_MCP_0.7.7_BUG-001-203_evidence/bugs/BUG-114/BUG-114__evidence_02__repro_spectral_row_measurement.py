import json
import runpy
import sys
from pathlib import Path

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(repo))
fixture = runpy.run_path(str(repo / 'development_kit/tests/spectral_job_fixtures.py'))
from comsol_mcp.jobs.spectral_audit import build_spectral_audit_point, extract_spectral_audit_result
from comsol_mcp.jobs.spectral_rows import append_spectral_row, read_spectral_rows

root = Path('/workspace/code-review/spectral-row-measurement')
root.mkdir(exist_ok=True)
spec = fixture['spectral_job_spec'](root)
point = build_spectral_audit_point(spec, 4e-6)
artifact = root / 'artifacts' / point['point_id']
result = fixture['write_fake_point_audit'](artifact, spec, point, absorption=0.2)
args = extract_spectral_audit_result(job_dir=root, artifact_dir=artifact, spec=spec, point=point, result=result)
args.update(A=0.9, R=0.05, evaluated_wavelength_m=8e-6)
journal = root / 'spectral_rows.jsonl'
journal.unlink(missing_ok=True)
append_spectral_row(journal, spec, attempt=1, stage_index=0, stage_kind='initial_locator', artifact_root=root, **args)
row = read_spectral_rows(journal, spec, artifact_root=root)[0]
assert row['A'] == 0.9 and row['evaluated_wavelength_m'] == 8e-6
assert json.loads((artifact / 'audit/manifest.json').read_text())['measurement']['power']['A'] == 0.2
print(json.dumps({'artifact_A':0.2, 'replayed_A':row['A'], 'artifact_wavelength_m':4e-6,
    'replayed_evaluated_wavelength_m':row['evaluated_wavelength_m'], 'real_solver_started':False}, indent=2))
