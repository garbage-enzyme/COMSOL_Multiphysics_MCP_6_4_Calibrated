"""Production adapter hash and summary-only artifact reading checks, solver-free."""
import json
import os
import sys
import tempfile
import tracemalloc
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from mcp.server.mcpserver import MCPServer
from comsol_mcp.tools.evidence_integrity import register_evidence_integrity_tools
from comsol_mcp.evidence.contracts import canonical_sha256
from comsol_mcp.evidence.integrity_controls import EVIDENCE_SETTINGS_ENV
from comsol_mcp.evidence.portfolio_verifier import verify_portfolio_evidence_checks
from comsol_mcp.settings import default_settings_document
from development_kit.tests.test_portfolio_verifier import _fixture

with tempfile.TemporaryDirectory(prefix='integrity-receipt-', dir='/workspace/code-review') as temp:
    root = Path(temp)
    artifacts = root / 'artifacts'
    artifacts.mkdir()
    request, raw, fit = _fixture(artifacts)
    settings = root / 'settings.json'
    settings.write_text(json.dumps(default_settings_document()), encoding='utf-8')
    with patch.dict(os.environ, {
        'COMSOL_MCP_SETTINGS_PATH': str(settings),
        'COMSOL_MCP_ARTIFACT_WRITE_ROOT': str(artifacts),
    }):
        os.environ.pop(EVIDENCE_SETTINGS_ENV, None)
        server = MCPServer('integrity-receipt')
        register_evidence_integrity_tools(server)
        result = server._tool_manager._tools['evidence_integrity_verify'].fn(
            request, {'case-one': str(artifacts)})
        digest = result.pop('verification_sha256')
        print('verified:', result['strictly_verified'])
        print('returned receipt hash matches:', canonical_sha256(result) == digest)
        result.pop('artifact_root_validation')
        print('hash matches after removing adapter field:', canonical_sha256(result) == digest)
    # The manifest still declares the original small file. Summary verification
    # remains enabled while artifact-chain verification is explicitly disabled.
    (artifacts / raw['relative_path']).write_bytes(b'x' * (8 * 1024 * 1024))
    tracemalloc.start()
    try:
        verify_portfolio_evidence_checks(request,
            artifact_roots={'case-one': str(artifacts)},
            check_outcome_contract=True, check_artifact_chain=False,
            check_summary_claims=True)
    except ValueError as exc:
        print('summary-only rejection:', str(exc))
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('summary-only allocation peak:', peak)
