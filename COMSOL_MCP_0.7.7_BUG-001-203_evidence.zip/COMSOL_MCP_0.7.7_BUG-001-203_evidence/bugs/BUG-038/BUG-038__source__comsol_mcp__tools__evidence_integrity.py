"""MCP adapters for default-on solver-free evidence-integrity verification."""

from __future__ import annotations

import logging
from typing import Any, Optional

from mcp.server.mcpserver import MCPServer

from comsol_mcp.path_policy import PathPolicy
from comsol_mcp.utils.public_errors import public_error

logger = logging.getLogger(__name__)


def register_evidence_integrity_tools(mcp: MCPServer) -> None:
    """Register path-redacted settings discovery and formal verification."""

    @mcp.tool()
    def evidence_integrity_status() -> dict[str, Any]:
        """Report every effective default-on check and the settings fingerprint."""
        from comsol_mcp.evidence.integrity_controls import load_evidence_integrity_status

        return load_evidence_integrity_status()

    @mcp.tool()
    def evidence_integrity_verify(
        portfolio_request: dict[str, Any],
        artifact_roots: dict[str, str],
        resumed: bool = False,
        producer_compatibility: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Verify exact outcomes, artifact bytes, summary citations, and resume identity."""
        from comsol_mcp.evidence.integrity_controls import (
            load_evidence_integrity_status,
            warning_fields,
        )
        from comsol_mcp.evidence.integrity_verifier import verify_evidence_integrity

        status = load_evidence_integrity_status()
        if status.get("configuration_state") != "valid":
            try:
                result = verify_evidence_integrity(
                    portfolio_request=portfolio_request,
                    artifact_roots={},
                    resumed=resumed,
                    producer_compatibility=producer_compatibility,
                    settings_status=status,
                )
                result["artifact_root_validation"] = {
                    "enforced": False,
                    "accepted": False,
                    "paths_included": False,
                    "discarded_root_count": len(artifact_roots),
                }
                return result
            except TypeError, ValueError:
                logger.exception("Evidence integrity request was rejected")
                result = {
                    **public_error(
                        "integrity_verification_rejected",
                        "Evidence integrity request was rejected.",
                    ),
                    "verification_state": "blocked",
                    "strictly_verified": False,
                    "artifact_root_validation": {
                        "enforced": False,
                        "accepted": False,
                        "paths_included": False,
                    },
                }
                result.update(warning_fields(status))
                return result
            except OSError, RuntimeError:
                logger.exception("Evidence integrity verification failed")
                result = {
                    **public_error(
                        "integrity_verification_failed",
                        "Evidence integrity verification failed safely.",
                    ),
                    "verification_state": "blocked",
                    "strictly_verified": False,
                    "artifact_root_validation": {
                        "enforced": False,
                        "accepted": False,
                        "paths_included": False,
                    },
                }
                result.update(warning_fields(status))
                return result
        filesystem_checks_enabled = any(
            status["checks"][name]["enabled"]
            for name in (
                "artifact_chain_verification",
                "summary_claim_verification",
            )
        )
        if not filesystem_checks_enabled and artifact_roots:
            result = {
                **public_error(
                    "artifact_roots_forbidden",
                    "artifact_roots must be empty when filesystem checks are disabled.",
                ),
                "verification_state": "blocked",
                "strictly_verified": False,
                "artifact_root_validation": {
                    "enforced": False,
                    "accepted": False,
                    "paths_included": False,
                },
            }
            result.update(warning_fields(status))
            return result
        try:
            policy = PathPolicy.from_environment()
            normalized_roots: dict[str, str] = {}
            root_ids: set[str] = set()
            for case_id, value in artifact_roots.items():
                if not isinstance(case_id, str) or not case_id or len(case_id) > 192:
                    raise ValueError("artifact_roots keys must be bounded case IDs")
                decision = policy.validate_artifact_read_root(value)
                normalized_roots[case_id] = str(decision.normalized_path)
                root_ids.add(decision.root_id)
        except OSError, RuntimeError, TypeError, ValueError:
            logger.exception("Evidence artifact-root validation failed")
            result = {
                **public_error(
                    "artifact_root_rejected",
                    "Artifact-root validation failed.",
                ),
                "verification_state": "blocked",
                "strictly_verified": False,
                "artifact_root_validation": {
                    "enforced": True,
                    "accepted": False,
                    "paths_included": False,
                },
            }
            result.update(warning_fields(status))
            return result

        try:
            result = verify_evidence_integrity(
                portfolio_request=portfolio_request,
                artifact_roots=normalized_roots,
                resumed=resumed,
                producer_compatibility=producer_compatibility,
                settings_status=status,
            )
            result["artifact_root_validation"] = {
                "enforced": True,
                "validated_root_count": len(normalized_roots),
                "root_ids": sorted(root_ids),
                "paths_included": False,
            }
            return result
        except TypeError, ValueError:
            logger.exception("Evidence integrity request was rejected")
            reason_code = "integrity_verification_rejected"
            message = "Evidence integrity request was rejected."
        except OSError, RuntimeError:
            logger.exception("Evidence integrity verification failed")
            reason_code = "integrity_verification_failed"
            message = "Evidence integrity verification failed safely."
        result = {
            **public_error(reason_code, message),
            "verification_state": "blocked",
            "strictly_verified": False,
            "artifact_root_validation": {
                "enforced": True,
                "accepted": True,
                "validated_root_count": len(normalized_roots),
                "root_ids": sorted(root_ids),
                "paths_included": False,
            },
        }
        result.update(warning_fields(status))
        return result


__all__ = ["register_evidence_integrity_tools"]
