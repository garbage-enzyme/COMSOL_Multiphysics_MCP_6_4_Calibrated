"""Cold public semantic status returns unchecked deployment identity text."""
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from mcp.server.mcpserver import MCPServer
from comsol_mcp.knowledge.semantic_runtime import SemanticService
from comsol_mcp.knowledge.semantic_contracts import PUBLIC_LIMITS
from comsol_mcp.tools import semantic_docs

with tempfile.TemporaryDirectory(prefix='semantic-status-', dir='/workspace/code-review') as temp:
    root = Path(temp)
    deployment = root / 'deployment'
    index = deployment / 'indexes' / 'fixture'
    index.mkdir(parents=True)
    model = root / 'model'
    model.mkdir()
    lexical = root / 'manuals.json'
    lexical.write_text('{}')
    build_id = 'a' * (2 * 1024 * 1024)
    manifest_bytes = json.dumps({'build_id': build_id, 'model_fingerprint': 'b' * 64}).encode()
    (index / 'manifest.json').write_bytes(manifest_bytes)
    (deployment / 'current.json').write_text(json.dumps({
        'index_path': str(index), 'build_id': build_id, 'model_fingerprint': 'b' * 64,
        'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    }))
    (model / 'model_manifest.json').write_text(json.dumps({'model_sha256': 'b' * 64}))
    service = SemanticService({
        'COMSOL_SEMANTIC_ROOT': str(deployment),
        'COMSOL_SEMANTIC_LEXICAL_INDEX': str(lexical),
        'COMSOL_SEMANTIC_MODEL_PATH': str(model),
    })
    server = MCPServer('semantic-status-bound')
    with patch.object(semantic_docs, 'get_semantic_service', return_value=service):
        semantic_docs.register_semantic_doc_tools(server)
        result = server._tool_manager._tools['semantic_status'].fn()
    print('cold status response bytes:', len(json.dumps(result).encode()))
    print('declared maximum response bytes:', PUBLIC_LIMITS['maximum_response_bytes'])
    print('worker was started:', service._manager is not None)
