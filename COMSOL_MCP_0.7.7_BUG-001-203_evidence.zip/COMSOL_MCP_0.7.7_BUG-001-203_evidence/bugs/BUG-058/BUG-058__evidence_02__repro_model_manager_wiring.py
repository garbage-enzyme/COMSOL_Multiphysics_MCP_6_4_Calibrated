import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
root = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(root))
from comsol_mcp.tools import model_manager as tools_module
from comsol_mcp.shared_session.model_manager import ModelManagerRuntime, ModelManagerContext
manager = tools_module.shared_session_manager
registrar = SimpleNamespace(profile_selection=SimpleNamespace(feature_enabled=lambda name: name == 'model_manager'))
with tempfile.TemporaryDirectory(dir='/workspace/code-review', prefix='model-manager-') as temp:
    with patch.object(manager, '_client', object()), \
         patch.object(manager, '_server_identity', SimpleNamespace(identity_sha256='a'*64)), \
         patch.object(manager, '_session_acquisition_id', 'attached-session-test'), \
         patch('comsol_mcp.utils.runtime_paths.default_runtime_dir', return_value=Path(temp)):
        status = manager.status()
        runtime = tools_module._runtime(registrar)
        print(json.dumps({'actual_status_attached': status['attached'],
                          'actual_status_server_hash': status['server_identity_sha256'],
                          'runtime_session_identity': runtime.capabilities()['session_identity'],
                          'production_dispatch_exists': callable(getattr(manager, 'model_manager_dispatch', None))}))
        try:
            runtime.open(uri='dbmodel://library/models/cell')
        except Exception as exc:
            print('Actual frontend runtime refused:', type(exc).__name__, getattr(exc, 'reason_code', None))
        print('Refusal journal row count:', runtime.replay()['row_count'])
    fixed_identity_only = ModelManagerRuntime(feature_enabled=True, upload_enabled=False,
        context=ModelManagerContext(attached=True, session_identity='attached-session-test',
                                   dispatch=tools_module._resolve_dispatch()), runtime_dir=Path(temp)/'identity-only')
    result = fixed_identity_only.open(uri='dbmodel://library/models/cell')
    print(json.dumps({'identity_only_fix_outcome': result['outcome'], 'reason': result.get('reason')}))
    disabled = ModelManagerRuntime(feature_enabled=False, upload_enabled=False,
        context=ModelManagerContext(attached=True, session_identity='s', dispatch=None),
        runtime_dir=Path(temp)/'disabled')
    try:
        disabled.open(uri='dbmodel://library/models/cell')
    except Exception as exc:
        print('Disabled gate refusal:', getattr(exc, 'reason_code', None))
    print('Disabled gate journal row count:', disabled.replay()['row_count'])
