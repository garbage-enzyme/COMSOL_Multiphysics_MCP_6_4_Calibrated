"""Analytic irregularly spaced seven-point spectrum; real SciPy fit."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_spectral_model_comparison import _bundle, _policy
from comsol_mcp.evidence.spectral_characterization import build_spectral_analysis_decision, build_spectral_characterization
wavelengths = [4.97e-6,4.98e-6,4.99e-6,5e-6,5.10e-6,5.20e-6,5.30e-6]
values = [0.1+0.8/(1+((x-5e-6)/.10e-6)**2) for x in wavelengths]
bundle = _bundle(wavelengths, values)
decision = build_spectral_analysis_decision(bundle, _policy())
config = {'peak_method':'lorentzian_fit','baseline_rule':'declared_response',
    'baseline_response_value':.1,'fwhm_definition':'half_prominence',
    'fit_support_points':7,'fit_support_sensitivity_points':[],
    'local_polynomial_degree':None,'fit_max_evaluations':20000,
    'fit_quality_policy':{'maximum_relative_rms_residual':.2,
                         'maximum_covariance_condition':1e20,
                         'minimum_parameter_bound_margin_fraction':0.}}
result = build_spectral_characterization(bundle, decision, config)
print('classification', decision['classification'])
print('fit_state', result['measurement_state'], result['reason_code'])
if result['measurement_state'] == 'measured':
    print('declared_support_window', result['candidate']['peak']['diagnostics']['fit_window_m'])
    print('fwhm', result['candidate']['fwhm'])
