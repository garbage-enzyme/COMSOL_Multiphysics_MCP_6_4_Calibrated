from comsol_mcp.server import create_server
from comsol_mcp.contracts.job_submission import validate_job_submission

spec = {'job_type': 'staged_sweep', 'source_model_path': '/tmp/source.mph',
        'parameter_name': 'x', 'parameter_values': [1.0], 'expressions': ['R'],
        'physical_bounds': {'R': [0.0, 1.0]}}
normalized = validate_job_submission(spec)
server = create_server('map-schema-repro', profile='core')
schema = server._tool_manager._tools['job_spec_preview'].parameters
definition = schema['$defs']['StagedSweepInput']
physical = definition['properties']['physical_bounds']['anyOf'][0]
print('runtime contract accepts nonempty physical_bounds:', bool(normalized['physical_bounds']))
print('advertised physical_bounds schema:', physical)
print('nonempty map keys rejected by schema:', physical.get('additionalProperties') is False
      and not physical.get('properties') and not physical.get('patternProperties'))
