"""Bounded custom worker stand-ins exercising real POSIX manager cleanup/handshake."""
import json
import sys
import tempfile
from pathlib import Path
import psutil
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.knowledge.semantic_process import SemanticWorkerManager
from comsol_mcp.knowledge.semantic_contracts import PUBLIC_LIMITS

with tempfile.TemporaryDirectory(prefix='semantic-process-', dir='/workspace/code-review') as temp:
    pid_file = Path(temp) / 'child.pid'
    code = (
        'import json,os,subprocess,sys,time; from pathlib import Path; '
        'child=subprocess.Popen([sys.executable,"-c","import time;time.sleep(20)"],'
        'stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); '
        f'Path({str(pid_file)!r}).write_text(str(child.pid)); '
        'print(json.dumps({"schema_version":"1","event":"ready","pid":os.getpid(),'
        '"host":"127.0.0.1","port":9}),flush=True); time.sleep(20)'
    )
    manager = SemanticWorkerManager(startup_deadline=3)
    manager._command = lambda: [sys.executable, '-c', code]
    child = None
    try:
        started = manager.start()
        assert started['success'], started
        child = psutil.Process(int(pid_file.read_text()))
        child_created = child.create_time()
        result = manager.reset()
        print('reset reports complete absence:', result['reset']['absent'])
        print('recorded descendant still alive:', child.is_running() and child.status() != psutil.STATUS_ZOMBIE)
    finally:
        manager.reset()
        if child is not None and child.is_running() and child.create_time() == child_created:
            child.kill()
            try:
                child.wait(timeout=3)
            except psutil.TimeoutExpired:
                pass  # An orphan may remain briefly as a reaped-by-init zombie.

code = (
    'import json,os,time; '
    'print(json.dumps({"schema_version":"1","event":"ready","pid":os.getpid(),'
    '"host":"127.0.0.1","port":9,"padding":"x"*(2*1024*1024)}),flush=True); time.sleep(20)'
)
manager = SemanticWorkerManager(startup_deadline=3)
manager._command = lambda: [sys.executable, '-c', code]
try:
    result = manager.start()
    print('2 MiB startup handshake accepted:', result['success'])
    print('public response budget:', PUBLIC_LIMITS['maximum_response_bytes'])
finally:
    assert manager.reset()['success']
