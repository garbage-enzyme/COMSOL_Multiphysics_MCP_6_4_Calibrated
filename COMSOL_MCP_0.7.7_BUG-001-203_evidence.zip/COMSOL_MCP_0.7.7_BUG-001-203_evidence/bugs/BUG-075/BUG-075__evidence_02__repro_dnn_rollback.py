"""Actual configuration applier with bounded in-memory protocol backend."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_surrogate_dnn_adapter import FakeBackend, _configuration
from comsol_mcp.surrogate.dnn_adapter import apply_surrogate_configuration

backend = FakeBackend(fail_on='write:activation')
backend.studies['smt1'] = {'user_owned': True, 'features': {}}
result = apply_surrogate_configuration(backend, _configuration())
print('foreign_study_after_failed_create_apply', backend.studies,
      'reported_rolled_back', result['rolled_back'], 'calls', backend.calls)
backend = FakeBackend(fail_on='write:layertype')
backend.functions['dnn1'] = {'activation':['none','relu'], 'layertype':['input','dense']}
before = dict(backend.functions['dnn1'])
result = apply_surrogate_configuration(backend, _configuration(), create_nodes=False)
print('existing_node_before', before)
print('existing_node_after', backend.functions['dnn1'],
      'success', result['success'], 'reported_rolled_back', result['rolled_back'])
