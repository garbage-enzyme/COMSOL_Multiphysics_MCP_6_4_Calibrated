"""Bounded offline cosine contract reproduction; no ML runtime or COMSOL."""
import json
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
import numpy as np
from comsol_mcp.knowledge.semantic_index import build_index, pin_model_snapshot, validate_pinned_model
from comsol_mcp.knowledge import semantic_index as index_module
from comsol_mcp.knowledge.lexical_manual import build_index_from_records
from comsol_mcp.knowledge.semantic_retrieval import HybridRetriever

class Encoder:
    dimension = 2
    def __init__(self, path, dimension=None):
        model = validate_pinned_model(path)
        self.model_id = model['model_id']
        self.model_revision = model['revision']
        self.model_fingerprint = model['model_sha256']
    def encode(self, texts):
        return np.asarray([[1., 0.] if text in ('aligned document', 'question')
                           else [10., 10.] for text in texts], dtype=np.float32)

with tempfile.TemporaryDirectory(prefix='cosine-', dir='/workspace/code-review') as temp:
    root = Path(temp)
    source = root / 'source'
    source.mkdir()
    (source / 'model.bin').write_bytes(b'offline fixture')
    model = root / 'model'
    pin_model_snapshot(source, model, model_id='fixture/cosine', revision='r1', dimension=2, license_name='test-only')
    lexical = root / 'manuals.sqlite3'
    build_index_from_records([dict(source='Manual.pdf', module='Core', page=i, heading='', text=text)
                              for i, text in enumerate(('aligned document', 'diagonal document'), 1)],
                             lexical, corpus_fingerprint='8'*64)
    deployment = root / 'deployment'
    built = build_index(deployment_root=deployment, lexical_index=lexical, model_path=model,
                        encoder=Encoder(model), build_id='cosine-test')
    retriever = HybridRetriever(deployment_root=deployment, lexical_index=lexical,
                               model_path=model, encoder_factory=Encoder)
    result = retriever.query('question', retrieval_mode='vector', limit=2)
    print(json.dumps({'build_validated': built['index']['validated'],
                      'distance_metric': retriever.manifest['distance_metric'],
                      'results': [{k:r[k] for k in ('page', 'vector_similarity', 'vector_distance')}
                                  for r in result['results']],
                      'expected_cosine_order': [1, 2],
                      'expected_cosine_similarities': [1.0, 2**-0.5]}, indent=2))
    index = Path(built['index']['path'])
    manifest = json.loads((index / 'manifest.json').read_text())
    chunks = [json.loads(line) for line in (index / 'chunks.jsonl').read_text().splitlines()]
    chunks[1]['source'] = 'AbsentManual.pdf'
    chunks[1]['page'] = 999
    chunks[1]['id'] = index_module._chunk_id(chunks[1]['corpus_fingerprint'],
                                           chunks[1]['source'], chunks[1]['page'],
                                           chunks[1]['ordinal'], chunks[1]['text_sha256'])
    (index / 'chunks.jsonl').write_bytes(b''.join(index_module.canonical_json_bytes(c)+b'\n' for c in chunks))
    manifest['files'] = [index_module._file_record(index / name, index)
                         for name in ('chunks.jsonl', 'embeddings.npy')]
    manifest['file_set_sha256'] = index_module._file_set_sha256(manifest['files'])
    index_module._atomic_write_json(index / 'manifest.json', manifest)
    index_module.switch_current(deployment, index)
    try:
        index_module.validate_index_against_lexical(index, lexical)
    except ValueError as exc:
        print('Independent lexical proof rejected:', str(exc))
    fresh = HybridRetriever(deployment_root=deployment, lexical_index=lexical,
                            model_path=model, encoder_factory=Encoder)
    answer = fresh.query('question', retrieval_mode='vector', limit=1)['results'][0]
    print(json.dumps({k: answer[k] for k in ('source', 'page', 'citation_integrity')}))
