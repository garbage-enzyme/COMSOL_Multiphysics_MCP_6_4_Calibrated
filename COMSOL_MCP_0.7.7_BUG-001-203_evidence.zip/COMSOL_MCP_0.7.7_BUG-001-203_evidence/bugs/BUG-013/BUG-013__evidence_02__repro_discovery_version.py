import tempfile
from pathlib import Path
from settings_gui.comsol_discovery import validate_comsol_root

with tempfile.TemporaryDirectory(prefix='comsol-metadata-', dir='/tmp') as directory:
    root = Path(directory)
    (root / 'bin/win64').mkdir(parents=True)
    for name in ('comsol.exe', 'comsolmphserver.exe'):
        (root / 'bin/win64' / name).touch()
    for name in ('plugins', 'apiplugins'):
        (root / name).mkdir()
    for metadata in ('COMSOL Multiphysics 6.3', 'unrelated application 6.4'):
        (root / 'bin/win64/comsol.ini').write_text(metadata)
        print('metadata:', metadata, 'accepted:', validate_comsol_root(root) == root)
