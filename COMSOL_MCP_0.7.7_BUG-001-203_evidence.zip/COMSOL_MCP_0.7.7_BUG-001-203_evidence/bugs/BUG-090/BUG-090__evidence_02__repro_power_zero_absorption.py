"""Valid lossless limiting case with nonzero normalization denominators."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_power_audit import _cross_section, _volume_loss
from comsol_mcp.evidence.power_audit import normalize_internal_absorption_consistency
cross, volume = _cross_section(), _volume_loss()
cross['value_m2'] = 0.0
volume['value_w'] = 0.0
print('positive_denominators', cross['unit_cell_area_m2'], volume['incident_power_w'])
try:
    print(normalize_internal_absorption_consistency(cross, volume))
except ValueError as exc:
    print('zero_absorption_rejected', str(exc))
