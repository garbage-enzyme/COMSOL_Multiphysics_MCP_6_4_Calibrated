from pathlib import Path
import tempfile
import tracemalloc
from comsol_mcp.settings_gui_handshake import MAX_HANDSHAKE_BYTES, read_handshake

with tempfile.TemporaryDirectory(prefix='mcp-review-handshake-', dir='/tmp') as directory:
    parent = Path(directory)/'settings_gui'
    parent.mkdir()
    path = parent / ('.settings-gui-'+'a'*32+'.json')
    size = 8 * 1024 * 1024
    with path.open('wb') as stream:
        stream.truncate(size)
    tracemalloc.start()
    result = read_handshake(path)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('declared byte bound:', MAX_HANDSHAKE_BYTES, 'file bytes:', size, 'allocated peak:', peak, 'result:', result)
