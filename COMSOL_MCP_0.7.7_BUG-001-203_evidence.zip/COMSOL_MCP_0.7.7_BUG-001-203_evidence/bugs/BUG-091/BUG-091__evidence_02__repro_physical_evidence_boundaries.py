"""Tiny, solver-free migration and strict-policy inputs."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.evidence.contracts import migrate_legacy_point_audit, evaluate_physical_evidence_policy, example_validation_policies, build_physical_evidence
from development_kit.tests.test_evidence_contracts import _envelope
planes = {}
for name, raw, sign in [('incident',-2.,-1),('reflected',.4,1),('transmitted',-1.2,-1)]:
    planes[name] = {'raw_power_w':raw, 'directed_power_w':raw*sign, 'positive_power_sign':sign,
                    'expression':name, 'selection_ids':[1]}
legacy = {'schema_version':'1', 'measurement':{
    'provenance':{'config_sha256':'a'*64, 'source_sha256_before':'b'*64},
    'declared_plane_flux':{'state':'derived_from_declared_convention', 'planes':planes,
                          'R':.2,'T':.6,'A':.2,'closure_abs':0.}}}
migrated = migrate_legacy_point_audit(legacy)
print('plane_metadata', list(planes['incident']))
print('migrated_convention', migrated['evidence']['flux.convention_complete'])
print('missing_convention_policy', evaluate_physical_evidence_policy(migrated, example_validation_policies()['declared_flux_closure'])['overall'])

evidence = _envelope()
evidence.pop('contract_sha256')
for field in ('wavelength.evaluated_parameter_m','wavelength.solved_frequency_m'):
    evidence['evidence'][field]['value'] = -1.
evidence = build_physical_evidence(evidence)
print('negative_wavelength_policy', evaluate_physical_evidence_policy(evidence, example_validation_policies()['wavelength_synchronization']))
