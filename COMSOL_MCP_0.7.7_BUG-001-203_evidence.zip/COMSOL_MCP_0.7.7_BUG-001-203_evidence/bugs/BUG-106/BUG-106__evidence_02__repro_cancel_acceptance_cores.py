import json
import sys
from pathlib import Path
from unittest.mock import patch

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
from development_kit.tests.integration import durable_cancel_acceptance as gate
import src.evidence.real_fixture as fixture
captured = {}
class ReviewStop(Exception): pass
class FakeManager:
    def __init__(self,*args,**kwargs): pass
    def submit(self,spec):
        captured.update(spec)
        raise ReviewStop
with patch.object(gate,'JobManager',FakeManager), \
     patch.object(fixture,'controlled_fixture_from_environment',
        return_value={'wavelength_um':4.25,'source':Path('/workspace/code-review/mock.mph')}), \
     patch.dict(gate.os.environ, {'COMSOL_MCP_ACCEPTANCE_CORES':'1',
        'COMSOL_MCP_RUNTIME_DIR':'/workspace/code-review/manual-gate'}):
    try: gate.main()
    except ReviewStop: pass
assert captured['cores'] == 14
print(json.dumps({'caller_requested_cores':1,'submitted_cores':captured['cores'],
    'native_started':False},indent=2))
