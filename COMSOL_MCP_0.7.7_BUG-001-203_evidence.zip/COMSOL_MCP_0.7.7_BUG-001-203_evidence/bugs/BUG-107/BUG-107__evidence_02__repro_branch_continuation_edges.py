import json
import runpy
import sys
from copy import deepcopy
from pathlib import Path

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
from comsol_mcp.evidence.branch_continuation import (
    build_continuation_states, plan_branch_continuation, validate_continuation_states)
fixture = runpy.run_path(str(repo/'development_kit/tests/test_branch_continuation.py'))
states = fixture['_multi_candidate_states'](include_later_state=True)
evidence = fixture['_measured_continuity_evidence'](states)
policy = fixture['_continuation_policy'](continuity_evidence=[evidence])
plan = plan_branch_continuation(states,policy)
flags = [t['branch_followed'] for t in plan['coordinate_transitions']]
assert flags == [True,False]
selected = evidence['selected_candidate_wavelength_m']
next_peak = states['states'][2]['candidate']['peak_wavelength_m']
assert abs(next_peak-selected) < policy['guard_window_m']

normal = build_continuation_states(states_id='normal', states=fixture['_build_dispersive_states'](2))
invalid = deepcopy(normal)
for state in invalid['states']:
    state['candidate']['fwhm_m'] = -1.0
    state['candidate']['quality_factor'] = -2.0
    state['state_sha256'] = fixture['_canonical_hash'](
        {k:v for k,v in state.items() if k != 'state_sha256'})
invalid['states_sha256'] = fixture['_canonical_hash'](
    {k:v for k,v in invalid.items() if k != 'states_sha256'})
validated = validate_continuation_states(invalid)
invalid_plan = plan_branch_continuation(validated,fixture['_continuation_policy']())
assert invalid_plan['scientific_disposition'] == 'accepted'
print(json.dumps({'resolved_multi_branch_followed_flags':flags,
    'later_peak_distance_m':abs(next_peak-selected),'guard_m':policy['guard_window_m'],
    'plan_disposition':plan['scientific_disposition'],
    'negative_width_quality_validated':validated['states'][0]['candidate'],
    'negative_width_quality_plan_disposition':invalid_plan['scientific_disposition']},indent=2))
