# BUG-008 修复辅助

复现原件和输出按编号保存。脚本可能覆盖多条问题；以问题正文所述段落/断言为准。
首次 replay 注入 repository PYTHONPATH，走了仓库 settings 路径，因此失败；repro_gui_first_run.log 是清空 PYTHONPATH 后对已安装包的正确复现。

位置和可能解决办法见本目录问题正文。完整冻结源码见 ../../common/source。
复制源码文件保持原始字节；其扁平文件名带 BUG 编号，原路径见索引。
运行环境与路径迁移见 ../../README.md；没有自动执行原生 COMSOL。

- bugs/BUG-008/BUG-008__evidence_01__repro_gui_first_run.replay.log
- bugs/BUG-008/BUG-008__evidence_02__repro_gui_first_run.log
- bugs/BUG-008/BUG-008__evidence_03__repro_gui_first_run.py
- bugs/BUG-008/BUG-008__source__comsol_mcp__settings_gui_launcher.py
- bugs/BUG-008/BUG-008__source__settings_gui__app.py
