from pathlib import Path
import tempfile
from comsol_mcp.settings_gui_launcher import launch_settings_gui

with tempfile.TemporaryDirectory(prefix='mcp-review-gui-', dir='/tmp') as directory:
    root = Path(directory)
    environment = {'HOME': str(root), 'XDG_CONFIG_HOME': str(root/'config'), 'XDG_STATE_HOME': str(root/'state'), 'XDG_DATA_HOME': str(root/'data')}
    launched = []
    def child(*args, **kwargs):
        launched.append(True)
        raise AssertionError('GUI child should not be reached in this reproduction')
    print('fresh-user result:', launch_settings_gui(environ=environment, runtime_dir=root/'runtime', popen_factory=child))
    print('child launched:', bool(launched))
    print('settings directory exists:', (root/'config/comsol-mcp').exists())
