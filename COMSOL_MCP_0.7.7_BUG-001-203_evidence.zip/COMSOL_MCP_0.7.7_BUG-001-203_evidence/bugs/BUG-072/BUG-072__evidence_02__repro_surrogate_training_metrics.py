"""Pure numerical/identity helpers; bounded inputs."""
import math, statistics, sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.surrogate.training import compute_metrics, evaluate_continuation, evaluate_seed_stability
from comsol_mcp.durable.canonical import canonical_json_v1
metrics = compute_metrics(predicted=[[float('nan')],[1.0]], actual=[[1.0],[1.0]], group_ids=['bad','ok'])
print('metrics_with_failure', metrics)
try:
    canonical_json_v1(metrics)
    print('metrics_canonical_serializable')
except ValueError as exc:
    print('metrics_canonical_rejected', str(exc))
seed_metrics = [{'rmse':1.0},{'rmse':3.0}]
result = evaluate_seed_stability(seed_metrics, maximum_spread_fraction=0.8)
print('seed_stability', result, 'independent_median', statistics.median([1.0,3.0]))
print('missing_identity_continuation', evaluate_continuation(prior={}, current={}))
