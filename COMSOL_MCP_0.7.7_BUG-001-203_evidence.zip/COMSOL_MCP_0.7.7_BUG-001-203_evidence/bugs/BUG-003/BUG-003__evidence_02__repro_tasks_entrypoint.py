import asyncio
import json
import os
import sys

async def check(label, command):
    environment = dict(os.environ)
    environment.update(COMSOL_MCP_RUNTIME_DIR='/workspace/code-review/runtime-tasks', COMSOL_MCP_PROFILE='core')
    child = await asyncio.create_subprocess_exec(*command, env=environment, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stderr = asyncio.create_task(child.stderr.read())
    message = {'jsonrpc':'2.0', 'id':1, 'method':'tasks/get', 'params': {'taskId':'review-nonexistent', '_meta': {'io.modelcontextprotocol/protocolVersion':'2026-07-28', 'io.modelcontextprotocol/clientCapabilities': {'extensions': {'io.modelcontextprotocol/tasks': {}}}}}}
    try:
        child.stdin.write((json.dumps(message)+'\n').encode())
        await child.stdin.drain()
        raw = await asyncio.wait_for(child.stdout.readline(), timeout=20)
        print(label, raw.decode().strip())
    finally:
        child.stdin.close()
        await child.stdin.wait_closed()
        try:
            await asyncio.wait_for(child.wait(), timeout=10)
        except TimeoutError:
            child.kill()
            await child.wait()
        await stderr

async def main():
    await check('installed-console', ['/workspace/.cloud-onboarding/venv/bin/comsol-mcp'])
    await check('create_server', [sys.executable, '-c', 'from comsol_mcp.server import create_server; create_server().run()'])

asyncio.run(main())
