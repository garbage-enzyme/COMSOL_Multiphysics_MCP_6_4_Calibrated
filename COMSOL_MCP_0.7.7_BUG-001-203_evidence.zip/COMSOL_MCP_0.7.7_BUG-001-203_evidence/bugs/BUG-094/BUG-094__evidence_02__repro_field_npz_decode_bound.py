"""A tiny compressed archive proves the shape check follows array materialization."""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_field_manifest import _manifest
from comsol_mcp.jobs.field_review import _verify_field_array
_, manifest = _manifest()
path = Path('/workspace/code-review/small-overshape.npz')
np.savez_compressed(path, coordinate_x=np.linspace(-.9,.9,96),
    coordinate_y=np.linspace(-1.4,1.4,128), quantity_electric_norm=np.zeros((256,256)),
    quantity_magnetic_norm=np.zeros((256,256)))
original = np.lib.npyio.NpzFile.__getitem__
observed = []
def tracked(self, key):
    array = original(self, key)
    observed.append((key,array.shape,array.nbytes))
    return array
np.lib.npyio.NpzFile.__getitem__ = tracked
try:
    _verify_field_array(path, manifest)
except ValueError as exc:
    print('rejection', str(exc))
finally:
    np.lib.npyio.NpzFile.__getitem__ = original
print('compressed_bytes', path.stat().st_size, 'expected_shape', manifest['grid']['shape'])
print('materialized_before_rejection', observed)
