"""Concurrent output publication before worker creation failure; no renderer needed."""
import hashlib
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.evidence.field_render import render_field_png_bundle

with tempfile.TemporaryDirectory(prefix='field-cleanup-', dir='/workspace/code-review') as temp:
    root = Path(temp)
    source = root / 'input.npz'
    source.write_bytes(b'worker-will-not-start')
    output_root = root / 'output'
    view_id = 'view-one'
    output = output_root / (hashlib.sha256(view_id.encode()).hexdigest()[:16] + '.png')
    def concurrent_publish_then_launch_fail(*args, **kwargs):
        output.write_bytes(b'concurrent-owner-output')
        raise OSError('bounded simulated process creation failure')
    with patch('comsol_mcp.evidence.field_render.subprocess.Popen', concurrent_publish_then_launch_fail):
        try:
            render_field_png_bundle(views=[{
                'view_id': view_id, 'array_path': str(source),
                'array_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'png_artifact_id': 'png-one',
            }], quantity_name='E', quantity_unit='V/m', coordinate_unit='m',
            color_scale='linear', shared_color_limits=False, output_root=output_root)
        except OSError:
            pass
    print('concurrently published output survived:', output.exists())
