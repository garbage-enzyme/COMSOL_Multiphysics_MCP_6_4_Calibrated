import hashlib
import json
import runpy
import sys
import types
from pathlib import Path
from unittest.mock import patch

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(repo))
from comsol_mcp.jobs.manager import validate_staged_sweep_spec
from comsol_mcp.jobs import worker
from comsol_mcp.jobs.store import JobStore
import comsol_mcp.tools.ownership as ownership
from comsol_mcp.tools.workflow import run_staged_parametric_sweep

root = Path('/workspace/code-review/staged-worker-edge')
root.mkdir(exist_ok=True)
source = root / 'source.mph'
source.write_bytes(b'original mock model')
raw = dict(job_type='staged_sweep', source_model_path=str(source), parameter_name='wl',
    parameter_values=[1.0], expressions=['A'])
malformed = validate_staged_sweep_spec(dict(raw, continue_on_error='false', smoke_points=True))
kwargs = worker._runner_kwargs(malformed, root)
assert kwargs['continue_on_error'] is True and malformed['smoke_points'] is True

spec = validate_staged_sweep_spec(raw)
source.write_bytes(b'changed mock model')
store = JobStore(root / 'jobs')
job_id = store.create(spec, {'schema_version':'2', 'status':'submitted', 'attempt':1,
    'progress':{'completed':0,'total':1}})
loads = []
class FakeOwnership:
    def __init__(self,*a,**kw): pass
    def preflight(self,**kw): return {'ready':True}
    def acquire(self,**kw): return {'success':True}
    def heartbeat(self,**kw): return True
    def release(self): return {'success':True}
class FakeClient:
    port = None
    def __init__(self,**kw): pass
    def load(self,path):
        loads.append(hashlib.sha256(Path(path).read_bytes()).hexdigest())
        raise RuntimeError('bounded review stop after mock load')
    def clear(self): pass
with patch.object(ownership,'SolverOwnership',FakeOwnership), \
     patch.dict(sys.modules, {'mph':types.SimpleNamespace(Client=FakeClient)}):
    code = worker.run(str(store.root), job_id)
assert loads and loads[0] != spec['source_model_sha256']

duplicate_spec = validate_staged_sweep_spec(dict(raw, parameter_values=[1.0,1.0]))
fixture = runpy.run_path(str(repo/'development_kit/tests/test_workflow.py'))
result = run_staged_parametric_sweep(fixture['FakeModel'](), 'wl', [1.0,1.0], ['A'],
    csv_path=str(root/'duplicates.csv'), config_id=duplicate_spec['spec_fingerprint'])
count = worker._valid_row_count(root/'duplicates.csv', duplicate_spec['spec_fingerprint'])
assert result['success'] and count == 1 and len(duplicate_spec['parameter_values']) == 2
print(json.dumps({'malformed_boolean':kwargs['continue_on_error'],
    'smoke_points_bool_accepted':malformed['smoke_points'],
    'source_hash_bound':spec['source_model_sha256'], 'source_hash_loaded':loads[0],
    'duplicate_points':{'declared':2,'unique_completed':count,'runner_success':result['success']}},indent=2))
