import tempfile
import tracemalloc
from pathlib import Path
from comsol_mcp.jobs.journal import locked_journal, recover_jsonl_tail

with tempfile.TemporaryDirectory(prefix='journal-bound-', dir='/tmp') as directory:
    journal = Path(directory) / 'rows.jsonl'
    with journal.open('wb') as stream:
        stream.truncate(8 * 1024 * 1024)
    with locked_journal(journal):
        tracemalloc.start()
        recover_jsonl_tail(journal, max_row_bytes=1024)
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    print('row byte limit:', 1024)
    print('allocated peak:', peak)
    print('remaining journal bytes:', journal.stat().st_size)
