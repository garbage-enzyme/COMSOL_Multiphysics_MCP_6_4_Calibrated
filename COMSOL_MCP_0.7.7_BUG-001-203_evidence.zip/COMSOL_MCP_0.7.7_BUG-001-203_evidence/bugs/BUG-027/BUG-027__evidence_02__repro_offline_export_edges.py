import copy
import hashlib
import json
import tempfile
import tracemalloc
from pathlib import Path
from comsol_mcp.durable import canonical_sha256_v1
from comsol_mcp.evidence.offline_export import build_offline_export_manifest, validate_offline_export_manifest
from comsol_mcp.path_policy import PathPolicy

with tempfile.TemporaryDirectory(prefix='offline-export-', dir='/tmp') as directory:
    root = Path(directory)
    policy = PathPolicy((), root)
    data = b'T[K],wl[nm]\n300,1000\n'
    (root / 'data.csv').write_bytes(data)
    manifest = build_offline_export_manifest(
        producer_tool='test', producer_version='0.7.7', model_path_redacted='**/model.mph',
        model_sha256='a' * 64,
        artifacts=[{'artifact_id': 'csv-1', 'relative_path': 'data.csv', 'format': 'csv',
                    'expressions': ['wl', 'T'], 'units': ['m', 'K'], 'parameter_values': {},
                    'time_values': None, 'byte_count': len(data),
                    'sha256': hashlib.sha256(data).hexdigest(),
                    'reader_status': 'offline_reader_available'}],
    )
    def validate(document):
        return validate_offline_export_manifest(document, root, path_policy=policy)
    print('CSV contradictory order/units accepted:', validate(manifest)['valid'])
    changed = copy.deepcopy(manifest)
    changed['unexpected_claim'] = 'not hashed by manifest seal'
    print('unknown top field accepted with original seal:', validate(changed)['valid'])
    changed = copy.deepcopy(manifest)
    changed['artifacts'][0]['parameter_values'] = False
    print('false parameters accepted with original seal:', validate(changed)['valid'])
    oversized = root / 'oversized.json'
    with oversized.open('wb') as stream:
        stream.truncate(8 * 1024 * 1024)
    tracemalloc.start()
    verdict = validate_offline_export_manifest(oversized, root, max_manifest_bytes=1024, path_policy=policy)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('manifest byte limit:', 1024, 'allocated peak:', peak)
    expected = canonical_sha256_v1({key: value for key, value in verdict.items() if key != 'validation_sha256'})
    print('rejection verdict seal matches returned body:', expected == verdict['validation_sha256'])
    print('rejection reason:', verdict['failures'][0]['reason_codes'])
