import json
import os
import tempfile
from pathlib import Path
from mcp.server.mcpserver import MCPServer
from comsol_mcp.knowledge.lexical_manual import build_index_from_records, register_lexical_manual_tools
from comsol_mcp.settings import LEXICAL_DOCS_INDEX_ENV

with tempfile.TemporaryDirectory(prefix='lexical-public-', dir='/tmp') as directory:
    index = Path(directory) / 'private-index.sqlite3'
    os.environ[LEXICAL_DOCS_INDEX_ENV] = str(index)
    server = MCPServer('lexical-public-repro')
    register_lexical_manual_tools(server)
    read = server._tool_manager._tools['manual_read_pages'].fn
    result = read('manual.pdf', [1])
    print('missing index error reveals configured path:', str(index) in result['error'])
    build_index_from_records([
        {'source': 'manual.pdf', 'module': 'manual', 'page': 1, 'text': 'x' * (2 * 1024 * 1024)}
    ], index)
    result = read('manual.pdf', [1])
    print('one-page response success:', result['success'])
    print('one-page text bytes:', len(result['pages'][0]['text'].encode()))
    print('response bytes:', len(json.dumps(result).encode()))
