from comsol_mcp.utils.immutability import deep_freeze

snapshot = deep_freeze({'empty': {}})
print('before:', snapshot)
snapshot['empty'].__init__({'changed': True})
print('after:', snapshot)
