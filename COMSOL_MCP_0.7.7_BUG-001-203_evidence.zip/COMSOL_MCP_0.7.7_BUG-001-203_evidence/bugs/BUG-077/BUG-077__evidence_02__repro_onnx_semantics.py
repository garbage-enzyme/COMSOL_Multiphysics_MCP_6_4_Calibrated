"""Decode bounded test protobufs through production loader, evaluate independently."""
import sys
from pathlib import Path
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_surrogate_onnx_runtime import _onnx, _node, _tensor, _ld, _f32
from comsol_mcp.surrogate.onnx_runtime import load_onnx_model, evaluate_onnx_model
import comsol_mcp.surrogate.onnx_runtime as runtime
root = Path('/workspace/code-review/onnx-repro'); root.mkdir(exist_ok=True)
def evaluate(name, nodes, tensors, point):
    path = root/name
    path.write_bytes(_onnx(nodes, tensors, ['input']))
    model = load_onnx_model(path)
    return evaluate_onnx_model(model, input_names=['x'], points=[[point]])
gemm = _node('Gemm', ['input','W','B'], ['output'])
for name, value in [('alpha',2.0),('beta',3.0)]:
    gemm += _ld(5, _ld(1,name.encode()) + _f32(2,value))
print('gemm_alpha_beta', evaluate('scaled.onnx',[gemm],[_tensor('W',[1,1],[4.0]),_tensor('B',[1],[5.0])],2.0),'expected',[[31.0]])
print('declared_output', evaluate('outputs.onnx',[_node('Identity',['input'],['output']),_node('Add',['output','bias'],['dead'])],[_tensor('bias',[1],[10.0])],2.0),'expected',[[2.0]])
try:
    print('sigmoid',evaluate('sigmoid.onnx',[_node('Sigmoid',['input'],['output'])],[],-1000.0))
except Exception as exc:
    print('sigmoid_finite_input_exception',type(exc).__name__,str(exc),'expected',[[0.0]])
count = 0
real_decode = runtime._decode_node
def measured_decode(payload):
    global count
    count += 1
    return real_decode(payload)
runtime._decode_node = measured_decode
path = root/'overcap.onnx'
path.write_bytes(_onnx([_node('Identity',['input'],['output'])]*(runtime.MAX_NODES+2),[],['input']))
try:
    load_onnx_model(path)
except ValueError as exc:
    print('node_cap',runtime.MAX_NODES,'decoded_before_refusal',count,'error',str(exc))
