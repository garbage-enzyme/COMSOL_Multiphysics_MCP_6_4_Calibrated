"""Real async handler + real operation guards, with a bounded fake study.run."""
import sys
import tempfile
import threading
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.async_handler.solver import AsyncSolver
from comsol_mcp.operation_arbiter import OperationArbiter, guard_tool_call
from comsol_mcp.tools.study import solve_study

entered = threading.Event()
finish = threading.Event()
class Study:
    def tags(self):
        return ['std1']
    def run(self):
        entered.set()
        assert finish.wait(5), 'fake solve was not released'
study = Study()
model = SimpleNamespace(java=SimpleNamespace(study=lambda *args: study), name=lambda: 'fake-model')
solver = AsyncSolver()
with tempfile.TemporaryDirectory(prefix='async-operation-', dir='/workspace/code-review') as root:
    arbiter = OperationArbiter(root)
    with patch('comsol_mcp.operation_arbiter.get_operation_arbiter', return_value=arbiter):
        launch = guard_tool_call(
            lambda: solve_study(model, wait=False, solver=solver),
            tool_name='study_solve', side_effect_class='solver_execution',
            concurrency_class='comsol_bound', profile_name='full')
        mutate = guard_tool_call(lambda: {'success': True, 'mutation_called': True},
            tool_name='param_set', side_effect_class='model_mutation',
            concurrency_class='comsol_bound', profile_name='full')
        try:
            launch_result = launch()
            assert entered.wait(2)
            print('background solve still running:', solver.is_running)
            print('operation lock during background solve:', arbiter.inspect()['state'])
            mutation_result = mutate()
            print('concurrent guarded mutation accepted:', mutation_result['success'])
            print('launch reports release verified:', launch_result['operation_gate']['release']['verified'])
        finally:
            finish.set()
            assert solver.wait(3)
