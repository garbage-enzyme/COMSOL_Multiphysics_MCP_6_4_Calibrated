import json
import runpy
import sys
import threading
from pathlib import Path
from unittest.mock import patch

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
from comsol_mcp.jobs.spectral_characterization import (
    normalize_spectral_characterization_job_spec, _SPECTRAL_CHARACTERIZATION_INPUT_FIELDS)
from comsol_mcp.jobs.spectral_runner import run_spectral_characterization
from comsol_mcp.jobs.spectral_worker import _run
from comsol_mcp.jobs.store import JobStore,atomic_write_json,process_identity
from comsol_mcp.jobs import native_cancel_probe
fixture = runpy.run_path(str(repo/'development_kit/tests/test_spectral_worker.py'))
root = Path('/workspace/code-review/spectral-worker-edges')
root.mkdir(exist_ok=True)

source_dir = root/'retry-source'
source_dir.mkdir(exist_ok=True)
base = fixture['spectral_job_spec'](source_dir)
raw = {k:v for k,v in base.items() if k in _SPECTRAL_CHARACTERIZATION_INPUT_FIELDS}
spec = normalize_spectral_characterization_job_spec(dict(raw,max_retries=3,continue_on_error=True))
calls = []
def fail(point,directory):
    calls.append(point['point_fingerprint'])
    raise RuntimeError('review injected transient collector error')
try:
    run_spectral_characterization(spec,root/'retry-run',attempt=1,point_executor=fail)
except RuntimeError: pass
assert len(calls) == 1

startup = root/'startup-source'
startup.mkdir(exist_ok=True)
store,basespec,job = fixture['_created_job'](startup,root/'startup')
basespec['driver_identity']['package_content_sha256'] = '0'*64
atomic_write_json(store.job_dir(job)/'spec.json',basespec)
startup_error = None
try: _run(str(store.root),job,native_cancel_enabled=False)
except ValueError as exc: startup_error = str(exc)
stale = store.read_state(job)
assert startup_error and stale['status'] == 'submitted' and stale['last_error'] is None

native_source = root/'native-source'
native_source.mkdir(exist_ok=True)
store2,spec2,job2 = fixture['_created_job'](native_source,root/'native')
native_started = threading.Event()
native_release = threading.Event()
native_done = threading.Event()
actions = []
def blocked_native():
    native_started.set()
    try: native_release.wait(timeout=8)
    finally: native_done.set()
    return {'attempted':True,'outcome':'review mock'}
class Client(fixture['_Client']):
    def clear(self):
        actions.append({'action':'client.clear','native_call_active':not native_done.is_set()})
        super().clear()
class Ownership(fixture['_Ownership']):
    def release(self):
        actions.append({'action':'ownership.release','native_call_active':not native_done.is_set()})
        return super().release()
def collect(point,collector,directory):
    result = fixture['write_fake_point_audit'](directory,spec2,point,absorption=0.5)
    store2.request_cancel(job2,requester_identity=process_identity(__import__('os').getpid()))
    assert native_started.wait(timeout=3)
    return result
try:
    with patch.object(native_cancel_probe,'request_native_cancel_once',blocked_native):
        code = _run(str(store2.root),job2,ownership_factory=lambda *a:Ownership(),
            client_factory=lambda s:Client(spec2['source_model_path']),collector_executor=collect,
            telemetry_provider=fixture['_telemetry'],native_cancel_enabled=True)
finally:
    native_release.set()
    assert native_done.wait(timeout=3)
assert len(actions) == 2 and all(a['native_call_active'] for a in actions)
print(json.dumps({'ignored_retry_and_continue':{'max_retries':3,'continue_on_error':True,
    'collector_calls_before_raise':len(calls)},'startup_failure':{'error':startup_error,
    'stored_status':stale['status'],'stored_last_error':stale['last_error']},
    'cleanup_during_native_cancel':{'return':code,'actions':actions},'real_native_started':False},indent=2))
