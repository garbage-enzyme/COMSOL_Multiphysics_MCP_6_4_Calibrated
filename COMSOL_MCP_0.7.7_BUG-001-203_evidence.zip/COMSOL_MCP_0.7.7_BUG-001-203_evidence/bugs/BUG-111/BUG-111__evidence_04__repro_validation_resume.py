import json
import runpy
import sys
from pathlib import Path

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(repo))
fixture = runpy.run_path(str(repo/'development_kit/tests/test_validation_runner.py'))
from comsol_mcp.jobs.validation_matrix import normalize_validation_matrix_spec
from comsol_mcp.jobs.validation_rows import read_validation_rows
from comsol_mcp.jobs.validation_runner import run_pending_validation_points

root = Path('/workspace/code-review/validation-resume')
root.mkdir(exist_ok=True)
base = fixture['_spec'](root)
raw = {k:v for k,v in base.items() if k not in {'schema_version','source_model_sha256','spec_fingerprint'}}
raw['points'] = [{k:v for k,v in point.items() if k != 'point_fingerprint'} for point in base['points']]
spec = normalize_validation_matrix_spec(dict(raw,max_retries=3))
directory = root/'job'
journal = directory/'matrix_rows.jsonl'
journal.unlink(missing_ok=True)
first = run_pending_validation_points(spec,directory,attempt=1,collector_executor=fixture['_complete_executor'])
rows = read_validation_rows(journal,spec)
for row in rows:
    for summary in row['collector_summaries']:
        (directory/summary['manifest_relative_path']).unlink()
calls = []
def unexpected(*args):
    calls.append('called')
    raise RuntimeError('missing evidence should not be skipped')
resume = run_pending_validation_points(spec,directory,attempt=2,collector_executor=unexpected)
assert resume['success'] and resume['remaining'] == 0 and not calls
retry_dir = root/'retry'
(retry_dir/'matrix_rows.jsonl').unlink(missing_ok=True)
failed = run_pending_validation_points(spec,retry_dir,attempt=1,collector_executor=unexpected)
assert len(calls) == 1 and failed['errors'] == 1
print(json.dumps({'missing_artifacts_resume':resume,'accepted_max_retries':spec['max_retries'],
    'transient_failure_collector_calls':len(calls), 'real_solver_started':False},indent=2))
