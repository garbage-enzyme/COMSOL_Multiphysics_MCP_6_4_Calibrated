# BUG-111 修复辅助

复现原件和输出按编号保存。脚本可能覆盖多条问题；以问题正文所述段落/断言为准。

位置和可能解决办法见本目录问题正文。完整冻结源码见 ../../common/source。
复制源码文件保持原始字节；其扁平文件名带 BUG 编号，原路径见索引。
运行环境与路径迁移见 ../../README.md；没有自动执行原生 COMSOL。

- bugs/BUG-111/BUG-111__evidence_01__repro_spectral_worker_edges.replay.log
- bugs/BUG-111/BUG-111__evidence_02__repro_validation_resume.replay.log
- bugs/BUG-111/BUG-111__evidence_03__repro_spectral_worker_edges.py
- bugs/BUG-111/BUG-111__evidence_04__repro_validation_resume.py
- bugs/BUG-111/BUG-111__source__comsol_mcp__jobs__spectral_characterization.py
- bugs/BUG-111/BUG-111__source__comsol_mcp__jobs__spectral_runner.py
- bugs/BUG-111/BUG-111__source__comsol_mcp__jobs__spectral_worker.py
