from pathlib import Path
import os
import tempfile
from comsol_mcp.settings import MAX_SETTINGS_BYTES
from settings_gui.storage import SettingsStore

with tempfile.TemporaryDirectory(prefix='mcp-review-settings-', dir='/tmp') as directory:
    root = Path(directory)
    target = root / 'settings.json'
    target.write_bytes(b'a' * (MAX_SETTINGS_BYTES+1))
    with SettingsStore(target) as store:
        external = root / 'external.json'
        foreign = b'b' * (MAX_SETTINGS_BYTES+1)
        external.write_bytes(foreign)
        os.replace(external, target)
        try:
            store.rebuild()
            print('rebuild succeeded despite persistent external replacement')
            print('external target preserved:', target.read_bytes() == foreign)
            print('external bytes moved to backup:', any(p.read_bytes() == foreign for p in root.glob('*.damaged-*.json')))
        except Exception as exc:
            print(type(exc).__name__, str(exc))
