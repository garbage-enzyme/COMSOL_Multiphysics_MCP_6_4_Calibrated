"""Small pure-Python boundary probes; no native runtime or repository writes."""
import copy
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.durable.canonical import canonical_sha256_v1
from comsol_mcp.surrogate.splits import assign_group_disjoint_split, validate_split_plan, detect_leakage
from comsol_mcp.surrogate.rows import build_row_provenance, validate_row_provenance, summarize_row_ledger
from comsol_mcp.surrogate.manifests import build_schema_manifest, validate_schema_manifest, build_training_transforms, validate_training_transforms
from comsol_mcp.surrogate.fields import verify_transform_roundtrip

def reseal(value, key='manifest_sha256'):
    value[key] = canonical_sha256_v1({k:v for k,v in value.items() if k != key})
    return value

split = assign_group_disjoint_split(group_ids=['g1','g2','g3'], seed=3)
old = split['manifest_sha256']
split['group_counts'] = {'train':99999,'validation':-1,'test':'invalid'}
print('tampered_counts_accepted', validate_split_plan(split)['group_counts'], 'unchanged_digest', old == split['manifest_sha256'])
print('reported_checks', detect_leakage(assignments={'g1':'train'}, group_members={'g1':['r1']})['classes_checked'])

row = build_row_provenance(row_id='r1', candidate_id='c1', source_model_sha256='a'*64,
    solver_identity_sha256='b'*64, study_identity='s1', solution_identity='sol1',
    dataset_identity='d1', fidelity='FEM', evidence_state='verified', features={'x':1.},
    targets={'y':2.}, leakage_group_id='g1')
row.update(evidence_state='unknown', eligible=1, source_model_sha256='', study_identity='', features={})
reseal(row, 'row_sha256')
print('unknown_row_accepted', validate_row_provenance(row)['eligible'])
print('unknown_row_summary', summarize_row_ledger([row]))

schema = build_schema_manifest(schema_id='s', feature_names=['x1','x2'], target_names=['y'])
schema['feature_names'] = ['x1','x1']
reseal(schema)
print('duplicate_features_accepted', validate_schema_manifest(schema)['feature_names'])
transforms = build_training_transforms(transform_id='t', transforms=[{'kind':'standardize','columns':['x1']}])
transforms['transforms'] = [{'kind':'standardize','columns':[], 'arbitrary':True}]
reseal(transforms)
print('invalid_transform_accepted', validate_training_transforms(transforms)['transforms'])

fitted = reseal({'schema':'comsol_mcp.surrogate_fitted_transforms', 'schema_version':'1.0.0',
    'transform_id':'t', 'field_schema_sha256':'a'*64, 'fit_split':'train', 'fit_row_count':2,
    'transforms':[{'field_id':'x','kind':'minmax','low':-1e308,'high':1e308}]})
print('nonfinite_roundtrip', verify_transform_roundtrip(fitted, [{'x':-1e308}]))
print('empty_invalid_roundtrip', verify_transform_roundtrip({}, []))
