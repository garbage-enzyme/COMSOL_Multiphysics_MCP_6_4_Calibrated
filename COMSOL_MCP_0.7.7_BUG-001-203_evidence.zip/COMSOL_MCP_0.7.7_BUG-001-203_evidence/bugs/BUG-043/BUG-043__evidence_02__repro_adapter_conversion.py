"""Bounded numeric-conversion checks without Java or MPh."""
import sys
from collections.abc import Sequence
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.adapter.conversion import MAX_MATRIX_ELEMENTS, convert_explicitly
from comsol_mcp.adapter.protocol import AdapterError

class CountingRow(Sequence):
    reads = 0
    def __len__(self):
        return MAX_MATRIX_ELEMENTS + 1
    def __getitem__(self, index):
        if index >= len(self):
            raise IndexError(index)
        self.reads += 1
        return 1

row = CountingRow()
try:
    convert_explicitly([row], form='int_matrix')
except AdapterError as exc:
    print('oversize matrix rejected:', str(exc))
print('cells materialized before rejection:', row.reads)
value = 2**53 + 1
converted = convert_explicitly(value, form='float')
print('integer before float conversion:', value)
print('conversion changed numeric value:', converted.value != value)
try:
    convert_explicitly(10**400, form='float')
except Exception as exc:
    print('overflow raised stable AdapterError:', isinstance(exc, AdapterError))
    print('overflow exception type:', type(exc).__name__)
