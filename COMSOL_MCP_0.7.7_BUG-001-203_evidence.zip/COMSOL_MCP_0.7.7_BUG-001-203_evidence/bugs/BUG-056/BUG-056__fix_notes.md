# BUG-056 修复辅助

复现原件和输出按编号保存。脚本可能覆盖多条问题；以问题正文所述段落/断言为准。

位置和可能解决办法见本目录问题正文。完整冻结源码见 ../../common/source。
复制源码文件保持原始字节；其扁平文件名带 BUG 编号，原路径见索引。
运行环境与路径迁移见 ../../README.md；没有自动执行原生 COMSOL。

- bugs/BUG-056/BUG-056__evidence_01__repro_embedded_guide.replay.log
- bugs/BUG-056/BUG-056__evidence_02__repro_embedded_guide.py
- bugs/BUG-056/BUG-056__source__comsol_mcp__knowledge__embedded.py
