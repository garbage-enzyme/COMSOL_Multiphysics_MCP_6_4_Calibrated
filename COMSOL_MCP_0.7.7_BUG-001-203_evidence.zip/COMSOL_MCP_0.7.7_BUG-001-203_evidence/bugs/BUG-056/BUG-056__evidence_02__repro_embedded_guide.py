import ast
import json
import sys
from pathlib import Path
root = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(root))
from comsol_mcp.knowledge.embedded import get_physics_guide
guide = get_physics_guide('electrostatics')
functions = {node.name for node in ast.walk(ast.parse((root / 'comsol_mcp/tools/physics.py').read_text()))
             if isinstance(node, ast.FunctionDef)}
name = guide['guide']['tool_to_add']
print(json.dumps({'success': guide['success'], 'recommended': name,
                  'recommended_function_exists': name in functions,
                  'actual_function_exists': 'physics_add_electrostatics' in functions}))
