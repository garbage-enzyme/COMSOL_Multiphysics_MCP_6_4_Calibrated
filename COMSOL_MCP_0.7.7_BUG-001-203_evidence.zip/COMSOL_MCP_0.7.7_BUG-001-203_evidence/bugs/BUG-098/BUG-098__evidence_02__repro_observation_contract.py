"""Small process identity and stored receipt probes; no process actions."""
import json
import sys
from pathlib import Path
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.jobs.observation import verify_exact_ownership, summarize_observation
from comsol_mcp.durable import canonical_sha256_v1
expected={'pid':100,'process_create_time':100.,'executable':'/fake/executable',
          'command_signature':'a'*64,'target_files':['/model/expected.mph']}
observed = {k:v for k,v in expected.items() if k != 'target_files'}
print('missing_targets_ownership', verify_exact_ownership(expected, observed))
observed['target_files'] = ['/model/other.mph']
print('changed_targets_ownership', verify_exact_ownership(expected, observed))
root = Path('/workspace/code-review/observation-invalid')
root.mkdir(exist_ok=True)
payload={'job_id':'fake','attempt':True,'observer_outcome':'solver_terminal',
    'reason_codes':[],'terminal_state':'running','cleanup_outcome':'invented',
    'resume_disposition':'magical'}
payload['receipt_sha256']=canonical_sha256_v1(payload)
(root/'observation.json').write_text(json.dumps(payload),encoding='utf-8')
print('invalid_receipt_summary', summarize_observation(root,expected_job_id='fake',expected_attempt=1))
