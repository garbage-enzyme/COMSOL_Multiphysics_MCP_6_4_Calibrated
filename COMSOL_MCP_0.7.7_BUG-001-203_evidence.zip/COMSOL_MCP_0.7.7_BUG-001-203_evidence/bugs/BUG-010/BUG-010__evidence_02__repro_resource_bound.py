import asyncio
from mcp.server.mcpserver import MCPServer
from comsol_mcp.resources import model_resources

class Model:
    def name(self):
        return 'bounded-test'
    def parameters(self):
        return {'p': 'x' * (2 * 1024 * 1024)}
    def descriptions(self):
        return {}

model_resources.session_manager.get_model = lambda name: Model()
server = MCPServer('resource-bound-repro')
model_resources.register_model_resources(server)
async def main():
    contents = await server.read_resource('comsol://model/test/parameters')
    text = ''.join(item.content for item in contents)
    print('response_bytes:', len(text.encode()))
    print('complete_value_included:', 'x' * (2 * 1024 * 1024) in text)
asyncio.run(main())
