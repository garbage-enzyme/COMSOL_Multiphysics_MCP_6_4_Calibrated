import json
import tempfile
from pathlib import Path
from comsol_mcp.evidence.inspection import probe

with tempfile.TemporaryDirectory(prefix='probe-cache-', dir='/tmp') as directory:
    root = Path(directory)
    job = root / 'job'
    job.mkdir()
    cache = job / probe.MPH_ARTIFACT_PROBE_CACHE_FILENAME
    cache.write_text(json.dumps({'file_fingerprints': [], 'probe': 1}))
    try:
        probe.probe_mph_artifacts(job)
    except Exception as error:
        print('malformed cache escaped:', type(error).__name__)
    cache.unlink()
    for index in range(5):
        (job / f'{index}.mph').write_bytes(b'not-a-zip')
    first = probe.probe_mph_artifacts(job)
    second = probe.probe_mph_artifacts(job)
    print('five-file unchanged cache states:', first['cache']['status'], second['cache']['status'])
    cache.unlink()
    victim = root / 'outside-job.txt'
    victim.write_text('user document to preserve')
    cache.symlink_to(victim)
    result = probe.probe_mph_artifacts(job)
    print('external symlink target overwritten:', victim.read_text() != 'user document to preserve')
    print('probe returned available:', result['available'])
