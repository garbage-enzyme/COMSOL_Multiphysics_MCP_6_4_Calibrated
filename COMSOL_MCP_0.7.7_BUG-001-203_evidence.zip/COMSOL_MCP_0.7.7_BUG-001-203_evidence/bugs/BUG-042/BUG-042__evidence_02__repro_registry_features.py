"""Compare real server startup selection with its compatibility registry."""
import os
import sys
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.server import create_server
from comsol_mcp.tools.profiles import resolve_profile

with patch.dict(os.environ, {'COMSOL_MCP_ENABLE_MODEL_MANAGER': 'true'}):
    server = create_server(profile='core')
    result = server._tool_manager._tools['runtime_compatibility_status'].fn()
    print('startup features:', resolve_profile('core').enabled_features)
    print('registry features:', result['registry']['profile']['enabled_features'])
    print('model_manager present in registry:',
          'model_manager' in result['registry']['profile']['enabled_features'])
