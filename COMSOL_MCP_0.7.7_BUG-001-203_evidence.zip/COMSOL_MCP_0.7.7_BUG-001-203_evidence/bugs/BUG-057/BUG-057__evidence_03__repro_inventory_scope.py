import json
import sys
import tempfile
from pathlib import Path
root = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(root))
from comsol_mcp.adapter.migration_inventory import measure_module_sites, measure_repository, inventory_status
relative = 'development_kit/tests/integration/wave_optics_preflight_acceptance.py'
single = measure_module_sites((root / relative).read_text())
print(json.dumps({'real_module_direct_sites': sum(single.values()),
                  'real_module_in_repository_measurement': relative in measure_repository(root)}))
with tempfile.TemporaryDirectory(dir='/workspace/code-review', prefix='inventory-') as temp:
    path = Path(temp) / 'development_kit/tests/integration/probe.py'
    path.parent.mkdir(parents=True)
    path.write_text('import mph\nmodel.java.study().run()\n')
    status = inventory_status(Path(temp), inventory=())
    print(json.dumps({'synthetic_direct_sites': sum(measure_module_sites(path.read_text()).values()),
                      'measured_modules': status['measured_module_count'],
                      'missing_disposition_violations': status['violations']}))
