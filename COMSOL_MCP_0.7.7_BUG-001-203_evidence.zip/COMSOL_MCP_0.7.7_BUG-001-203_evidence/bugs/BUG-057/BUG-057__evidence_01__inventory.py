import csv
import hashlib
from pathlib import Path
import subprocess

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
target = Path('/workspace/code-review/file-inventory.tsv')
paths = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '-z']).decode().split('\0')
old = {}
if target.exists():
    with target.open() as stream:
        old = {row['path']: row for row in csv.DictReader(stream, delimiter='\t')}
with target.open('w') as stream:
    fields = ['path', 'bytes', 'lines', 'sha256', 'status', 'notes']
    writer = csv.DictWriter(stream, fields, delimiter='\t')
    writer.writeheader()
    for name in filter(None, paths):
        data = (repo / name).read_bytes()
        try:
            content = data.decode('utf-8')
            lines = len(content.splitlines())
        except UnicodeDecodeError:
            lines = 'binary'
        row = dict(path=name, bytes=len(data), lines=lines, sha256=hashlib.sha256(data).hexdigest(), status='pending', notes='')
        if name in old and old[name]['sha256'] == row['sha256']:
            row.update(status=old[name]['status'], notes=old[name]['notes'])
        writer.writerow(row)
print(f'{len(list(filter(None, paths)))} tracked files inventoried')
