"""Accepted artifact preservation across a partial journal tail and next append."""
import sys
import tempfile
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.durable.operation_ledger import OperationLedger

with tempfile.TemporaryDirectory(prefix='ledger-recovery-', dir='/workspace/code-review') as root:
    ledger = OperationLedger(root)
    common = dict(family='dbmodel', operation='download', owner='owner-one', outcome='succeeded')
    digest = 'a' * 64
    ledger.append(subject='artifact-one', artifact_sha256=digest, **common)
    print('initial acceptance:', ledger.evaluate_acceptance(subject='artifact-one', artifact_sha256=digest))
    with ledger.journal_path.open('ab') as stream:
        stream.write(b'{"partial":')
    print('partial journal state:', ledger.journal_state)
    ledger.append(subject='artifact-two', artifact_sha256='b' * 64, **common)
    restarted = OperationLedger(root)
    print('journal after append:', restarted.journal_state)
    print('replayed rows after append:', len(restarted.rows()))
    print('previous accepted artifact now:', restarted.evaluate_acceptance(subject='artifact-one', artifact_sha256=digest))
    print('previous terminal subject now:', restarted.evaluate_resume(subject='artifact-one'))
