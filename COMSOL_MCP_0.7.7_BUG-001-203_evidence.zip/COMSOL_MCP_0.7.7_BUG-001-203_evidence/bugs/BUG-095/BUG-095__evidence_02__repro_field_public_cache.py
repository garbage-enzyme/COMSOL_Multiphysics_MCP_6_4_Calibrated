"""Public extraction with repository dataset fake; artifacts stay in audit dir."""
import copy
import hashlib
import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_field_tools import _tool, _extraction_request
from development_kit.tests.test_field_dataset import _Model
from comsol_mcp.tools import field_evidence as fe
from comsol_mcp.evidence.field_bundle import normalize_field_evidence_request
root = Path('/workspace/code-review/field-public-cache')
root.mkdir(exist_ok=True)
source = root/'fixture.mph'
source.write_bytes(b'fake-source-only')
raw = _extraction_request(source)
other = copy.deepcopy(raw['views'][0])
other['view_id'] = 'off'
other['source']['solution_number'] = 2
other['outputs'] = {'array_artifact_id':'field-off-npz','manifest_artifact_id':'field-off-manifest'}
raw['views'].append(other)
request = normalize_field_evidence_request(raw)
model = _Model()
model.file = lambda: str(source)
with patch.object(fe.session_manager,'preflight_long_operation',return_value={'ready':True}), \
     patch.object(fe.session_manager,'get_model',return_value=model), \
     patch.object(fe.ownership_manager,'runtime_dir',root/'runtime'):
    extract = _tool('wave_optics_field_extract')
    first = extract(model_name='fake',request=request,view_id='on')
    second = extract(model_name='fake',request=request,view_id='off')
print('first', first['success'], 'evaluations', len(model.calls))
print('second', second)
artifact_root = root/'runtime'/'field_evidence'/request['request_fingerprint']
print('off_view_directory_exists', (artifact_root/request['views'][1]['view_fingerprint']).exists())
