import tempfile
import tracemalloc
import zipfile
from pathlib import Path
from comsol_mcp.contracts.mph_inspection import MphInspectionLimits
from comsol_mcp.evidence.inspection.archive import inspect_archive_inventory, MphInspectionError

with tempfile.TemporaryDirectory(prefix='mph-entries-', dir='/tmp') as directory:
    path = Path(directory) / 'many.mph'
    with zipfile.ZipFile(path, 'w') as archive:
        for index in range(20000):
            archive.writestr(f'entry{index:05d}', b'')
    tracemalloc.start()
    try:
        inspect_archive_inventory(path, MphInspectionLimits(max_entries=1))
    except MphInspectionError as error:
        print('reason:', error.reason_code)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('configured entry limit:', 1)
    print('archive bytes:', path.stat().st_size)
    print('allocated peak:', peak)
