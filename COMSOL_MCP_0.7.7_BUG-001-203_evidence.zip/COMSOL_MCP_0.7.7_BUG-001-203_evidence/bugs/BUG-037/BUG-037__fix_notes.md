# BUG-037 修复辅助

本条依据源代码/文档对照或现存测试日志确认；没有声称提供单独原生复现。

位置和可能解决办法见本目录问题正文。完整冻结源码见 ../../common/source。
复制源码文件保持原始字节；其扁平文件名带 BUG 编号，原路径见索引。
运行环境与路径迁移见 ../../README.md；没有自动执行原生 COMSOL。

- bugs/BUG-037/BUG-037__source__README.md
- bugs/BUG-037/BUG-037__source__comsol_mcp__tools__catalog.py
- bugs/BUG-037/BUG-037__source__docs__evidence_integrity__README.md
