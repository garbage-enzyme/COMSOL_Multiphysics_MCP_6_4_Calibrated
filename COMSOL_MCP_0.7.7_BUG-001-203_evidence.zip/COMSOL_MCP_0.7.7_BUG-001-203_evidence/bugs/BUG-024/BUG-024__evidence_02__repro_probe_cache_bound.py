import tempfile
import tracemalloc
from pathlib import Path
from comsol_mcp.evidence.inspection.probe import probe_mph_artifacts, MPH_ARTIFACT_PROBE_CACHE_FILENAME

with tempfile.TemporaryDirectory(prefix='probe-bound-', dir='/tmp') as directory:
    cache = Path(directory) / MPH_ARTIFACT_PROBE_CACHE_FILENAME
    with cache.open('wb') as stream:
        stream.truncate(8 * 1024 * 1024)
    tracemalloc.start()
    result = probe_mph_artifacts(directory)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('cache byte limit:', 262144)
    print('allocated peak:', peak)
    print('probe available:', result['available'])
