# BUG-109 修复辅助

复现原件和输出按编号保存。脚本可能覆盖多条问题；以问题正文所述段落/断言为准。

位置和可能解决办法见本目录问题正文。完整冻结源码见 ../../common/source。
复制源码文件保持原始字节；其扁平文件名带 BUG 编号，原路径见索引。
运行环境与路径迁移见 ../../README.md；没有自动执行原生 COMSOL。

- bugs/BUG-109/BUG-109__evidence_01__repro_campaign_resources_progress.replay.log
- bugs/BUG-109/BUG-109__evidence_02__repro_convergence_campaign_edges.replay.log
- bugs/BUG-109/BUG-109__evidence_03__repro_campaign_resources_progress.py
- bugs/BUG-109/BUG-109__evidence_04__repro_convergence_campaign_edges.py
- bugs/BUG-109/BUG-109__source__comsol_mcp__jobs__branch_continuation_campaign.py
- bugs/BUG-109/BUG-109__source__comsol_mcp__jobs__resource_admission.py
- bugs/BUG-109/BUG-109__source__comsol_mcp__jobs__spectral_level_execution.py
