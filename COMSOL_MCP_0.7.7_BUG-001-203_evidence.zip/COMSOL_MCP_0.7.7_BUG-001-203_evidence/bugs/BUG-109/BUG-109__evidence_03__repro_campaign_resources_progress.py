import json
import runpy
import sys
import time
from pathlib import Path
from unittest.mock import patch

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
from comsol_mcp.jobs.branch_continuation_campaign import normalize_branch_continuation_campaign_spec
from comsol_mcp.jobs.branch_continuation_campaign_worker import _run
from comsol_mcp.jobs.spectral_rows import read_spectral_rows
from comsol_mcp.jobs.store import JobStore
fixture = runpy.run_path(str(repo/'development_kit/tests/test_branch_continuation_campaign_worker.py'))
campaign_fixture = runpy.run_path(str(repo/'development_kit/tests/test_branch_continuation_campaign_job.py'))
root = Path('/workspace/code-review/campaign-resource-progress')
root.mkdir(exist_ok=True)

raw = campaign_fixture['_raw_campaign'](root/'different-policy/sources')
for child in raw['states']:
    child['spectral_job']['measurement_configuration']['peak_method'] = 'quadratic_interpolation'
    child['spectral_job']['refinement_policy']['peak_shift_abs_tolerance_m'] = 1e-6
raw['states'][1]['spectral_job']['resource_policy'] = {
    **raw['states'][1]['spectral_job']['resource_policy']['rules'], 'max_mesh_elements':2000}
spec = normalize_branch_continuation_campaign_spec(raw)
store = JobStore(root/'different-policy/runtime/jobs')
job_id = store.create(spec, {'status':'submitted','attempt':1,
    'progress':{'completed':0,'total':spec['maximum_total_points']}})
client = fixture['_Client']()
args = dict(ownership_factory=lambda *a:fixture['_Ownership'](), client_factory=lambda s:client,
    collector_executor=fixture['_collector_for'](spec),telemetry_provider=fixture['_telemetry'],
    native_cancel_enabled=False)
code = _run(str(store.root),job_id,**args)
state = store.read_state(job_id)
assert code == 1 and 'policy does not match' in state['last_error']['message']

store2,spec2,job2 = fixture['_created_job'](root/'projection/sources',root/'projection/work')
original = JobStore.update_state
faulted = [False]
projection_calls = [0]
def fail_once(self,*a,**kw):
    if kw.get('event') == 'durable_spectral_point':
        projection_calls[0] += 1
    if kw.get('event') == 'durable_spectral_point' and projection_calls[0] == 3:
        faulted[0] = True
        raise OSError('review injected failure after raw row before progress projection')
    return original(self,*a,**kw)
collector_calls = []
original_collector = fixture['_collector_for'](spec2)
def tracked_collector(point,collector,directory):
    collector_calls.append(point['point_fingerprint'])
    return original_collector(point,collector,directory)
common = dict(ownership_factory=lambda *a:fixture['_Ownership'](),
    client_factory=lambda s:fixture['_Client'](),
    collector_executor=tracked_collector,
    telemetry_provider=fixture['_telemetry'], native_cancel_enabled=False)
with patch.object(JobStore,'update_state',fail_once):
    first = _run(str(store2.root),job2,**common)
assert first == 1 and faulted[0]
store2.update_state(job2,'starting',patch={'attempt':2,'last_error':None})
second = _run(str(store2.root),job2,**common)
final = store2.read_state(job2)
actual = sum(len(read_spectral_rows(store2.job_dir(job2)/f's{state["ordinal"]}'/'spectral_rows.jsonl',
    state['spectral_job'],artifact_root=store2.job_dir(job2)/f's{state["ordinal"]}'))
    for state in spec2['states'])
assert second == 0 and final['status'] == 'completed'
assert final['progress']['completed'] == actual+2
assert len(collector_calls) == actual+3
print(json.dumps({'different_child_policy':{'return':code,'status':state['status'],
    'error':state['last_error'],'client_loads':len(client.loaded)},
    'durable_row_projection_gap':{'first_return':first,'resume_return':second,
    'status':final['status'],'projected_progress':final['progress'],
    'verified_durable_points':actual,'total_collector_calls':len(collector_calls),
    'recomputed_verified_points':len(collector_calls)-len(set(collector_calls))},'native_started':False},indent=2))
