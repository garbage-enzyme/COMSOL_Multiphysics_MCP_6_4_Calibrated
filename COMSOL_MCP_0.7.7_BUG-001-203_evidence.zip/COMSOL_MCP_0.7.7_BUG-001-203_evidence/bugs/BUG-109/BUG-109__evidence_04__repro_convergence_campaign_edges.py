import json
import runpy
import sys
from pathlib import Path
from unittest.mock import patch

repo=Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
fixture=runpy.run_path(str(repo/'development_kit/tests/test_convergence_campaign_worker.py'))
campaign=runpy.run_path(str(repo/'development_kit/tests/test_convergence_campaign_job.py'))
from comsol_mcp.jobs.convergence_campaign import normalize_convergence_campaign_spec
from comsol_mcp.jobs.convergence_campaign_worker import _run
from comsol_mcp.jobs.convergence_campaign_rows import read_convergence_campaign_levels
from comsol_mcp.jobs.spectral_rows import read_spectral_rows
from comsol_mcp.jobs.store import JobStore

root=Path('/workspace/code-review/convergence-campaign-edges')
root.mkdir(exist_ok=True)
raw=campaign['_raw_campaign'](root/'resources/sources')
raw['levels'][1]['spectral_job']['resource_policy']={
    **raw['levels'][1]['spectral_job']['resource_policy']['rules'],'max_mesh_elements':2000}
spec=normalize_convergence_campaign_spec(raw)
store=JobStore(root/'resources/runtime/jobs')
job=store.create(spec,{'status':'submitted','attempt':1,'progress':{'completed':0,'total':spec['maximum_total_points']}})
client=fixture['_Client']()
code=_run(str(store.root),job,ownership_factory=lambda *a:fixture['_Ownership'](),
    client_factory=lambda s:client,collector_executor=fixture['_collector_for'](spec),
    telemetry_provider=fixture['_telemetry'],native_cancel_enabled=False)
error=store.read_state(job)['last_error']
assert code==1 and 'policy does not match' in error['message']

store2,spec2,job2=fixture['_created_job'](root/'partial/sources',root/'partial/work')
calls=[]
collector=fixture['_collector_for'](spec2)
def collect(point,c,d):
    calls.append(point['point_fingerprint'])
    return collector(point,c,d)
original=JobStore.update_state
projection=[0]
def fail_once(self,*a,**kw):
    if kw.get('event')=='durable_spectral_point':
        projection[0]+=1
        if projection[0]==3: raise OSError('review interrupted partial level')
    return original(self,*a,**kw)
common=dict(ownership_factory=lambda *a:fixture['_Ownership'](),client_factory=lambda s:fixture['_Client'](),
    collector_executor=collect,telemetry_provider=fixture['_telemetry'],native_cancel_enabled=False)
with patch.object(JobStore,'update_state',fail_once):
    first=_run(str(store2.root),job2,**common)
assert first==1
store2.update_state(job2,'starting',patch={'attempt':2,'last_error':None})
second=_run(str(store2.root),job2,**common)
state=store2.read_state(job2)
actual=sum(len(read_spectral_rows(store2.job_dir(job2)/f'l{level["ordinal"]}'/'spectral_rows.jsonl',
    level['spectral_job'],artifact_root=store2.job_dir(job2)/f'l{level["ordinal"]}')) for level in spec2['levels'])
assert second==0 and state['progress']['completed']==actual+3 and len(calls)==actual+3

tail=root/'partial-tail.jsonl'
tail.write_bytes(b'{"schema_name":')
tail_error=None
try: read_convergence_campaign_levels(tail,spec,artifact_root=root)
except ValueError as exc: tail_error=type(exc).__name__+': '+str(exc)
assert tail_error and tail.read_bytes()==b'{"schema_name":'
print(json.dumps({'different_policy':{'error':error,'client_loads':len(client.loaded)},
    'partial_resume':{'actual_rows':actual,'projected_progress':state['progress'],
    'collector_calls':len(calls),'recomputed_points':len(calls)-len(set(calls))},
    'partial_tail_error':tail_error,'real_solver_started':False},indent=2))
