import sys
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.shared_session import process_probe
unknown = SimpleNamespace(status=process_probe.psutil.CONN_LISTEN, pid=None,
                          laddr=SimpleNamespace(ip='127.0.0.1', port=2036))
with patch.object(process_probe.psutil, 'net_connections', return_value=[unknown]):
    listeners, complete = process_probe._listener_records()
    print('Observed listening sockets:', 1)
    print('Reported listeners:', listeners, 'Reported complete:', complete)
    snapshot = process_probe.collect_shared_preflight_snapshot(process_provider=lambda: [],
        window_provider=lambda: {}, version_provider=lambda path: None)
    print('Public snapshot inventory_complete:', snapshot['inventory_complete'])
