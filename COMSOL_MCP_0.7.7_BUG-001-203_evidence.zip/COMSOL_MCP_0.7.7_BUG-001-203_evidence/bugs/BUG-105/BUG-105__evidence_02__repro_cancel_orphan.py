import json
import runpy
import sys
from pathlib import Path

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0,str(repo))
import pytest
from comsol_mcp.jobs.store import JobStore
from comsol_mcp.jobs import cancel_worker
fixture = runpy.run_path(str(repo/'development_kit/tests/test_cancel_state_machine.py'))
clock = fixture['FakeClock']()
processes = fixture['FakeProcesses'](clock, auto_exit_at=0.5, descendants=1)
root = Path('/workspace/code-review/cancel-orphan')
store = JobStore(root)
job_id,request_id = fixture['_prepare_cancel'](store,processes,process_tree_contained=False)
mp = pytest.MonkeyPatch()
try:
    fixture['_install_fakes'](mp,clock,processes)
    first = cancel_worker.run(str(root),job_id,request_id,1.0,0.0)
    before = store.read_state(job_id)
    second = cancel_worker.run(str(root),job_id,request_id,1.0,0.0)
    after = store.read_state(job_id)
finally:
    mp.undo()
assert processes.actions == []
assert all(x == 'active' for x in processes.descendant_states.values())
assert before['cancel']['phase'] == after['cancel']['phase'] == 'blocked'
print(json.dumps({'first_return':first,'restart_return':second,
    'status':after['status'],'phase':after['cancel']['phase'],
    'owned_descendants_still_active':len(processes.descendant_states),
    'termination_actions':processes.actions,
    'blocker':after['cancel']['blocker'], 'real_process_actions':False}, indent=2))
