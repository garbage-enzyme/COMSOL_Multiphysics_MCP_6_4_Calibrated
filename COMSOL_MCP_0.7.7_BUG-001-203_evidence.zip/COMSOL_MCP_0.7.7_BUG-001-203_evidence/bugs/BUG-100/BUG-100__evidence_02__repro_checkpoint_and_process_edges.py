import hashlib
import json
import runpy
import sys
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch

repo = Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
sys.path.insert(0, str(repo))
from comsol_mcp.jobs.bounded_steps import build_bounded_step_receipt, verify_checkpoint_usability
from comsol_mcp.jobs import process_control

fixture = runpy.run_path(str(repo / 'development_kit/tests/test_bounded_steps.py'))
payload = b'bounded checkpoint'
path = Path('/workspace/code-review/checkpoint-edge.bin')
path.write_bytes(payload)
record = fixture['_checkpoint_record'](payload)
record['source_identity']['file_sha256'] = None
receipt = build_bounded_step_receipt(record)
result = verify_checkpoint_usability(receipt, path,
    current_source_file_sha256='f'*64,
    current_model_fingerprint=receipt['source_identity']['model_fingerprint'],
    current_revision=receipt['source_identity']['revision'])
assert result == {'usable': True, 'reason_codes': []}

class FakeProcess:
    pid = 12345
    acted = False
    def oneshot(self): return nullcontext()
    def create_time(self): return 123.0
    def cmdline(self): return ['review-fake']
    def terminate(self): self.acted = True

fake = FakeProcess()
identity = {'pid': fake.pid, 'process_create_time': float('nan'),
    'command_signature': hashlib.sha256(b'review-fake').hexdigest()}
with patch.object(process_control.psutil, 'Process', return_value=fake):
    verdict = process_control.terminate_exact(identity)
assert verdict['acted'] is True and fake.acted
print(json.dumps({'checkpoint_missing_receipt_source_hash': result,
    'nan_identity_mock_termination': {'acted': verdict['acted'],
        'state': verdict['before']['state'], 'real_process_action': False}}, indent=2))
