"""Pure public Python contracts, no native calls."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.surrogate.registry import build_model_card, assert_no_contract_drift
from comsol_mcp.surrogate.export import build_export_manifest

def card(identities, checksum=None):
    return build_model_card(model_id='model', lineage_id='lineage',
                            identities=identities, metrics={'rmse': 0.01}, trained_chksum=checksum)
for field in ['material_identity_sha256','mesh_identity_sha256','physics_identity_sha256','adapter_identity_sha256']:
    report = assert_no_contract_drift(card({field:'a'*64}), card({field:'b'*64}))
    print('assert_no_contract_drift_returned', field, report)
checksum = '-8938453606443985335'
try:
    card({'architecture_sha256':'a'*64}, checksum)
    print('native_checksum_card_accepted')
except ValueError as exc:
    print('native_checksum_card_rejected', str(exc))
manifest = build_export_manifest(export_id='export', trained_chksum=checksum,
    architecture_sha256='a'*64, artifacts=[{'export_format':'onnx','artifact_name':'model.onnx',
    'size_bytes':100,'sha256':'b'*64}])
print('native_checksum_export_accepted', manifest['trained_chksum'])
for invalid in ['-' + 'a'*63, '+' + 'a'*63, ' ' + 'a'*63, 'a'*31 + '_' + 'b'*32]:
    result = card({'architecture_sha256': invalid})
    print('nonhex_digest_accepted', repr(result['identities']['architecture_sha256']))
