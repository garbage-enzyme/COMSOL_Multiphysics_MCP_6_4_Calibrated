import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.shared_session.solver_owners import SolverOwnerRegistry, owner_receipt
for timestamp in (float('nan'), float('inf')):
    registry = SolverOwnerRegistry()
    fields = dict(owner='owner', cores=1, process_id=123, process_create_time=timestamp,
                  lease_sha256='a'*64, session_id='session')
    verdict = registry.evaluate_registration(**fields)
    record = registry.register(**fields)
    print('Timestamp:', timestamp, 'admitted:', verdict['admitted'], 'owners:', registry.owner_count())
    try:
        owner_receipt(owner='owner', action='register', verdict=verdict, record=record)
    except Exception as exc:
        print('Receipt failed:', type(exc).__name__)
    print('Release verdict:', registry.release(owner='owner', process_id=123,
        process_create_time=timestamp, observed_process_absent=True, observed_lease_absent=True))
