"""Actual field entry points with small repository fakes, never native COMSOL."""
import sys
from pathlib import Path
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_field_discovery import _Node, _Model as DiscoveryModel
from development_kit.tests.test_field_dataset import _Model, _normalized_request, _TaggedCollection
from development_kit.tests.test_field_bundle import _request
from comsol_mcp.evidence.field_discovery import discover_field_datasets
from comsol_mcp.evidence.field_dataset import collect_existing_dataset_field_evidence
from comsol_mcp.evidence.field_bundle import normalize_field_evidence_request

discovery = discover_field_datasets(DiscoveryModel(datasets=[
    _Node('Base','base','Solution',{'solution':'sol1'}),
    _Node('Cut','cut','CutPlane',{'data':'base'})]))
print('cut_discovery', discovery['datasets'][1])
class DerivedDataset:
    def getString(self, name):
        if name == 'data': return 'base'
        raise KeyError(name)
model = _Model()
model.java._datasets = _TaggedCollection({'dset_on':DerivedDataset()})
try:
    collect_existing_dataset_field_evidence(model=model, request=_normalized_request(),
        view_id='on', artifact_root=Path('/workspace/code-review/field-derived'))
except ValueError as exc:
    print('derived_extraction_rejects', str(exc), 'evaluations', len(model.calls))

model = _Model()
model.values[2:] = [array*1e-6 for array in model.values[2:]]
try:
    collect_existing_dataset_field_evidence(model=model, request=_normalized_request(),
        view_id='on', artifact_root=Path('/workspace/code-review/field-units'))
except ValueError as exc:
    print('SI_coordinates_with_um_request', str(exc))
print('actual_evaluate_arguments', model.calls)
