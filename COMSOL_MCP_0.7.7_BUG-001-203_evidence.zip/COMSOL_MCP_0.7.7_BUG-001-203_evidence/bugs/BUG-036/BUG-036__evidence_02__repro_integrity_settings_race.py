"""Two real settings reads separated by an atomic external configuration change."""
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.evidence import integrity_controls as controls
from comsol_mcp.settings import default_settings_document, settings_status

with tempfile.TemporaryDirectory(prefix='integrity-race-', dir='/workspace/code-review') as temp:
    path = Path(temp) / 'settings.json'
    document = default_settings_document()
    path.write_text(json.dumps(document), encoding='utf-8')
    def observe_then_replace():
        old_status = settings_status()
        replacement = path.with_suffix('.new')
        replacement.write_text('{ invalid json', encoding='utf-8')
        replacement.replace(path)
        return old_status
    with patch.dict(os.environ, {'COMSOL_MCP_SETTINGS_PATH': str(path)}):
        os.environ.pop(controls.EVIDENCE_SETTINGS_ENV, None)
        with patch.object(controls, 'settings_status', observe_then_replace):
            mixed = controls.load_evidence_integrity_status()
        current = controls.load_evidence_integrity_status()
        print('mixed valid:', mixed['configuration_state'])
        print('mixed strict verification:', mixed['strict_verification_active'])
        print('same current file:', current['configuration_state'])
        print('current strict verification:', current['strict_verification_active'])
        assert mixed['strict_verification_active'] is True
        assert current['strict_verification_active'] is False
