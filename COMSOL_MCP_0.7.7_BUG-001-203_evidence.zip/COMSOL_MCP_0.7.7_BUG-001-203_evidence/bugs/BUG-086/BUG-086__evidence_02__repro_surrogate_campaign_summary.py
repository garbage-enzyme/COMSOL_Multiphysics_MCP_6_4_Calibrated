"""Exercise actual public pure helpers with tiny inputs."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.surrogate.campaign import build_campaign_spec, build_screening_record, summarize_campaign, assert_no_prediction_promotion
spec = build_campaign_spec(campaign_id='c', candidate_count=1, top_k=1,
    maximum_fem_escalations=1, wall_time_budget_seconds=10, objective='y', maximize=True,
    surrogate_registry_entry_sha256='a'*64, dataset_manifest_sha256='b'*64)
record = build_screening_record(candidate_id='r1', features={'x':1.}, predicted_objective=1.,
    ood_state='in_domain', surrogate_registry_entry_sha256='a'*64)
results = [{'candidate_id':'not-screened', 'state':'verified'}, {'candidate_id':'not-screened', 'state':'verified'}]
summary = summarize_campaign(spec=spec, screening_records=[record], fem_results=results,
    fem_escalations_used=0, wall_time_seconds=1.)
print('unvalidated_summary', summary)
try:
    assert_no_prediction_promotion([record], results)
except ValueError as exc:
    print('independent_gate_rejects', str(exc))
