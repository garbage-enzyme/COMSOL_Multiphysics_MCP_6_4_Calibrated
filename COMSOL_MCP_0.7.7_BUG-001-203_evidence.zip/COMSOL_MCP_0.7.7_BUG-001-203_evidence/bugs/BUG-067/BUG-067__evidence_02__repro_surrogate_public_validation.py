"""Real MCP wrappers with contained audit files, no COMSOL."""
import asyncio, json, os, sys
from pathlib import Path
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.server import create_server
from comsol_mcp.durable.canonical import canonical_sha256_v1
from comsol_mcp.surrogate.export import validate_export_manifest
from development_kit.tests.test_surrogate_public_tools import _export_manifest
from development_kit.tests.mcp_test_support import decode_tool_result
root = Path('/workspace/code-review/surrogate-repro')
root.mkdir(exist_ok=True)
os.environ['COMSOL_MCP_MODEL_READ_ROOTS'] = str(root)
os.environ['COMSOL_MCP_ARTIFACT_WRITE_ROOT'] = str(root)
(root/'data.csv').write_text('x,y\n1,2\n', encoding='utf-8')
(root/'schema.json').write_text('{invalid-json', encoding='utf-8')
server = create_server('audit-surrogate', profile='core')
result = decode_tool_result(asyncio.run(server.call_tool('surrogate_dataset_validate', {
    'dataset_path': str(root/'data.csv'), 'field_schema_path': str(root/'schema.json')})))
print('invalid_declared_schema', 'success', result.get('success'), 'valid', result.get('valid'),
      'checks', result.get('checks'), 'path_policy', result.get('path_policy',{}).get('accepted'))
manifest = _export_manifest()
manifest['schema_version'] = '999.0.0'
manifest['onnx_available'] = True
manifest['artifacts'][0]['export_format'] = 'bogus'
manifest['manifest_sha256'] = canonical_sha256_v1({k:v for k,v in manifest.items() if k != 'manifest_sha256'})
try:
    validate_export_manifest(manifest)
    print('canonical_validator_accepted')
except ValueError as exc:
    print('canonical_validator_rejected', str(exc))
(root/'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
for name, args in [('surrogate_model_inspect', {}), ('surrogate_model_verify', {'require_consistent_export':True})]:
    result = decode_tool_result(asyncio.run(server.call_tool(name, {'document_path':str(root/'manifest.json'), **args})))
    print('public', name, 'success', result.get('success'), 'verified', result.get('verified'),
          'hash_verified', result.get('summary',{}).get('hash_verified'), 'checks', result.get('checks'))
