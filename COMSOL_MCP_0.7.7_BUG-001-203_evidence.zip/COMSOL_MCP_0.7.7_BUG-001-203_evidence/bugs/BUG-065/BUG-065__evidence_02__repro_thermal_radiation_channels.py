"""Production contracts/evaluator; no solver or file side effects."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_thermal_radiation import _request, _kirchhoff
from comsol_mcp.contracts.thermal_radiation import ThermalRadiationRequest
from comsol_mcp.evidence.thermal_radiation import build_kirchhoff_assessment, evaluate_thermal_radiation

polarization = {'mode': 'stokes_mueller', 'channels': ['I', 'Q', 'U', 'V'],
                'weights': [], 'propagation_direction': 'negative_z',
                'source_handedness': 'explicit_stokes', 'analyzer_handedness': 'explicit_stokes',
                'analyzer_stokes': [1.0, 0.0, 0.0, 0.0]}
for values in ([0.8, -0.3, 0.4, -0.1], [0.8, 0.3, 0.4, 0.1]):
    try:
        typed = ThermalRadiationRequest.model_validate(_request([2e-6,3e-6], values*2, polarization=polarization))
        result = evaluate_thermal_radiation(typed)
        print('physical_stokes', values, 'accepted', result['radiated_power_W_m2'])
    except ValueError as exc:
        print('physical_stokes', values, 'rejected', str(exc).splitlines()[0])
assessment = build_kirchhoff_assessment(_kirchhoff(propagation_direction='positive_z'))
request = _request([2e-6,3e-6], [0.5,0.5], optical_quantity='absorptivity', assessment=assessment)
result = evaluate_thermal_radiation(request)
print('opposite_direction_assessment_accepted', assessment['propagation_direction'],
      result['polarization']['propagation_direction'], result['radiated_power_W_m2'])
print('assessment_source_in_request', assessment['absorptivity_evidence_sha256'] in request['source_artifact_sha256s'])
