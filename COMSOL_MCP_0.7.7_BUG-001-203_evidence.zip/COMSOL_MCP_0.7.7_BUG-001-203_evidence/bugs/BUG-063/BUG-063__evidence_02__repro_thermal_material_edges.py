"""Use production evaluation and typed public tool; no native client."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_thermal_material import _ledger, _state, _request
from comsol_mcp.evidence.thermal_material import evaluate_thermal_material
from comsol_mcp.contracts.thermal_material import ThermalMaterialEvaluationRequest
from comsol_mcp.server import create_server

table = {
    'model_kind': 'nk_table', 'wavelengths_m': [1e-6, 2e-6],
    'temperatures_K': [300.0, 400.0], 'n_flat': [2.0, 3.0, 4.0, 5.0],
    'k_flat': [0.1, 0.2, 0.3, 0.4], 'table_sha256': 'c' * 64,
    'interpolation': {'wavelength_method': 'piecewise_constant',
                      'temperature_method': 'piecewise_constant',
                      'wavelength_discontinuities_m': [],
                      'temperature_discontinuities_K': []}}
for w, t, expected in [(2e-6, 300.0, 3.0), (1e-6, 400.0, 4.0), (2e-6, 400.0, 5.0)]:
    actual = evaluate_thermal_material(_request(_ledger([_state(model=table)]), wavelength=w, temperature=t))
    print('exact_grid_node', w, t, 'n_actual', actual['refractive_index_internal']['n'], 'n_expected', expected)
server = create_server('audit-thermal-edges', profile='basic_fem')
tool = server._tool_manager._tools['thermal_material_evaluate'].fn
model = {'model_kind': 'drude', 'epsilon_infinity': 4.0,
         'plasma_angular_frequency_rad_s': 1e200,
         'damping_angular_frequency_rad_s': 1e14}
typed = ThermalMaterialEvaluationRequest.model_validate(_request(_ledger([_state(model=model)])))
try:
    result = tool(typed)
    print('overflow_tool_result', result)
except Exception as exc:
    print('accepted_finite_input_tool_exception', type(exc).__name__, str(exc))
