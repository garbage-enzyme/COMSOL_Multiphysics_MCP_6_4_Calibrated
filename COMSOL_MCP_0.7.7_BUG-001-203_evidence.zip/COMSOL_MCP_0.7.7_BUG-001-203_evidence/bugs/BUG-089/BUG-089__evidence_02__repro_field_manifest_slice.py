"""Pure canonical builder and validator; no field arrays or native solver."""
import sys
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_field_manifest import _build_kwargs
from comsol_mcp.evidence.field_manifest import build_field_evidence_manifest, validate_field_evidence_manifest
request, kwargs = _build_kwargs()
kwargs['coordinate_ranges']['z'] = [0.75, 0.75]
manifest = build_field_evidence_manifest(**kwargs)
checked = validate_field_evidence_manifest(manifest, request=request)
print('request_slice', request['slice'])
print('accepted_coordinate_range', checked['coordinate_ranges']['z'])
print('status', checked['measurement_status'])
