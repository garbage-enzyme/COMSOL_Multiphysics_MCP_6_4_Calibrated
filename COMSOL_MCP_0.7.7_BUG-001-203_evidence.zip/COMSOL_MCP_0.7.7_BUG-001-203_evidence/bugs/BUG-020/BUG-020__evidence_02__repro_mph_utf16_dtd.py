import tempfile
import zipfile
from pathlib import Path
from comsol_mcp.evidence.inspection.summary import build_mph_inspection_summary
from comsol_mcp.evidence.inspection.archive import MphInspectionError

model_info = '''<?xml version="1.0" encoding="ENCODING"?>
<!DOCTYPE modelInfo [<!ENTITY title "entity-was-expanded">]>
<modelInfo comsolVersion="6.4.0.293" isRunnable="false" title="&title;"/>'''
with tempfile.TemporaryDirectory(prefix='mph-dtd-', dir='/tmp') as directory:
    for encoding in ('utf-8', 'utf-16'):
        path = Path(directory) / f'{encoding}.mph'
        with zipfile.ZipFile(path, 'w') as archive:
            archive.writestr('fileversion', '2092:COMSOL 6.4.0.293\n')
            archive.writestr('modelinfo.xml', model_info.replace('ENCODING', encoding).encode(encoding))
            archive.writestr('dmodel.xml', '<Model/>')
        try:
            summary = build_mph_inspection_summary(path)
            print(encoding, 'accepted with title:', summary['title'])
        except MphInspectionError as error:
            print(encoding, 'rejected:', error.reason_code)
