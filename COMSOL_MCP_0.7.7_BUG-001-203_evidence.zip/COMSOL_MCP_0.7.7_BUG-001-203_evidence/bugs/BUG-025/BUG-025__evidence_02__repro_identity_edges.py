import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch
from mcp.server.mcpserver import MCPServer
from comsol_mcp.tools import model_identity as tools
from comsol_mcp.tools.session import session_manager
from comsol_mcp.evidence.model_identity import _bounded_file_sha256

with tempfile.TemporaryDirectory(prefix='identity-edges-', dir='/tmp') as directory:
    root = Path(directory)
    model = root / 'model.mph'
    with zipfile.ZipFile(model, 'w') as archive:
        archive.writestr('fileversion', '2092:COMSOL 6.4.0.293\n')
        archive.writestr('modelinfo.xml', '<modelInfo comsolVersion="6.4.0.293" isRunnable="false"/>')
        archive.writestr('dmodel.xml', '<Model/>')
    server = MCPServer('identity-edges')
    tools.register_model_identity_tools(server)
    identity = server._tool_manager._tools['model_identity'].fn
    with patch.object(tools, '_passive_shared_session_attached', return_value=False):
        for label in ('FriendlyModel', 'My Model'):
            status = {'connected': True, 'current_model': label, 'version': '6.4.0.293',
                      'models': [{'name': label, 'label': label, 'tracking_key': label,
                                  'java_tag': 'Model1', 'revision_sha256': 'a' * 64}]}
            with patch.object(session_manager, 'get_status', return_value=status):
                result = identity(str(model), request_session_identity=True)
            print('label:', label, 'success:', result['success'],
                  'active tag:', result.get('identity', {}).get('active_model_tag'),
                  'reason:', result.get('reason_code'))
    source = root / 'source.mph'
    source.write_bytes(b'x')
    original_open = Path.open
    def grow_on_open(path, *args, **kwargs):
        if path == source and args and args[0] == 'rb':
            with original_open(path, 'ab') as stream:
                stream.write(b'y' * 1024)
        return original_open(path, *args, **kwargs)
    with patch.object(Path, 'open', grow_on_open):
        _, count = _bounded_file_sha256(source, max_bytes=8,
                                       missing_code='missing', over_limit_code='too_large')
    print('hash byte budget:', 8, 'accepted bytes:', count)
