import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from settings_gui import manual_index

original_popen = subprocess.Popen
entered = threading.Event()
release = threading.Event()
child = []

def delayed_popen(command, **kwargs):
    entered.set()
    if not release.wait(3):
        raise RuntimeError('reproduction deadline')
    process = original_popen(
        [sys.executable, '-c',
         "import sys,time; sys.stdin.buffer.read(); "
         "print('{\"event\":\"progress\",\"stage\":\"started_after_cancel\"}',flush=True); time.sleep(1)"],
        **kwargs,
    )
    child.append(process)
    return process

with tempfile.TemporaryDirectory(prefix='index-cancel-', dir='/tmp') as root:
    task = manual_index.ManualIndexBuildTask(pdf_root=root, index_path=Path(root) / 'index.db')
    manual_index.subprocess.Popen = delayed_popen
    try:
        task.start()
        assert entered.wait(3)
        task.cancel()
        release.set()
        assert task.wait(5)
        events = task.drain_events()
        # terminal publication clears progress events, so independently report child completion.
        print('cancel requested before process registration:', task._cancel.is_set())
        print('worker exited normally after cancellation:', child[0].returncode == 0)
        print('reported events:', events)
    finally:
        release.set()
        manual_index.subprocess.Popen = original_popen
        for process in child:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=3)
