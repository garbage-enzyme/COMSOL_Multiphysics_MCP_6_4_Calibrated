"""Adapter interface checks using passive client and typed-accessor stand-ins."""
import ast
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from comsol_mcp.adapter.mph_backend import MphBackendBase
from comsol_mcp.adapter.protocol import AdapterError, NodeRef

client_source = Path('/workspace/.cloud-onboarding/venv/lib/python3.14/site-packages/mph/client.py')
tree = ast.parse(client_source.read_text(encoding='utf-8-sig'))
client_class = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Client')
methods = {node.name for node in client_class.body if isinstance(node, ast.FunctionDef)}
print('installed MPh Client has versions method:', 'versions' in methods)
backend = MphBackendBase()
backend._client = SimpleNamespace(version='6.4', host=None, port=None, standalone=True)
backend._mph_version = '1.3.1'
print('client known version:', backend._client.version)
print('adapter COMSOL version:', backend.session_identity().comsol_version)

class TypedProperty:
    def getString(self, name):
        return '0.1'
    def getDouble(self, name):
        return 0.1

with patch.object(backend, '_java_node', return_value=TypedProperty()):
    try:
        backend.read_property(NodeRef('comp1', ('component', 'comp1')), 'L', form='float')
    except AdapterError as exc:
        print('numeric property read refusal:', exc.reason_code)
    print('typed numeric accessor value:', TypedProperty().getDouble('L'))
