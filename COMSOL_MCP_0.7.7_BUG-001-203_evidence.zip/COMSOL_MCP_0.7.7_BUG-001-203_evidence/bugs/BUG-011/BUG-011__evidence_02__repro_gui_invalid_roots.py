from types import SimpleNamespace
from comsol_mcp.settings import default_settings_document
from settings_gui import app
from settings_gui.model import SettingsFormModel, FIELD_BY_KEY

raw = default_settings_document()
raw['paths']['model_read_roots'] = None
loaded = app._load_startup_document(SimpleNamespace(load=lambda: raw))
model = SettingsFormModel.from_raw(loaded)
print('startup accepted document:', loaded is raw)
print('model validation error:', model.errors.get('paths.model_read_roots'))

class Widget:
    def __init__(self, *args, **kwargs):
        pass
    def grid_size(self):
        return (0, 0)
    def grid(self, *args, **kwargs):
        pass
    def columnconfigure(self, *args, **kwargs):
        pass

app.ttk.Frame = Widget
app.ttk.Label = Widget
app.tk.StringVar = Widget
application = app.SettingsApplication.__new__(app.SettingsApplication)
application.controller = SimpleNamespace(model=model)
try:
    application._add_field(Widget(), FIELD_BY_KEY['paths.model_read_roots'])
except Exception as error:
    print('widget construction failed:', type(error).__name__, str(error))
