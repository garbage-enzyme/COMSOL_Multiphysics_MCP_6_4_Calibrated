import os
import subprocess
import sys
import tempfile
from pathlib import Path
from comsol_mcp.jobs.store import JobStore
from mcp.server.mcpserver import MCPServer
from comsol_mcp.tools import jobs
from comsol_mcp.jobs.manager import JobManager

with tempfile.TemporaryDirectory(prefix='job-store-', dir='/tmp') as directory:
    root = Path(directory)
    store = JobStore(root / 'jobs')
    job_id = store.create({}, {'status': 'completed'})
    job = store.job_dir(job_id)
    (job / 'worker.log').write_bytes(b'x' * (2 * 1024 * 1024) + b'\n')
    tail = store.tail(job_id, 1)
    print('one-line tail response log bytes:', len(tail['worker_log'][0].encode()))
    outside = root / 'outside'
    outside.mkdir()
    target = outside / 'control.json'
    target.write_text('user file')
    (store.root / 'job-escape').symlink_to(outside, target_is_directory=True)
    store.write_control('job-escape', 'cancel_requested')
    print('symlink job directory wrote outside root:', target.read_text() != 'user file')
    jobs.job_manager = JobManager(store.root, reconcile_on_start=False)
    server = MCPServer('job-store-edges')
    jobs.register_job_tools(server)
    result = server._tool_manager._tools['job_status'].fn('job-missing')
    print('job error reveals configured runtime path:', str(store.root) in result['error'])
    fifo = root / 'fifo.lock'
    os.mkfifo(fifo)
    child = subprocess.Popen([sys.executable, '-c',
        'from pathlib import Path; from comsol_mcp.jobs.store import JobLock; '
        'import sys; JobLock(Path(sys.argv[1]), timeout=0.2).acquire()', str(fifo)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        child.communicate(timeout=2)
        print('FIFO lock acquisition blocked past deadline:', False)
    except subprocess.TimeoutExpired:
        print('FIFO lock acquisition blocked past deadline:', True)
    finally:
        if child.poll() is None:
            child.kill()
        child.communicate(timeout=3)
