import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
from development_kit.tests.test_robust_finalist_runtime import _spec, _observation
from development_kit.tests.test_gradient_contracts import _outer_optimizer
from comsol_mcp.jobs.robust_shape_optimization import expand_robust_shape_manifest
from comsol_mcp.jobs import robust_shape_worker as worker, robust_shape_native_runtime as native
from comsol_mcp.jobs.store import JobStore, atomic_write_json
from comsol_mcp.tools import ownership
root=Path('/workspace/code-review/robust-startup-budget-source')
shutil.rmtree(root,ignore_errors=True)
root.mkdir()
_spec(root)
manifest=root/'manifest.json'
raw=json.loads(manifest.read_text())
raw['native_optimizer']=_outer_optimizer()
raw['native_optimizer']['budget']['cores']=envelope_cores=json.loads((root/'envelope.json').read_text())['cores']
raw['native_optimizer']['budget']['max_solves']=1
payload=json.dumps(raw).encode()
manifest.write_bytes(payload)
envelope=json.loads((root/'envelope.json').read_text())
envelope['submission_manifest_sha256']=hashlib.sha256(payload).hexdigest()
spec=expand_robust_shape_manifest(envelope)
assert spec['synthetic_mode'] is False and spec['native_optimizer']['budget']['max_solves']==1
source=Path(spec['source_model_path'])
source.write_bytes(b'changed after true manifest validation')
current_hash=hashlib.sha256(source.read_bytes()).hexdigest()
assert current_hash!=spec['source_model_sha256']
store=JobStore(root/'jobs')
job=store.create(spec,{'status':'submitted','attempt':1,'worker_pid':None,
                     'worker_process_create_time':None,'worker_command_signature':None})
calls=[]
class Ownership:
    def __init__(self,*a,**kw): pass
    def preflight(self,**kw): return {'ready':True}
    def acquire(self,**kw): return {'success':True,'acquired':True}
    def release(self): return {'success':True,'released':True}
    def status(self,**kw): return {'process_inventory':{'complete':True},'external_solver_processes':[], 'lease':{'state':'absent'}}
class Client:
    def clear(self): pass
def execute(candidate,directory,**kw):
    observations=[_observation(c) for c in candidate['condition_table']['conditions'] if c['active'] and c['objective_role']=='objective']
    calls.append({'observations':len(observations),'include_gradients':kw['include_gradients'],
                  'actual_source_sha':hashlib.sha256(Path(candidate['source_model_path']).read_bytes()).hexdigest()})
    atomic_write_json(directory/'native-cleanup.json',{'client_clear':True,'errors':[],'client_disconnect':'not_applicable'})
    return {'observations':observations,'aggregate_gradient':{'complete':True,'receipt_fingerprint':'a'*64,'aggregate_gradient':[1.,1.]}}
with patch.object(worker,'_await_licensed_wall_watchdog',lambda *a,**kw: {}), \
     patch.object(worker,'collect_resource_telemetry',lambda **kw:{'stage':'pre_mesh','available_memory_bytes':10**15,'runtime_free_bytes':10**15}), \
     patch.object(ownership,'SolverOwnership',Ownership), patch.object(native,'execute_lin2025_conditions',execute), \
     patch.dict(sys.modules,{'mph':SimpleNamespace(Client=lambda **kw:Client()),
                             'jpype':SimpleNamespace(JClass=lambda n:SimpleNamespace(getenv=os.environ.get))}):
    exit_code=worker._run_licensed(str(store.root),job)
state=store.read_state(job)
assert exit_code==1 and len(calls)==1 and calls[0]['observations']==24 and calls[0]['include_gradients']
assert state['last_error']['message']=='GCMMA condition solve budget is exhausted'
assert calls[0]['actual_source_sha']==current_hash
print(json.dumps({'normalized_max_solves':1,'native_batch_entered_before_budget_error':calls,
                  'input_source_pin_matches':False,'terminal_error':state['last_error'],
                  'real_solver_started':False},indent=2))

loads=[]
class LoadClient:
    port=None
    def load(self,path):
        loads.append(hashlib.sha256(Path(path).read_bytes()).hexdigest())
        raise RuntimeError('review stop before solver')
    def clear(self): pass
target=root/'direct-native'
target.mkdir()
try:
    native.execute_lin2025_conditions(spec,target,attempt=1,
             client_factory=lambda **kw:LoadClient(),java_environment_reader=os.environ.get,
             cancel_requested=lambda:False)
except RuntimeError as exc:
    assert str(exc)=='review stop before solver'
assert loads==[current_hash]
print(json.dumps({'real_native_entry_loads_changed_source':True,'real_solver_started':False}))
