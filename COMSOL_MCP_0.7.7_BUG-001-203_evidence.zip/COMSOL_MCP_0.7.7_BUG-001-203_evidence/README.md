# COMSOL MCP 修复 agent 交付包

审查提交：da9f168baedfcca28d04d93369ef711240011d73（alpha7-7，0.7.7）。
全部 780 个 Git 跟踪文件已逐项处理。确认 203 个未修复 bug：{'P2': 168, 'P1': 25, 'P3': 10}。
源码与起始 SHA256 清单一致；没有提交或改动产品代码。

## 使用顺序

1. 阅读 buglist.md 和 bug-index.tsv，按优先级分派 BUG。
2. 打开 bugs/BUG-NNN/BUG-NNN.md；六字段包含触发条件、证据边界和可能解决办法。
3. 使用同目录 BUG-NNN__evidence_* 与 BUG-NNN__source__* 定位。证据原件未改写。
4. common/source 包含该提交全部 780 个跟踪文件，供逐项交叉阅读和补全导入；不是已修复版本。
5. 原始探针保留原文件名在 common/original-probes，供脚本间导入；每 BUG 的副本文件名带编号。

## 环境与复现

实际宿主：Debian 13 x86_64、Python 3.14.7、PowerShell 7.5.4、Node 24.19.0。
Python 依赖来自仓库 Ubuntu hash lock，另有开发测试依赖。按项目 pyproject/constraints 安装，不需安装 COMSOL。
全部 Python/Node 探针是此次审查的有限无求解器场景；需要已安装 comsol-mcp 的脚本保持安装入口测试条件。
部分探针注入纯模型、Java、ownership、时钟或进程替身，原生/科学验收仍未运行。静态缺陷未伪造动态日志。

原始脚本包含 /workspace 绝对路径。先用以下命令生成路径适配副本；这不会执行探针或安装依赖：

```powershell
python common/original-probes/prepare_repro_workspace.py --bundle <解压目录> --repository <目标仓库> --scratch <新的ASCII临时目录>
```

随后从生成的 code-review 目录，用 Python 执行对应脚本；需要 src 导入的脚本设置 PYTHONPATH 为目标仓库。
BUG-008 必须清空 PYTHONPATH、从仓库外运行，检查的是已安装包的首次用户路径。
PowerShell 脚本使用 pwsh -NoProfile -File，Node 脚本使用 node。
适配工具采用文本路径替换，只适用于本包这些已知脚本；迁移后检查 path-adaptation.json 和对应输出。
不要将同目录脚本副本的编号文件名直接代替原名执行有 sibling import 的脚本。

## 验证记录与限制

完整四 worker 主套件：4963 passed、6 failed、57 skipped；串行尾 3 passed。
六个失败在不同条件的定向重跑中通过，原始失败日志仍保留，不能称完整主套件全绿。
既有脚本补录 104 个 Python replay：103 exit=0，1 因 BUG-008 导入条件错误失败，零超时；正确安装条件重跑已确认。
其他已保存的复现原日志不覆盖。额外 Node/PowerShell 复现日志已保存。
replay exit=0 通常意味着已确认的错误行为符合探针断言，不代表产品已通过或 bug 已修复。
最终文件/编号/哈希/工作树核验见 final-audit-verification.log。
封包时逐成员验证 SHA256、复制来源、780 项源码清单和 ZIP CRC；路径适配后的 BUG-203 从包内源码复现成功，日志位于对应 BUG 目录。

DSH 官方 0.2.0-rc.2 在 Debian 已实际安装并经真实 Web/profile/Cordis 宿主接入 56 个 MCP 工具。
BUG-181、182、184 的真实宿主证据、脚本和精确 npm lock 位于 common/dsh-rc2；目录不包含 node_modules 或宿主认证信息。
要重复宿主验收，在路径适配的 dsh-rc2 目录 npm ci，再运行 acceptance-boot.mjs；先核对 overlay 中入口与仓库路径。
generation probe 需要 acceptance probe 建立的 @local bridge 路径，或手动创建同一 link。
基础宿主/MCP/镜像检查不需要 DeepSeek API key；真实 DeepSeek 推理未测试。
未安装/启动 COMSOL；Debian native 支持由当前代码拒绝，不能把接入成功当作 Linux 原生求解已支持。
云配置草稿已保存但未发布；新任务恢复未验证，不影响本包审查范围。

## 完整性

provenance.json 记录每个复制文件的原路径、字节数和 SHA256。
SHA256SUMS.txt 覆盖包内除其自身之外的全部文件；zip 外另有摘要。
未包含依赖缓存、虚拟环境、node_modules、DSH_HOME、API key、许可手册或私有模型。
配套 skill 的冻结跟踪文件在 common/companion-skill。
源码中的测试 fixture/图标与翻译资源是仓库跟踪文件，保留原样。
