"""Linux operation-root cache identity and abnormal lock IO, no solver."""
import os
import sys
import subprocess
import tempfile
import tracemalloc
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/COMSOL_MCP_debian_reacceptance_42f9e95')
from comsol_mcp.operation_arbiter import OperationArbiter, get_operation_arbiter

with tempfile.TemporaryDirectory(prefix='operation-linux-', dir='/workspace/code-review') as temp:
    root = Path(temp)
    upper, lower = root / 'Runtime', root / 'runtime'
    upper.mkdir()
    lower.mkdir()
    with patch.dict(os.environ, {'COMSOL_MCP_RUNTIME_DIR': str(upper)}):
        first = get_operation_arbiter()
    with patch.dict(os.environ, {'COMSOL_MCP_RUNTIME_DIR': str(lower)}):
        second = get_operation_arbiter()
    print('distinct POSIX roots shared arbiter:', first is second)
    print('second arbiter points to requested root:', second.runtime_root == lower)
    arbiter = OperationArbiter(root)
    arbiter.lock_path.write_bytes(b'x' * (8 * 1024 * 1024))
    tracemalloc.start()
    print('large lock verdict:', arbiter.inspect()['state'])
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print('large lock allocation peak:', peak)
    arbiter.lock_path.unlink()
    os.mkfifo(arbiter.lock_path)
    child = subprocess.Popen([sys.executable, '-c',
        'from comsol_mcp.operation_arbiter import OperationArbiter; '
        'import sys; OperationArbiter(sys.argv[1]).inspect()', str(root)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        child.communicate(timeout=2)
        print('FIFO inspect blocks:', False)
    except subprocess.TimeoutExpired:
        print('FIFO inspect blocks:', True)
    finally:
        if child.poll() is None:
            child.kill()
        child.communicate(timeout=3)
