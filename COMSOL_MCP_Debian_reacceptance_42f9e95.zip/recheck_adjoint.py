import subprocess,os,sys,json,time
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for label,repo in [('target','/workspace/COMSOL_MCP_debian_reacceptance_42f9e95'),('previous','/workspace/COMSOL_MCP_debian_fix_acceptance')]:
    command=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','development_kit/tests/test_adjoint_optimization.py','--basetemp',str(root/(label+'-adjoint-temp'))]
    start=time.monotonic()
    r=subprocess.run(command,cwd=repo,env=dict(os.environ,PYTHONPATH=repo,PYTHONDONTWRITEBYTECODE='1',COMSOL_MCP_TEST_ASCII_ROOT=str(root/(label+'-adjoint-ascii'))),capture_output=True,timeout=90)
    for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
        (root/'ci-local-results'/('adjoint_recheck_'+label+'__'+suffix+'.log')).write_bytes(data)
    results.append({'version':label,'repository':repo,'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
    print(json.dumps(results[-1]),flush=True)
(root/'adjoint-recheck.json').write_text(json.dumps(results,indent=2)+'\n')
