## ACC-007（CI 格式门禁）

**第二轮状态**：未修复，backend 两处和 GUI 一处 format 仍失败。

- **编号**：ACC-007
- **标题**：三处新增格式不符合当前 Ruff，阻断 backend 和 Windows GUI CI
- **严重性/优先级**：中 / P2；发布门禁失败。
- **位置**：`comsol_mcp/durable/io.py:365`、`comsol_mcp/tools/model_identity.py:61`、`settings_gui/tests/test_discovery.py:71`；引入提交 `1ce4cce`、`131eef8`。
- **内容/复现方法**：精确 quality_gate 的 lint 通过、format 失败，提示两个文件需要重排版，receipt 的 stage=format。workflow 原样 GUI 格式范围提示 test_discovery.py 一处需要重排版。对应 GitHub job 公共 annotation 分别显示失败在 quality gate 与 GUI formatting/lint。原始 exact command 输出保存在 ci-local-results。早期 ruff '.' 扫描包含非 CI recipes，不作为这三处的门禁依据。
- **可能的解决办法**：按当前 Ruff 规范整理这三个调用/表达式的格式，保持功能和断言；重跑项目原 gate 与 workflow GUI 格式、lint 范围。

