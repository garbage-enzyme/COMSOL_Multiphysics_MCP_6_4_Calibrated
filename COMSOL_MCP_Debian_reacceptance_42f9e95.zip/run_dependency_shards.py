"""Reproduce the dependency job's actual two-shard test command on Debian."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/COMSOL_MCP_debian_reacceptance_42f9e95')
command=[sys.executable,'development_kit/scripts/serial_test_shards.py',
         '--basetemp-root',str(ROOT/'ci-dependency-shards'),'--shards','2',
         '--ignore','development_kit/tests/test_control_plane_startup.py']
env=dict(os.environ,PYTHONPATH=str(REPO),PYTHONDONTWRITEBYTECODE='1',
         COMSOL_MCP_TEST_ASCII_ROOT=str(ROOT/'ci-test-ascii'),
         COVERAGE_FILE=str(ROOT/'ci-dependency.coverage'),
         PYTEST_ADDOPTS='-o cache_dir='+str(ROOT/'ci-pytest-cache'))
started=time.monotonic()
process=subprocess.Popen(command,cwd=REPO,env=env,start_new_session=True,
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE)
timed_out=False
try: stdout,stderr=process.communicate(timeout=600)
except subprocess.TimeoutExpired:
    timed_out=True
    os.killpg(process.pid,signal.SIGKILL)
    stdout,stderr=process.communicate(timeout=5)
finally:
    try: os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError: pass
folder=ROOT/'ci-local-results'
(folder/'dependency_shards__stdout.log').write_bytes(stdout)
(folder/'dependency_shards__stderr.log').write_bytes(stderr)
receipt={'command':command,'cwd':str(REPO),'returncode':process.returncode,
         'seconds':round(time.monotonic()-started,3),'outer_timeout':timed_out,
         'timeout_seconds':600,'python':sys.version,
         'differences_from_hosted':'Debian 13/Python 3.14.7 and existing Ubuntu-lock dependencies; temp/cache/coverage paths relocated outside source; two shards retain a shared coverage base as in CI.'}
(ROOT/'ci-dependency-shards-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
