"""Explain the exact compatibility-fingerprint failure without updating policy."""
import json
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/COMSOL_MCP_debian_fix_acceptance')
sys.path.insert(0,str(REPO))
from development_kit.scripts import planning_code_gate as gate
path = 'development_kit/tests/test_durable_job_control_plane.py'
baseline = subprocess.check_output(['git','show','da9f168:'+path],cwd=REPO).decode()
current = (REPO/path).read_text()
expected = gate.load_planning_code_allowlist(REPO/'development_kit/release/planning_code_allowlist.json')[path]
old, new = gate._matches(baseline),gate._matches(current)
receipt = {'path':path,'expected_allowlist':expected,
           'baseline':{'matches':old,'sha256':gate._fingerprint(old)},
           'target':{'matches':new,'sha256':gate._fingerprint(new)},
           'tokens_unchanged':[m['token'] for m in old]==[m['token'] for m in new],
           'only_match_offsets_changed':len(old)==len(new) and old!=new,
           'baseline_fingerprint_matches_allowlist':gate._fingerprint(old)==expected['match_sha256'],
           'target_fingerprint_matches_allowlist':gate._fingerprint(new)==expected['match_sha256']}
(ROOT/'ci-planning-fingerprint.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
