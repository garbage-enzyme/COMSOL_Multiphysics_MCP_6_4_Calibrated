"""Probe real short pipe delivery and actual fake semantic worker startup."""
import argparse
import json
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--repository',type=Path,required=True)
args=parser.parse_args()
sys.path.insert(0,str(args.repository))
from comsol_mcp.knowledge.semantic_process import SemanticWorkerManager
worker=subprocess.Popen([sys.executable,'-c',
    'import sys; sys.stdout.buffer.write(b\'{"event":"ready"}\\n\'); sys.stdout.buffer.flush(); '
    'sys.stderr.write("flushed\\n"); sys.stderr.flush(); sys.stdin.buffer.read(1)'],
    stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
delivered=worker.stderr.readline()
results=queue.Queue()
read=SemanticWorkerManager._read_startup_line if hasattr(SemanticWorkerManager,'_read_startup_line') else lambda stream:stream.readline()
def observe():
    try: results.put(('line',read(worker.stdout)))
    except Exception as exc: results.put(('error',str(exc)))
thread=threading.Thread(target=observe,daemon=True)
thread.start()
start=time.monotonic()
try:
    early=results.get(timeout=0.4)
except queue.Empty:
    early=None
alive=worker.poll() is None
worker.kill()
worker.wait(timeout=3)
thread.join(timeout=3)
after=results.get(timeout=1) if early is None else early
for stream in (worker.stdin,worker.stdout,worker.stderr): stream.close()
manager=SemanticWorkerManager(startup_deadline=1.0,query_deadline=1.0)
try:
    started=manager.start()
    health=manager.health() if started.get('success') else None
finally:
    cleanup=manager.reset()
receipt={'repository':str(args.repository),'module':sys.modules[SemanticWorkerManager.__module__].__file__,
         'child_confirmed_flushed':delivered.decode().strip()=='flushed',
         'worker_alive_during_observation':alive,
         'reader_returned_before_eof':early is not None,
         'reader_after_eof':{'kind':after[0],'value':after[1].decode() if isinstance(after[1],bytes) else after[1]},
         'short_line_wait_bound_seconds':0.4,'actual_start':started,'actual_health':health,
         'cleanup':cleanup,'functional_acceptance_passed':early is not None and started.get('success') is True}
print(json.dumps(receipt,ensure_ascii=False,indent=2))
