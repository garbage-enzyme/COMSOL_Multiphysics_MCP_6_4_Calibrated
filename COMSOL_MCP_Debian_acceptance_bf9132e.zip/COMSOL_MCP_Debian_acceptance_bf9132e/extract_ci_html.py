"""Extract public Actions page text and data without executing page content."""
import sys
from html.parser import HTMLParser
from pathlib import Path

class Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag in {'script','style'}: self.skip += 1
    def handle_endtag(self, tag):
        if tag in {'script','style'}: self.skip = max(0,self.skip-1)
    def handle_data(self, data):
        if not self.skip and data.strip(): self.parts.append(' '.join(data.split()))

for name in sys.argv[1:]:
    path = Path(name)
    parser = Text()
    parser.feed(path.read_text())
    target = path.with_suffix('.text.txt')
    target.write_text('\n'.join(parser.parts)+'\n')
    # Headers precede the useful Actions panel; retain the full text on disk.
    output = parser.parts
    for i, part in enumerate(output):
        if part in {'Summary','Jobs'}:
            output = output[max(0,i-6):]
            break
    print('\n'.join(output[-210:]))
