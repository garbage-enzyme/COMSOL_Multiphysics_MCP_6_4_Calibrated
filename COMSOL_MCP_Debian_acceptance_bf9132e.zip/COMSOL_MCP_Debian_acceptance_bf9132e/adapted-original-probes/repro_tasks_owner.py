from pathlib import Path
import tempfile
from comsol_mcp.jobs.tasks_bridge import TasksBridge, TasksMappingStore, TaskNotFound

class Engine:
    def submit(self, _spec):
        return {'job_id': 'job-fixed', 'status': 'completed', 'duplicate': True}
    def status(self, _job):
        return {'job_id': 'job-fixed', 'status': 'completed', 'attempt': 1}
    def cancel(self, _job, **_kwargs):
        raise AssertionError('not needed')

with tempfile.TemporaryDirectory(prefix='mcp-review-owner-', dir='/tmp') as directory:
    store = TasksMappingStore(Path(directory))
    engine = Engine()
    first = TasksBridge(engine=engine, store=store, owner='owner-a')
    other = TasksBridge(engine=engine, store=store, owner='owner-b')
    extensions = {'io.modelcontextprotocol/tasks': {}}
    handle = first.submit_task({'spec': {}}, client_extensions=extensions)
    identifier = handle['taskId']
    print('submitted handle status:', handle['status'], 'actual status:', first.get_task(identifier)['status'])
    try:
        other.get_task(identifier)
    except TaskNotFound:
        print('owner-b initially refused')
    stolen = other.submit_task({'spec': {}}, client_extensions=extensions)
    print('owner-b reused owner-a task id:', stolen['taskId'] == identifier)
    print('owner-b now reads:', other.get_task(identifier)['status'])
    try:
        first.get_task(identifier)
    except TaskNotFound:
        print('owner-a lost access after identical owner-b submission')
