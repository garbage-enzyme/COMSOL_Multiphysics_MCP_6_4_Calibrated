from pathlib import Path
import tempfile

from comsol_mcp.jobs.tasks_bridge import TaskRow, TasksMappingStore

with tempfile.TemporaryDirectory(prefix='mcp-review-tasks-', dir='/tmp') as directory:
    store = TasksMappingStore(Path(directory))
    def row(task):
        return TaskRow(task, 'job-'+task, 0, None, 1000, 'a'*64, 'owner')
    store.append(row('first'))
    with store.journal_path.open('ab') as stream:
        stream.write(b'{"task_id":"interrupted')
    print('after interrupted append:', [r.task_id for r in store.rows()])
    store.append(row('second'))
    print('after next append:', [r.task_id for r in store.rows()])
    print('first mapping survived:', store.latest_for_task('first') is not None)
