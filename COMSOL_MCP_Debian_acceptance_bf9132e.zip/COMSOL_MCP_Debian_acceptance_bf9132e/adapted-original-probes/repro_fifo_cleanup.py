import os
from pathlib import Path
import subprocess
import sys
import tempfile

with tempfile.TemporaryDirectory(prefix='mcp-review-fifo-', dir='/tmp') as directory:
    fifo = Path(directory) / 'candidate'
    os.mkfifo(fifo)
    code = ('from comsol_mcp.durable.io import unlink_if_identity; '
            f'print(unlink_if_identity({str(fifo)!r}, (0, 0)))')
    try:
        outcome = subprocess.run([sys.executable, '-c', code], timeout=3, capture_output=True, text=True)
        print('returncode:', outcome.returncode, 'stdout:', outcome.stdout, 'stderr:', outcome.stderr)
    except subprocess.TimeoutExpired:
        print('CONFIRMED: unlink_if_identity blocks on a FIFO before regular-file validation; child was terminated and reaped')
