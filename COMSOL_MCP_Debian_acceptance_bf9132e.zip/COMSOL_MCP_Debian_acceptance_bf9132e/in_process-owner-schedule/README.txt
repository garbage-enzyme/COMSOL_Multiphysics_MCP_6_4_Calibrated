Initial deterministic overlap used two bridge objects in one interpreter.
Final accepted evidence uses an independent writer-B interpreter and real shared mapping storage.
