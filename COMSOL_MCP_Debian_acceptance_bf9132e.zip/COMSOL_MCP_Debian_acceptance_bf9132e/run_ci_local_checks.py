"""Run exact applicable CI gates and retain diagnostic scope boundaries."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/COMSOL_MCP_debian_fix_acceptance')
environment = dict(os.environ,PYTHONPATH=str(REPO),PYTHONDONTWRITEBYTECODE='1')
jobs = [
 ('quality_gate_exact',[sys.executable,'development_kit/scripts/quality_gate.py',
   '--defer-platform-coverage','--artifact-root',str(ROOT/'quality-gate')],600),
 ('integration_contracts_exact',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider',
   'development_kit/tests/test_release_engineering.py','--basetemp',str(ROOT/'ci-integration-temp')],120),
 ('gui_format_exact',[sys.executable,'-m','ruff','format','--check','settings_gui',
   'comsol_mcp/settings_gui_handshake.py','comsol_mcp/settings_gui_launcher.py','comsol_mcp/tools/settings_gui.py',
   'development_kit/scripts/installed_package_probe.py','development_kit/scripts/settings_gui_icon.py',
   'development_kit/scripts/settings_gui_locales.py','development_kit/scripts/settings_gui_package_probe.py',
   'development_kit/tests/test_settings_gui_root_launcher.py'],60),
]
outcomes=[]
for name,command,bound in jobs:
    start=time.monotonic()
    process=subprocess.Popen(command,cwd=REPO,env=environment,start_new_session=True,
                             stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed_out=False
    try: stdout,stderr=process.communicate(timeout=bound)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGKILL)
        stdout,stderr=process.communicate(timeout=5)
    finally:
        try: os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError: pass
    folder=ROOT/'ci-local-results'
    folder.mkdir(exist_ok=True)
    (folder/(name+'__stdout.log')).write_bytes(stdout)
    (folder/(name+'__stderr.log')).write_bytes(stderr)
    row={'name':name,'command':command,'returncode':process.returncode,
         'outer_timeout':timed_out,'timeout_seconds':bound,'seconds':round(time.monotonic()-start,3)}
    outcomes.append(row)
    print(json.dumps(row),flush=True)
    (ROOT/'ci-local-results.json').write_text(json.dumps(outcomes,indent=2)+'\n')
