"""Confirm cross-process owner overlap and real linked-job rejection."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/COMSOL_MCP_debian_fix_acceptance')
sys.path.insert(0,str(REPO))
case='BUG-005__concurrent'
logs=ROOT/'independent-results'
archive=ROOT/'in_process-owner-schedule'
archive.mkdir()
for suffix in ('stdout','stderr'):
    name=case+'__'+suffix+'.log'
    shutil.copyfile(logs/name,archive/name)
(archive/'README.txt').write_text('Initial deterministic overlap used two bridge objects in one interpreter.\nFinal accepted evidence uses an independent writer-B interpreter and real shared mapping storage.\n')
result=subprocess.run([sys.executable,str(ROOT/'independent_checks.py'),'--case',case],cwd=ROOT,
                      capture_output=True,timeout=12,
                      env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(REPO)))
(logs/(case+'__stdout.log')).write_bytes(result.stdout)
(logs/(case+'__stderr.log')).write_bytes(result.stderr)
outcomes=json.loads((ROOT/'independent-results.json').read_text())
entry=next(r for r in outcomes if r['case']==case)
entry.update(returncode=result.returncode,result=json.loads(result.stdout),outer_timeout=False)
(ROOT/'independent-results.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2)+'\n')
print(result.stdout.decode())
from comsol_mcp.jobs.store import JobStore
with tempfile.TemporaryDirectory(dir=ROOT,prefix='job-link-') as directory:
    root=Path(directory)
    outside=root/'outside'
    outside.mkdir()
    sentinel=outside/'state.json'
    sentinel.write_bytes(b'{"owner":"external"}\n')
    store=JobStore(root/'jobs')
    store.root.mkdir(exist_ok=True)
    link=store.root/'job-linked'
    link.symlink_to(outside,target_is_directory=True)
    errors=[]
    for name,call in [('job_dir',lambda:store.job_dir('job-linked')),
                      ('read_state',lambda:store.read_state('job-linked'))]:
        try: call()
        except ValueError as exc: errors.append({'operation':name,'message':str(exc)})
    receipt={'linked_job_directory_refused':len(errors)==2,'errors':errors,
             'outside_bytes_unchanged':sentinel.read_bytes()==b'{"owner":"external"}\n',
             'outside_files_unchanged':[p.name for p in outside.iterdir()]==['state.json'],
             'scope':'Additional path-link acceptance for the added JobStore regression; not an original BUG-041 entry point.'}
    assert receipt['linked_job_directory_refused'] and receipt['outside_bytes_unchanged'] and receipt['outside_files_unchanged']
    (ROOT/'job-directory-link-acceptance.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
