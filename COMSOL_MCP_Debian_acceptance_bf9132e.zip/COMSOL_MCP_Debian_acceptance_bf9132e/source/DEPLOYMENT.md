# COMSOL MCP deployment guide

This document describes Windows deployment. For experimental solver-free Ubuntu installation, read the [Linux guide](docs/experimental_linux/README.md).

This guide covers a fresh COMSOL MCP installation and client configuration for
Claude Code, Hermes Agent, Codex CLI, and opencode. Replace every example path
with the target machine's actual paths.

Client acceptance scope:

- Earlier installed-package tests covered ordinary tool calls in Codex CLI, opencode, and Claude Code. See the [README](README.md#client-compatibility-and-deployment) for limits.
- Native Claude Tasks acceptance for 0.7.6 remains incomplete. Python SDK tests do not replace native-client tests.
- OpenCode testing stopped after a connection failure. This is not a pass.
- Hermes Agent has configuration guidance only. End-to-end acceptance remains untested.

## 1. Server installation

Requirements:

- COMSOL Multiphysics 6.4.0.* (licensed reference acceptance is pinned to
  6.4.0.293. A third numeric component change is a separate release family).
- standard GIL-enabled Python 3.14 in an ASCII-only environment path.
- COMSOL's Java runtime for the verified local configuration.

Python 3.15 is a separate experimental engineering lane, not a production
upgrade recommendation. See the [compatibility build requirements](README.md#requirements-and-installation)
before using it: missing native wheels require source builds, and neither
licensed COMSOL compatibility nor the `semantic-docs` extra is accepted there.

Perform a non-editable install:

```powershell
git clone https://github.com/garbage-enzyme/COMSOL_Multiphysics_MCP_6_4_Calibrated.git
Set-Location .\COMSOL_Multiphysics_MCP_6_4_Calibrated
D:\path\to\python-env\python.exe -m pip install .
Test-Path "D:\path\to\python-env\Scripts\comsol-mcp.exe"
Test-Path "D:\path\to\python-env\Scripts\comsol-mcp-settings.exe"
```

The wheel exposes the canonical `comsol_mcp` runtime and the solver-free
`settings_gui` application. The repository-only `src` compatibility namespace
is not installed. Configure the absolute installed server console entry point
for a portable deployment.

### Optional DeepSeek Harness bridge

For DeepSeek Harness only, this repository contains the repo-only Node.js
bridge at [`dsh_bridge/`](dsh_bridge/). It is excluded from the Python wheel
and sdist, does not change the standard MCP server, and does not replace COMSOL
ownership or durable job state. Node.js 20+ is required and the bridge has no
npm dependencies.

Run its solver-free checks and install the junction into the DSH web profile:

```powershell
npm test --prefix dsh_bridge
npm run smoke --prefix dsh_bridge
.\dsh_bridge\install.ps1
```

Then add the `comsol-bridge` Cordis entry documented in
[`dsh_bridge/README.md`](dsh_bridge/README.md), using the absolute installed
`comsol-mcp.exe`, runtime working directory, and shared settings path. The
bridge's own `config.enabled` Boolean controls whether the client plugin is
active. It is intentionally not a Settings GUI/server feature. Do not configure
a second `dsh-mcp-client` COMSOL entry in the same DSH session: the bridge owns
the single serialized stdio connection. Follow the versioned
[`DeepSeek compatibility contract`](dsh_bridge/DEEPSEEK_COMPATIBILITY.md) for
settings-change, verification, and recovery boundaries. Fake-server tests prove bridge behavior
only. Report real DSH discovery, cleanup, and licensed solves separately.
The current recovery checks cover original-session delivery on DSH 0.1.6-alpha.2
after explicit session persistence. Do not infer crash-proof notification
delivery from a successful mirror or tool registration.

## 2. Configure with the Settings GUI (recommended)

The Settings GUI is the normal configuration path for users. Open the installed
application before starting an MCP client, or ask an already connected agent to
call `settings.start` once:

```powershell
comsol-mcp-settings
# Bind the GUI to the same explicit file used by the MCP client when needed:
comsol-mcp-settings --settings-path "D:\settings\settings.json"
```

Use the GUI to choose the profile and feature gates, review discovered COMSOL
and Java paths, and set runtime, model-read, and artifact roots. Save the
settings, close the GUI, then restart the owning MCP client. The GUI and every
agent use one shared `settings.json`. There is no per-agent settings file. See
the [settings guide](docs/setting_guide/README.md) for every field's meaning,
default, and accepted values.

Direct JSON editing is an advanced path for developers, deployment automation,
and agents acting on an explicit user request. Ordinary users should not need to
hand-edit the checked-in template.

### Developer and agent JSON configuration (advanced)

The template contains every setting and its default. Removing a field restores
that field's safe default. An illegal value restores only that field's default
and is reported in `settings_errors`. Malformed JSON restores the complete safe
default document. Call `capabilities` or `evidence_integrity_status` after
startup and inspect `project_settings.configuration_state` and
`project_settings.settings_errors`.

For example, edit only the relevant grouped entries for a Wave Optics deployment:

```json
{
  "profile": { "name": "wave_optics" },
  "runtime": { "directory": "D:/comsol_runtime" },
  "paths": {
    "model_read_roots": ["D:/comsol_models"],
    "artifact_write_root": "D:/comsol_runtime/owned_artifacts"
  },
  "java": {
    "java_home": "D:/COMSOL64/Multiphysics/java/win64/jre",
    "jdk_home": "D:/COMSOL64/Multiphysics/java/win64/jre"
  }
}
```

The snippet is a partial edit, not a replacement document: keep the schema fields
and other required settings from the repository template. If a client does not preserve the
project path, pass one absolute locator variable and no per-setting variables:

```text
COMSOL_MCP_SETTINGS_PATH=D:\path\to\COMSOL_Multiphysics_MCP\settings.json
```

The old individual `COMSOL_MCP_*`, `COMSOL_SEMANTIC_*`, and Java variables remain
one-release compatibility overrides, but are not needed for a normal deployment
and are omitted from the checked-in examples.

For an installed package with no persistent file, `capabilities` reports:

```json
{
  "setup_required": true,
  "configuration_source": "bundled_template",
  "setup_methods": ["settings.start", "agent_edit"],
  "restart_required_after_change": true
}
```

For an ordinary user, call `settings.start` once, state that startup-setting
changes require restarting Codex or the owning MCP client, stop further task
output, and wait for the user's next message. Do not modify settings directly
while the GUI is open. Use agent JSON editing only when the user explicitly
requests it. Modify only the resolved writable file, validate it, and request
the restart.
The GUI writes `%LOCALAPPDATA%/comsol_mcp/settings.json` by default. The bundled
package file remains a read-only template. `comsol-mcp-settings` is the direct
console fallback. The MCP response asks agents to pause, but cannot technically
enforce arbitrary third-party behavior.

For an installed deployment, bind the independent executable to the exact shared
file. It works while every MCP stdio host is stopped:

```powershell
comsol-mcp-settings --settings-path "D:\settings\settings.json" --validate-only
comsol-mcp-settings --settings-path "D:\settings\settings.json"
comsol-mcp-settings --settings-path "D:\settings\settings.json" --create-desktop-shortcut
comsol-mcp-settings --settings-path "D:\settings\settings.json" --remove-desktop-shortcut
```

The opt-in per-user link is `COMSOL MCP Settings.lnk`. No install, deployment,
startup, first-launch, Save, or Apply path creates it automatically. A foreign
same-name item is preserved unless the user explicitly confirms replacement in
the GUI or adds `--replace-existing-shortcut` to the create command.

Confirmed first-run setup creates the Unicode-capable model-read directory
under `%LOCALAPPDATA%/comsol_mcp` and the ASCII-only runtime and owned-artifact
directories under `%PROGRAMDATA%/comsol_mcp`. Optional assets remain unset.

Before choosing a profile, choose how the simulation will run. The independent
[five execution modes guide](docs/simulation_execution_modes/README.md)
distinguishes `interactive`, `inline`, `launcher`, `standalone`, and `mphonly`.
A cross-device or cloud package requires the target operating system, COMSOL
build/modules, license, scheduler, storage, and output requirements first.

## 3. Select a profile

| Profile | Intended use |
| --- | --- |
| `core` | Compact default control plane and lexical manuals. |
| `basic_fem` | Conventional FEM construction, bounded exports, and the Python-free standalone launcher tools. |
| `wave_optics` | Periodic optics, metasurfaces, bounded field discovery/extraction, preflight, and evidence audits. |
| `experimental` | Explicit opt-in generic tools plus bounded robust-shape preview, durable submission, and evidence inspection/verification. |
| `full` | Broad non-feature compatibility surface. Not recommended by default. |

Select the profile in the Settings GUI. Developers and agents may set the
equivalent `profile.name` field in JSON. Omitting it selects `core`. The profile
is frozen when the stdio process starts, so changing it requires a
client/MCP-host restart. An invalid profile keeps `core` and is reported in
`settings_errors` instead of silently selecting another profile.

Profiles control COMSOL automation/simulation and future autonomous-exploration
tool visibility. In the GUI, independent feature gates can be combined with any
profile and with one another. Their advanced JSON equivalents are
`shared_server.enabled=true` for the protected shared workflow and
`semantic_docs.enabled=true` for isolated semantic retrieval. Both remain
default-off. The legacy `comsol_connect` compatibility tool remains experimental
and is not a substitute for this lifecycle.

The alpha7.2 robust-shape tools are available only in `experimental` and
`full`. `robust_shape_plan_preview` is solver-free. `robust_shape_job_submit`
uses the durable job authority and can start licensed solver work. The evidence
inspect/verify tools are bounded, path-redacted, and read-only. These tools are
absent from `core`, `basic_fem`, and `wave_optics`, and they do not expose a
generic Java/property mutation escape hatch.

The standalone tools in `basic_fem` still run inside the normal Python MCP host. They build
and control a separate native EXE whose target runtime needs only Windows
10/11 x64 plus an installed licensed COMSOL 6.4. The EXE does not bundle COMSOL
and does not require target-side Python, Conda, MPh, JPype, or external Java.
The build step uses the Windows inbox `.NET Framework 4.x` x64 compiler at
`%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe`. No separate modern
`.NET Runtime`, `.NET SDK`, Visual Studio, download, or network access is
required. A missing inbox compiler is a fail-closed prerequisite error.

### Optional shared Desktop/attached-Server mode

The shared-server feature never starts, stops, or terminates the user's COMSOL
Server.
Start COMSOL Multiphysics Server 6.4 manually with its persistent multi-client
option, record the local endpoint (normally port 2036), and connect the Desktop
client to that Server. In the Settings GUI, enable interactive shared-server
collaboration in the Profile tab. The equivalent advanced JSON configuration is:

```json
{
  "profile": { "name": "core" },
  "shared_server": { "enabled": true },
  "runtime": { "directory": "D:/comsol_mcp_runtime" }
}
```

After restarting the MCP host, call `capabilities` and verify the chosen live
profile, `enabled_features` contains `shared_server`, and
`shared_session.feature_enabled` and `shared_session.gate_open` are true. Call `shared_server_preflight` before
`shared_server_attach`. Pass `user_confirmed=true` only after the endpoint and
Desktop connection are correct. The attach path requires one exact 6.4.0.*
Server identity and one exact server-held model. It rejects starting/unready
servers, multiple GUI clients, ambiguous models, PID reuse, mixed release
families, and unclassified COMSOL/MPh processes without guessing.

The Desktop lower-left `localhost:2036` cue is useful user evidence, but it does
not replace process/listener identity checks. While MCP holds an
`automation_exclusive` lock, COMSOL may display an occupied-model warning and
disable GUI editing. This is expected. Unlock before detach. Detach preserves
the user-owned Server, listener, Desktop, model, and result. MCP does not call
`clear()` or shut down the external Server.

## 4. Claude Code (limited prior tests, incomplete 0.7.6 acceptance)

Claude Code officially supports local stdio MCP servers through `claude mcp
add`, user/local configuration in `~/.claude.json`, or a project-scoped
`.mcp.json`. The checked-in template is inactive until copied and edited:

```powershell
Copy-Item .\config\claude-code-mcp.example.json .\.mcp.json
# Replace every example path in .mcp.json with an absolute local path.
claude mcp list
claude mcp get comsol
```

Claude Code asks for approval before using a project-scoped `.mcp.json`. Do not
commit machine-specific executable, Java, runtime, credential, or model paths to
a shared project.

For a private user-scoped configuration instead of `.mcp.json`:

```powershell
claude mcp add --transport stdio --scope user `
  --env COMSOL_MCP_SETTINGS_PATH=D:\path\to\COMSOL_Multiphysics_MCP\settings.json `
  comsol -- 'D:\path\to\python-env\Scripts\comsol-mcp.exe'
```

All Claude options must precede the server name, and `--` separates the server
name from its executable and arguments. Use the in-session `/mcp` panel to
inspect connection status. The configuration deliberately uses an absolute
installed executable and an ASCII runtime root. It does not depend on Claude
Code's launch directory.

Claude Code's documented `.mcp.json` format has no project-specific field used
here to disable parallel calls. In the project `CLAUDE.md` or companion skill,
instruct Claude to call `capabilities`, `solver_status`, and `solver_preflight`
first and never issue COMSOL mutation or solver operations in parallel.

Complete template: `config/claude-code-mcp.example.json`. This configuration is
derived from the official [Claude Code MCP documentation](https://code.claude.com/docs/en/mcp),
but configuration guidance does not establish complete native compatibility for 0.7.6.
A client test must retain sanitized `initialize`, `list_tools`, `capabilities`, status, and cleanup evidence.

## 5. Hermes Agent (theoretical compatibility. Not yet tested)

Native Windows Hermes stores its default configuration at
`%LOCALAPPDATA%\hermes\config.yaml`. Linux and WSL use
`~/.hermes/config.yaml`.

```yaml
mcp_servers:
  comsol:
    command: "D:/path/to/python-env/Scripts/comsol-mcp.exe"
    args: []
    env:
      COMSOL_MCP_SETTINGS_PATH: "D:/path/to/COMSOL_Multiphysics_MCP/settings.json"
    connect_timeout: 120
    timeout: 3600
    supports_parallel_tool_calls: false
    idle_timeout_seconds: 0
    max_lifetime_seconds: 0
```

Hermes' documented stdio launcher passes `command`, `args`, and `env`, but does
not provide a working directory to the child process. Keep
`supports_parallel_tool_calls` false: COMSOL ownership and mutation must remain
serialized. Native Windows is the expected configuration for a Windows COMSOL
installation. Neither Hermes end-to-end operation nor a WSL-to-Windows COMSOL
bridge has been tested by this project. Test reports and pull requests with
sanitized discovery and cleanup receipts are welcome.

Complete template: `config/hermes-mcp.example.yaml`.

## 6. Codex CLI

Windows configuration: `%USERPROFILE%\.codex\config.toml`.
POSIX configuration: `~/.codex/config.toml`.

```toml
[mcp_servers.comsol]
command = 'D:\path\to\python-env\Scripts\comsol-mcp.exe'
args = []

[mcp_servers.comsol.env]
COMSOL_MCP_SETTINGS_PATH = 'D:\path\to\COMSOL_Multiphysics_MCP\settings.json'
```

Complete template: `config/codex-mcp.example.toml`.

## 7. opencode

Use a project `opencode.json`, or merge the entry into
`~/.config/opencode/opencode.json`.

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "comsol": {
      "type": "local",
      "command": ["D:\\path\\to\\python-env\\Scripts\\comsol-mcp.exe"],
      "environment": {
        "COMSOL_MCP_SETTINGS_PATH": "D:\\path\\to\\COMSOL_Multiphysics_MCP\\settings.json"
      }
    }
  }
}
```

Complete template: `config/opencode-mcp.example.json`.

## 8. Restart and verify

Restart Claude Code, Hermes, Codex, or opencode after changing the profile,
executable path, or installed package. Existing stdio hosts do not hot-load
these changes.

Call `capabilities` before starting COMSOL. A `wave_optics` deployment should
report:

```text
profile = wave_optics
active_profile = wave_optics
```

Use the returned registered-tool list and deployment hashes as authority. Do
not compare against a tool count copied from this guide.

Then call `solver_status` and `solver_preflight` before constructing a client.
Keep one solver owner. Use durable jobs for long simulations instead of holding a
single synchronous MCP call for the full wall time.

For a local stand-alone session, `comsol_start` returns an accepted response
before solver preflight, MPh import, or JPype JVM initialization. Poll
`comsol_status`. It exposes the bounded startup phases also persisted under the
configured runtime root.
The JVM may remain embedded in the MCP Python process, so the absence of a
separate COMSOL child process is not by itself a startup failure.

MPh permits only one client wrapper per Python process. Therefore
`comsol_disconnect` clears models and releases the solver lease but retains the
exact stand-alone wrapper for a later same-host `comsol_start`. It never creates
a second client. A 180-second startup timeout is terminal to callers. If the
native constructor is still blocked, status reports `cleanup_pending=true` and
the owned lease remains held until that call returns and cleanup is verified.
Do not retry start or restart the MCP host while cleanup is pending.

For shared Desktop work, verify that `capabilities` reports the chosen profile
unchanged and that shared-session tools are present only after the independent
feature flag is enabled.
Start and connect Desktop/Server first, then call `shared_server_preflight` and
`shared_server_attach` with explicit user confirmation. Do not call
`comsol_start` in this mode, and do not treat a successful attach as permission
to run parallel model mutations.

## 9. Updating an installation

After source changes:

```powershell
D:\path\to\python-env\python.exe -m pip install . --no-deps
```

Restart the exact MCP host and use `capabilities.deployment_identity` to verify
that the installed package and profile are the intended revision.
