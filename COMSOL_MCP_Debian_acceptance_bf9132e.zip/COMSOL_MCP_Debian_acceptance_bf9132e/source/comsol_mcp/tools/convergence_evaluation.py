"""MCP adapter for bounded solver-free convergence evaluation."""

from __future__ import annotations

import logging
from typing import Any, Optional

from mcp.server.mcpserver import MCPServer

from comsol_mcp.utils.public_errors import public_error

logger = logging.getLogger(__name__)


def register_convergence_evaluation_tools(mcp: MCPServer) -> None:
    """Register one read-only convergence evaluation tool."""

    @mcp.tool()
    def convergence_evaluate(
        convergence_policy: dict[str, Any],
        ladder_spec: Optional[dict[str, Any]] = None,
        convergence_ladder: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Compare an ordered configuration ladder at each level's own peak."""
        try:
            from comsol_mcp.evidence.convergence_evaluation import (
                build_convergence_ladder,
                evaluate_convergence,
                validate_convergence_ladder,
            )

            if (ladder_spec is None) == (convergence_ladder is None):
                raise ValueError("provide exactly one of ladder_spec or convergence_ladder")
            if ladder_spec is not None:
                ladder = build_convergence_ladder(**ladder_spec)
            else:
                ladder = validate_convergence_ladder(convergence_ladder)
            evaluation = evaluate_convergence(ladder, convergence_policy)
            return {
                "success": True,
                "scientific_disposition": evaluation["scientific_disposition"],
                "convergence_ladder": ladder,
                "convergence_evaluation": evaluation,
                "artifact_separation": {
                    "ordered_evidence": "convergence_ladder",
                    "policy_decision": "convergence_evaluation",
                },
                "fixed_reference_governs": False,
                "monotonicity_proves_convergence": False,
                "undeclared_configuration_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        except (ImportError, TypeError, ValueError) as exc:
            return {
                "success": False,
                "scientific_disposition": "invalid_evidence",
                "reason_code": "convergence_input_rejected",
                "error": str(exc)[:2048],
                "undeclared_configuration_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        except Exception:
            logger.exception("Convergence evaluation failed")
            return {
                **public_error(
                    "convergence_evaluation_failed",
                    "Convergence evaluation failed safely.",
                ),
                "scientific_disposition": "internal_error",
                "undeclared_configuration_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }


__all__ = ["register_convergence_evaluation_tools"]
