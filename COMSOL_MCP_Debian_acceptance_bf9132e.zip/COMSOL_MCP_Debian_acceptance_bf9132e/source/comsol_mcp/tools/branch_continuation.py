"""MCP adapter for bounded solver-free branch-continuation planning."""

from __future__ import annotations

import inspect
import logging
from typing import Any, Optional

from mcp.server.mcpserver import MCPServer

from comsol_mcp.utils.public_errors import public_error

logger = logging.getLogger(__name__)


def register_branch_continuation_tools(mcp: MCPServer) -> None:
    """Register one read-only branch-continuation planning tool."""

    @mcp.tool()
    def branch_continuation_plan(
        continuation_policy: dict[str, Any],
        states_spec: Optional[dict[str, Any]] = None,
        continuation_states: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Plan bounded per-coordinate continuation windows from spectral evidence."""
        try:
            from comsol_mcp.evidence.branch_continuation import (
                build_continuation_states,
                plan_branch_continuation,
                validate_continuation_states,
            )
        except Exception:
            logger.exception("Branch-continuation evidence module failed to import")
            return {
                **public_error(
                    "continuation_planning_failed",
                    "Branch-continuation planning failed safely.",
                ),
                "scientific_disposition": "internal_error",
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }

        try:
            if (states_spec is None) == (continuation_states is None):
                raise ValueError("provide exactly one of states_spec or continuation_states")
            if states_spec is not None:
                if not isinstance(states_spec, dict):
                    raise ValueError("states_spec must be an object")
                parameters = inspect.signature(build_continuation_states).parameters
                required = {
                    name
                    for name, parameter in parameters.items()
                    if parameter.default is inspect.Parameter.empty
                    and parameter.kind
                    in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
                }
                unknown = sorted(set(states_spec) - set(parameters))
                missing = sorted(required - set(states_spec))
                if unknown or missing:
                    raise ValueError(
                        f"invalid states_spec keys; unknown={unknown}, missing={missing}"
                    )
                states = build_continuation_states(**states_spec)
            else:
                states = validate_continuation_states(continuation_states)
        except ValueError as exc:
            return {
                "success": False,
                "scientific_disposition": "invalid_evidence",
                "reason_code": "continuation_input_rejected",
                "error": str(exc)[:2048],
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        except Exception:
            logger.exception("Branch-continuation evidence normalization failed")
            return {
                **public_error(
                    "continuation_planning_failed",
                    "Branch-continuation planning failed safely.",
                ),
                "scientific_disposition": "internal_error",
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        try:
            plan = plan_branch_continuation(states, continuation_policy)
            return {
                "success": True,
                "scientific_disposition": plan["scientific_disposition"],
                "continuation_states": states,
                "branch_continuation_plan": plan,
                "artifact_separation": {
                    "ordered_evidence": "continuation_states",
                    "policy_plan": "branch_continuation_plan",
                },
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        except ValueError as exc:
            return {
                "success": False,
                "scientific_disposition": "invalid_policy",
                "reason_code": "continuation_policy_rejected",
                "error": str(exc)[:2048],
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }
        except Exception:
            logger.exception("Branch-continuation planning failed")
            return {
                **public_error(
                    "continuation_planning_failed",
                    "Branch-continuation planning failed safely.",
                ),
                "scientific_disposition": "internal_error",
                "branch_disappearance_claimed": False,
                "undeclared_coordinate_started": False,
                "solver_started": False,
                "filesystem_modified": False,
            }


__all__ = ["register_branch_continuation_tools"]
