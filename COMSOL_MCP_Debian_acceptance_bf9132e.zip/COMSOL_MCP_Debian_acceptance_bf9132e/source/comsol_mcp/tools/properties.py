"""Constrained get/set access to properties on existing clientapi features."""

from __future__ import annotations

import re
from typing import Literal, Optional

from mcp.server.mcpserver import MCPServer

from .property_transport import JSONValue, normalize_property_value, validate_property_name
from .session import session_manager

ClientAPIContainer = Literal[
    "geometry_feature",
    "physics_feature",
    "mesh_feature",
    "study_step",
    "result_feature",
]

_CONTAINERS = frozenset(
    {
        "geometry_feature",
        "physics_feature",
        "mesh_feature",
        "study_step",
        "result_feature",
    }
)
_COMPONENT_SCOPED_CONTAINERS = frozenset(
    {
        "geometry_feature",
        "physics_feature",
        "mesh_feature",
    }
)
_TAG = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")

#: Declared value types whose reader is ``getStringArray`` rather than
#: ``getString``. Measured on COMSOL 6.4 against an ordinary geometry ``Block``,
#: whose ``input`` and ``posvertex`` properties are both declared ``Selection``.
#: Strings are matched on the normalized (lowercased) declared type.
_CONTAINER_PROPERTY_TYPES = frozenset({"selection"})


def _validate_target(
    component_name: str,
    container: str,
    feature_tag: str,
    property_name: str,
) -> tuple[str, str, str]:
    if not isinstance(component_name, str) or not _TAG.fullmatch(component_name):
        raise ValueError("component_name must be one exact clientapi tag")
    if container not in _CONTAINERS:
        raise ValueError(f"unsupported clientapi container: {container!r}")
    if not isinstance(feature_tag, str):
        raise TypeError("feature_tag must be a parent/child tag path")
    parts = feature_tag.split("/")
    if len(parts) != 2 or not all(_TAG.fullmatch(part) for part in parts):
        raise ValueError("feature_tag must be an exact parent/child tag path")
    validate_property_name(property_name)
    return parts[0], parts[1], property_name


def _resolve_existing_target(
    model,
    component_name: str,
    container: str,
    feature_tag: str,
    property_name: str,
):
    parent_tag, child_tag, property_name = _validate_target(
        component_name, container, feature_tag, property_name
    )
    jm = model.java
    component = None
    if container in _COMPONENT_SCOPED_CONTAINERS:
        component = jm.component(component_name)
        if component is None:
            raise ValueError(f"component does not exist: {component_name}")

    if container == "geometry_feature":
        parent = component.geom(parent_tag)
    elif container == "physics_feature":
        parent = component.physics(parent_tag)
    elif container == "mesh_feature":
        parent = component.mesh(parent_tag)
    elif container == "study_step":
        parent = jm.study(parent_tag)
    else:
        parent = jm.result(parent_tag)
    if parent is None:
        raise ValueError(f"clientapi parent does not exist: {container}:{parent_tag}")
    target = parent.feature().get(child_tag)
    if target is None:
        raise ValueError(f"clientapi target does not exist: {container}:{feature_tag}")

    try:
        property_names = {str(name) for name in target.properties()}
    except Exception as exc:
        raise ValueError(f"cannot inventory target properties: {exc}") from exc
    if property_name not in property_names:
        raise ValueError(f"unknown property {property_name!r} on {container}:{feature_tag}")
    return target


def _read_property(target, property_name: str) -> tuple[JSONValue, str]:
    try:
        value_type = str(target.getValueType(property_name))
    except Exception as exc:
        # Guessing "String" here would either mask the real failure or return
        # a stringified value under a wrong declared type; surface the cause.
        raise RuntimeError("clientapi property type read failed") from exc
    normalized_type = value_type.lower().replace("[]", "array")

    if "matrix" in normalized_type:
        if "double" in normalized_type or "float" in normalized_type:
            value = [[float(item) for item in row] for row in target.getDoubleMatrix(property_name)]
        elif "int" in normalized_type:
            value = [[int(item) for item in row] for row in target.getIntMatrix(property_name)]
        else:
            getter = target.getStringMatrix
            value = [[str(item) for item in row] for row in getter(property_name)]
    elif "array" in normalized_type:
        if "double" in normalized_type or "float" in normalized_type:
            value = [float(item) for item in target.getDoubleArray(property_name)]
        elif "int" in normalized_type:
            value = [int(item) for item in target.getIntArray(property_name)]
        elif "bool" in normalized_type:
            value = [bool(item) for item in target.getBooleanArray(property_name)]
        else:
            value = [str(item) for item in target.getStringArray(property_name)]
    elif "double" in normalized_type or "float" in normalized_type:
        value = float(target.getDouble(property_name))
    elif "int" in normalized_type:
        value = int(target.getInt(property_name))
    elif "bool" in normalized_type:
        value = bool(target.getBoolean(property_name))
    elif normalized_type in _CONTAINER_PROPERTY_TYPES:
        # Selection-valued properties are not strings: COMSOL rejects
        # ``getString`` with a FlException ("property 'input' cannot be converted
        # to a string"), which used to surface as an unexplained snapshot failure
        # on any geometry containing an ordinary Block, because every Block has an
        # ``input`` property of this kind. Measured on COMSOL 6.4: the supported
        # reader is ``getStringArray``, which returns the selection's entity
        # expressions (an empty list when nothing is selected). Reporting an empty
        # selection honestly is better than refusing to snapshot the feature.
        value = [str(item) for item in target.getStringArray(property_name)]
    else:
        value = str(target.getString(property_name))
    return normalize_property_value(value), value_type


def _exact_json_value_equal(left: JSONValue, right: JSONValue) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        # COMSOL returns doubles for Double properties, so a JSON integer
        # request reads back as 5.0; compare numerically instead of by type.
        return float(left) == float(right)
    if type(left) is not type(right):
        return False
    if isinstance(left, list):
        return len(left) == len(right) and all(
            _exact_json_value_equal(left_item, right_item)
            for left_item, right_item in zip(left, right, strict=True)
        )
    return left == right


def _attempt_restore(
    target, property_name: str, old_value: JSONValue, value_type: str
) -> tuple[bool, Optional[str]]:
    """Best-effort restore; returns (restored, failure_detail)."""
    try:
        target.set(property_name, old_value)
        restored_value, restored_type = _read_property(target, property_name)
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"[:300]
    restored = restored_type == value_type and _exact_json_value_equal(restored_value, old_value)
    return restored, (None if restored else "restored readback mismatch")


def _restore_property(target, property_name: str, old_value: JSONValue, value_type: str) -> bool:
    restored, _detail = _attempt_restore(target, property_name, old_value, value_type)
    return restored


def get_existing_property(
    model,
    component_name: str,
    container: str,
    feature_tag: str,
    property_name: str,
) -> dict:
    """Read one property without reflection or arbitrary method invocation."""
    try:
        target = _resolve_existing_target(
            model, component_name, container, feature_tag, property_name
        )
        value, value_type = _read_property(target, property_name)
        return {
            "success": True,
            "target": f"{component_name}/{container}/{feature_tag}/{property_name}",
            "container": container,
            "feature_tag": feature_tag,
            "property": property_name,
            "value": value,
            "value_type": value_type,
            "maturity": "experimental",
        }
    except (TypeError, ValueError) as exc:
        return {"success": False, "error": str(exc)}
    except Exception as exc:
        return {"success": False, "error": f"clientapi property read failed: {exc}"}


def set_existing_property(
    model,
    component_name: str,
    container: str,
    feature_tag: str,
    property_name: str,
    value: JSONValue,
) -> dict:
    """Set one existing property using only the fixed clientapi ``set`` method."""
    try:
        normalized_value = normalize_property_value(value)
        target = _resolve_existing_target(
            model, component_name, container, feature_tag, property_name
        )
        old_value, value_type = _read_property(target, property_name)
        try:
            target.set(property_name, normalized_value)
        except Exception:
            rolled_back, restore_error = _attempt_restore(
                target, property_name, old_value, value_type
            )
            payload = {
                "success": False,
                "error": "clientapi property set failed",
                "old_value": old_value,
                "rolled_back": rolled_back,
            }
            if restore_error:
                payload["rollback_error"] = restore_error
            return payload
        try:
            new_value, new_value_type = _read_property(target, property_name)
        except Exception as readback_exc:
            rolled_back, restore_error = _attempt_restore(
                target, property_name, old_value, value_type
            )
            payload = {
                "success": False,
                "error": f"clientapi property readback failed: {readback_exc}",
                "old_value": old_value,
                "rolled_back": rolled_back,
            }
            if restore_error:
                payload["rollback_error"] = restore_error
            return payload
        if new_value_type != value_type or not _exact_json_value_equal(new_value, normalized_value):
            rolled_back, restore_error = _attempt_restore(
                target, property_name, old_value, value_type
            )
            payload = {
                "success": False,
                "error": "clientapi property assignment did not match the requested value",
                "old_value": old_value,
                "observed_value": new_value,
                "rolled_back": rolled_back,
            }
            if restore_error:
                payload["rollback_error"] = restore_error
            return payload
        return {
            "success": True,
            "target": f"{component_name}/{container}/{feature_tag}/{property_name}",
            "container": container,
            "feature_tag": feature_tag,
            "property": property_name,
            "old_value": old_value,
            "new_value": new_value,
            "value_type": new_value_type,
            "maturity": "experimental",
            "warning": "This constrained setter mutates only the in-memory model.",
        }
    except (TypeError, ValueError) as exc:
        return {"success": False, "error": str(exc)}
    except Exception as exc:
        return {"success": False, "error": f"clientapi property set failed: {exc}"}


def register_property_tools(mcp: MCPServer) -> None:
    """Register constrained existing-object property tools."""

    @mcp.tool()
    def clientapi_property_get(
        model_name: str,
        component_name: str,
        container: ClientAPIContainer,
        feature_tag: str,
        property_name: str,
    ) -> dict:
        """Read one existing feature property from an exact parent/child tag path."""
        if not model_name.strip():
            return {"success": False, "error": "model_name must be exact and non-empty"}
        model = session_manager.get_model(model_name)
        if model is None:
            return {"success": False, "error": f"Model not found: {model_name}"}
        return get_existing_property(model, component_name, container, feature_tag, property_name)

    @mcp.tool()
    def clientapi_property_set(
        model_name: str,
        component_name: str,
        container: ClientAPIContainer,
        feature_tag: str,
        property_name: str,
        value: JSONValue,
    ) -> dict:
        """Set one existing property; cannot create, remove, run, save, or invoke methods."""
        if not model_name.strip():
            return {"success": False, "error": "model_name must be exact and non-empty"}
        model = session_manager.get_model(model_name)
        if model is None:
            return {"success": False, "error": f"Model not found: {model_name}"}
        return set_existing_property(
            model, component_name, container, feature_tag, property_name, value
        )


__all__ = [
    "ClientAPIContainer",
    "get_existing_property",
    "register_property_tools",
    "set_existing_property",
]
