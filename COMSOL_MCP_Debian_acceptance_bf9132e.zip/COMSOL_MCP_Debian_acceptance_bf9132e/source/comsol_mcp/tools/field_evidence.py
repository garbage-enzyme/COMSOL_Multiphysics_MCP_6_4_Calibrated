"""Public read-only discovery for bounded Wave Optics field datasets."""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from mcp.server.mcpserver import MCPServer

from comsol_mcp.evidence.field_bundle import (
    normalize_field_evidence_request,
    validate_field_evidence_request,
)
from comsol_mcp.evidence.field_dataset import collect_existing_dataset_field_evidence
from comsol_mcp.evidence.field_discovery import (
    discover_field_datasets,
    validate_field_discovery_limits,
)
from comsol_mcp.utils.public_errors import public_error

from .ownership import ownership_manager
from .session import session_manager

logger = logging.getLogger(__name__)

_NORMALIZED_REQUEST_MARKERS = frozenset(
    {
        "schema_name",
        "schema_version",
        "grid_point_count",
        "visual_review_state",
        "request_fingerprint",
    }
)


def _normalize_public_field_request(request: object) -> dict[str, Any]:
    if isinstance(request, dict) and _NORMALIZED_REQUEST_MARKERS & request.keys():
        return validate_field_evidence_request(request)
    return validate_field_evidence_request(normalize_field_evidence_request(request))


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _loaded_source_path(model: Any) -> Path:
    try:
        value = model.file()
    except Exception as exc:
        raise ValueError("loaded model source path is unavailable") from exc
    if value is None:
        raise ValueError("loaded model source path is unavailable")
    path = Path(str(value)).expanduser().resolve()
    if not path.is_file() or path.suffix.casefold() != ".mph":
        raise ValueError("loaded model source must be one existing MPH file")
    return path


def register_field_evidence_tools(mcp: MCPServer) -> None:
    """Register field-evidence tools that neither solve nor mutate a model."""

    @mcp.tool()
    def wave_optics_field_datasets(
        model_name: str,
        max_datasets: int = 64,
        max_components: int = 32,
    ) -> dict[str, Any]:
        """Discover exact MPh dataset names and clientapi tags on one loaded model."""
        if not isinstance(model_name, str) or not model_name.strip():
            return {"success": False, "error": "model_name must be exact and non-empty"}
        try:
            dataset_limit, component_limit = validate_field_discovery_limits(
                max_datasets=max_datasets,
                max_components=max_components,
            )
            ownership = session_manager.preflight_long_operation()
            if not ownership.get("ready"):
                return {
                    "success": False,
                    "error": (
                        "Complete owned-session preflight is required for field dataset discovery"
                    ),
                    "blockers": ownership.get("blockers", []),
                }
            model = session_manager.get_model(model_name)
            if model is None:
                return {"success": False, "error": f"Model not found: {model_name}"}
            result = discover_field_datasets(
                model,
                max_datasets=dataset_limit,
                max_components=component_limit,
            )
            return {
                "success": True,
                "model_name": model_name,
                "ownership_checked": True,
                "solver_started_by_tool": False,
                **result,
            }
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        except Exception as exc:
            return {
                "success": False,
                "error": f"Field dataset discovery failed safely: {type(exc).__name__}: {exc}",
            }

    @mcp.tool()
    def wave_optics_field_extract(
        model_name: str,
        request: dict[str, Any],
        view_id: str,
    ) -> dict[str, Any]:
        """Extract one existing solved dataset into an owned bounded NPZ manifest."""
        if not isinstance(model_name, str) or not model_name.strip():
            return {"success": False, "error": "model_name must be exact and non-empty"}
        try:
            normalized = _normalize_public_field_request(request)
            matches = [view for view in normalized["views"] if view["view_id"] == view_id]
            if len(matches) != 1:
                raise ValueError("view_id must identify exactly one requested view")
            view = matches[0]
            if view["source"]["kind"] != "existing_dataset":
                raise ValueError(
                    "public existing-dataset extraction cannot read a validation-matrix source"
                )
            if normalized["render"]["png"]:
                raise ValueError("PNG rendering is not yet public; request NPZ and manifest only")
            ownership = session_manager.preflight_long_operation()
            if not ownership.get("ready"):
                return {
                    "success": False,
                    "error": "Complete owned-session preflight is required for field extraction",
                    "blockers": ownership.get("blockers", []),
                }
            model = session_manager.get_model(model_name)
            if model is None:
                return {"success": False, "error": f"Model not found: {model_name}"}
            source_path = _loaded_source_path(model)
            source_before = _sha256_file(source_path)
            expected_source = view["source"]["source_model_sha256"]
            if source_before != expected_source:
                raise ValueError("loaded source SHA-256 does not match the field request")

            relative_root = Path("field_evidence") / normalized["request_fingerprint"]
            artifact_root = ownership_manager.runtime_dir / relative_root
            artifact_root.parent.mkdir(parents=True, exist_ok=True)
            if artifact_root.exists():
                return {
                    "success": True,
                    "model_name": model_name,
                    "artifact_root_id": relative_root.as_posix(),
                    "source_model_sha256": source_before,
                    "source_unchanged": True,
                    "already_present": True,
                    "ownership_checked": True,
                    "solver_started_by_tool": False,
                    "evaluation_skipped": True,
                }
            staging_root = Path(
                tempfile.mkdtemp(
                    prefix=f".{artifact_root.name}.stage-",
                    dir=artifact_root.parent,
                )
            )
            source_after = None
            try:
                result = collect_existing_dataset_field_evidence(
                    model=model,
                    request=normalized,
                    view_id=view_id,
                    artifact_root=staging_root,
                )
                source_after = _sha256_file(source_path)
                if source_after != source_before:
                    raise RuntimeError("loaded source changed during read-only field extraction")
                os.rename(staging_root, artifact_root)
            finally:
                source_hash_error = None
                if source_after is None:
                    try:
                        source_after = _sha256_file(source_path)
                    except Exception as exc:
                        source_hash_error = exc
                try:
                    if staging_root.exists():
                        shutil.rmtree(staging_root)
                finally:
                    if source_hash_error is not None:
                        raise RuntimeError(
                            "loaded source could not be revalidated after field extraction"
                        ) from source_hash_error
                    if source_after != source_before:
                        raise RuntimeError(
                            "loaded source changed during read-only field extraction"
                        )
            return {
                "success": True,
                "model_name": model_name,
                "artifact_root_id": relative_root.as_posix(),
                "source_model_sha256": source_before,
                "source_unchanged": True,
                "ownership_checked": True,
                "solver_started_by_tool": False,
                **result,
            }
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        except Exception:
            logger.exception("Field extraction backend failed")
            return public_error("field_extraction_failed", "Field extraction failed safely.")


__all__ = ["register_field_evidence_tools"]
