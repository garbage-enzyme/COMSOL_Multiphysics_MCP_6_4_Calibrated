"""Physics tools for COMSOL MCP Server."""

import math
from typing import Optional, Sequence

from mcp.server.mcpserver import MCPServer

from comsol_mcp.utils.validation import strict_json_integer

from .property_transport import validate_properties
from .session import session_manager

PHYSICS_TYPE_ALIASES = {
    "es": ("es", "Electrostatics"),
    "electrostatics": ("es", "Electrostatics"),
    "ec": ("ec", "ConductiveMedia"),
    "electriccurrents": ("ec", "ConductiveMedia"),
    "conductivemedia": ("ec", "ConductiveMedia"),
    "solid": ("solid", "SolidMechanics"),
    "solidmechanics": ("solid", "SolidMechanics"),
    "ht": ("ht", "HeatTransfer"),
    "heattransfer": ("ht", "HeatTransfer"),
    "spf": ("spf", "LaminarFlow"),
    "laminarflow": ("spf", "LaminarFlow"),
}

MULTIPHYSICS_REFERENCE_PROPERTIES = {
    "ThermalExpansion": ("Solid_physics", "Heat_physics"),
    "ElectromagneticHeatSource": ("EMHeat_physics", "Heat_physics"),
}

BOUNDARY_TYPE_ALIASES = {
    "temperature": "TemperatureBoundary",
    "temperatureboundary": "TemperatureBoundary",
    "heatflux": "HeatFluxBoundary",
    "heatfluxboundary": "HeatFluxBoundary",
}


def _first_component(jm):
    """Return the first component's Java object.

    COMSOL's ModelEntityList.get() requires a String tag, not an int index,
    so we iterate via tags() and pick the first one.
    """
    tags = list(jm.component().tags())
    if not tags:
        return None
    return jm.component().get(tags[0])


def _component_sdim(comp):
    """Get spatial dimension from a component's first geometry.

    The COMSOL client API's physics `create` requires the spatial dimension
    passed as a string (e.g. "3"). Component dimension is determined by the
    geometry sequence created on it via `geom().create(tag, sdim)`. If no
    geometry exists yet, default to "3" (3D).
    """
    try:
        geom_tags = list(comp.geom().tags())
        if geom_tags:
            return str(comp.geom(geom_tags[0]).getSDim())
    except Exception:  # noqa: S110 - spatial dimension falls back to the 3D default
        pass
    return "3"


def _resolve_geometry_tag(geom_list, geometry_name: Optional[str] = None) -> str:
    """Resolve a geometry name or first clientapi tag to a Python string."""
    if geometry_name:
        return str(geometry_name)
    tags = list(geom_list.tags())
    if not tags:
        raise ValueError("No geometries in component.")
    return str(tags[0])


def _find_physics_context(jm, physics_name):
    """Return ``(component, physics)`` by canonical type, label, or tag.

    COMSOL localizes default interface labels, so an English canonical name such
    as ``Electrostatics`` cannot be resolved reliably by comparing labels alone.
    Known interface aliases are therefore mapped to their stable clientapi tags.
    """
    requested = str(physics_name).strip()
    normalized = requested.replace(" ", "").replace("_", "").casefold()
    alias = PHYSICS_TYPE_ALIASES.get(normalized)
    candidate_tags = {requested}
    candidate_names = {normalized}
    if alias is not None:
        candidate_tags.add(alias[0])
        candidate_names.add(alias[1].replace(" ", "").replace("_", "").casefold())

    matches = []
    for comp_tag in jm.component().tags():
        comp = jm.component().get(comp_tag)
        for p_tag in comp.physics().tags():
            p = comp.physics().get(p_tag)
            tag = str(p.tag())
            label = str(p.label())
            normalized_label = label.replace(" ", "").replace("_", "").casefold()
            if tag in candidate_tags or label == requested or normalized_label in candidate_names:
                matches.append((comp, p))
    if len(matches) > 1:
        raise ValueError(
            f"Physics interface identifier is ambiguous across components: {physics_name}"
        )
    if matches:
        return matches[0]
    return None, None


def _find_physics_java(jm, physics_name):
    """Look up a physics node by label or tag across all components."""
    _, physics = _find_physics_context(jm, physics_name)
    return physics


def add_boundary_condition(
    model,
    physics_name: str,
    boundary_condition: str,
    boundary_selection: Sequence[int],
    *,
    properties: Optional[dict] = None,
    feature_tag: Optional[str] = None,
    feature_prefix: Optional[str] = None,
) -> dict:
    """Create a boundary feature with the required clientapi entity dimension."""
    try:
        boundaries = [
            strict_json_integer(value, "boundary_selection", minimum=1)
            for value in boundary_selection
        ]
        if not boundaries:
            raise ValueError("boundary_selection must not be empty")
        normalized_properties = validate_properties(properties)
    except (TypeError, ValueError) as exc:
        return {"success": False, "error": str(exc)}

    try:
        comp, physics = _find_physics_context(model.java, physics_name)
    except ValueError as exc:
        return {"success": False, "error": str(exc)}
    if physics is None:
        return {
            "success": False,
            "error": f"Physics interface not found: {physics_name}",
        }

    normalized = boundary_condition.replace(" ", "").casefold()
    feature_type = BOUNDARY_TYPE_ALIASES.get(normalized, boundary_condition)
    boundary_dim = max(int(_component_sdim(comp)) - 1, 0)
    feature_list = physics.feature()
    existing = {str(value) for value in list(feature_list.tags())}
    if feature_tag is not None:
        if feature_tag in existing:
            return {"success": False, "error": f"Physics feature tag already exists: {feature_tag}"}
        tag = feature_tag
    else:
        tag = _make_tag(feature_prefix or feature_type.lower(), feature_list)
    feature = feature_list.create(tag, feature_type, boundary_dim)
    try:
        feature.selection().set(boundaries)
        for name, value in normalized_properties.items():
            feature.set(name, value)
    except Exception:
        try:
            feature_list.remove(tag)
        except Exception:
            return {
                "success": False,
                "error": "Boundary setup failed and rollback was incomplete.",
                "rolled_back": False,
            }
        return {"success": False, "error": "Boundary setup failed.", "rolled_back": True}
    try:
        feature.label(f"{boundary_condition} (Boundaries {boundaries})")
    except Exception:  # noqa: S110 - labeling is cosmetic and must not fail setup
        pass

    result = {
        "success": True,
        "physics": physics_name,
        "boundary_condition": {
            "tag": tag,
            "type": feature_type,
            "requested_type": boundary_condition,
            "boundaries": boundaries,
            "properties": normalized_properties,
            "entity_dimension": boundary_dim,
        },
    }
    return result


def add_domain_feature(
    model,
    physics_name: str,
    feature_type: str,
    domain_selection: Sequence[int],
    *,
    properties: Optional[dict] = None,
    feature_tag: Optional[str] = None,
) -> dict:
    """Create a domain feature using its owning component's dimension."""
    try:
        domains = [
            strict_json_integer(value, "domain_selection", minimum=1) for value in domain_selection
        ]
        if not domains:
            raise ValueError("domain_selection must not be empty")
        normalized_properties = validate_properties(properties)
    except (TypeError, ValueError) as exc:
        return {"success": False, "error": str(exc)}

    try:
        comp, physics = _find_physics_context(model.java, physics_name)
    except ValueError as exc:
        return {"success": False, "error": str(exc)}
    if physics is None:
        return {
            "success": False,
            "error": f"Physics interface not found: {physics_name}",
        }

    sdim = int(_component_sdim(comp))
    feature_list = physics.feature()
    existing = {str(value) for value in list(feature_list.tags())}
    if feature_tag is not None:
        if feature_tag in existing:
            return {
                "success": False,
                "error": f"Physics feature tag already exists: {feature_tag}",
            }
        tag = feature_tag
    else:
        tag = _make_tag(feature_type.lower(), feature_list)
    feature = feature_list.create(tag, feature_type, sdim)
    try:
        feature.selection().set(domains)
        for name, value in normalized_properties.items():
            feature.set(name, value)
    except Exception:
        try:
            feature_list.remove(tag)
        except Exception:
            return {
                "success": False,
                "error": "Domain feature setup failed and rollback was incomplete.",
                "rolled_back": False,
            }
        return {
            "success": False,
            "error": "Domain feature setup failed.",
            "rolled_back": True,
        }

    result = {
        "success": True,
        "domain_feature": {
            "tag": tag,
            "type": feature_type,
            "physics": physics_name,
            "selection": domains,
            "properties": normalized_properties,
            "sdim": sdim,
        },
    }
    return result


def assign_material(
    model,
    physics_name: str,
    material_name: str,
    *,
    domain_selection: Optional[Sequence[int]] = None,
    properties: Optional[dict] = None,
) -> dict:
    """Create or reuse a material in the target physics component."""
    try:
        if not isinstance(material_name, str) or not material_name.strip():
            raise ValueError("material_name must not be empty")
        domains = (
            [
                strict_json_integer(value, "domain_selection", minimum=1)
                for value in domain_selection
            ]
            if domain_selection is not None
            else []
        )
        normalized_properties = validate_properties(properties)
        comp, physics = _find_physics_context(model.java, physics_name)
    except (TypeError, ValueError) as exc:
        return {"success": False, "error": str(exc)}
    if physics is None:
        return {
            "success": False,
            "error": f"Physics interface not found: {physics_name}",
        }

    material_list = comp.material()
    material = None
    material_tag = None
    for tag in list(material_list.tags()):
        node = material_list.get(tag)
        try:
            label = str(node.label())
        except Exception:
            label = str(tag)
        if str(tag) == material_name or label == material_name:
            material = node
            material_tag = str(tag)
            break

    created = False
    if material is None:
        if not normalized_properties:
            return {
                "success": False,
                "error": (
                    f"Material not found: {material_name}. Explicit physical "
                    "properties are required to create a Common material."
                ),
            }
        base_tag = material_name.replace(" ", "_").replace("-", "_") or "mat"
        existing = {str(tag) for tag in material_list.tags()}
        material_tag = base_tag
        index = 2
        while material_tag in existing:
            material_tag = f"{base_tag}{index}"
            index += 1
        material = material_list.create(material_tag, "Common")
        created = True

    try:
        if created:
            material.label(material_name)
        if domains:
            material.selection().set(domains)
        if normalized_properties:
            group = material.propertyGroup("def")
            for name, value in normalized_properties.items():
                try:
                    group.set(name, [value])
                except Exception:
                    group.set(name, value)
    except Exception:
        if created:
            try:
                material_list.remove(material_tag)
            except Exception:
                return {
                    "success": False,
                    "error": "Material assignment failed and rollback was incomplete.",
                    "rolled_back": False,
                }
            return {
                "success": False,
                "error": "Material assignment failed.",
                "rolled_back": True,
            }
        return {
            "success": False,
            "error": "Existing material assignment failed.",
            "rolled_back": False,
        }

    result = {
        "success": True,
        "material": material_name,
        "material_tag": material_tag,
        "physics": physics_name,
        "component": str(comp.tag()),
        "domain_selection": domains or "all",
        "created": created,
        "message": f"Material '{material_name}' assigned to physics '{physics_name}'",
    }
    return result


def add_multiphysics_coupling(
    model,
    coupling_type: str,
    physics_list: Sequence[str],
) -> dict:
    """Create a coupling through the owning component's clientapi list."""
    if not coupling_type.strip():
        return {"success": False, "error": "coupling_type must not be empty."}
    if len(physics_list) < 2:
        return {"success": False, "error": "physics_list must contain at least two interfaces."}

    reference_properties = MULTIPHYSICS_REFERENCE_PROPERTIES.get(coupling_type)
    if reference_properties is None:
        return {
            "success": False,
            "error": f"Unsupported multiphysics coupling type: {coupling_type}",
        }
    if len(physics_list) != len(reference_properties):
        return {
            "success": False,
            "error": (
                f"{coupling_type} requires {len(reference_properties)} physics "
                "interfaces in documented reference-property order."
            ),
        }

    resolved = []
    owner = None
    owner_tag = None
    for identifier in physics_list:
        try:
            comp, physics = _find_physics_context(model.java, identifier)
        except ValueError as exc:
            return {"success": False, "error": str(exc)}
        if physics is None:
            return {
                "success": False,
                "error": f"Physics interface not found: {identifier}",
            }
        comp_tag = str(comp.tag())
        if owner is None:
            owner = comp
            owner_tag = comp_tag
        elif comp_tag != owner_tag:
            return {
                "success": False,
                "error": "All coupled physics interfaces must belong to the same component.",
            }
        resolved.append(str(physics.tag()))

    coupling_list = owner.multiphysics()
    existing = {str(tag) for tag in coupling_list.tags()}
    index = 1
    tag = f"mp{index}"
    while tag in existing:
        index += 1
        tag = f"mp{index}"
    dimension = int(_component_sdim(owner))
    coupling = coupling_list.create(tag, coupling_type, dimension)
    try:
        for property_name, physics_tag in zip(reference_properties, resolved, strict=True):
            coupling.set(property_name, physics_tag)
            if str(coupling.getString(property_name)) != physics_tag:
                raise ValueError(f"Multiphysics reference readback mismatch: {property_name}")
    except Exception:
        try:
            coupling_list.remove(tag)
        except Exception:
            return {
                "success": False,
                "error": "Multiphysics coupling setup failed and rollback was incomplete.",
                "rolled_back": False,
            }
        return {
            "success": False,
            "error": "Multiphysics coupling setup failed.",
            "rolled_back": True,
        }
    try:
        label = str(coupling.label())
    except Exception:
        label = coupling_type
    return {
        "success": True,
        "coupling": {
            "tag": tag,
            "label": label,
            "type": coupling_type,
            "component": owner_tag,
            "physics": resolved,
            "physics_references": dict(zip(reference_properties, resolved, strict=True)),
            "entity_dimension": dimension,
        },
    }


def setup_flow_boundaries(
    model,
    physics_name: str,
    inlet_boundaries: Sequence[int],
    outlet_boundaries: Sequence[int],
    *,
    inlet_velocity: str = "1[mm/s]",
    outlet_pressure: str = "0",
) -> dict:
    """Create per-boundary inlet and outlet features through clientapi."""
    configured = {"inlets": [], "outlets": []}
    created_tags: list[str] = []
    for boundary in inlet_boundaries:
        result = add_boundary_condition(
            model,
            physics_name,
            "InletBoundary",
            [boundary],
            properties={"U0": inlet_velocity},
            feature_prefix="inl",
        )
        if not result["success"]:
            return _rollback_composite_features(model, physics_name, created_tags, result)
        created_tags.append(result["boundary_condition"]["tag"])
        configured["inlets"].append(
            {
                "tag": result["boundary_condition"]["tag"],
                "boundary": int(boundary),
                "velocity": inlet_velocity,
            }
        )
    for boundary in outlet_boundaries:
        result = add_boundary_condition(
            model,
            physics_name,
            "OutletBoundary",
            [boundary],
            properties={"p0": outlet_pressure},
            feature_prefix="out",
        )
        if not result["success"]:
            return _rollback_composite_features(model, physics_name, created_tags, result)
        created_tags.append(result["boundary_condition"]["tag"])
        configured["outlets"].append(
            {
                "tag": result["boundary_condition"]["tag"],
                "boundary": int(boundary),
                "pressure": outlet_pressure,
            }
        )
    return {
        "success": True,
        "physics": physics_name,
        "configured_boundaries": configured,
        "inlet_velocity": inlet_velocity,
        "outlet_pressure": outlet_pressure,
    }


def setup_heat_boundaries(
    model,
    physics_name: str,
    *,
    heat_flux_boundaries: Sequence[int] = (),
    temperature_boundaries: Sequence[int] = (),
    convection_boundaries: Sequence[int] = (),
    heat_flux_value: str = "1e6[W/m^2]",
    temperature_value: str = "293.15[K]",
    convection_coeff: str = "10[W/(m^2*K)]",
    ambient_temp: str = "293.15[K]",
) -> dict:
    """Create per-boundary heat-transfer features through clientapi."""
    configured = {"heat_flux": [], "temperature": [], "convection": []}
    created_tags: list[str] = []
    specifications = (
        (
            "heat_flux",
            heat_flux_boundaries,
            "HeatFluxBoundary",
            "hf",
            {"q0": heat_flux_value},
            {"heat_flux": heat_flux_value},
        ),
        (
            "temperature",
            temperature_boundaries,
            "TemperatureBoundary",
            "temp",
            {"T0": temperature_value},
            {"temperature": temperature_value},
        ),
        (
            "convection",
            convection_boundaries,
            "ConvectiveHeatFlux",
            "conv",
            {"h": convection_coeff, "Text": ambient_temp},
            {"h": convection_coeff, "T_amb": ambient_temp},
        ),
    )
    for key, boundaries, feature_type, prefix, properties, output_values in specifications:
        for boundary in boundaries:
            result = add_boundary_condition(
                model,
                physics_name,
                feature_type,
                [boundary],
                properties=properties,
                feature_prefix=prefix,
            )
            if not result["success"]:
                return _rollback_composite_features(model, physics_name, created_tags, result)
            created_tags.append(result["boundary_condition"]["tag"])
            configured[key].append(
                {
                    "tag": result["boundary_condition"]["tag"],
                    "boundary": int(boundary),
                    **output_values,
                }
            )
    return {
        "success": True,
        "physics": physics_name,
        "configured_boundaries": configured,
        "summary": {
            "heat_flux_boundaries": len(heat_flux_boundaries),
            "temperature_boundaries": len(temperature_boundaries),
            "convection_boundaries": len(convection_boundaries),
        },
    }


def _rollback_composite_features(model, physics_name, tags, failure):
    try:
        physics = _find_physics_java(model.java, physics_name)
    except ValueError:
        physics = None
    rolled_back = True
    if physics is None:
        rolled_back = False
    else:
        for tag in reversed(tags):
            try:
                physics.feature().remove(tag)
            except Exception:
                rolled_back = False
    return {**failure, "composite_rolled_back": rolled_back}


def _make_tag(prefix, feature_list):
    """Generate the first unused tag from the live feature inventory."""
    existing = {str(value) for value in list(feature_list.tags())}
    index = 1
    while f"{prefix}_{index}" in existing:
        index += 1
    return f"{prefix}_{index}"


def _physics_spec(physics_type: str) -> tuple[str, str]:
    """Return the conventional tag prefix and clientapi interface type."""
    normalized = physics_type.replace(" ", "").replace("_", "").casefold()
    if normalized in PHYSICS_TYPE_ALIASES:
        return PHYSICS_TYPE_ALIASES[normalized]
    tag = physics_type.replace(" ", "_").lower()
    return tag, physics_type


def add_physics_interface(
    model,
    physics_type: str,
    *,
    component_name: Optional[str] = None,
    domain_selection: Optional[str] = None,
) -> dict:
    """Add a physics interface with alias normalization for clientapi."""
    try:
        if not isinstance(physics_type, str) or not physics_type.strip():
            raise ValueError("physics_type must not be empty")
        if domain_selection is not None and (
            not isinstance(domain_selection, str) or not domain_selection.strip()
        ):
            raise ValueError("domain_selection must be a nonempty string")
    except ValueError as exc:
        return {"success": False, "error": str(exc)}

    jm = model.java
    comp = jm.component(component_name) if component_name else _first_component(jm)
    if comp is None:
        return {"success": False, "error": f"Component not found: {component_name}"}

    tag_prefix, interface_type = _physics_spec(physics_type)
    existing = {str(tag) for tag in comp.physics().tags()}
    tag = tag_prefix
    index = 2
    while tag in existing:
        tag = f"{tag_prefix}{index}"
        index += 1

    physics_list = comp.physics()
    physics_java = physics_list.create(tag, interface_type, _component_sdim(comp))
    try:
        if domain_selection is not None:
            physics_java.selection().set(domain_selection)
    except Exception:
        try:
            physics_list.remove(tag)
        except Exception:
            return {
                "success": False,
                "error": "Physics interface setup failed and rollback was incomplete.",
                "rolled_back": False,
            }
        return {
            "success": False,
            "error": "Physics interface setup failed.",
            "rolled_back": True,
        }
    return {
        "success": True,
        "physics": {
            "name": (
                str(physics_java.label()) if hasattr(physics_java, "label") else interface_type
            ),
            "type": interface_type,
            "requested_type": physics_type,
            "tag": tag,
            "component": str(comp.tag()),
            "domain_selection": domain_selection,
        },
    }


def add_electrostatics_interface(
    model,
    *,
    domain_selection: Optional[str] = None,
    relpermittivity: Optional[float] = None,
    domain_numbers: Optional[Sequence[int]] = None,
) -> dict:
    """Create Electrostatics and optional dielectric nodes as one transaction."""
    try:
        domains = (
            [strict_json_integer(value, "domain_numbers", minimum=1) for value in domain_numbers]
            if domain_numbers is not None
            else []
        )
        if domain_selection is not None and (
            not isinstance(domain_selection, str) or not domain_selection.strip()
        ):
            raise ValueError("domain_selection must be a nonempty string")
        if relpermittivity is not None:
            if (
                isinstance(relpermittivity, bool)
                or not isinstance(relpermittivity, (int, float))
                or not math.isfinite(float(relpermittivity))
                or float(relpermittivity) <= 0.0
            ):
                raise ValueError("relpermittivity must be positive and finite")
            permittivity = float(relpermittivity)
        else:
            permittivity = None
    except ValueError as exc:
        return {"success": False, "error": str(exc)}

    comp = _first_component(model.java)
    if comp is None:
        return {"success": False, "error": "No component found in model."}
    if "es" in {str(value) for value in list(comp.physics().tags())}:
        return {"success": False, "error": "Physics tag already exists: es"}
    mat_tag = "mat_es"
    if permittivity is not None and mat_tag in {
        str(value) for value in list(comp.material().tags())
    }:
        return {"success": False, "error": f"Material tag already exists: {mat_tag}"}

    physics_created = False
    material_created = False
    try:
        physics_java = comp.physics().create("es", "Electrostatics", _component_sdim(comp))
        physics_created = True
        if domain_selection:
            physics_java.selection().set(domain_selection)
        ccn_info = None
        if permittivity is not None:
            material = comp.material().create(mat_tag, "Common")
            material_created = True
            material.label(f"dielectric_epsr_{permittivity}")
            material.propertyGroup("def").set("relpermittivity", str(permittivity))
            if domains:
                material.selection().set(domains)
            ccn = physics_java.feature().create(
                "ccn1", "ChargeConservation", int(_component_sdim(comp))
            )
            if domains:
                ccn.selection().set(domains)
            ccn.set("materialType", "from_mat")
            ccn_info = {
                "tag": "ccn1",
                "type": "ChargeConservation",
                "materialType": "from_mat",
                "relpermittivity": permittivity,
                "material_tag": mat_tag,
                "domain_numbers": domains or "all",
            }
        return {
            "success": True,
            "physics": {
                "name": str(physics_java.label()),
                "type": "Electrostatics",
                "tag": "es",
                "domain_selection": domain_selection,
                "charge_conservation": ccn_info,
            },
        }
    except Exception:
        rolled_back = True
        if material_created:
            try:
                comp.material().remove(mat_tag)
            except Exception:
                rolled_back = False
        if physics_created:
            try:
                comp.physics().remove("es")
            except Exception:
                rolled_back = False
        return {
            "success": False,
            "error": "Electrostatics setup failed.",
            "rolled_back": rolled_back,
        }


def list_physics_features(model, physics_name: str) -> dict:
    """List physics child features through clientapi tags and labels."""
    physics = _find_physics_java(model.java, physics_name)
    if physics is None:
        return {
            "success": False,
            "error": f"Physics interface not found: {physics_name}",
        }

    features = []
    feature_list = physics.feature()
    for raw_tag in list(feature_list.tags()):
        tag = str(raw_tag)
        feature = feature_list.get(tag)
        info = {"tag": tag}
        try:
            info["label"] = str(feature.label())
        except Exception:
            info["label"] = tag
        try:
            info["selection"] = list(feature.selection().entities())
        except Exception:
            info["selection"] = None
        features.append(info)

    return {
        "success": True,
        "physics": physics_name,
        "features": features,
        "count": len(features),
    }


def remove_physics_interface(model, physics_name: str) -> dict:
    """Remove a physics interface by tag or label through clientapi."""
    jm = model.java
    available = []
    for raw_component_tag in list(jm.component().tags()):
        component_tag = str(raw_component_tag)
        component = jm.component().get(component_tag)
        physics_list = component.physics()
        for raw_tag in list(physics_list.tags()):
            tag = str(raw_tag)
            physics = physics_list.get(tag)
            try:
                label = str(physics.label())
            except Exception:
                label = tag
            available.append({"component": component_tag, "tag": tag, "label": label})
            if physics_name in {tag, label}:
                physics_list.remove(tag)
                return {
                    "success": True,
                    "removed": tag,
                    "label": label,
                    "component": component_tag,
                }
    return {
        "success": False,
        "error": f"Physics interface not found: {physics_name}",
        "available": available,
    }


PHYSICS_INTERFACES = {
    "AC/DC": {
        "electrostatic": "Electrostatics (es)",
        "electric_currents": "Electric Currents (ec)",
        "magnetic_fields": "Magnetic Fields (mf)",
        "electromagnetic_waves": "Electromagnetic Waves (emw)",
    },
    "Structural": {
        "solid_mechanics": "Solid Mechanics (solid)",
        "shell": "Shell (shell)",
        "beam": "Beam (beam)",
        "membrane": "Membrane (memb)",
    },
    "Heat Transfer": {
        "heat_transfer": "Heat Transfer in Solids (ht)",
        "conjugate_ht": "Conjugate Heat Transfer (cht)",
        "radiation": "Radiation (rad)",
    },
    "Fluid Flow": {
        "laminar_flow": "Laminar Flow (spf)",
        "turbulent_flow": "Turbulent Flow (spf)",
        "creeping_flow": "Creeping Flow (brinkman)",
    },
    "Acoustics": {
        "pressure_acoustics": "Pressure Acoustics (acpr)",
        "thermoacoustics": "Thermoacoustics (ta)",
    },
    "Chemical": {
        "transport_diluted": "Transport of Diluted Species (tds)",
        "reaction_engineering": "Reaction Engineering (re)",
    },
    "Optics": {
        "ray_optics": "Geometrical Optics (gop)",
        "wave_optics": "Wave Optics (ewfd)",
    },
    "Multiphysics": {
        "thermal_stress": "Thermal Stress (ts)",
        "fluid_structure": "Fluid-Structure Interaction (fsi)",
        "electromechanical": "Electromechanical Forces",
        "joule_heating": "Joule Heating (jh)",
    },
}


def register_physics_tools(mcp: MCPServer) -> None:
    """Register physics tools with the MCP server."""

    @mcp.tool()
    def physics_list(model_name: Optional[str] = None) -> dict:
        """
        List all physics interfaces defined in a model.

        Args:
            model_name: Model name (default: current model)

        Returns:
            List of physics interface names
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            physics = model.physics()
            multiphysics = model.multiphysics()

            return {
                "success": True,
                "physics": physics,
                "multiphysics": multiphysics,
                "physics_count": len(physics),
                "multiphysics_count": len(multiphysics),
            }
        except Exception as e:
            return {"success": False, "error": f"Failed to list physics: {str(e)}"}

    @mcp.tool()
    def physics_get_available() -> dict:
        """
        Get a list of available physics interfaces organized by category.

        Returns:
            Dictionary of physics categories and their interfaces
        """
        return {
            "success": True,
            "interfaces": PHYSICS_INTERFACES,
            "note": "Interface identifiers (in parentheses) are used when adding physics.",
        }

    @mcp.tool()
    def physics_add(
        physics_type: str, component_name: Optional[str] = None, model_name: Optional[str] = None
    ) -> dict:
        """
        Add a physics interface to the model.

        Common physics types:
        - "Electrostatics" or "es": Electrostatic field analysis
        - "ElectricCurrents" or "ec": Electric current conduction
        - "SolidMechanics" or "solid": Structural stress analysis
        - "HeatTransfer" or "ht": Heat transfer in solids
        - "LaminarFlow" or "spf": Fluid dynamics

        Args:
            physics_type: Type identifier (e.g., "Electrostatics", "es")
            component_name: Component to add physics to (default: first component)
            model_name: Model name (default: current model)

        Returns:
            Created physics interface info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_physics_interface(
                model,
                physics_type,
                component_name=component_name,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add physics: {str(e)}"}

    @mcp.tool()
    def physics_add_electrostatics(
        domain_selection: Optional[str] = None,
        relpermittivity: Optional[float] = None,
        domain_numbers: Optional[Sequence[int]] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Add Electrostatics physics interface for electric field analysis.

        In COMSOL 6.3+/6.4 the Electrostatics interface defaults to a FreeSpace
        domain feature that uses vacuum permittivity and IGNORES material
        relpermittivity. To model a dielectric, pass relpermittivity (e.g. 2.1)
        and this tool will automatically create a ChargeConservation feature
        plus a material node so the value takes effect.

        Args:
            domain_selection: Selection name for domains (default: all domains)
            relpermittivity: Relative permittivity eps_r (e.g. 2.1). If given,
                a ChargeConservation feature + material are created automatically.
            domain_numbers: Domain numbers to assign the dielectric to (default: all)
            model_name: Model name (default: current model)

        Returns:
            Created physics info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_electrostatics_interface(
                model,
                domain_selection=domain_selection,
                relpermittivity=relpermittivity,
                domain_numbers=domain_numbers,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add Electrostatics: {str(e)}"}

    @mcp.tool()
    def physics_add_solid_mechanics(
        domain_selection: Optional[str] = None, model_name: Optional[str] = None
    ) -> dict:
        """
        Add Solid Mechanics physics for structural analysis.

        Args:
            domain_selection: Selection name for domains (default: all domains)
            model_name: Model name (default: current model)

        Returns:
            Created physics info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_physics_interface(
                model,
                "SolidMechanics",
                domain_selection=domain_selection,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add Solid Mechanics: {str(e)}"}

    @mcp.tool()
    def physics_add_heat_transfer(
        domain_selection: Optional[str] = None, model_name: Optional[str] = None
    ) -> dict:
        """
        Add Heat Transfer physics for thermal analysis.

        Args:
            domain_selection: Selection name for domains (default: all domains)
            model_name: Model name (default: current model)

        Returns:
            Created physics info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_physics_interface(
                model,
                "HeatTransfer",
                domain_selection=domain_selection,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add Heat Transfer: {str(e)}"}

    @mcp.tool()
    def physics_add_laminar_flow(
        domain_selection: Optional[str] = None, model_name: Optional[str] = None
    ) -> dict:
        """
        Add Laminar Flow physics for fluid dynamics.

        Args:
            domain_selection: Selection name for domains (default: all domains)
            model_name: Model name (default: current model)

        Returns:
            Created physics info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_physics_interface(
                model,
                "LaminarFlow",
                domain_selection=domain_selection,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add Laminar Flow: {str(e)}"}

    @mcp.tool()
    def physics_add_domain_feature(
        physics_name: str,
        feature_type: str,
        domain_selection: Sequence[int],
        properties: Optional[dict] = None,
        feature_tag: Optional[str] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Add a domain feature (e.g. ChargeConservation) to a physics interface.

        In COMSOL 6.3+/6.4 several physics interfaces ship with a default domain
        feature that ignores material properties. For Electrostatics the
        default is FreeSpace (fsp1, vacuum eps0); to use a dielectric you must
        add a ChargeConservation feature:
            feature_type="ChargeConservation", properties={"materialType": "from_mat"}
        or hardcode the relative permittivity:
            properties={"epsilonr": "2.1"}  (requires materialType != from_mat)

        Common domain feature types:
        - Electrostatics: "ChargeConservation"
        - Heat Transfer: "Solid", "Fluid", "ThinLayer"
        - Solid Mechanics: "LinearElasticMaterial", "RigidDomain"

        Args:
            physics_name: Name or label of the physics interface
            feature_type: Domain feature type (e.g. "ChargeConservation")
            domain_selection: Domain numbers to apply the feature to
            properties: Dictionary of property names and values
            feature_tag: Tag for the feature (auto-generated if None)
            model_name: Model name (default: current model)

        Returns:
            Created domain feature info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_domain_feature(
                model,
                physics_name,
                feature_type,
                domain_selection,
                properties=properties,
                feature_tag=feature_tag,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add domain feature: {str(e)}"}

    @mcp.tool()
    def physics_configure_boundary(
        physics_name: str,
        boundary_condition: str,
        boundary_selection: Sequence[int],
        properties: Optional[dict] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Configure a boundary condition for a physics interface.

        Common boundary conditions for Heat Transfer:
        - "Temperature": Fixed temperature
        - "HeatFlux": Heat flux boundary
        - "ConvectiveHeatFlux": Convection cooling
        - "ThermalInsulation": Thermal insulation (adiabatic)

        Common for Solid Mechanics:
        - "Fixed": Fixed constraint
        - "Roller": Roller constraint
        - "Symmetry": Symmetry plane
        - "BoundaryLoad": Applied force/pressure

        Common for Electrostatics:
        - "Ground": Zero potential boundary
        - "ElectricPotential": Specified voltage
        - "SurfaceChargeDensity": Surface charge
        - "ZeroCharge": Zero normal displacement field

        Args:
            physics_name: Name or label of the physics interface
            boundary_condition: Type of boundary condition (e.g. "Temperature", "HeatFlux")
            boundary_selection: Boundary/edge numbers to apply condition to
            properties: Dictionary of property names and values (e.g. {"T0": "293.15[K]"})
            model_name: Model name (default: current model)

        Returns:
            Created boundary condition info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        properties = properties or {}

        try:
            return add_boundary_condition(
                model,
                physics_name,
                boundary_condition,
                boundary_selection,
                properties=properties,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to configure boundary: {str(e)}"}

    @mcp.tool()
    def physics_set_material(
        physics_name: str,
        material_name: str,
        domain_selection: Optional[Sequence[int]] = None,
        properties: Optional[dict] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Assign a material to physics domains.

        Existing materials are reused by tag or label. Creating a missing
        Common material requires explicit ``properties``; this tool does not
        import from COMSOL's built-in material libraries. Supplied values are
        written into the material's Basic property group (tag ``def``) so
        domain features with ``materialType=from_mat`` will use them.

        Recognised property names (Heat Transfer / Electrostatics):
        - "thermalconductivity": e.g. "130[W/(m*K)]"
        - "density":              e.g. "2329[kg/m^3]"
        - "heatcapacity":         e.g. "700[J/(kg*K)]"
        - "relpermittivity":      e.g. "2.1"   (Electrostatics)

        Args:
            physics_name: Name of the physics interface
            material_name: Name of the material (e.g. "Silicon", "Steel AISI 4340", "Copper")
            domain_selection: Domain numbers (default: all domains for this physics)
            properties: Optional dict of Basic material properties to write
            model_name: Model name (default: current model)

        Returns:
            Assignment confirmation
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return assign_material(
                model,
                physics_name,
                material_name,
                domain_selection=domain_selection,
                properties=properties,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to set material: {str(e)}"}

    @mcp.tool()
    def multiphysics_add(
        coupling_type: str, physics_list: Sequence[str], model_name: Optional[str] = None
    ) -> dict:
        """
        Add a multiphysics coupling between physics interfaces.

        Supported coupling types and required physics_list order:
        - "ThermalExpansion": Solid Mechanics, then Heat Transfer
        - "ElectromagneticHeatSource": electromagnetic heating, then Heat Transfer

        Args:
            coupling_type: Type of multiphysics coupling
            physics_list: Names of physics interfaces to couple
            model_name: Model name (default: current model)

        Returns:
            Created coupling info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return add_multiphysics_coupling(
                model,
                coupling_type,
                physics_list,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to add multiphysics: {str(e)}"}

    @mcp.tool()
    def physics_list_features(physics_name: str, model_name: Optional[str] = None) -> dict:
        """
        List all features (boundary conditions, domain settings) in a physics interface.

        Args:
            physics_name: Name of the physics interface
            model_name: Model name (default: current model)

        Returns:
            List of physics features
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return list_physics_features(model, physics_name)
        except Exception as e:
            return {"success": False, "error": f"Failed to list features: {str(e)}"}

    @mcp.tool()
    def physics_remove(physics_name: str, model_name: Optional[str] = None) -> dict:
        """
        Remove a physics interface from the model.

        Args:
            physics_name: Name of the physics interface to remove
            model_name: Model name (default: current model)

        Returns:
            Removal confirmation
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return remove_physics_interface(model, physics_name)
        except Exception as e:
            return {"success": False, "error": f"Failed to remove physics: {str(e)}"}

    @mcp.tool()
    def geometry_get_boundaries(
        geometry_name: Optional[str] = None,
        component_name: str = "comp1",
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Get all boundaries from a geometry with their properties.

        Use this to identify which boundary numbers correspond to which faces
        before setting boundary conditions.

        Args:
            geometry_name: Geometry sequence name (default: first geometry)
            component_name: Component name (default: 'comp1')
            model_name: Model name (default: current model)

        Returns:
            List of boundaries with their numbers and areas
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            import jpype as _jpype

            jm = model.java

            comp = jm.component(component_name)
            if comp is None:
                return {"success": False, "error": f"Component '{component_name}' not found."}

            geom_list = comp.geom()
            if geom_list.size() == 0:
                return {"success": False, "error": "No geometries in component."}
            # clientapi lists are not subscriptable; resolve via tags().
            geom_tag = _resolve_geometry_tag(geom_list, geometry_name)
            geom = comp.geom(geom_tag)
            geom.run()

            nboundary = geom.getNBoundaries()
            ndomain = geom.getNDomains()
            sdim = int(geom.getSDim())

            # Whole-geometry bounding box [xmin,xmax,ymin,ymax,zmin,zmax].
            try:
                bbox = [float(x) for x in geom.getBoundingBox()]
            except Exception:
                bbox = None

            boundaries = []
            if sdim == 3:
                for i in range(1, nboundary + 1):
                    info = {"boundary_number": i}
                    try:
                        pr = list(geom.faceParamRange(i))
                        u_mid = (float(pr[0]) + float(pr[1])) / 2.0
                        v_mid = (float(pr[2]) + float(pr[3])) / 2.0
                        pp = _jpype.JArray(_jpype.JArray(_jpype.JDouble))(1)
                        pp[0] = _jpype.JArray(_jpype.JDouble)([u_mid, v_mid])
                        normal = list(geom.faceNormal(i, pp)[0])
                        center = list(geom.faceX(i, pp)[0])
                        info["normal"] = [float(n) for n in normal]
                        info["center"] = [float(c) for c in center]
                    except Exception as e:
                        info["error"] = f"Could not get face info: {str(e)[:80]}"
                    boundaries.append(info)
            elif sdim == 2:
                for i in range(1, nboundary + 1):
                    info = {"boundary_number": i}
                    try:
                        pr = list(geom.edgeParamRange(i))
                        u_mid = (float(pr[0]) + float(pr[1])) / 2.0
                        pp = _jpype.JArray(_jpype.JDouble)([u_mid])
                        normal = list(geom.edgeNormal(i, pp)[0])
                        center = list(geom.edgeX(i, pp)[0])
                        info["normal"] = [float(n) for n in normal]
                        info["center"] = [float(c) for c in center]
                    except Exception as e:
                        info["error"] = f"Could not get edge info: {str(e)[:80]}"
                    boundaries.append(info)
            else:
                for i in range(1, nboundary + 1):
                    boundaries.append({"boundary_number": i})

            result = {
                "success": True,
                "geometry": geom_tag,
                "space_dimension": sdim,
                "total_boundaries": nboundary,
                "total_domains": ndomain,
                "boundaries": boundaries,
                "hint": "Use 'normal' to identify faces (e.g. z=0 face has normal [0,0,-1]); "
                "use 'center' to confirm by coordinate. Then set BCs via "
                "physics_configure_boundary.",
            }
            if bbox is not None:
                result["bounding_box"] = bbox
            return result
        except Exception as e:
            return {"success": False, "error": f"Failed to get boundaries: {str(e)}"}

    @mcp.tool()
    def physics_interactive_setup_flow(
        physics_name: str = "Laminar Flow", model_name: Optional[str] = None
    ) -> dict:
        """
        Interactive setup wizard for Laminar Flow boundary conditions.

        This tool helps identify and configure flow boundary conditions:
        1. Lists all available boundaries
        2. Prompts user to select inlet, outlet, and wall boundaries
        3. Configures appropriate boundary conditions

        Args:
            physics_name: Name of the Laminar Flow physics interface
            model_name: Model name (default: current model)

        Returns:
            Boundary information and setup instructions
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            # Get geometry boundaries
            boundaries_info = geometry_get_boundaries(
                geometry_name=None,
                model_name=model_name,
            )
            if not boundaries_info.get("success"):
                return boundaries_info

            return {
                "success": True,
                "message": "Interactive Flow Setup - Please specify boundaries",
                "available_boundaries": boundaries_info["total_boundaries"],
                "boundaries": boundaries_info["boundaries"],
                "setup_instructions": {
                    "step1": "Identify which boundary numbers are INLETS (flow enters)",
                    "step2": "Identify which boundary numbers are OUTLETS (flow exits)",
                    "step3": "Use physics_configure_boundary to set conditions",
                },
                "boundary_condition_types": {
                    "InletBoundary": "Set inlet velocity (U0 parameter)",
                    "OutletBoundary": "Set outlet pressure (p0 parameter, default 0)",
                    "Wall": "No-slip wall (default for unspecified boundaries)",
                    "Symmetry": "Symmetry plane",
                },
                "example_usage": {
                    "inlet": (
                        "physics_configure_boundary(physics_name='Laminar Flow', "
                        "boundary_condition='InletBoundary', boundary_selection=[1, 2], "
                        "properties={'U0': '1[mm/s]'})"
                    ),
                    "outlet": (
                        "physics_configure_boundary(physics_name='Laminar Flow', "
                        "boundary_condition='OutletBoundary', boundary_selection=[3])"
                    ),
                },
                "next_step": (
                    "Please tell me which boundary numbers to use for inlet(s) and outlet(s)"
                ),
            }
        except Exception as e:
            return {"success": False, "error": f"Interactive setup failed: {str(e)}"}

    @mcp.tool()
    def physics_setup_flow_boundaries(
        physics_name: str,
        inlet_boundaries: Sequence[int],
        outlet_boundaries: Sequence[int],
        inlet_velocity: str = "1[mm/s]",
        outlet_pressure: str = "0",
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Setup Laminar Flow boundary conditions with specified boundaries.

        This tool configures inlet velocity and outlet pressure boundary conditions
        for a fluid flow simulation.

        Args:
            physics_name: Name of the Laminar Flow physics interface
            inlet_boundaries: List of boundary numbers for inlets
            outlet_boundaries: List of boundary numbers for outlets
            inlet_velocity: Inlet velocity expression (default: "1[mm/s]")
            outlet_pressure: Outlet pressure expression (default: "0")
            model_name: Model name (default: current model)

        Returns:
            Configuration confirmation
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return setup_flow_boundaries(
                model,
                physics_name,
                inlet_boundaries,
                outlet_boundaries,
                inlet_velocity=inlet_velocity,
                outlet_pressure=outlet_pressure,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to setup boundaries: {str(e)}"}

    @mcp.tool()
    def physics_interactive_setup_heat(
        physics_name: str = "Heat Transfer in Solids", model_name: Optional[str] = None
    ) -> dict:
        """
        Interactive setup wizard for Heat Transfer boundary conditions.

        This tool helps identify and configure thermal boundary conditions:
        1. Lists all available boundaries
        2. Shows typical boundary condition types for thermal analysis
        3. Provides setup instructions

        Args:
            physics_name: Name of the Heat Transfer physics interface
            model_name: Model name (default: current model)

        Returns:
            Boundary information and setup instructions
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            boundaries_info = geometry_get_boundaries(
                geometry_name=None,
                model_name=model_name,
            )
            if not boundaries_info.get("success"):
                return boundaries_info

            return {
                "success": True,
                "message": "Interactive Heat Transfer Setup",
                "available_boundaries": boundaries_info["total_boundaries"],
                "boundaries": boundaries_info["boundaries"],
                "boundary_condition_types": {
                    "TemperatureBoundary": "Fixed temperature (heat sink/source)",
                    "HeatFluxBoundary": "Prescribed heat flux (heat source)",
                    "ConvectiveHeatFlux": "Convection cooling/heating",
                    "Symmetry": "Symmetry plane (adiabatic)",
                    "ThermalInsulation": "Thermal insulation (default)",
                },
                "typical_setup": {
                    "heat_source": "Use HeatFluxBoundary with q0 parameter (W/m^2)",
                    "heat_sink": "Use TemperatureBoundary with T0 parameter (K or degC)",
                    "convection": "Use ConvectiveHeatFlux with h and Text parameters",
                },
                "example_usage": {
                    "heat_source": (
                        "physics_setup_heat_boundaries(physics_name='Heat Transfer in Solids', "
                        "heat_flux_boundaries=[1, 2], heat_flux_value='1e6[W/m^2]')"
                    ),
                    "heat_sink": (
                        "physics_setup_heat_boundaries(physics_name='Heat Transfer in Solids', "
                        "temperature_boundaries=[3], temperature_value='293.15[K]')"
                    ),
                },
                "next_step": "Tell me which boundary numbers to use for heat source and heat sink",
            }
        except Exception as e:
            return {"success": False, "error": f"Interactive setup failed: {str(e)}"}

    @mcp.tool()
    def physics_setup_heat_boundaries(
        physics_name: str,
        heat_flux_boundaries: Optional[Sequence[int]] = None,
        temperature_boundaries: Optional[Sequence[int]] = None,
        convection_boundaries: Optional[Sequence[int]] = None,
        heat_flux_value: str = "1e6[W/m^2]",
        temperature_value: str = "293.15[K]",
        convection_coeff: str = "10[W/(m^2*K)]",
        ambient_temp: str = "293.15[K]",
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Setup Heat Transfer boundary conditions with specified boundaries.

        This tool configures thermal boundary conditions for heat transfer simulation:
        - Heat flux boundaries (heat sources)
        - Temperature boundaries (heat sinks)
        - Convective cooling/heating boundaries

        Args:
            physics_name: Name of the Heat Transfer physics interface
            heat_flux_boundaries: List of boundary numbers for heat flux
            temperature_boundaries: List of boundary numbers for fixed temperature
            convection_boundaries: List of boundary numbers for convection
            heat_flux_value: Heat flux value (default: "1e6[W/m^2]")
            temperature_value: Temperature value (default: "293.15[K]" = 20°C)
            convection_coeff: Convection coefficient (default: "10[W/(m^2*K)]")
            ambient_temp: Ambient temperature for convection (default: "293.15[K]")
            model_name: Model name (default: current model)

        Returns:
            Configuration confirmation
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        heat_flux_boundaries = heat_flux_boundaries or []
        temperature_boundaries = temperature_boundaries or []
        convection_boundaries = convection_boundaries or []

        try:
            return setup_heat_boundaries(
                model,
                physics_name,
                heat_flux_boundaries=heat_flux_boundaries,
                temperature_boundaries=temperature_boundaries,
                convection_boundaries=convection_boundaries,
                heat_flux_value=heat_flux_value,
                temperature_value=temperature_value,
                convection_coeff=convection_coeff,
                ambient_temp=ambient_temp,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to setup heat boundaries: {str(e)}"}

    @mcp.tool()
    def physics_boundary_selection(
        physics_name: str,
        boundary_condition_type: str,
        boundary_numbers: Sequence[int],
        properties: Optional[dict] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Generic boundary condition setup with boundary selection.

        Use this tool to configure any boundary condition by specifying:
        1. The physics interface name
        2. The boundary condition type
        3. The boundary numbers to apply the condition to
        4. Properties specific to the boundary condition

        Common boundary condition types by physics:

        Heat Transfer (ht):
        - Temperature: Set T0 (temperature)
        - HeatFlux: Set q0 (heat flux)
        - ConvectiveHeatFlux: Set h (coefficient), Text (ambient temp)

        Laminar Flow (spf):
        - InletBoundary: Set U0 (velocity)
        - OutletBoundary: Set p0 (pressure)
        - Wall: No-slip wall

        Solid Mechanics (solid):
        - Fixed: Fixed constraint
        - BoundaryLoad: Set Fx, Fy, Fz or FAx, FAy, FAz

        Args:
            physics_name: Name or label of the physics interface
            boundary_condition_type: Type of boundary condition
            boundary_numbers: List of boundary numbers
            properties: Dictionary of property names and values
            model_name: Model name (default: current model)

        Returns:
            Configuration confirmation
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        properties = properties or {}

        try:
            return add_boundary_condition(
                model,
                physics_name,
                boundary_condition_type,
                boundary_numbers,
                properties=properties,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to create boundary condition: {str(e)}"}
