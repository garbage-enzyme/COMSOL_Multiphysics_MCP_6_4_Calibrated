"""Mesh tools for COMSOL MCP Server."""

from typing import Optional

from mcp.server.mcpserver import MCPServer

from .session import session_manager


def create_mesh_sequence(
    model,
    *,
    mesh_name: str = "mesh1",
    element_type: str = "FreeTet",
    component_name: Optional[str] = None,
    build: bool = True,
) -> dict:
    """Create one owned mesh transaction and remove it on setup/build failure."""
    if not isinstance(mesh_name, str) or not mesh_name.strip():
        return {"success": False, "error": "mesh_name must be nonempty"}
    if not isinstance(element_type, str) or not element_type.strip():
        return {"success": False, "error": "element_type must be nonempty"}
    if not isinstance(build, bool):
        return {"success": False, "error": "build must be boolean"}
    if component_name is not None and (
        not isinstance(component_name, str) or not component_name.strip()
    ):
        return {"success": False, "error": "component_name must be nonempty"}
    from .physics import _first_component

    jm = model.java
    comp = jm.component(component_name) if component_name else _first_component(jm)
    if comp is None:
        return {"success": False, "error": "No component found in model."}
    mesh_list = comp.mesh()
    if mesh_name in {str(value) for value in list(mesh_list.tags())}:
        return {"success": False, "error": f"Mesh tag already exists: {mesh_name}"}
    created = False
    try:
        mesh_seq = mesh_list.create(mesh_name)
        created = True
        feat_tag = "ftr1"
        mesh_seq.feature().create(feat_tag, element_type)
        result = {
            "success": True,
            "mesh_name": mesh_name,
            "feature_tag": feat_tag,
            "element_type": element_type,
            "built": False,
        }
        if build:
            mesh_seq.run()
            result["built"] = True
            collected_statistics = False
            try:
                if hasattr(mesh_seq, "getNumElem"):
                    result["num_elements"] = int(mesh_seq.getNumElem())
                    collected_statistics = True
                if hasattr(mesh_seq, "getNumVertex"):
                    result["num_vertices"] = int(mesh_seq.getNumVertex())
                    collected_statistics = True
                result["statistics_complete"] = collected_statistics
            except Exception as exc:
                result["statistics_complete"] = False
                result["statistics_error_type"] = type(exc).__name__
        return result
    except Exception:
        if created:
            try:
                mesh_list.remove(mesh_name)
            except Exception:
                return {
                    "success": False,
                    "error": "Mesh setup failed and rollback was incomplete.",
                    "rolled_back": False,
                }
            return {"success": False, "error": "Mesh setup failed.", "rolled_back": True}
        # Nothing was created, so nothing was rolled back; reporting a rollback
        # here would misrepresent the model state to the caller.
        return {"success": False, "error": "Mesh setup failed.", "rolled_back": False}


def get_mesh_info(
    model,
    *,
    mesh_name: Optional[str] = None,
    component_name: Optional[str] = None,
) -> dict:
    """Return mesh metadata through the COMSOL 6.4 clientapi."""
    if component_name is not None and (
        not isinstance(component_name, str) or not component_name.strip()
    ):
        return {"success": False, "error": "component_name must be nonempty"}
    from .physics import _first_component

    jm = model.java
    comp = jm.component(component_name) if component_name else _first_component(jm)
    if comp is None:
        return {"success": False, "error": "No component found in model."}

    mesh_list = comp.mesh()
    tags = [str(tag) for tag in mesh_list.tags()]
    if not tags:
        return {"success": False, "error": "No meshes defined in model."}

    target_tag = None
    label_failure = None
    if mesh_name is None:
        target_tag = tags[0]
    elif mesh_name in tags:
        target_tag = mesh_name
    else:
        for tag in tags:
            try:
                if str(mesh_list.get(tag).label()) == mesh_name:
                    target_tag = tag
                    break
            except Exception as exc:
                if label_failure is None:
                    label_failure = (tag, type(exc).__name__)
                continue
    if target_tag is None:
        if label_failure is not None:
            return {
                "success": False,
                "error": "Mesh label lookup failed.",
                "mesh_tag": label_failure[0],
                "error_type": label_failure[1],
            }
        return {
            "success": False,
            "error": f"Mesh not found: {mesh_name}. Available tags: {tags}",
        }

    mesh = mesh_list.get(target_tag)
    info = {
        "name": target_tag,
        "component": str(comp.tag()),
        "features": [str(tag) for tag in mesh.feature().tags()],
    }
    try:
        info["label"] = str(mesh.label())
    except Exception:  # noqa: S110 - labels are optional diagnostics
        pass
    try:
        info["num_elements"] = int(mesh.getNumElem())
        info["num_vertices"] = int(mesh.getNumVertex())
    except Exception as exc:
        return {
            "success": False,
            "error": f"Mesh statistics are unavailable: {str(exc)[:300]}",
            "mesh": info,
            "statistics_complete": False,
        }
    info["statistics_complete"] = True
    return {"success": True, "mesh": info}


def register_mesh_tools(mcp: MCPServer) -> None:
    """Register mesh tools with the MCP server."""

    @mcp.tool()
    def mesh_list(model_name: Optional[str] = None) -> dict:
        """
        List all mesh sequences in a model.

        Args:
            model_name: Model name (default: current model)

        Returns:
            List of mesh sequence names
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            meshes = model.meshes()
            return {
                "success": True,
                "meshes": meshes,
                "count": len(meshes),
            }
        except Exception as e:
            return {"success": False, "error": f"Failed to list meshes: {str(e)}"}

    @mcp.tool()
    def mesh_create(mesh_name: Optional[str] = None, model_name: Optional[str] = None) -> dict:
        """
        Run a mesh sequence to generate the mesh.

        This executes the meshing operations defined in the mesh sequence.

        Args:
            mesh_name: Mesh sequence name (default: run all mesh sequences)
            model_name: Model name (default: current model)

        Returns:
            Mesh generation status
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            model.mesh(mesh_name)
            return {
                "success": True,
                "mesh": mesh_name,
                "message": f"Mesh created: {mesh_name or 'all meshes'}",
            }
        except Exception as e:
            return {"success": False, "error": f"Failed to create mesh: {str(e)}"}

    @mcp.tool()
    def mesh_sequence_create(
        mesh_name: str = "mesh1",
        element_type: str = "FreeTet",
        component_name: Optional[str] = None,
        build: bool = True,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Create a mesh sequence with a single meshing feature and optionally build it.

        COMSOL does NOT auto-create a mesh sequence; one must be created before
        solving. This tool creates a mesh sequence on the component, adds one
        meshing feature (default FreeTet = free tetrahedral), and runs it.

        Args:
            mesh_name: Tag/name for the mesh sequence (default 'mesh1')
            element_type: Meshing operation type, e.g. 'FreeTet' (free tetrahedral,
                default), 'FreeSweep' (sweep), 'FreeTri' (free triangular),
                'Map' (mapped), 'BoundaryLayer'.
            component_name: Component name (default: first component)
            build: If True (default), immediately build the mesh after creation.
            model_name: Model name (default: current model)

        Returns:
            Created mesh info including element counts if built.
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return create_mesh_sequence(
                model,
                mesh_name=mesh_name,
                element_type=element_type,
                component_name=component_name,
                build=build,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to create mesh sequence: {str(e)}"}

    @mcp.tool()
    def mesh_info(
        mesh_name: Optional[str] = None,
        component_name: Optional[str] = None,
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Get information about a mesh.

        Args:
            mesh_name: Mesh sequence name (default: first mesh)
            component_name: Component containing the mesh (default: first)
            model_name: Model name (default: current model)

        Returns:
            Mesh statistics including element counts
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return get_mesh_info(
                model,
                mesh_name=mesh_name,
                component_name=component_name,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to get mesh info: {str(e)}"}
