"""Study and solving tools for COMSOL MCP Server."""

import math
from typing import Optional, Sequence

from mcp.server.mcpserver import MCPServer

from ..async_handler.solver import async_solver
from .session import session_manager


def create_study(
    model,
    study_type: str = "Stationary",
    study_name: Optional[str] = None,
    time_list: Optional[Sequence] = None,
    time_unit: str = "s",
) -> dict:
    """Create one study and remove it if step configuration cannot complete."""
    if not isinstance(study_type, str) or not study_type.strip():
        return {"success": False, "error": "study_type must be nonempty"}
    if study_name is not None and (not isinstance(study_name, str) or not study_name.strip()):
        return {"success": False, "error": "study_name must be nonempty"}
    if not isinstance(time_unit, str) or not time_unit.strip():
        return {"success": False, "error": "time_unit must be nonempty"}
    normalized_times = None
    if time_list is not None:
        if isinstance(time_list, (str, bytes)):
            return {"success": False, "error": "time_list must be numeric"}
        normalized_times = []
        for value in time_list:
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                return {"success": False, "error": "time_list must be numeric"}
            number = float(value)
            if not math.isfinite(number):
                return {"success": False, "error": "time_list must be finite"}
            normalized_times.append(number)
        if not normalized_times:
            return {"success": False, "error": "time_list must not be empty"}
    aliases = {
        "stat": "Stationary",
        "time": "Transient",
        "timedependent": "Transient",
        "transient": "Transient",
        "eig": "Eigenfrequency",
        "freq": "FrequencyDomain",
        "frequency": "FrequencyDomain",
        "pert": "Perturbation",
    }
    step_type = aliases.get(study_type.casefold(), study_type)
    study_list = model.java.study()
    existing = {str(value) for value in list(study_list.tags())}
    if study_name:
        study_tag = study_name
        if study_tag in existing:
            return {"success": False, "error": f"Study tag already exists: {study_tag}"}
    else:
        index = 1
        while f"std{index}" in existing:
            index += 1
        study_tag = f"std{index}"
    created = False
    try:
        study = study_list.create(study_tag)
        created = True
        study.create("step1", step_type)
        if step_type == "Transient" and normalized_times is not None:
            study.feature("step1").set(
                "tlist", " ".join(f"{value}[{time_unit}]" for value in normalized_times)
            )
    except Exception as exc:
        if created:
            try:
                study_list.remove(study_tag)
            except Exception as rollback_exc:
                return {
                    "success": False,
                    "error": "Study setup failed and rollback was incomplete.",
                    "error_type": type(exc).__name__,
                    "rollback_error_type": type(rollback_exc).__name__,
                    "rollback_attempted": True,
                    "rolled_back": False,
                }
            return {
                "success": False,
                "error": "Study setup failed.",
                "error_type": type(exc).__name__,
                "rollback_attempted": True,
                "rolled_back": True,
            }
        return {
            "success": False,
            "error": "Study creation failed before a study was created.",
            "error_type": type(exc).__name__,
            "rollback_attempted": False,
            "rolled_back": False,
        }
    result = {
        "success": True,
        "study": study_tag,
        "type": study_type,
        "step_type": step_type,
        "model": model.name(),
    }
    if step_type == "Transient" and normalized_times is None:
        result["warning"] = "Transient study created without time_list."
    return result


def _resolve_study_tag(model, study_name: Optional[str]) -> Optional[str]:
    """Resolve a study identifier (tag OR label) to its tag.

    mph's high-level ``model.solve(name)`` looks studies up by *label*
    (e.g. "研究 1"), but ``study_create`` returns and most callers pass the
    *tag* (e.g. "std1"). This helper accepts either form and returns the
    canonical tag so we can call the Java API ``jm.study(tag).run()``
    directly.

    Returns ``None`` when ``study_name`` is ``None`` (meaning "all studies").
    Raises ``ValueError`` if no matching study is found.
    """
    if study_name is None:
        return None
    jm = model.java
    study_list = jm.study()
    tags = [str(tag) for tag in study_list.tags()]
    if study_name in tags:
        return study_name
    matches = []
    for tag in tags:
        try:
            if str(study_list.get(tag).label()) == study_name:
                matches.append(tag)
        except Exception as exc:
            raise RuntimeError(f"Cannot read label for study {tag!r}: {exc}") from exc
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(f"Study label {study_name!r} is ambiguous across tags: {matches}")
    raise ValueError(f"Study '{study_name}' not found. Available tags: {tags}")


def list_studies(model) -> dict:
    """List studies and steps through stable clientapi tags and labels."""
    study_list = model.java.study()
    studies = []
    for raw_tag in list(study_list.tags()):
        tag = str(raw_tag)
        study = study_list.get(tag)
        info = {"tag": tag}
        try:
            info["label"] = str(study.label())
        except Exception:
            info["label"] = tag

        steps = []
        feature_list = study.feature()
        for raw_step_tag in list(feature_list.tags()):
            step_tag = str(raw_step_tag)
            step = feature_list.get(step_tag)
            step_info = {"tag": step_tag}
            try:
                step_info["label"] = str(step.label())
            except Exception:
                step_info["label"] = step_tag
            steps.append(step_info)
        info["steps"] = steps
        studies.append(info)
    return {"success": True, "studies": studies, "count": len(studies)}


def solve_study(
    model,
    study_name: Optional[str] = None,
    *,
    wait: bool = True,
    timeout: Optional[float] = None,
    solver=async_solver,
) -> dict:
    """Run synchronously only for an unbounded wait; finite waits use the manager."""
    if not isinstance(wait, bool):
        return {"success": False, "error": "wait must be a boolean"}
    if timeout is not None:
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            return {"success": False, "error": "timeout must be a finite non-negative number"}
        timeout = float(timeout)
        if not math.isfinite(timeout) or timeout < 0:
            return {"success": False, "error": "timeout must be a finite non-negative number"}
        if not wait:
            return {"success": False, "error": "timeout requires wait=true"}
    if solver.is_running:
        return {
            "success": False,
            "error": (
                "Another solving operation is in progress. Use study_get_progress to check status."
            ),
        }

    tag = _resolve_study_tag(model, study_name)
    if wait and timeout is None:
        jm = model.java
        if tag is None:
            for raw_tag in jm.study().tags():
                jm.study(str(raw_tag)).run()
        else:
            jm.study(tag).run()
        return {
            "success": True,
            "study": study_name,
            "resolved_tag": tag,
            "message": "Solving completed.",
            "completed": True,
            "async": False,
        }

    started = solver.start_solve(model, tag)
    if not started:
        return {"success": False, "error": "Failed to start async solver."}
    if not wait:
        return {
            "success": True,
            "study": study_name,
            "resolved_tag": tag,
            "message": "Solving started in background. Use study_get_progress to monitor.",
            "async": True,
            "completed": False,
        }

    completed = solver.wait(timeout=timeout)
    progress = solver.get_progress()
    if not completed:
        return {
            "success": False,
            "study": study_name,
            "resolved_tag": tag,
            "completed": False,
            "timed_out": True,
            "async": True,
            "background_continues": True,
            "progress": progress,
            "message": (
                "The wait deadline expired; the blocking COMSOL call may continue in "
                "the managed background solver."
            ),
        }
    if progress.get("status") != "completed":
        return {
            "success": False,
            "study": study_name,
            "resolved_tag": tag,
            "completed": True,
            "async": True,
            "progress": progress,
            "error": "Managed solving finished without a completed status.",
        }
    return {
        "success": True,
        "study": study_name,
        "resolved_tag": tag,
        "completed": True,
        "async": True,
        "progress": progress,
        "message": "Solving completed.",
    }


def _validate_wait_timeout(timeout: Optional[float]) -> None:
    """Reject bool/negative/non-finite/non-numeric deadlines before the solver."""
    if timeout is not None and (
        isinstance(timeout, bool)
        or not isinstance(timeout, (int, float))
        or not math.isfinite(timeout)
        or timeout <= 0
    ):
        raise ValueError("timeout must be a positive number of seconds or null")


def _wait_payload(completed: bool, progress: dict) -> dict:
    """Map a finished wait onto the public success contract.

    An expired deadline is a failed wait, never a completed solve wearing
    ``success=True``; the background solve keeps running either way.
    """
    if not completed:
        return {
            "success": False,
            "completed": False,
            "timed_out": True,
            "progress": progress,
        }
    return {"success": True, "completed": True, "progress": progress}


def register_study_tools(mcp: MCPServer) -> None:
    """Register study and solving tools with the MCP server."""

    @mcp.tool()
    def study_list(model_name: Optional[str] = None) -> dict:
        """
        List all studies in a model.

        Args:
            model_name: Model name (default: current model)

        Returns:
            List of study names with their types
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return list_studies(model)
        except Exception as e:
            return {"success": False, "error": f"Failed to list studies: {str(e)}"}

    @mcp.tool()
    def study_create(
        study_type: str = "Stationary",
        study_name: Optional[str] = None,
        time_list: Optional[Sequence] = None,
        time_unit: str = "s",
        model_name: Optional[str] = None,
    ) -> dict:
        """
        Create a new study in the model.

        Common study types:
        - "Stationary": Stationary study (most common for electrostatics, structural)
        - "Transient": Time-dependent study (also accepts "TimeDependent"/"time")
        - "Eigenfrequency": Eigenfrequency analysis
        - "FrequencyDomain": Frequency domain study (also accepts "Frequency")
        - "Perturbation": Perturbation study

        Args:
            study_type: Type of study to create
            study_name: Optional name/tag for the study
            time_list: For Transient studies, the list of output times.
                Elements are numbers expressed in ``time_unit`` (default s).
                Typical usage for ns simulation: ``time_list=[0,0.1e-9,1e-9]``
                or ``time_list=[0,1,10]`` with ``time_unit="ns"``.
            time_unit: Unit string for ``time_list`` (default "s")
            model_name: Model name (default: current model)

        Returns:
            Created study info
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return create_study(
                model,
                study_type=study_type,
                study_name=study_name,
                time_list=time_list,
                time_unit=time_unit,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to create study: {str(e)}"}

    @mcp.tool()
    def study_solve(
        study_name: Optional[str] = None,
        model_name: Optional[str] = None,
        wait: bool = True,
        timeout: Optional[float] = None,
    ) -> dict:
        """
        Solve a study (synchronous by default).

        Args:
            study_name: Study to solve (None for all studies)
            model_name: Model name (default: current model)
            wait: If True, wait for completion; if False, return immediately
            timeout: Maximum wait time in seconds (only used if wait=True)

        Returns:
            Solution status, or error message
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            return solve_study(
                model,
                study_name,
                wait=wait,
                timeout=timeout,
            )
        except Exception as e:
            return {"success": False, "error": f"Failed to solve: {str(e)}"}

    @mcp.tool()
    def study_solve_async(
        study_name: Optional[str] = None, model_name: Optional[str] = None
    ) -> dict:
        """
        Start solving a study in the background (asynchronous).

        Use study_get_progress to inspect synthetic lifecycle checkpoints.
        study_cancel records a cooperative request but cannot interrupt a
        blocking COMSOL study.run() call.

        Args:
            study_name: Study to solve (None for all studies)
            model_name: Model name (default: current model)

        Returns:
            Confirmation that solving started, or error message
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        if async_solver.is_running:
            progress = async_solver.get_progress()
            return {
                "success": False,
                "error": "Another solving operation is already in progress.",
                "current_progress": progress,
            }

        try:
            tag = _resolve_study_tag(model, study_name)
            started = async_solver.start_solve(model, tag)
            if started:
                return {
                    "success": True,
                    "study": study_name,
                    "resolved_tag": tag,
                    "model": model.name(),
                    "message": "Solving started in background.",
                }
            else:
                return {"success": False, "error": "Failed to start async solver."}
        except Exception as e:
            return {"success": False, "error": f"Failed to start solving: {str(e)}"}

    @mcp.tool()
    def study_get_progress() -> dict:
        """
        Get synthetic lifecycle status for the current solving operation.

        The numeric progress field is not COMSOL solver percentage. While
        study.run() is blocking, it remains at the pre-solve checkpoint.

        Returns:
            Status, synthetic checkpoint value, and elapsed time
        """
        progress = async_solver.get_progress()
        return {
            "success": True,
            "progress": progress,
        }

    @mcp.tool()
    def study_cancel() -> dict:
        """
        Request cooperative cancellation of the current solving operation.

        This cannot interrupt a blocking COMSOL study.run() call. It can only
        stop work before the blocking call begins or between separate studies.

        Returns:
            Cancellation status
        """
        if async_solver.cancel():
            return {
                "success": True,
                "requested": True,
                "interrupts_solver": False,
                "message": (
                    "Cancellation flag recorded. A blocking COMSOL study.run() "
                    "will continue until it returns."
                ),
            }
        return {
            "success": False,
            "message": "No solving operation in progress.",
        }

    @mcp.tool()
    def study_wait(timeout: Optional[float] = None) -> dict:
        """
        Wait for the current solving operation to complete.

        Args:
            timeout: Maximum time to wait in seconds (None for indefinite)

        Returns:
            Final progress status
        """
        _validate_wait_timeout(timeout)
        completed = async_solver.wait(timeout=timeout)
        progress = async_solver.get_progress()
        return _wait_payload(completed, progress)

    @mcp.tool()
    def solutions_list(model_name: Optional[str] = None) -> dict:
        """
        List all solutions in a model.

        Args:
            model_name: Model name (default: current model)

        Returns:
            List of solution configurations
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            solutions = model.solutions()
            return {
                "success": True,
                "solutions": solutions,
                "count": len(solutions),
            }
        except Exception as e:
            return {"success": False, "error": f"Failed to list solutions: {str(e)}"}

    @mcp.tool()
    def datasets_list(model_name: Optional[str] = None) -> dict:
        """
        List all datasets in a model.

        Datasets represent solution data that can be evaluated or visualized.

        Args:
            model_name: Model name (default: current model)

        Returns:
            List of dataset names
        """
        model = session_manager.get_model(model_name)
        if model is None:
            return {
                "success": False,
                "error": f"Model not found: {model_name or 'no current model'}",
            }

        try:
            datasets = model.datasets()
            return {
                "success": True,
                "datasets": datasets,
                "count": len(datasets),
            }
        except Exception as e:
            return {"success": False, "error": f"Failed to list datasets: {str(e)}"}
