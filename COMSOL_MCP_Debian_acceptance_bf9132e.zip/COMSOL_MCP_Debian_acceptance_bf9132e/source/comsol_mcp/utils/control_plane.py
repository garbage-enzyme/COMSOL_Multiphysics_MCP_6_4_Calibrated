"""Bounded in-process latency and outcome evidence for MCP control calls."""

from __future__ import annotations

import logging
import math
import re
import threading
import time
from collections import Counter, OrderedDict, deque
from typing import Any, Callable

CONTROL_PLANE_SCHEMA_VERSION = "1.0.0"
CONTROL_PLANE_WINDOW_SIZE = 256
CONTROL_PLANE_MAX_OPERATIONS = 128
logger = logging.getLogger(__name__)
_BUSY_ERROR_CODES = frozenset({"busy", "queue_full", "resource_busy", "worker_queue_full"})
_TIMEOUT_ERROR_CODES = frozenset({"deadline_exceeded", "timed_out", "timeout"})


def _outcome(result: dict[str, Any]) -> str:
    if result.get("success") is True:
        return "success"
    error = result.get("error")
    error_code = error.get("code") if isinstance(error, dict) else None
    normalized_code = str(error_code).strip().casefold() if error_code is not None else None
    if normalized_code in _BUSY_ERROR_CODES:
        return "busy"
    if normalized_code in _TIMEOUT_ERROR_CODES:
        return "timeout"
    if normalized_code is not None:
        # Structured codes take precedence by contract; the message fallback
        # below applies only to payloads without any code field.
        return "error"
    text = " ".join(
        str(value) for value in (result.get("error_type"), error) if value is not None
    ).casefold()
    if "queue is full" in text or "queue full" in text or re.search(r"\bbusy\b", text):
        return "busy"
    if any(token in text for token in ("timeout", "timed out", "deadline exceeded")):
        return "timeout"
    return "error"


def _percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    index = min(
        len(ordered) - 1,
        max(0, math.ceil(float(fraction) * len(ordered)) - 1),
    )
    return ordered[index]


class ControlPlaneMetrics:
    """Thread-safe rolling metrics with fixed memory per named operation."""

    def __init__(
        self,
        window_size: int = CONTROL_PLANE_WINDOW_SIZE,
        max_operations: int = CONTROL_PLANE_MAX_OPERATIONS,
    ):
        if not 1 <= int(window_size) <= 4096:
            raise ValueError("control-plane window_size must be between 1 and 4096")
        if not 1 <= int(max_operations) <= 4096:
            raise ValueError("control-plane max_operations must be between 1 and 4096")
        self.window_size = int(window_size)
        self.max_operations = int(max_operations)
        self._lock = threading.Lock()
        self._samples: OrderedDict[str, deque[tuple[float, str]]] = OrderedDict()
        self._totals: Counter[str] = Counter()

    def record(
        self, operation: str, latency_seconds: float, result: dict[str, Any]
    ) -> dict[str, Any]:
        operation = str(operation)
        latency = float(latency_seconds)
        if not operation or len(operation) > 80:
            raise ValueError("control-plane operation must be a short non-empty string")
        if not math.isfinite(latency) or latency < 0:
            raise ValueError("control-plane latency must be finite and nonnegative")
        outcome = _outcome(result)
        with self._lock:
            if operation not in self._samples and len(self._samples) >= self.max_operations:
                evicted, _samples = self._samples.popitem(last=False)
                self._totals.pop(evicted, None)
            samples = self._samples.setdefault(
                operation,
                deque(maxlen=self.window_size),
            )
            self._samples.move_to_end(operation)
            samples.append((latency, outcome))
            self._totals[operation] += 1
            return self._summary_unlocked(operation)

    def _summary_unlocked(self, operation: str) -> dict[str, Any]:
        samples = list(self._samples.get(operation, ()))
        latencies = [item[0] for item in samples]
        counts = Counter(item[1] for item in samples)
        latency = (
            {
                "p50_seconds": round(_percentile(latencies, 0.50), 6),
                "p95_seconds": round(_percentile(latencies, 0.95), 6),
                "max_seconds": round(max(latencies), 6),
            }
            if latencies
            else {
                "p50_seconds": None,
                "p95_seconds": None,
                "max_seconds": None,
            }
        )
        return {
            "schema_version": CONTROL_PLANE_SCHEMA_VERSION,
            "operation": operation,
            "window_capacity": self.window_size,
            "window_samples": len(samples),
            "total_recorded": int(self._totals.get(operation, 0)),
            "outcomes": {
                name: int(counts.get(name, 0)) for name in ("success", "busy", "timeout", "error")
            },
            "latency": latency,
        }

    def summary(self, operation: str) -> dict[str, Any]:
        with self._lock:
            return self._summary_unlocked(str(operation))

    def reset(self) -> None:
        with self._lock:
            self._samples.clear()
            self._totals.clear()


control_plane_metrics = ControlPlaneMetrics()


def attach_control_plane_evidence(
    operation: str,
    started: float,
    result: dict[str, Any],
    *,
    metrics: ControlPlaneMetrics = control_plane_metrics,
) -> dict[str, Any]:
    """Attach current-call timing and a bounded rolling summary to one result."""
    latency = time.perf_counter() - float(started)
    enriched = dict(result)
    summary = metrics.record(operation, latency, enriched)
    enriched["control_plane"] = {
        "operation": operation,
        "latency_seconds": round(latency, 6),
        "outcome": _outcome(enriched),
        "summary": summary,
    }
    return enriched


def measured_call(
    operation: str,
    callback: Callable[[], dict[str, Any]],
    *,
    metrics: ControlPlaneMetrics = control_plane_metrics,
) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        result = callback()
    except Exception as exc:
        latency = time.perf_counter() - started
        try:
            metrics.record(
                operation,
                latency,
                {
                    "success": False,
                    "error_type": type(exc).__name__,
                    "error": {"code": "callback_exception"},
                },
            )
        except Exception:
            logger.exception("Failed to record a control-plane callback exception")
        raise
    return attach_control_plane_evidence(operation, started, result, metrics=metrics)


__all__ = [
    "CONTROL_PLANE_MAX_OPERATIONS",
    "CONTROL_PLANE_SCHEMA_VERSION",
    "CONTROL_PLANE_WINDOW_SIZE",
    "ControlPlaneMetrics",
    "attach_control_plane_evidence",
    "control_plane_metrics",
    "measured_call",
]
