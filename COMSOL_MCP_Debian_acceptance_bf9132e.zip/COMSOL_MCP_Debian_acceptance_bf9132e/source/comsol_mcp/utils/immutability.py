"""Recursively immutable JSON-compatible snapshots."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class FrozenDict(dict):
    """A JSON-serializable dictionary that rejects mutation after construction.

    The guard covers the public mapping mutator surface and re-initialization.
    Direct base-class calls such as ``dict.__setitem__(fd, ...)`` remain a
    documented interpreter-level escape hatch.
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "FrozenDict":
        instance = super().__new__(cls)
        instance._frozen_initialized = False
        return instance

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if getattr(self, "_frozen_initialized", False):
            raise TypeError("frozen snapshot cannot be mutated")
        super().__init__(*args, **kwargs)
        self._frozen_initialized = True

    def _immutable(self, *_args: Any, **_kwargs: Any) -> None:
        raise TypeError("frozen snapshot cannot be mutated")

    __setitem__ = _immutable
    __delitem__ = _immutable
    clear = _immutable
    pop = _immutable
    popitem = _immutable
    setdefault = _immutable
    update = _immutable
    __ior__ = _immutable

    def __deepcopy__(self, _memo: dict[int, Any]) -> "FrozenDict":
        return self

    def __hash__(self) -> int:
        return hash(frozenset(self.items()))


def deep_freeze(value: Any) -> Any:
    """Copy JSON-like containers into recursively immutable equivalents."""
    if isinstance(value, Mapping):
        return FrozenDict((key, deep_freeze(item)) for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return tuple(deep_freeze(item) for item in value)
    return value


def deep_thaw(value: Any) -> Any:
    """Return mutable JSON-compatible copies of recursively frozen values."""
    if isinstance(value, Mapping):
        return {key: deep_thaw(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [deep_thaw(item) for item in value]
    return value


__all__ = ["FrozenDict", "deep_freeze", "deep_thaw"]
