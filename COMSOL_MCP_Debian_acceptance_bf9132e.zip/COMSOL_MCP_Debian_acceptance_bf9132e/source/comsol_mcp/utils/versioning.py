"""Version naming utilities for model version management."""

import re
import uuid
from datetime import datetime
from pathlib import Path

from .runtime_paths import default_runtime_dir


def _model_stem(model_name: str) -> str:
    name = Path(model_name).name
    clean_name = name[:-4] if name.casefold().endswith(".mph") else name
    if clean_name in {"", ".", ".."}:
        raise ValueError("model_name must identify one safe model directory")
    if re.search(r'[<>:"/\\|?*]', clean_name) or clean_name != clean_name.rstrip(" ."):
        raise ValueError(
            f"model_name contains characters invalid for a model directory: {clean_name!r}"
        )
    if re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?", clean_name):
        raise ValueError(f"model_name uses a reserved Windows device name: {clean_name!r}")
    return clean_name


def default_models_root() -> Path:
    """Return the writable runtime directory for versioned model copies."""
    return default_runtime_dir() / "models"


def get_model_directory(
    model_name: str,
    base_path: str | Path | None = None,
) -> Path:
    """
    Get the directory path for a model.

    Args:
        model_name: Name of the model.
        base_path: Optional model-storage root. Defaults to the runtime
            directory's ``models`` subdirectory.

    Returns:
        Path to the model directory
    """
    # Clean model name (remove .mph extension if present)
    clean_name = _model_stem(model_name)
    root = Path(base_path).expanduser() if base_path is not None else default_models_root()
    return root / clean_name


def generate_version_name(base_name: str) -> str:
    """
    Generate a versioned name with timestamp suffix.

    Args:
        base_name: Original model name (with or without .mph extension)

    Returns:
        Versioned name with timestamp, e.g., "model_20260215_143022.mph"
    """
    path = Path(base_name)
    stem = path.stem
    extension = path.suffix or ".mph"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{stem}_{timestamp}_{uuid.uuid4().hex[:8]}{extension}"


def generate_version_path(model_name: str, base_path: str | Path | None = None) -> str:
    """
    Generate a versioned file path with timestamp suffix.
    Uses structured path: <runtime>/models/{model_name}/{model_name}_{timestamp}.mph

    Args:
        model_name: Name of the model (used for directory)
        base_path: Optional directory in which to create the model subdirectory.
            When omitted, uses the runtime directory's ``models`` subdirectory.

    Returns:
        Versioned file path with timestamp
    """
    # Clean model name
    clean_name = _model_stem(model_name)

    # Get model directory
    model_dir = get_model_directory(model_name, base_path=base_path)
    model_dir.mkdir(parents=True, exist_ok=True)

    # Generate versioned filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    versioned_name = f"{clean_name}_{timestamp}_{uuid.uuid4().hex[:8]}.mph"

    return str(model_dir / versioned_name)


def generate_latest_path(
    model_name: str,
    base_path: str | Path | None = None,
) -> str:
    """
    Generate path for the 'latest' version of a model.
    Uses structured path: <runtime>/models/{model_name}/{model_name}_latest.mph

    Args:
        model_name: Name of the model.
        base_path: Optional model-storage root. Defaults to the runtime
            directory's ``models`` subdirectory.

    Returns:
        Path for the latest version
    """
    clean_name = _model_stem(model_name)
    model_dir = get_model_directory(model_name, base_path=base_path)
    model_dir.mkdir(parents=True, exist_ok=True)
    return str(model_dir / f"{clean_name}_latest.mph")


def list_model_versions(
    model_name: str,
    base_path: str | Path | None = None,
) -> list[str]:
    """
    List all versions of a model.

    Args:
        model_name: Name of the model.
        base_path: Optional model-storage root. Defaults to the runtime
            directory's ``models`` subdirectory.

    Returns:
        List of version file paths, sorted by modification time (newest first)
    """
    model_dir = get_model_directory(model_name, base_path=base_path)
    if not model_dir.exists():
        return []

    clean_name = _model_stem(model_name)
    latest_name = f"{clean_name}_latest.mph"
    versions: list[tuple[float, str]] = []
    for f in model_dir.glob("*.mph"):
        if f.name == latest_name:
            continue
        try:
            modified = f.stat().st_mtime
        except FileNotFoundError:
            continue
        versions.append((modified, str(f)))

    # Sort by modification time, newest first
    versions.sort(key=lambda item: item[0], reverse=True)
    return [path for _modified, path in versions]


def parse_version_info(name: str) -> dict | None:
    """
    Parse version information from a model name.

    Args:
        name: Model name to parse

    Returns:
        Dict with 'base_name', 'timestamp', 'datetime' or None if not versioned
    """
    path = Path(name)
    stem = path.stem

    import re

    # A bare _YYYYMMDD_HHMMSS suffix is accepted as versioned by contract
    # (test_parse_version_info_valid); the generated-uuid marker is optional.
    match = re.match(r"^(.+)_(\d{8}_\d{6})(?:_[0-9a-f]{8})?$", stem)
    if match:
        base_name = match.group(1)
        timestamp_str = match.group(2)
        try:
            dt = datetime.strptime(timestamp_str, "%Y%m%d_%H%M%S")
            return {
                "base_name": base_name,
                "timestamp": timestamp_str,
                "datetime": dt,
            }
        except ValueError:
            pass
    return None
