"""Dependency-free contracts for the optional semantic-retrieval service."""

from __future__ import annotations

import math
import re
import unicodedata
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from comsol_mcp.durable import canonical_json_v1, canonical_sha256_v1

CONTRACT_VERSION = "1"
EVALUATION_SCHEMA_VERSION = "1"
INDEX_MANIFEST_SCHEMA_VERSION = "1"
MODEL_MANIFEST_SCHEMA_VERSION = "1"
WORKER_PROTOCOL_SCHEMA_VERSION = "1"
DEFAULT_DEPLOYMENT_ROOT: Path | None = None
SEMANTIC_BUILD_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,79}$")

ALLOWED_CATEGORIES = frozenset(
    {
        "exact_clientapi",
        "wave_optics",
        "conventional_fem",
        "troubleshooting",
        "negative",
    }
)
ALLOWED_STYLES = frozenset(
    {
        "exact",
        "paraphrase",
        "multi_concept",
        "zh_cross_language",
    }
)

PUBLIC_LIMITS = {
    "status_deadline_seconds": 1.0,
    "query_deadline_seconds": 5.0,
    "maximum_query_characters": 2_000,
    "maximum_results": 10,
    "maximum_snippet_characters": 1_200,
    "maximum_response_bytes": 65_536,
    "maximum_queue_depth": 8,
}

SEMANTIC_CONTINUATION_GATE = {
    "target_styles": ["paraphrase", "multi_concept", "zh_cross_language"],
    "maximum_lexical_recall_at_5": 0.80,
    "minimum_target_queries": 20,
    "minimum_target_misses_at_5": 10,
}

SEMANTIC_PROMOTION_GATE = {
    "citation_validity": 1.0,
    "maximum_exact_symbol_recall_at_5_regression": 0.03,
    "minimum_target_recall_at_5_absolute_gain": 0.10,
    "minimum_target_recall_at_5_relative_gain": 0.15,
    "maximum_warm_p95_seconds": 3.0,
    "hard_query_deadline_seconds": 5.0,
}

THREAT_MODEL = {
    "protected_parent": "COMSOL MCP control process",
    "untrusted_failures": [
        "embedding_model_load_hang",
        "vector_query_hang",
        "worker_crash",
        "invalid_or_oversized_json",
        "stale_pid_or_port",
        "corrupt_or_mismatched_index",
        "unexpected_network_download",
    ],
    "containment": [
        "heavy_dependencies_import_only_in_worker",
        "localhost_random_port_and_session_token",
        "hard_socket_deadlines",
        "exact_recorded_worker_tree_termination",
        "no_automatic_query_retry",
        "lexical_fallback_remains_independent",
        "no_solver_lease_or_COMSOL_start",
    ],
}


def canonical_json_bytes(value: Any) -> bytes:
    """Encode a contract object deterministically for hashing."""
    return canonical_json_v1(value)


def object_sha256(value: Any) -> str:
    return canonical_sha256_v1(value)


def validate_semantic_filters(filters: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """Validate bounded public query filters before a worker is started."""
    if filters is None:
        return None
    if not isinstance(filters, Mapping):
        raise ValueError("filters must be an object")
    value = dict(filters)
    if not all(isinstance(key, str) for key in value):
        raise ValueError("filter names must be strings")
    unknown = sorted(set(value) - {"module", "source", "page_start", "page_end"})
    if unknown:
        raise ValueError(f"unsupported semantic filters: {unknown}")
    for field in ("module", "source"):
        item = value.get(field)
        if item is not None and (not isinstance(item, str) or not item.strip()):
            raise ValueError(f"{field} filter must be a nonempty string")
        if isinstance(item, str):
            value[field] = item.strip()
    for field in ("page_start", "page_end"):
        item = value.get(field)
        if item is not None and (not isinstance(item, int) or isinstance(item, bool) or item < 1):
            raise ValueError(f"{field} must be a positive integer")
    if (
        value.get("page_start") is not None
        and value.get("page_end") is not None
        and value["page_start"] > value["page_end"]
    ):
        raise ValueError("page_start cannot exceed page_end")
    canonical_json_bytes(value)
    return value


def _require_ascii_absolute_path(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be a non-empty string")
    if not value.isascii():
        raise ValueError(f"{label} must contain ASCII characters only")
    path = Path(value)
    if not path.is_absolute():
        raise ValueError(f"{label} must be absolute")
    return str(path)


def _require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError(f"{label} must be a lowercase SHA-256 hex string")
    if value != value.lower() or any(char not in "0123456789abcdef" for char in value):
        raise ValueError(f"{label} must be a lowercase SHA-256 hex string")
    return value


def _require_identity_text(value: Any, label: str, *, maximum: int = 256) -> str:
    if not isinstance(value, str) or not value or len(value) > maximum:
        raise ValueError(f"{label} must be a non-empty string of at most {maximum} characters")
    if value != value.strip() or unicodedata.normalize("NFKC", value) != value:
        raise ValueError(f"{label} must be canonical text without surrounding whitespace")
    if any(
        ord(char) < 32
        or ord(char) == 127
        or 0x80 <= ord(char) <= 0x9F
        or ord(char) in (0x2028, 0x2029)
        for char in value
    ):
        raise ValueError(f"{label} must not contain control characters")
    return value


def validate_semantic_build_id(value: Any) -> str:
    """Require the canonical immutable semantic-index build identifier."""
    if not isinstance(value, str) or not SEMANTIC_BUILD_ID_PATTERN.fullmatch(value):
        raise ValueError("build_id is invalid")
    return value


def validate_citation_source(value: Any) -> str:
    """Require one canonical relative POSIX PDF citation identity."""
    source = _require_identity_text(value, "citation source", maximum=512)
    if "\\" in source or "//" in source or ":" in source:
        raise ValueError("citation source must be a canonical relative POSIX PDF path")
    path = PurePosixPath(source)
    if (
        path.is_absolute()
        or source != path.as_posix()
        or any(part in {"", ".", ".."} for part in path.parts)
        or path.suffix != ".pdf"
    ):
        raise ValueError("citation source must be a canonical relative POSIX PDF path")
    return source


def validate_evaluation_set(
    payload: Mapping[str, Any], *, minimum_queries: int = 60
) -> dict[str, Any]:
    """Validate and normalize the frozen semantic-retrieval evaluation set."""
    if not isinstance(payload, Mapping):
        raise ValueError("evaluation set must be an object")
    if payload.get("schema_version") != EVALUATION_SCHEMA_VERSION:
        raise ValueError("unsupported evaluation schema_version")
    corpus_fingerprint = _require_sha256(payload.get("corpus_fingerprint"), "corpus_fingerprint")
    queries = payload.get("queries")
    if not isinstance(queries, list) or len(queries) < minimum_queries:
        raise ValueError(f"evaluation set must contain at least {minimum_queries} queries")

    normalized_queries = []
    seen_ids: set[str] = set()
    for index, item in enumerate(queries):
        if not isinstance(item, Mapping):
            raise ValueError(f"queries[{index}] must be an object")
        qid = _require_identity_text(item.get("id"), f"queries[{index}].id", maximum=80)
        if qid in seen_ids:
            raise ValueError(f"duplicate query id: {qid}")
        seen_ids.add(qid)
        query = item.get("query")
        if not isinstance(query, str) or not query.strip():
            raise ValueError(f"queries[{index}].query is invalid")
        if len(query) > PUBLIC_LIMITS["maximum_query_characters"]:
            raise ValueError(f"queries[{index}].query exceeds the public limit")
        category = item.get("category")
        style = item.get("style")
        if category not in ALLOWED_CATEGORIES:
            raise ValueError(f"queries[{index}].category is invalid")
        if style not in ALLOWED_STYLES:
            raise ValueError(f"queries[{index}].style is invalid")
        relevant = item.get("relevant")
        expected_no_relevant = item.get("expected_no_relevant", False)
        if not isinstance(expected_no_relevant, bool):
            raise ValueError(f"queries[{index}].expected_no_relevant must be boolean")
        if not isinstance(relevant, list):
            raise ValueError(f"queries[{index}].relevant must be a list")
        if expected_no_relevant != (len(relevant) == 0):
            raise ValueError(
                f"queries[{index}] must declare expected_no_relevant exactly when relevant is empty"
            )
        if expected_no_relevant and category != "negative":
            raise ValueError(
                f"queries[{index}] empty relevance is restricted to the negative category"
            )
        if not expected_no_relevant and category == "negative":
            raise ValueError(f"queries[{index}] negative category must have empty relevance")
        normalized_relevant = []
        seen_citations = set()
        for citation in relevant:
            if not isinstance(citation, Mapping):
                raise ValueError(f"queries[{index}] has an invalid citation")
            source = citation.get("source")
            page = citation.get("page")
            try:
                source = validate_citation_source(source)
            except ValueError as exc:
                raise ValueError(f"queries[{index}] citation source is invalid") from exc
            if not isinstance(page, int) or isinstance(page, bool) or page < 1:
                raise ValueError(f"queries[{index}] citation page is invalid")
            key = (source, page)
            if key not in seen_citations:
                seen_citations.add(key)
                normalized_relevant.append({"source": source, "page": page})
        judge_note = item.get("judge_note")
        if not isinstance(judge_note, str) or not judge_note.strip():
            raise ValueError(f"queries[{index}].judge_note is required")
        normalized_queries.append(
            {
                "id": qid,
                "query": query.strip(),
                "category": category,
                "style": style,
                "relevant": normalized_relevant,
                "expected_no_relevant": expected_no_relevant,
                "judge_note": judge_note.strip(),
            }
        )

    # name and frozen_at are canonical frozen-schema text: validate them
    # explicitly instead of silently stringifying arbitrary payload values.
    raw_name = payload.get("name")
    if raw_name is None:
        name = "semantic-retrieval-evaluation"
    elif isinstance(raw_name, str) and raw_name.strip():
        name = raw_name.strip()
    else:
        raise ValueError("evaluation name must be a nonempty string when provided")
    raw_frozen_at = payload.get("frozen_at")
    if raw_frozen_at is None:
        frozen_at = ""
    elif isinstance(raw_frozen_at, str):
        frozen_at = raw_frozen_at
    else:
        raise ValueError("evaluation frozen_at must be a string when provided")

    return {
        "schema_version": EVALUATION_SCHEMA_VERSION,
        "name": name,
        "frozen_at": frozen_at,
        "corpus_fingerprint": corpus_fingerprint,
        "queries": normalized_queries,
    }


def validate_model_manifest(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the immutable offline embedding-model identity contract."""
    if not isinstance(payload, Mapping):
        raise ValueError("model manifest must be an object")
    required = {"schema_version", "model_id", "revision", "model_path", "model_sha256", "dimension"}
    missing = sorted(required - set(payload))
    if missing:
        raise ValueError(f"model manifest missing fields: {missing}")
    if payload["schema_version"] != MODEL_MANIFEST_SCHEMA_VERSION:
        raise ValueError("unsupported model manifest schema_version")
    dimension = payload["dimension"]
    if not isinstance(dimension, int) or isinstance(dimension, bool) or dimension < 1:
        raise ValueError("dimension must be a positive integer")
    license_value = payload["license"] if "license" in payload else "unknown"
    return {
        "schema_version": MODEL_MANIFEST_SCHEMA_VERSION,
        "model_id": _require_identity_text(payload["model_id"], "model_id"),
        "revision": _require_identity_text(payload["revision"], "revision"),
        "model_path": _require_ascii_absolute_path(payload["model_path"], "model_path"),
        "model_sha256": _require_sha256(payload["model_sha256"], "model_sha256"),
        "dimension": dimension,
        "license": _require_identity_text(license_value, "license"),
    }


def validate_index_manifest(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the versioned read-only semantic-index identity contract."""
    if not isinstance(payload, Mapping):
        raise ValueError("index manifest must be an object")
    required = {
        "schema_version",
        "build_id",
        "index_path",
        "corpus_fingerprint",
        "lexical_index_sha256",
        "model_manifest_sha256",
        "chunk_count",
        "vector_dimension",
        "distance_metric",
        "file_set_sha256",
    }
    missing = sorted(required - set(payload))
    if missing:
        raise ValueError(f"index manifest missing fields: {missing}")
    if payload["schema_version"] != INDEX_MANIFEST_SCHEMA_VERSION:
        raise ValueError("unsupported index manifest schema_version")
    validate_semantic_build_id(payload["build_id"])
    for field in ("chunk_count", "vector_dimension"):
        value = payload[field]
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValueError(f"{field} must be a positive integer")
    metric = payload["distance_metric"]
    if metric not in {"cosine", "l2", "inner_product"}:
        raise ValueError("distance_metric is unsupported")
    for field in (
        "corpus_fingerprint",
        "lexical_index_sha256",
        "model_manifest_sha256",
        "file_set_sha256",
    ):
        _require_sha256(payload[field], field)
    normalized = dict(payload)
    normalized["index_path"] = _require_ascii_absolute_path(payload["index_path"], "index_path")
    canonical_json_bytes(normalized)
    return normalized


def evaluate_semantic_continuation(baseline: Mapping[str, Any]) -> dict[str, Any]:
    """Apply the predeclared lexical-gap gate without semantic results."""
    if not isinstance(baseline, Mapping):
        raise ValueError("baseline must be an object")
    target = baseline.get("target_styles")
    if not isinstance(target, Mapping):
        raise ValueError("baseline target_styles metrics are missing")
    query_count = target.get("query_count")
    recall_at_5 = target.get("recall_at_5")
    misses_at_5 = target.get("misses_at_5")
    if not isinstance(query_count, int) or isinstance(query_count, bool) or query_count < 0:
        raise ValueError("baseline target_styles.query_count must be a non-negative integer")
    if (
        isinstance(recall_at_5, bool)
        or not isinstance(recall_at_5, (int, float))
        or not math.isfinite(float(recall_at_5))
        or not 0.0 <= float(recall_at_5) <= 1.0
    ):
        raise ValueError("baseline target_styles.recall_at_5 must be finite and in 0..1")
    if (
        not isinstance(misses_at_5, int)
        or isinstance(misses_at_5, bool)
        or not 0 <= misses_at_5 <= query_count
    ):
        raise ValueError("baseline target_styles.misses_at_5 must be an integer in 0..query_count")
    recall_at_5 = float(recall_at_5)
    passed = (
        query_count >= SEMANTIC_CONTINUATION_GATE["minimum_target_queries"]
        and recall_at_5 <= SEMANTIC_CONTINUATION_GATE["maximum_lexical_recall_at_5"]
        and misses_at_5 >= SEMANTIC_CONTINUATION_GATE["minimum_target_misses_at_5"]
    )
    return {
        "continue_to_semantic_worker": passed,
        "measured": {
            "query_count": query_count,
            "recall_at_5": recall_at_5,
            "misses_at_5": misses_at_5,
        },
        "thresholds": dict(SEMANTIC_CONTINUATION_GATE),
        "reason": (
            "material_lexical_gap_demonstrated"
            if passed
            else "material_lexical_gap_not_demonstrated"
        ),
    }


__all__ = [
    "CONTRACT_VERSION",
    "DEFAULT_DEPLOYMENT_ROOT",
    "SEMANTIC_CONTINUATION_GATE",
    "SEMANTIC_PROMOTION_GATE",
    "INDEX_MANIFEST_SCHEMA_VERSION",
    "MODEL_MANIFEST_SCHEMA_VERSION",
    "PUBLIC_LIMITS",
    "THREAT_MODEL",
    "WORKER_PROTOCOL_SCHEMA_VERSION",
    "canonical_json_bytes",
    "evaluate_semantic_continuation",
    "object_sha256",
    "validate_citation_source",
    "validate_semantic_filters",
    "validate_evaluation_set",
    "validate_index_manifest",
    "validate_model_manifest",
    "validate_semantic_build_id",
]
