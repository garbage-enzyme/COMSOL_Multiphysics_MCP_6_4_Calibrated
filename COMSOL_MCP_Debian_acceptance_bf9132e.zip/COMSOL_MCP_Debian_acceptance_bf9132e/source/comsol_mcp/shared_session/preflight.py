"""Pure two-probe classification for local shared Desktop/Server state."""

from __future__ import annotations

import math
import re
from typing import Any, Mapping

from comsol_mcp.durable import canonical_sha256_v1

from .contracts import (
    LISTENER_BIND_SCOPE_WILDCARD,
    normalize_shared_listener_bind_host,
    normalize_shared_server_endpoint,
    summarize_shared_listener_bindings,
)

SHARED_SERVER_PREFLIGHT_SCHEMA = "comsol_mcp.shared_server_preflight"
SHARED_SERVER_PREFLIGHT_VERSION = "1.1.0"
ACCEPTED_RELEASE_LINE = (6, 4, 0)
MAX_INVENTORY_PROCESSES = 128
MAX_INVENTORY_LISTENERS = 128

_PROCESS_FIELDS = frozenset(
    {
        "pid",
        "parent_pid",
        "kind",
        "create_time",
        "command_signature",
        "file_version",
        "window_count",
        "responding",
    }
)
_LISTENER_FIELDS = frozenset({"host", "port", "pid"})
_SNAPSHOT_FIELDS = frozenset({"inventory_complete", "observed_at_epoch", "processes", "listeners"})
_PROCESS_KINDS = frozenset({"comsol_desktop", "comsol_server", "mph_client", "other_comsol"})
_HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")
# The first digit-run must be the four-part build: a non-digit prefix (the
# localized product name) is allowed, but the match ends at the build, so
# extra dotted segments or trailing numbers keep the readback unreadable.
_VERSION = re.compile(r"^\D*?(\d+)\.(\d+)\.(\d+)\.(\d+)(?![\d.])")
# Display fallbacks may only use a parenthesized build whose digits reach the
# closing parenthesis (any localized label prefix allowed): "(Build: 293)",
# "(开发版本: 293)", "(293)". Architecture text such as "(64-bit)" leaves the
# digit run mid-parenthesis and must not be accepted as a build number.
_CLIENTAPI_DISPLAY_VERSION = re.compile(
    r"^[^\d]*(\d+)\.(\d+)(?:\.(\d+))?.*\(\D*(\d+)\s*\)"
)


def _exact_mapping(value: Any, fields: frozenset[str], label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping) or not all(isinstance(key, str) for key in value):
        raise ValueError(f"{label} must be an object with string keys")
    actual = set(value)
    if actual != fields:
        raise ValueError(
            f"{label} fields are invalid; "
            f"missing={sorted(fields - actual)}, unknown={sorted(actual - fields)}"
        )
    return dict(value)


def _positive_integer(value: Any, label: str, *, allow_zero: bool = False) -> int:
    minimum = 0 if allow_zero else 1
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        qualifier = "nonnegative" if allow_zero else "positive"
        raise ValueError(f"{label} must be a {qualifier} integer")
    return value


def _finite(value: Any, label: str, *, positive: bool = True) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be finite")
    number = float(value)
    if not math.isfinite(number) or (positive and number <= 0):
        raise ValueError(f"{label} must be positive and finite")
    return number


def _normalize_version(
    value: Any,
) -> tuple[str | None, tuple[int, int, int, int] | None]:
    if value is None:
        return None, None
    if not isinstance(value, str) or not value or len(value) > 128:
        raise ValueError("COMSOL file version must be a bounded string or null")
    match = _VERSION.search(value)
    if match is None:
        return "unreadable", None
    parts = tuple(int(item) for item in match.groups())
    return ".".join(str(item) for item in parts), parts


def normalize_comsol_version_readback(
    value: Any,
    *,
    expected_file_version: str | None = None,
) -> tuple[str | None, tuple[int, int, int, int] | None]:
    """Normalize one bounded full COMSOL build readback for post-connect gates."""
    normalized, parts = _normalize_version(value)
    if parts is not None or not isinstance(value, str):
        return normalized, parts
    display = _CLIENTAPI_DISPLAY_VERSION.search(value)
    if display is None or expected_file_version is None:
        return normalized, parts
    expected_normalized, expected_parts = _normalize_version(expected_file_version)
    if expected_parts is None:
        return normalized, parts
    major_text, minor_text, maintenance_text, build_text = display.groups()
    observed = (
        int(major_text),
        int(minor_text),
        0 if maintenance_text is None else int(maintenance_text),
        int(build_text),
    )
    if observed != (
        expected_parts[0],
        expected_parts[1],
        expected_parts[2],
        expected_parts[3],
    ):
        return "unreadable", None
    return expected_normalized, expected_parts


def _normalize_process(value: Any, index: int) -> dict[str, Any]:
    label = f"processes[{index}]"
    raw = _exact_mapping(value, _PROCESS_FIELDS, label)
    kind = raw["kind"]
    if kind not in _PROCESS_KINDS:
        raise ValueError(f"{label}.kind is unsupported")
    signature = raw["command_signature"]
    if not isinstance(signature, str) or not _HEX64.fullmatch(signature):
        raise ValueError(f"{label}.command_signature must be a SHA-256")
    version, version_parts = _normalize_version(raw["file_version"])
    if not isinstance(raw["responding"], bool):
        raise ValueError(f"{label}.responding must be boolean")
    body = {
        "pid": _positive_integer(raw["pid"], f"{label}.pid"),
        "parent_pid": _positive_integer(raw["parent_pid"], f"{label}.parent_pid", allow_zero=True),
        "kind": kind,
        "create_time": _finite(raw["create_time"], f"{label}.create_time"),
        "command_signature": signature.casefold(),
        "file_version": version,
        "version_parts": version_parts,
        "window_count": _positive_integer(
            raw["window_count"], f"{label}.window_count", allow_zero=True
        ),
        "responding": raw["responding"],
    }
    # Identity keys on process replacement only. Windows GetProcessTimes
    # exposes creation time at 100 ns resolution, so a recycled PID colliding
    # on create_time across two probes is not physically realizable; the
    # varying window_count/responding fields are deliberately excluded.
    body["identity_sha256"] = canonical_sha256_v1(
        {
            key: body[key]
            for key in ("pid", "kind", "create_time", "command_signature", "file_version")
        }
    )
    return body


def _normalize_listener(value: Any, index: int) -> dict[str, Any]:
    label = f"listeners[{index}]"
    raw = _exact_mapping(value, _LISTENER_FIELDS, label)
    host, bind_scope = normalize_shared_listener_bind_host(raw["host"])
    port = normalize_shared_server_endpoint({"host": "127.0.0.1", "port": raw["port"]}).port
    return {
        "host": host,
        "port": port,
        "pid": _positive_integer(raw["pid"], f"{label}.pid"),
        "bind_scope": bind_scope,
    }


def normalize_shared_preflight_snapshot(value: Any) -> dict[str, Any]:
    """Normalize one bounded complete process/listener observation."""
    raw = _exact_mapping(value, _SNAPSHOT_FIELDS, "preflight snapshot")
    if raw["inventory_complete"] is not True:
        raise ValueError("preflight process/listener inventory must be complete")
    processes = raw["processes"]
    listeners = raw["listeners"]
    if not isinstance(processes, list) or len(processes) > MAX_INVENTORY_PROCESSES:
        raise ValueError("preflight processes must be a bounded list")
    if not isinstance(listeners, list) or len(listeners) > MAX_INVENTORY_LISTENERS:
        raise ValueError("preflight listeners must be a bounded list")
    normalized_processes = [_normalize_process(item, index) for index, item in enumerate(processes)]
    pids = [item["pid"] for item in normalized_processes]
    if len(pids) != len(set(pids)):
        raise ValueError("preflight process inventory contains duplicate PIDs")
    return {
        "inventory_complete": True,
        "observed_at_epoch": _finite(raw["observed_at_epoch"], "preflight observation time"),
        "processes": normalized_processes,
        "listeners": [_normalize_listener(item, index) for index, item in enumerate(listeners)],
    }


def _public_processes(processes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "kind": item["kind"],
            "identity_sha256": item["identity_sha256"],
            "file_version": item["file_version"],
            "window_count": item["window_count"],
            "responding": item["responding"],
        }
        for item in sorted(processes, key=lambda item: (item["kind"], item["pid"]))
    ]


def classify_shared_server_preflight(
    *,
    endpoint: Mapping[str, Any],
    first_probe: Mapping[str, Any],
    second_probe: Mapping[str, Any],
) -> dict[str, Any]:
    """Classify stable local shared-session readiness without importing MPh."""
    declared = normalize_shared_server_endpoint(endpoint)
    first = normalize_shared_preflight_snapshot(first_probe)
    second = normalize_shared_preflight_snapshot(second_probe)
    processes = second["processes"]
    desktops = [item for item in processes if item["kind"] == "comsol_desktop"]
    servers = [item for item in processes if item["kind"] == "comsol_server"]
    collisions = [item for item in processes if item["kind"] in {"mph_client", "other_comsol"}]
    first_by_pid = {item["pid"]: item for item in first["processes"]}
    second_by_pid = {item["pid"]: item for item in processes}
    changed = [
        item
        for item in processes
        if item["pid"] not in first_by_pid
        or item["identity_sha256"] != first_by_pid[item["pid"]]["identity_sha256"]
    ]
    changed.extend(item for item in first["processes"] if item["pid"] not in second_by_pid)
    first_listener = summarize_shared_listener_bindings(first["listeners"], endpoint=declared)
    second_listener = summarize_shared_listener_bindings(second["listeners"], endpoint=declared)
    violations: list[str] = []
    warnings: list[str] = []
    state = "ready_for_attach"
    retryable = False
    listener_bind_scope = second_listener["bind_scope"]
    if listener_bind_scope == LISTENER_BIND_SCOPE_WILDCARD:
        warnings.append("listener_bind_scope=wildcard")

    comsol_versions = [item["version_parts"] for item in processes if item["kind"] != "mph_client"]
    if second["observed_at_epoch"] <= first["observed_at_epoch"]:
        violations.append("probe_chronology_invalid")
        state = "probe_chronology_invalid"
        retryable = True
    elif changed:
        violations.append("process_identity_changed_between_probes")
        state = "process_identity_changed_between_probes"
        retryable = True
    elif collisions:
        violations.append("unclassified_comsol_or_mph_collision")
        state = "unclassified_comsol_or_mph_collision"
        retryable = True
    elif any(parts is None or parts[:3] != ACCEPTED_RELEASE_LINE for parts in comsol_versions):
        violations.append("unsupported_or_ambiguous_comsol_version")
        state = "unsupported_or_ambiguous_comsol_version"
    elif len(desktops) > 1 or sum(item["window_count"] for item in desktops) > 1:
        violations.append("ambiguous_gui_clients")
        state = "ambiguous_gui_clients"
    elif not desktops and second_listener["classification"] == "unavailable":
        violations.append("desktop_and_server_absent")
        state = "desktop_and_server_absent"
        retryable = True
    elif not desktops:
        violations.append("desktop_absent")
        state = "desktop_absent"
        retryable = True
    elif (
        desktops[0]["window_count"] == 0
        or not desktops[0]["responding"]
        or first_listener["classification"] == "unavailable"
        or second_listener["classification"] == "unavailable"
    ):
        violations.append("desktop_or_server_starting")
        state = "desktop_or_server_starting"
        retryable = True
    elif not first_listener["stable"] or not second_listener["stable"]:
        violations.append("unknown_or_multiple_candidate_servers")
        state = "unknown_or_multiple_candidate_servers"
    elif first_listener["owner_pid"] != second_listener["owner_pid"]:
        violations.append("listener_owner_changed_between_probes")
        state = "listener_owner_changed_between_probes"
    elif first_listener["bind_scope"] != second_listener["bind_scope"]:
        violations.append("listener_bind_scope_changed_between_probes")
        state = "listener_bind_scope_changed_between_probes"
    else:
        owner_pid = second_listener["owner_pid"]
        owner = next((item for item in servers if item["pid"] == owner_pid), None)
        if owner is None or len(servers) != 1:
            violations.append("unknown_or_multiple_candidate_servers")
            state = "unknown_or_multiple_candidate_servers"
        elif not owner["responding"]:
            violations.append("desktop_or_server_starting")
            state = "desktop_or_server_starting"
            retryable = True
        else:
            builds = {item["file_version"] for item in (*desktops, owner)}
            if len(builds) > 1:
                warnings.append("same_accepted_release_line_build_difference")

    public_processes = _public_processes(processes)
    return {
        "schema_name": SHARED_SERVER_PREFLIGHT_SCHEMA,
        "schema_version": SHARED_SERVER_PREFLIGHT_VERSION,
        "success": state == "ready_for_attach",
        "state": state,
        "retryable": retryable,
        "endpoint": declared.to_dict(),
        "listener_bind_scope": listener_bind_scope,
        "listener_bind_hosts": second_listener["bind_hosts"],
        "desktop_count": len(desktops),
        "desktop_window_count": sum(item["window_count"] for item in desktops),
        "server_count": len(servers),
        "accepted_release_line": "6.4.0.*",
        "processes": public_processes,
        "process_inventory_sha256": canonical_sha256_v1(public_processes),
        "violations": violations,
        "warnings": warnings,
        "paths_included": False,
        "mph_imported": False,
        "client_constructed": False,
        "lease_acquired": False,
    }


__all__ = [
    "ACCEPTED_RELEASE_LINE",
    "SHARED_SERVER_PREFLIGHT_SCHEMA",
    "SHARED_SERVER_PREFLIGHT_VERSION",
    "classify_shared_server_preflight",
    "normalize_comsol_version_readback",
    "normalize_shared_preflight_snapshot",
]
