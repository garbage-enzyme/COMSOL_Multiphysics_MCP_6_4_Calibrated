"""Injected process-only worker used to prove reference-power durability without COMSOL."""

from __future__ import annotations

import csv
import hashlib
import io
import os
import sys
import time
from pathlib import Path

from .process_control import contain_current_process_tree
from .store import JobStore, cancel_request_targets_attempt, process_identity

MAX_SEQUENCE_RESULTS_BYTES = 64 * 1024


def _read_completed_results(path: Path, *, total: int) -> set[int]:
    if not path.is_file() or path.stat().st_size == 0:
        return set()
    if path.stat().st_size > MAX_SEQUENCE_RESULTS_BYTES:
        raise ValueError("sequence results exceed their byte limit")
    with path.open("r+b") as handle:
        payload = handle.read(MAX_SEQUENCE_RESULTS_BYTES + 1)
        if not payload.endswith(b"\n"):
            boundary = payload.rfind(b"\n")
            handle.truncate(0 if boundary < 0 else boundary + 1)
            handle.flush()
            os.fsync(handle.fileno())
            payload = b"" if boundary < 0 else payload[: boundary + 1]
    if not payload:
        return set()
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("sequence results are not UTF-8") from exc
    reader = csv.DictReader(io.StringIO(text, newline=""))
    if reader.fieldnames != ["index", "status"]:
        raise ValueError("sequence results header is invalid")
    completed: set[int] = set()
    for row in reader:
        if set(row) != {"index", "status"} or row["status"] != "ok":
            raise ValueError("sequence result row is invalid")
        try:
            index = int(row["index"])
        except (TypeError, ValueError) as exc:
            raise ValueError("sequence result index is invalid") from exc
        if index != len(completed) or not 0 <= index < total:
            raise ValueError("sequence result order is invalid")
        completed.add(index)
    return completed


def _run(root: str, job_id: str) -> int:
    process_tree_contained = contain_current_process_tree()
    store = JobStore(Path(root))
    spec = store.read_spec(job_id)
    if spec.get("job_type") != "test_sequence":
        raise ValueError("Sequence worker refuses non-test jobs")
    identity = process_identity(os.getpid())
    store.bind_worker_identity(job_id, identity)
    store.update_state(
        job_id,
        patch={
            "process_tree_contained": bool(process_tree_contained),
            "controlled_leaf_worker": {
                "kind": "sequence_leaf_v1",
                "worker": identity,
                "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            },
        },
        event="worker_containment_recorded",
        event_data={"process_tree_contained": bool(process_tree_contained)},
    )
    initial_state = store.read_state(job_id)
    attempt = int(initial_state.get("attempt", 1))
    current = initial_state["status"]
    if current == "cancel_requested" or cancel_request_targets_attempt(
        store.read_control(job_id), attempt
    ):
        store.record_cooperative_cancel_observed(
            job_id,
            attempt=attempt,
            message="Stopped before startup",
        )
        return 0
    if current == "submitted":
        store.update_state(job_id, "starting", event="worker_started")
    elif current != "starting":
        raise ValueError(f"Sequence worker cannot start from {current}")
    if cancel_request_targets_attempt(store.read_control(job_id), attempt):
        store.record_cooperative_cancel_observed(
            job_id,
            attempt=attempt,
            message="Stopped before smoke",
        )
        return 0
    store.update_state(job_id, "smoke_running", event="smoke_started")
    delays = spec["delays"]
    results_path = store.job_dir(job_id) / "results.csv"
    completed = _read_completed_results(results_path, total=len(delays))
    if 0 in completed:
        store.update_state(job_id, "smoke_validated", event="smoke_revalidated")
        if len(delays) > 1:
            store.update_state(job_id, "running", event="broad_phase_resumed")
    if completed:
        store.update_state(
            job_id,
            patch={"progress": {"completed": len(completed), "total": len(delays)}},
            event="durable_results_reconciled",
        )
    for index, delay in enumerate(delays):
        if index in completed:
            continue
        time.sleep(float(delay))
        write_header = not results_path.exists() or results_path.stat().st_size == 0
        with results_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["index", "status"])
            if write_header:
                writer.writeheader()
            writer.writerow({"index": index, "status": "ok"})
            handle.flush()
            os.fsync(handle.fileno())
        cancel_requested = cancel_request_targets_attempt(store.read_control(job_id), attempt)
        if cancel_requested:
            store.update_state(
                job_id,
                patch={"progress": {"completed": index + 1, "total": len(delays)}},
                event="sequence_step",
                event_data={"index": index},
            )
            store.record_cooperative_cancel_observed(
                job_id,
                attempt=attempt,
                message="Stopped between points",
            )
            return 0
        next_status = None
        if index == 0:
            next_status = "smoke_validated"
        store.update_state(
            job_id,
            next_status,
            patch={"progress": {"completed": index + 1, "total": len(delays)}},
            event="sequence_step",
            event_data={"index": index},
        )
        if index == 0 and len(delays) > 1:
            store.update_state(job_id, "running", event="broad_phase_started")
    store.update_state(job_id, "completed", event="completed")
    return 0


def run(root: str, job_id: str) -> int:
    try:
        return _run(root, job_id)
    except ValueError as exc:
        store = JobStore(Path(root))
        state = store.read_state(job_id)
        if state.get("status") in {"cancel_requested", "cancelling"}:
            store.record_cooperative_cancel_observed(
                job_id,
                attempt=int(state.get("attempt", 1)),
                message="Stopped between state transitions",
                worker_error={
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "cleanup_errors": [],
                },
            )
            return 1
        raise


if __name__ == "__main__":
    try:
        raise SystemExit(run(sys.argv[1], sys.argv[2]))
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
