"""Exact-identity process inspection used by the durable cancellation cancellation coordinator."""

from __future__ import annotations

import ctypes
import hashlib
import math
import os
from pathlib import Path
from ctypes import wintypes
from typing import Any

import psutil

from .store import (
    CREATE_TIME_TOLERANCE_SECONDS,
    process_identity_state,
)


def owned_solver_identities_from_lease(lease: dict[str, Any]) -> list[dict[str, Any]]:
    """Return only termination-eligible solver identities from one lease."""
    if not isinstance(lease, dict):
        raise ValueError("solver lease must be an object")
    servers = lease.get("comsol_server_processes")
    if not isinstance(servers, list):
        raise ValueError("lease server identities are missing")
    normalized: list[dict[str, Any]] = []
    for index, item in enumerate(servers):
        if not isinstance(item, dict):
            raise ValueError(f"lease server identity {index} must be an object")
        pid = item.get("pid")
        created = item.get("process_create_time")
        signature = item.get("command_signature")
        if isinstance(pid, bool) or not isinstance(pid, int) or pid <= 0:
            raise ValueError(f"lease server identity {index} has an invalid PID")
        if (
            isinstance(created, bool)
            or not isinstance(created, (int, float))
            or not math.isfinite(float(created))
        ):
            raise ValueError(f"lease server identity {index} has an invalid creation time")
        if not isinstance(signature, str) or len(signature) != 64:
            raise ValueError(f"lease server identity {index} has an invalid command signature")
        try:
            int(signature, 16)
        except ValueError as exc:
            raise ValueError(
                f"lease server identity {index} has an invalid command signature"
            ) from exc
        normalized.append(dict(item))
    attached = lease.get("attached_server")
    attached_pid = (
        attached.get("server_pid")
        if isinstance(attached, dict) and attached.get("owned") is False
        else None
    )
    if any(item["pid"] == attached_pid for item in normalized):
        raise ValueError("non-owned attached server appears in owned termination identities")
    return normalized


class OwnedJobObject:
    """Windows kill-on-close containment for one process tree we launched.

    The handle deliberately remains owned by the MCP control process.  Closing it
    (including normal process teardown) kills only processes explicitly assigned
    to this object; it never searches for processes by name or command line.
    """

    def __init__(self, handle: int, pid: int):
        self._handle = handle
        self.pid = int(pid)

    @classmethod
    def assign(cls, pid: int) -> "OwnedJobObject | None":
        """Create a kill-on-close Job Object and assign an exact child PID.

        Returns ``None`` on non-Windows platforms or when Windows refuses a safe
        assignment (for example a nested/restricted job).  Callers retain the
        existing exact-identity fallback in that case.
        """
        if os.name != "nt":
            return None
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.argtypes = (wintypes.LPVOID, wintypes.LPCWSTR)
        kernel32.CreateJobObjectW.restype = wintypes.HANDLE
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.AssignProcessToJobObject.argtypes = (wintypes.HANDLE, wintypes.HANDLE)
        kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel32.SetInformationJobObject.argtypes = (
            wintypes.HANDLE,
            wintypes.INT,
            wintypes.LPVOID,
            wintypes.DWORD,
        )
        kernel32.SetInformationJobObject.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL

        class _LargeInteger(ctypes.Structure):
            _fields_ = [("QuadPart", ctypes.c_longlong)]

        class _BasicLimitInformation(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", _LargeInteger),
                ("PerJobUserTimeLimit", _LargeInteger),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class _IoCounters(ctypes.Structure):
            _fields_ = [
                (name, ctypes.c_ulonglong)
                for name in (
                    "ReadOperationCount",
                    "WriteOperationCount",
                    "OtherOperationCount",
                    "ReadTransferCount",
                    "WriteTransferCount",
                    "OtherTransferCount",
                )
            ]

        class _ExtendedLimitInformation(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", _BasicLimitInformation),
                ("IoInfo", _IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            return None
        process = None
        assigned = False
        try:
            # PROCESS_SET_QUOTA | PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION
            process = kernel32.OpenProcess(0x0100 | 0x0001 | 0x1000, False, int(pid))
            if not process:
                return None
            limits = _ExtendedLimitInformation()
            limits.BasicLimitInformation.LimitFlags = (
                0x00002000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            )
            if not kernel32.SetInformationJobObject(
                job, 9, ctypes.byref(limits), ctypes.sizeof(limits)
            ):
                return None
            if not kernel32.AssignProcessToJobObject(job, process):
                return None
            assigned = True
            return cls(int(job), pid)
        finally:
            if process:
                kernel32.CloseHandle(process)
            if not assigned:
                kernel32.CloseHandle(job)

    def close(self) -> None:
        if self._handle and os.name == "nt":
            ctypes.WinDLL("kernel32", use_last_error=True).CloseHandle(
                wintypes.HANDLE(self._handle)
            )
            self._handle = 0


_CURRENT_PROCESS_JOB: OwnedJobObject | None = None


def contain_current_process_tree() -> bool:
    """Keep kill-on-close containment in the detached worker itself.

    The MCP host never owns this handle, so a host restart cannot kill a durable
    worker.  Worker exit instead closes the handle and cleans only descendants
    explicitly inherited by the job object.
    """
    global _CURRENT_PROCESS_JOB
    if _CURRENT_PROCESS_JOB is not None:
        return True
    contained = OwnedJobObject.assign(os.getpid())
    if contained is None:
        return False
    _CURRENT_PROCESS_JOB = contained
    return True


def inspect_identity(identity: dict[str, Any]) -> dict[str, Any]:
    """Return an exact identity verdict without acting on a process."""
    state, reason = process_identity_state(identity)
    return {"identity": identity, "state": state, "reason": reason}


def controlled_leaf_worker_proved(spec: dict, state: dict, worker: dict) -> bool:
    """Recognize only the fixed internal sequence worker, which never spawns children.

    This is a test-driver contract, not native process-tree containment.
    Public production submission never accepts this job type.
    """
    contract = state.get("controlled_leaf_worker")
    return bool(
        spec.get("job_type") == "test_sequence"
        and isinstance(contract, dict)
        and contract.get("kind") == "sequence_leaf_v1"
        and contract.get("worker") == worker
        and contract.get("driver_sha256")
        == hashlib.sha256(Path(__file__).with_name("sequence_worker.py").read_bytes()).hexdigest()
    )


def capture_owned_descendants(worker_identity: dict[str, Any]) -> dict[str, Any]:
    """Capture only descendants of a worker whose full identity still matches."""
    verdict = inspect_identity(worker_identity)
    if verdict["state"] != "active":
        return {"worker": verdict, "descendants": [], "capture_complete": False}
    try:
        worker = psutil.Process(int(worker_identity["pid"]))
        reopened = _inspect_open_process(worker, worker_identity)
        if reopened["state"] != "active":
            return {"worker": reopened, "descendants": [], "capture_complete": False}
        children = worker.children(recursive=True)
    except psutil.NoSuchProcess as exc:
        # The worker can exit between the exact identity check and children().
        # Re-inspect so callers can distinguish proven exit from inspection
        # uncertainty. Descendant cleanup still requires separate containment
        # evidence; an empty list alone is not proof.
        after = inspect_identity(worker_identity)
        return {
            "worker": after,
            "descendants": [],
            "capture_complete": False,
            "reason": f"worker exited during descendant capture: {exc}",
        }
    except (psutil.AccessDenied, psutil.ZombieProcess, OSError) as exc:
        return {
            "worker": {
                **verdict,
                "state": "uncertain",
                "reason": f"cannot inspect descendants: {exc}",
            },
            "descendants": [],
            "capture_complete": False,
        }
    descendants: list[dict[str, Any]] = []
    for child in children:
        try:
            # Snapshot identity through the enumerated Process object itself.
            # Re-resolving by PID here would silently adopt an unrelated
            # replacement process when the child exits and its PID is reused
            # before the second lookup runs; the snapshot keeps later exact
            # termination bound to the process that was actually observed.
            with child.oneshot():
                command = list(child.cmdline())
                descendants.append(
                    {
                        "pid": child.pid,
                        "process_create_time": child.create_time(),
                        "command_signature": hashlib.sha256(
                            "\0".join(command).encode("utf-8", errors="replace")
                        ).hexdigest(),
                    }
                )
        except psutil.NoSuchProcess:
            # A child that exits while the stable list is converted is already
            # absent. Preserve identities captured before and after it.
            continue
        except (psutil.AccessDenied, psutil.ZombieProcess, OSError) as exc:
            return {
                "worker": {
                    **verdict,
                    "state": "uncertain",
                    "reason": f"cannot inspect descendant identity: {exc}",
                },
                "descendants": descendants,
                "capture_complete": False,
            }
    return {"worker": verdict, "descendants": descendants, "capture_complete": True}


def _inspect_open_process(
    process: psutil.Process,
    identity: dict[str, Any],
) -> dict[str, Any]:
    """Validate exact identity through the same process object used to act."""
    try:
        expected_pid = int(identity["pid"])
        expected_created = float(identity["process_create_time"])
    except KeyError, TypeError, ValueError, OverflowError:
        return {
            "identity": identity,
            "state": "uncertain",
            "reason": "process identity fields are missing or invalid",
        }
    try:
        with process.oneshot():
            actual_pid = int(process.pid)
            actual_created = float(process.create_time())
            command = list(process.cmdline())
    except psutil.NoSuchProcess:
        return {"identity": identity, "state": "stale", "reason": "worker PID no longer exists"}
    except (psutil.AccessDenied, psutil.ZombieProcess, OSError) as exc:
        return {
            "identity": identity,
            "state": "uncertain",
            "reason": f"worker identity cannot be inspected: {exc}",
        }
    if actual_pid != expected_pid:
        return {"identity": identity, "state": "stale", "reason": "worker PID was reused"}
    if abs(actual_created - expected_created) > CREATE_TIME_TOLERANCE_SECONDS:
        return {"identity": identity, "state": "stale", "reason": "worker PID was reused"}
    expected_signature = identity.get("command_signature")
    if not isinstance(expected_signature, str) or not expected_signature:
        # The exact-identity contract includes the command signature; without
        # it PID + create time alone can never prove an active match.
        return {
            "identity": identity,
            "state": "uncertain",
            "reason": "worker command signature is missing from the captured identity",
        }
    actual_signature = hashlib.sha256(
        "\0".join(command).encode("utf-8", errors="replace")
    ).hexdigest()
    if actual_signature != expected_signature:
        return {
            "identity": identity,
            "state": "stale",
            "reason": "worker command line no longer matches",
        }
    return {
        "identity": identity,
        "state": "active",
        "reason": "worker PID, creation time, and command line match",
    }


def terminate_exact(identity: dict[str, Any], *, force: bool = False) -> dict[str, Any]:
    """Validate and terminate through one process object with reuse protection."""
    try:
        process = psutil.Process(int(identity["pid"]))
    except KeyError, TypeError, ValueError, OverflowError:
        before = {
            "identity": identity,
            "state": "uncertain",
            "reason": "process identity fields are missing or invalid",
        }
        return {"acted": False, "before": before, "reason": "identity_not_active"}
    except psutil.NoSuchProcess:
        before = {"identity": identity, "state": "stale", "reason": "worker PID no longer exists"}
        return {"acted": False, "before": before, "reason": "identity_not_active"}
    pinned_handle = None
    kernel32 = None
    if os.name == "nt":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.TerminateProcess.argtypes = (wintypes.HANDLE, wintypes.UINT)
        kernel32.TerminateProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL
        # PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION. Holding this
        # handle pins the kernel process object across identity validation and
        # termination, so PID reuse cannot retarget the action.
        pinned_handle = kernel32.OpenProcess(0x0001 | 0x1000, False, int(identity["pid"]))
        if not pinned_handle:
            before = inspect_identity(identity)
            return {
                "acted": False,
                "before": before,
                "reason": f"process_handle_open_failed: {ctypes.get_last_error()}",
            }
    try:
        before = _inspect_open_process(process, identity)
        if before["state"] != "active":
            # Preserve the distinction: "uncertain" is never proof of absence
            # and must not be reported as a proven-inactive identity.
            return {
                "acted": False,
                "before": before,
                "reason": (
                    "identity_uncertain"
                    if before["state"] == "uncertain"
                    else "identity_not_active"
                ),
            }
        action = "kill" if force else "terminate"
        if pinned_handle is not None and kernel32 is not None:
            if not kernel32.TerminateProcess(pinned_handle, 1):
                return {
                    "acted": False,
                    "before": before,
                    "reason": f"process_action_failed: winerror {ctypes.get_last_error()}",
                }
        elif force:
            process.kill()
        else:
            process.terminate()
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, OSError) as exc:
        return {
            "acted": False,
            "before": before,
            "reason": f"process_action_failed: {type(exc).__name__}: {exc}",
        }
    finally:
        if pinned_handle is not None and kernel32 is not None:
            kernel32.CloseHandle(pinned_handle)
    return {"acted": True, "action": action, "before": before}


def verify_absent(identities: list[dict[str, Any]]) -> dict[str, Any]:
    """Verify every captured identity is stale; uncertainty is never absence."""
    verdicts = [inspect_identity(identity) for identity in identities]
    return {
        "absent": all(item["state"] == "stale" for item in verdicts),
        "verdicts": verdicts,
    }
