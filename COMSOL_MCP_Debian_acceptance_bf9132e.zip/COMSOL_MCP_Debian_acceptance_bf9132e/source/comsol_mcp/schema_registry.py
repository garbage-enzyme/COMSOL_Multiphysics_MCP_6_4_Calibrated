"""Version support registry for named public and durable artifact schemas."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from comsol_mcp import __version__
from comsol_mcp.durable import canonical_sha256_v1
from comsol_mcp.research import (
    CAMPAIGN_MANIFEST_SCHEMA_NAME,
    CAMPAIGN_MANIFEST_SCHEMA_VERSION,
    CANDIDATE_RECORD_SCHEMA_NAME,
    CANDIDATE_RECORD_SCHEMA_VERSION,
    DECISION_RECORD_SCHEMA_NAME,
    DECISION_RECORD_SCHEMA_VERSION,
    DESIGN_SPACE_SCHEMA_NAME,
    DESIGN_SPACE_SCHEMA_VERSION,
    EVALUATION_RECORD_SCHEMA_NAME,
    EVALUATION_RECORD_SCHEMA_VERSION,
    EXTERNAL_VALIDATION_RECEIPT_SCHEMA_NAME,
    EXTERNAL_VALIDATION_RECEIPT_SCHEMA_VERSION,
    MATERIAL_CATALOG_SCHEMA_NAME,
    MATERIAL_CATALOG_SCHEMA_VERSION,
    MATERIAL_STATE_CONFIGURATION_SCHEMA_NAME,
    MATERIAL_STATE_CONFIGURATION_SCHEMA_VERSION,
    OBJECTIVE_SCORE_SCHEMA_NAME,
    OBJECTIVE_SCORE_SCHEMA_VERSION,
    OPTICAL_PROPERTY_MAPPING_SCHEMA_NAME,
    OPTICAL_PROPERTY_MAPPING_SCHEMA_VERSION,
    OPTIMIZATION_CONDITION_TABLE_SCHEMA_NAME,
    OPTIMIZATION_CONDITION_TABLE_SCHEMA_VERSION,
    OPTIMIZER_CHECKPOINT_SCHEMA_NAME,
    OPTIMIZER_CHECKPOINT_SCHEMA_VERSION,
    OPTIMIZER_EXPLANATION_SCHEMA_NAME,
    OPTIMIZER_EXPLANATION_SCHEMA_VERSION,
    OPTIMIZER_PROPOSAL_SCHEMA_NAME,
    OPTIMIZER_PROPOSAL_SCHEMA_VERSION,
    OPTIMIZER_STATE_SCHEMA_NAME,
    OPTIMIZER_STATE_SCHEMA_VERSION,
    PORTFOLIO_SCHEMA_NAME,
    PORTFOLIO_SCHEMA_VERSION,
    RESEARCH_GOAL_SCHEMA_NAME,
    RESEARCH_GOAL_SCHEMA_VERSION,
    RESEARCH_JOURNAL_RECORD_SCHEMA_NAME,
    RESEARCH_JOURNAL_RECORD_SCHEMA_VERSION,
    ROBUST_CONDITION_CONTROLS_SCHEMA_NAME,
    ROBUST_CONDITION_CONTROLS_SCHEMA_VERSION,
    ROBUST_FINALIST_VALIDATION_POLICY_READABLE_VERSIONS,
    ROBUST_FINALIST_VALIDATION_POLICY_SCHEMA_NAME,
    ROBUST_FINALIST_VALIDATION_POLICY_SCHEMA_VERSION,
    ROBUST_FINALIST_VALIDATION_RECEIPT_SCHEMA_NAME,
    ROBUST_FINALIST_VALIDATION_RECEIPT_SCHEMA_VERSION,
    ROBUST_GRADIENT_POLICY_SCHEMA_NAME,
    ROBUST_GRADIENT_POLICY_SCHEMA_VERSION,
    ROBUST_GRADIENT_RECEIPT_SCHEMA_NAME,
    ROBUST_GRADIENT_RECEIPT_SCHEMA_VERSION,
    ROBUST_MATERIAL_TENSOR_ROWS_SCHEMA_NAME,
    ROBUST_MATERIAL_TENSOR_ROWS_SCHEMA_VERSION,
    ROBUST_OBJECTIVE_CONFIGURATION_SCHEMA_NAME,
    ROBUST_OBJECTIVE_CONFIGURATION_SCHEMA_VERSION,
    ROBUST_OBJECTIVE_GRADIENT_RECEIPT_SCHEMA_NAME,
    ROBUST_OBJECTIVE_GRADIENT_RECEIPT_SCHEMA_VERSION,
    ROBUST_OBJECTIVE_RECEIPT_SCHEMA_NAME,
    ROBUST_OBJECTIVE_RECEIPT_SCHEMA_VERSION,
    ROBUST_OPTIMIZER_EXECUTION_RECEIPT_SCHEMA_NAME,
    ROBUST_OPTIMIZER_EXECUTION_RECEIPT_SCHEMA_VERSION,
    ROBUST_OPTIMIZER_POLICY_SCHEMA_NAME,
    ROBUST_OPTIMIZER_POLICY_SCHEMA_VERSION,
    ROBUST_SHAPE_ADAPTER_BINDING_SCHEMA_NAME,
    ROBUST_SHAPE_ADAPTER_BINDING_SCHEMA_VERSION,
    ROBUST_SHAPE_ADAPTER_CONFIGURATION_SCHEMA_NAME,
    ROBUST_SHAPE_ADAPTER_CONFIGURATION_SCHEMA_VERSION,
    ROBUST_SHAPE_CONTROL_RECEIPT_SCHEMA_NAME,
    ROBUST_SHAPE_CONTROL_RECEIPT_SCHEMA_VERSION,
    ROBUST_SMOOTHING_COMPARISON_SCHEMA_NAME,
    ROBUST_SMOOTHING_COMPARISON_SCHEMA_VERSION,
    SHAPE_SUPPORT_POLICY_SCHEMA_NAME,
    SHAPE_SUPPORT_POLICY_SCHEMA_VERSION,
    STRUCTURE_ADAPTER_APPLICATION_SCHEMA_NAME,
    STRUCTURE_ADAPTER_APPLICATION_SCHEMA_VERSION,
    STRUCTURE_ADAPTER_MANIFEST_SCHEMA_NAME,
    STRUCTURE_ADAPTER_MANIFEST_SCHEMA_VERSION,
    STRUCTURE_TREE_AUDIT_SCHEMA_NAME,
    STRUCTURE_TREE_AUDIT_SCHEMA_VERSION,
    WORKFLOW_CAPSULE_SCHEMA_NAME,
    WORKFLOW_CAPSULE_SCHEMA_VERSION,
)
from comsol_mcp.settings_gui_handshake import HANDSHAKE_SCHEMA, HANDSHAKE_VERSION

OPERATION_LOCK_SCHEMA, OPERATION_LOCK_VERSION = "comsol_mcp.operation_lock", "1.0.0"
PATH_POLICY_SCHEMA, PATH_POLICY_VERSION = "comsol_mcp.path_policy", "1.1.0"
SETTINGS_SCHEMA, SETTINGS_VERSION = "comsol_mcp.settings", "1.3.0"
CLEANUP_OUTCOME_SCHEMA, CLEANUP_OUTCOME_VERSION = "comsol_mcp.cleanup_outcome", "1.0.0"
SHARED_MODEL_LOCK_SCHEMA, SHARED_MODEL_LOCK_VERSION = (
    "comsol_mcp.shared_model_lock",
    "1.0.0",
)
SHARED_MODEL_SNAPSHOT_SCHEMA, SHARED_MODEL_SNAPSHOT_VERSION = (
    "comsol_mcp.shared_model_snapshot",
    "1.0.0",
)
SHARED_SERVER_PREFLIGHT_SCHEMA, SHARED_SERVER_PREFLIGHT_VERSION = (
    "comsol_mcp.shared_server_preflight",
    "1.1.0",
)
BRANCH_CONTINUATION_PLAN_SCHEMA, BRANCH_CONTINUATION_SCHEMA_VERSION = (
    "comsol_mcp.branch_continuation_plan",
    "2.0.0",
)
BRANCH_CONTINUATION_STATES_SCHEMA = "comsol_mcp.branch_continuation_states"
CONVERGENCE_EVALUATION_SCHEMA, CONVERGENCE_LADDER_SCHEMA, CONVERGENCE_SCHEMA_VERSION = (
    "comsol_mcp.convergence_evaluation",
    "comsol_mcp.convergence_ladder",
    "1.0.0",
)
_REFERENCE_POWER_NAMESPACE = "comsol_mcp" + "." + "h" + "1"
REFERENCE_POWER_CONTRACT_SCHEMA = _REFERENCE_POWER_NAMESPACE + "_licensed_gate"
REFERENCE_POWER_EXECUTION_SCHEMA = _REFERENCE_POWER_NAMESPACE + "_execution_spec"
(
    SPECTRAL_BUNDLE_SCHEMA,
    SPECTRAL_CHARACTERIZATION_SCHEMA,
    SPECTRAL_DECISION_SCHEMA,
    SPECTRAL_SCHEMA_VERSION,
) = (
    "comsol_mcp.spectral_point_bundle",
    "comsol_mcp.spectral_characterization",
    "comsol_mcp.spectral_analysis_decision",
    "1.0.0",
)
(
    EVIDENCE_SETTINGS_SCHEMA,
    EVIDENCE_STATUS_SCHEMA,
    EVIDENCE_VERIFICATION_SCHEMA,
    EVIDENCE_INTEGRITY_VERSION,
) = (
    "comsol_mcp.evidence_integrity_settings",
    "comsol_mcp.evidence_integrity_status",
    "comsol_mcp.evidence_integrity_verification",
    "1.0.0",
)
SPECTRAL_PROGRESS_SCHEMA_NAME, SPECTRAL_PROGRESS_SCHEMA_VERSION = (
    "comsol_mcp.spectral_progress",
    "1.0.0",
)
ATTACHED_EXECUTION_BACKEND_SCHEMA, ATTACHED_EXECUTION_BACKEND_VERSION = (
    "comsol_mcp.attached_execution_backend",
    "1.0.0",
)
CONVERGENCE_CAMPAIGN_LEVEL_SCHEMA_NAME, CONVERGENCE_CAMPAIGN_LEVEL_SCHEMA_VERSION = (
    "comsol_mcp.convergence_campaign_level",
    "1.0.0",
)
(
    CONVERGENCE_CAMPAIGN_SUMMARY_SCHEMA_NAME,
    CONVERGENCE_CAMPAIGN_SUMMARY_SCHEMA_VERSION,
) = "comsol_mcp.convergence_campaign_summary", "1.0.0"
(
    BRANCH_CONTINUATION_CAMPAIGN_STATE_SCHEMA_NAME,
    BRANCH_CONTINUATION_CAMPAIGN_STATE_SCHEMA_VERSION,
) = "comsol_mcp.branch_continuation_campaign_state", "1.0.0"
(
    BRANCH_CONTINUATION_CAMPAIGN_SUMMARY_SCHEMA_NAME,
    BRANCH_CONTINUATION_CAMPAIGN_SUMMARY_SCHEMA_VERSION,
) = "comsol_mcp.branch_continuation_campaign_summary", "1.0.0"
(
    THERMO_OPTOMECHANICAL_STAGE_SCHEMA_NAME,
    THERMO_OPTOMECHANICAL_STAGE_SCHEMA_VERSION,
) = "comsol_mcp.thermo_optomechanical_stage", "1.0.0"
(
    THERMO_OPTOMECHANICAL_MANIFEST_SCHEMA_NAME,
    THERMO_OPTOMECHANICAL_MANIFEST_SCHEMA_VERSION,
) = "comsol_mcp.thermo_optomechanical_replay_manifest", "1.0.0"
(
    THERMO_OPTOMECHANICAL_SUMMARY_SCHEMA_NAME,
    THERMO_OPTOMECHANICAL_SUMMARY_SCHEMA_VERSION,
) = "comsol_mcp.thermo_optomechanical_summary", "1.0.0"
SPECTRAL_ROW_SCHEMA_NAME, SPECTRAL_ROW_SCHEMA_VERSION = (
    "comsol_mcp.durable_spectral_point",
    "1.0.0",
)
SPECTRAL_SUMMARY_SCHEMA_NAME, SPECTRAL_SUMMARY_SCHEMA_VERSION = (
    "comsol_mcp.durable_spectral_summary",
    "1.0.0",
)
SPECTRAL_STAGE_SCHEMA_NAME, SPECTRAL_STAGE_SCHEMA_VERSION = (
    "comsol_mcp.spectral_stage_plan",
    "1.0.0",
)
SPECTRAL_MODEL_COMPARISON_SCHEMA_NAME, SPECTRAL_MODEL_COMPARISON_SCHEMA_VERSION = (
    "comsol_mcp.spectral_model_comparison",
    "1.0.0",
)
SIMULATION_CONFIGURATION_SCHEMA_NAME = "comsol_mcp.simulation_configuration"
SIMULATION_CONFIGURATION_DIFF_SCHEMA_NAME = "comsol_mcp.simulation_configuration_diff"
JOB_SPEC_PREVIEW_SCHEMA_NAME = "comsol_mcp.job_spec_preview"
CONFIGURATION_SCHEMA_VERSION = "1.0.0"
KIRCHHOFF_ASSESSMENT_SCHEMA_NAME = "comsol_mcp.kirchhoff_assessment"
THERMAL_RADIATION_REQUEST_SCHEMA_NAME = "comsol_mcp.thermal_radiation_request"
THERMAL_RADIATION_EVIDENCE_SCHEMA_NAME = "comsol_mcp.thermal_radiation_evidence"
THERMAL_RADIATION_SCHEMA_VERSION = "1.0.0"
THERMAL_MATERIAL_LEDGER_SCHEMA_NAME = "comsol_mcp.thermal_material_ledger"
THERMAL_MATERIAL_EVALUATION_SCHEMA_NAME = "comsol_mcp.thermal_material_evaluation"
THERMAL_MATERIAL_SCHEMA_VERSION = "1.0.0"
STANDALONE_SCHEMA_VERSION = "1.0.0"
STANDALONE_SCHEMAS = (
    "comsol_mcp.standalone_build_receipt",
    "comsol_mcp.standalone_driver_event",
    "comsol_mcp.standalone_licensed_acceptance",
    "comsol_mcp.standalone_mcp_launch",
    "comsol_mcp.standalone_owner",
    "comsol_mcp.standalone_pause_ack",
    "comsol_mcp.standalone_pause_request",
    "comsol_mcp.standalone_status",
    "comsol_mcp.standalone_terminal",
)


_REGISTRY_SCHEMA = "comsol_mcp.schema_registry"
_REGISTRY_VERSION = "1.0.0"
_LEGACY_POINT_AUDIT_SCHEMA = "comsol_mcp.wave_optics_point_audit"
_REFERENCE_POWER_DRY_RUN_SCHEMA = REFERENCE_POWER_EXECUTION_SCHEMA.replace(
    "execution_spec", "dry_run_receipt"
)
_MIGRATION_SOURCE_CONTRACTS = {
    "comsol_mcp.physical_evidence": frozenset({(_LEGACY_POINT_AUDIT_SCHEMA, "1")}),
}


def _entry(
    schema_name: str,
    version: str,
    producer: str,
    *,
    artifact_kind: str = "public_artifact",
    writable: bool = True,
    readable_versions: tuple[str, ...] | None = None,
    migration_sources: tuple[str, ...] = (),
) -> dict[str, Any]:
    return {
        "schema_name": schema_name,
        "artifact_kind": artifact_kind,
        "producer": producer,
        "producer_version": __version__,
        # An explicitly empty readable_versions tuple means "not readable";
        # only an omitted value falls back to the writable version.
        "readable_versions": (
            list(readable_versions) if readable_versions is not None else [version]
        ),
        "writable_version": version if writable else None,
        "migration": {
            "available": bool(migration_sources),
            "source_schema_names": list(migration_sources),
            "rewrites_source_in_place": False,
        },
    }


def _entries() -> list[dict[str, Any]]:
    legacy_point_audit = _LEGACY_POINT_AUDIT_SCHEMA
    entries = [
        # S4A: the adapter protocol declares its own receipt schema.
        _entry(
            "comsol_mcp.adapter.operation",
            "1.0.0",
            "comsol_mcp.adapter.protocol",
            artifact_kind="public_artifact",
        ),
        _entry(
            "comsol_mcp.adjoint_optimization_manifest",
            "1.0.0",
            "comsol_mcp.jobs.adjoint_optimization",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.adjoint_optimization_row",
            "1.0.0",
            "comsol_mcp.jobs.adjoint_rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.adjoint_optimization_submission",
            "1.0.0",
            "comsol_mcp.jobs.adjoint_optimization",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.robust_shape_optimization_manifest",
            "1.1.0",
            "comsol_mcp.jobs.robust_shape_optimization",
            artifact_kind="configuration",
            readable_versions=("1.0.0", "1.1.0"),
        ),
        _entry(
            "comsol_mcp.robust_condition_receipt",
            "1.0.0",
            "comsol_mcp.jobs.robust_condition_runtime",
        ),
        _entry(
            "comsol_mcp.robust_condition_gradient_receipt",
            "1.0.0",
            "comsol_mcp.jobs.robust_gradient_runtime",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.robust_licensed_cleanup_receipt",
            "1.0.0",
            "comsol_mcp.jobs.robust_shape_worker",
        ),
        _entry(
            "comsol_mcp.robust_shape_plan_preview",
            "1.0.0",
            "comsol_mcp.tools.robust_shape",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.robust_shape_evidence_summary",
            "1.0.0",
            "comsol_mcp.tools.robust_shape",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.robust_shape_evidence_verification",
            "1.0.0",
            "comsol_mcp.tools.robust_shape",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.robust_wall_watchdog",
            "1.0.0",
            "comsol_mcp.jobs.robust_wall_watchdog",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.robust_shape_optimization_submission",
            "1.0.0",
            "comsol_mcp.jobs.robust_shape_optimization",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.robust_pedot_fixture_manifest",
            "1.0.0",
            "development_kit.scripts.robust_pedot_fixture",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.lin2025_pedot_cylinder_fixture",
            "1.0.0",
            "comsol_mcp.research.lin2025_pedot_cylinder",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.lin2025_pedot_cylinder_fixture.binding",
            "1.0.0",
            "comsol_mcp.research.lin2025_pedot_cylinder",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.lin2025_pedot_cylinder_control_receipt",
            "1.0.0",
            "comsol_mcp.research.lin2025_pedot_backend",
        ),
        _entry(
            "comsol_mcp.lin2025_robust_campaign_inputs",
            "1.0.0",
            "development_kit.scripts.lin2025_robust_manifest",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.robust_startup_admission_policy",
            "1.0.0",
            "comsol_mcp.research.robust_startup_admission",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.robust_startup_admission_receipt",
            "1.0.0",
            "comsol_mcp.research.robust_startup_admission",
        ),
        _entry(
            "comsol_mcp.robust_shape_optimization_row",
            "1.0.0",
            "comsol_mcp.jobs.robust_shape_rows",
            artifact_kind="durable_artifact",
        ),
        _entry("comsol_mcp.artifact_chain", "1.0.0", "comsol_mcp.artifact_chain"),
        _entry(
            "comsol_mcp.artifact_chain_verification",
            "1.0.0",
            "comsol_mcp.artifact_chain",
        ),
        _entry(
            ATTACHED_EXECUTION_BACKEND_SCHEMA,
            ATTACHED_EXECUTION_BACKEND_VERSION,
            "comsol_mcp.jobs.attached_backend",
            artifact_kind="durable_artifact",
        ),
        _entry("comsol_mcp.build_identity", "1.0.0", "comsol_mcp.build_identity"),
        _entry(
            CLEANUP_OUTCOME_SCHEMA,
            CLEANUP_OUTCOME_VERSION,
            "comsol_mcp.shared_session.cleanup",
        ),
        _entry(
            CANDIDATE_RECORD_SCHEMA_NAME,
            CANDIDATE_RECORD_SCHEMA_VERSION,
            "comsol_mcp.research.records",
            artifact_kind="durable_artifact",
        ),
        _entry(
            CAMPAIGN_MANIFEST_SCHEMA_NAME,
            CAMPAIGN_MANIFEST_SCHEMA_VERSION,
            "comsol_mcp.research.compiler",
            artifact_kind="configuration",
        ),
        _entry(
            BRANCH_CONTINUATION_PLAN_SCHEMA,
            BRANCH_CONTINUATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.branch_continuation",
        ),
        _entry(
            BRANCH_CONTINUATION_STATES_SCHEMA,
            BRANCH_CONTINUATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.branch_continuation",
        ),
        _entry(
            BRANCH_CONTINUATION_CAMPAIGN_STATE_SCHEMA_NAME,
            BRANCH_CONTINUATION_CAMPAIGN_STATE_SCHEMA_VERSION,
            "comsol_mcp.jobs.branch_continuation_campaign_rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            BRANCH_CONTINUATION_CAMPAIGN_SUMMARY_SCHEMA_NAME,
            BRANCH_CONTINUATION_CAMPAIGN_SUMMARY_SCHEMA_VERSION,
            "comsol_mcp.jobs.branch_continuation_campaign_runner",
            artifact_kind="durable_artifact",
        ),
        _entry(
            THERMO_OPTOMECHANICAL_MANIFEST_SCHEMA_NAME,
            THERMO_OPTOMECHANICAL_MANIFEST_SCHEMA_VERSION,
            "comsol_mcp.contracts.thermo_optomechanical",
        ),
        _entry(
            THERMO_OPTOMECHANICAL_STAGE_SCHEMA_NAME,
            THERMO_OPTOMECHANICAL_STAGE_SCHEMA_VERSION,
            "comsol_mcp.jobs.thermo_optomechanical_replay_rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            THERMO_OPTOMECHANICAL_SUMMARY_SCHEMA_NAME,
            THERMO_OPTOMECHANICAL_SUMMARY_SCHEMA_VERSION,
            "comsol_mcp.jobs.thermo_optomechanical_replay_runner",
            artifact_kind="durable_artifact",
        ),
        _entry(
            CONVERGENCE_LADDER_SCHEMA,
            CONVERGENCE_SCHEMA_VERSION,
            "comsol_mcp.evidence.convergence_evaluation",
        ),
        _entry(
            CONVERGENCE_CAMPAIGN_LEVEL_SCHEMA_NAME,
            CONVERGENCE_CAMPAIGN_LEVEL_SCHEMA_VERSION,
            "comsol_mcp.jobs.convergence_campaign_rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            CONVERGENCE_CAMPAIGN_SUMMARY_SCHEMA_NAME,
            CONVERGENCE_CAMPAIGN_SUMMARY_SCHEMA_VERSION,
            "comsol_mcp.jobs.convergence_campaign_runner",
            artifact_kind="durable_artifact",
        ),
        _entry(
            CONVERGENCE_EVALUATION_SCHEMA,
            CONVERGENCE_SCHEMA_VERSION,
            "comsol_mcp.evidence.convergence_evaluation",
        ),
        _entry(
            "comsol_mcp.deployment_identity",
            "1.2.0",
            "comsol_mcp.tools.capabilities",
            readable_versions=("1.0.0", "1.1.0", "1.2.0"),
        ),
        _entry(
            DECISION_RECORD_SCHEMA_NAME,
            DECISION_RECORD_SCHEMA_VERSION,
            "comsol_mcp.research.decisions",
            artifact_kind="durable_artifact",
        ),
        _entry(
            DESIGN_SPACE_SCHEMA_NAME,
            DESIGN_SPACE_SCHEMA_VERSION,
            "comsol_mcp.research.contracts",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.derivative_support",
            "1.0.0",
            "comsol_mcp.research.derivative_support",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.environment_identity",
            "1.0.0",
            "comsol_mcp.environment_identity",
        ),
        _entry(
            "comsol_mcp.protocol_identity",
            "1.0.0",
            "comsol_mcp.protocol_identity",
        ),
        _entry(
            "comsol_mcp.task_cleanup_receipt",
            "1.0.0",
            "comsol_mcp.jobs.tasks_bridge",
        ),
        _entry(
            "comsol_mcp.tasks_mapping",
            "1.0.0",
            "comsol_mcp.jobs.tasks_bridge",
        ),
        _entry(
            "comsol_mcp.dbmodel_operation",
            "1.0.0",
            "comsol_mcp.shared_session.dbmodel_operations",
        ),
        _entry(
            "comsol_mcp.dbmodel_operation_receipt",
            "1.0.0",
            "comsol_mcp.shared_session.dbmodel_operations",
        ),
        _entry(
            "comsol_mcp.solver_owner_registry",
            "1.0.0",
            "comsol_mcp.shared_session.solver_owners",
        ),
        _entry(
            "comsol_mcp.solver_owner_receipt",
            "1.0.0",
            "comsol_mcp.shared_session.solver_owners",
        ),
        _entry(
            "comsol_mcp.operation_ledger_row",
            "1.0.0",
            "comsol_mcp.durable.operation_ledger",
        ),
        _entry(
            "comsol_mcp.operation_recovery_report",
            "1.0.0",
            "comsol_mcp.durable.operation_ledger",
        ),
        _entry(
            "comsol_mcp.operation_receipt_binding",
            "1.0.0",
            "comsol_mcp.durable.operation_ledger",
        ),
        _entry(
            "comsol_mcp.model_manager_refusal",
            "1.0.0",
            "comsol_mcp.shared_session.model_manager",
        ),
        _entry(
            EVIDENCE_SETTINGS_SCHEMA,
            EVIDENCE_INTEGRITY_VERSION,
            "comsol_mcp.evidence.integrity_controls",
        ),
        _entry(
            EVIDENCE_STATUS_SCHEMA,
            EVIDENCE_INTEGRITY_VERSION,
            "comsol_mcp.evidence.integrity_controls",
        ),
        _entry(
            EVIDENCE_VERIFICATION_SCHEMA,
            EVIDENCE_INTEGRITY_VERSION,
            "comsol_mcp.evidence.integrity_verifier",
        ),
        _entry(
            EVALUATION_RECORD_SCHEMA_NAME,
            EVALUATION_RECORD_SCHEMA_VERSION,
            "comsol_mcp.research.evaluations",
            artifact_kind="durable_artifact",
        ),
        _entry(
            EXTERNAL_VALIDATION_RECEIPT_SCHEMA_NAME,
            EXTERNAL_VALIDATION_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.external_validation",
        ),
        _entry(
            "comsol_mcp.execution_evidence_outcome",
            "1.0.0",
            "comsol_mcp.evidence.outcome_contract",
        ),
        _entry(
            "comsol_mcp.field_dataset_discovery",
            "1.0.0",
            "comsol_mcp.evidence.field_discovery",
        ),
        _entry(
            "comsol_mcp.field_evidence_manifest",
            "1.0.0",
            "comsol_mcp.evidence.field_manifest",
        ),
        _entry(
            "comsol_mcp.field_evidence_request",
            "1.1.0",
            "comsol_mcp.evidence.field_bundle",
        ),
        _entry(
            "comsol_mcp.gradient_check",
            "1.0.0",
            "comsol_mcp.research.gradient_validation",
        ),
        _entry(
            "comsol_mcp.gradient_record",
            "1.0.0",
            "comsol_mcp.research.gradient_contracts",
        ),
        _entry(
            "comsol_mcp.model_version_metadata",
            "1.0.0",
            "comsol_mcp.tools.model",
        ),
        _entry(
            "comsol_mcp.model_identity",
            "1.0.0",
            "comsol_mcp.evidence.model_identity",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.bounded_step_receipt",
            "1.0.0",
            "comsol_mcp.jobs.bounded_steps",
        ),
        _entry(
            "comsol_mcp.compatibility_registry",
            "1.0.0",
            "comsol_mcp.evidence.compatibility_registry",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.offline_export_manifest",
            "1.0.0",
            "comsol_mcp.evidence.offline_export",
            artifact_kind="public_response",
        ),
        # S10: the bounded public surrogate surface emits these two responses.
        # Both are read-only validation verdicts that never upgrade FEM evidence.
        _entry(
            "comsol_mcp.surrogate_evidence_verdict",
            "1.0.0",
            "comsol_mcp.evidence.surrogate_evidence",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.surrogate_training_preview",
            "1.0.0",
            "comsol_mcp.evidence.surrogate_evidence",
            artifact_kind="public_response",
        ),
        # S10/S11: the surrogate lifecycle modules emit these artifact schemas
        # with a "schema" identity key.  They were emitted but unregistered, so
        # the registry completeness assertion could not see them until the
        # scanner was taught both identity spellings.  All are version 1.0.0.
        _entry(
            "comsol_mcp.surrogate_baseline",
            "1.0.0",
            "comsol_mcp.surrogate.training",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_campaign_spec",
            "1.0.0",
            "comsol_mcp.surrogate.campaign",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_campaign_summary",
            "1.0.0",
            "comsol_mcp.surrogate.campaign",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_continuation_identity",
            "1.0.0",
            "comsol_mcp.surrogate.training",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_dataset_manifest",
            "1.0.0",
            "comsol_mcp.surrogate.manifests",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_dnn_configuration",
            "1.0.0",
            "comsol_mcp.surrogate.dnn_adapter",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_dnn_write_plan",
            "1.0.0",
            "comsol_mcp.surrogate.dnn_adapter",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_export_manifest",
            "1.0.0",
            "comsol_mcp.surrogate.export",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_fem_result",
            "1.0.0",
            "comsol_mcp.surrogate.campaign",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_field_schema",
            "1.0.0",
            "comsol_mcp.surrogate.fields",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_fitted_transforms",
            "1.0.0",
            "comsol_mcp.surrogate.fields",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_lhs_design",
            "1.0.0",
            "comsol_mcp.surrogate.rows",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_model_card",
            "1.0.0",
            "comsol_mcp.surrogate.registry",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_onnx_model",
            "1.0.0",
            "comsol_mcp.surrogate.onnx_runtime",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_registry_entry",
            "1.0.0",
            "comsol_mcp.surrogate.registry",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_row_provenance",
            "1.0.0",
            "comsol_mcp.surrogate.rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_schema_manifest",
            "1.0.0",
            "comsol_mcp.surrogate.manifests",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.surrogate_screening_record",
            "1.0.0",
            "comsol_mcp.surrogate.campaign",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_split_plan",
            "1.0.0",
            "comsol_mcp.surrogate.splits",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.surrogate_training_transforms",
            "1.0.0",
            "comsol_mcp.surrogate.manifests",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.observation_receipt",
            "1.0.0",
            "comsol_mcp.jobs.observation",
        ),
        _entry(
            "comsol_mcp.mph_artifact_probe",
            "1.0.0",
            "comsol_mcp.evidence.inspection.probe",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.mph_diff",
            "1.0.0",
            "comsol_mcp.evidence.inspection.diff",
            artifact_kind="public_response",
        ),
        _entry(
            "comsol_mcp.mph_inspection_summary",
            "1.0.0",
            "comsol_mcp.evidence.inspection.summary",
            artifact_kind="public_response",
        ),
        _entry(
            MATERIAL_CATALOG_SCHEMA_NAME,
            MATERIAL_CATALOG_SCHEMA_VERSION,
            "comsol_mcp.research.materials",
            artifact_kind="configuration",
        ),
        _entry(
            MATERIAL_STATE_CONFIGURATION_SCHEMA_NAME,
            MATERIAL_STATE_CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.research.robust_conditions",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.native_adjoint_adapter_receipt",
            "1.0.0",
            "comsol_mcp.research.adjoint_adapter",
        ),
        _entry(
            "comsol_mcp.native_optimizer_configuration",
            "1.1.0",
            "comsol_mcp.research.gradient_contracts",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.native_optimizer_runtime_receipt",
            "1.0.0",
            "comsol_mcp.jobs.native_adjoint_runtime",
        ),
        _entry(
            OPTIMIZATION_CONDITION_TABLE_SCHEMA_NAME,
            OPTIMIZATION_CONDITION_TABLE_SCHEMA_VERSION,
            "comsol_mcp.research.robust_conditions",
            artifact_kind="configuration",
        ),
        _entry(
            _REFERENCE_POWER_DRY_RUN_SCHEMA,
            "1.0.0",
            "comsol_mcp.evidence.reference_power_acceptance",
        ),
        _entry(
            REFERENCE_POWER_EXECUTION_SCHEMA,
            "1.0.0",
            "comsol_mcp.evidence.reference_power_acceptance",
        ),
        _entry(
            REFERENCE_POWER_CONTRACT_SCHEMA,
            "1.0.0",
            "comsol_mcp.evidence.reference_power_acceptance",
        ),
        _entry(
            OPTICAL_PROPERTY_MAPPING_SCHEMA_NAME,
            OPTICAL_PROPERTY_MAPPING_SCHEMA_VERSION,
            "comsol_mcp.research.robust_material_mapping",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_OBJECTIVE_CONFIGURATION_SCHEMA_NAME,
            ROBUST_OBJECTIVE_CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.research.robust_objectives",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_FINALIST_VALIDATION_POLICY_SCHEMA_NAME,
            ROBUST_FINALIST_VALIDATION_POLICY_SCHEMA_VERSION,
            "comsol_mcp.research.robust_finalist_validation",
            artifact_kind="configuration",
            readable_versions=ROBUST_FINALIST_VALIDATION_POLICY_READABLE_VERSIONS,
        ),
        _entry(
            ROBUST_FINALIST_VALIDATION_RECEIPT_SCHEMA_NAME,
            ROBUST_FINALIST_VALIDATION_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_finalist_evidence",
        ),
        _entry(
            ROBUST_GRADIENT_POLICY_SCHEMA_NAME,
            ROBUST_GRADIENT_POLICY_SCHEMA_VERSION,
            "comsol_mcp.research.robust_gradient_acceptance",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_GRADIENT_RECEIPT_SCHEMA_NAME,
            ROBUST_GRADIENT_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_gradient_acceptance",
        ),
        _entry(
            ROBUST_OBJECTIVE_RECEIPT_SCHEMA_NAME,
            ROBUST_OBJECTIVE_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_objectives",
        ),
        _entry(
            ROBUST_OBJECTIVE_GRADIENT_RECEIPT_SCHEMA_NAME,
            ROBUST_OBJECTIVE_GRADIENT_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_objectives",
        ),
        _entry(
            ROBUST_OPTIMIZER_POLICY_SCHEMA_NAME,
            ROBUST_OPTIMIZER_POLICY_SCHEMA_VERSION,
            "comsol_mcp.research.robust_optimizer_policy",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_OPTIMIZER_EXECUTION_RECEIPT_SCHEMA_NAME,
            ROBUST_OPTIMIZER_EXECUTION_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_optimizer_policy",
        ),
        _entry(
            "comsol_mcp.robust_outer_gcmma_proposal",
            "1.0.0",
            "comsol_mcp.research.robust_outer_gcmma",
        ),
        _entry(
            "comsol_mcp.robust_outer_gcmma_state",
            "1.0.0",
            "comsol_mcp.research.robust_outer_gcmma",
        ),
        _entry(
            ROBUST_SHAPE_ADAPTER_BINDING_SCHEMA_NAME,
            ROBUST_SHAPE_ADAPTER_BINDING_SCHEMA_VERSION,
            "comsol_mcp.research.robust_shape_adapter",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_SHAPE_ADAPTER_CONFIGURATION_SCHEMA_NAME,
            ROBUST_SHAPE_ADAPTER_CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.research.robust_adapter_configuration",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_MATERIAL_TENSOR_ROWS_SCHEMA_NAME,
            ROBUST_MATERIAL_TENSOR_ROWS_SCHEMA_VERSION,
            "comsol_mcp.research.robust_material_tensor_rows",
            artifact_kind="configuration",
        ),
        _entry(
            ROBUST_CONDITION_CONTROLS_SCHEMA_NAME,
            ROBUST_CONDITION_CONTROLS_SCHEMA_VERSION,
            "comsol_mcp.research.robust_condition_controls",
            artifact_kind="configuration",
            readable_versions=(
                "1.0.0",
                "1.1.0",
                "1.2.0",
                "1.3.0",
                "1.4.0",
                ROBUST_CONDITION_CONTROLS_SCHEMA_VERSION,
            ),
        ),
        _entry(
            ROBUST_SHAPE_CONTROL_RECEIPT_SCHEMA_NAME,
            ROBUST_SHAPE_CONTROL_RECEIPT_SCHEMA_VERSION,
            "comsol_mcp.research.robust_shape_adapter",
        ),
        _entry(
            "comsol_mcp.robust_forward_shape_stage",
            "1.0.0",
            "comsol_mcp.jobs.robust_shape_native_runtime",
        ),
        _entry(
            "comsol_mcp.robust_shape_application",
            "1.1.0",
            "comsol_mcp.jobs.robust_shape_native_runtime",
            readable_versions=("1.0.0", "1.1.0"),
        ),
        _entry(
            ROBUST_SMOOTHING_COMPARISON_SCHEMA_NAME,
            ROBUST_SMOOTHING_COMPARISON_SCHEMA_VERSION,
            "comsol_mcp.research.robust_smoothing_selection",
        ),
        _entry(
            SHAPE_SUPPORT_POLICY_SCHEMA_NAME,
            SHAPE_SUPPORT_POLICY_SCHEMA_VERSION,
            "comsol_mcp.research.shape_support",
            artifact_kind="configuration",
        ),
        _entry(
            "comsol_mcp.periodic_mesh_audit",
            "1.0.0",
            "comsol_mcp.tools.periodic_mesh_audit",
        ),
        _entry(
            "comsol_mcp.periodic_mesh_smoke",
            "1.0.0",
            "comsol_mcp.tools.periodic_mesh_audit",
        ),
        _entry(
            OPERATION_LOCK_SCHEMA,
            OPERATION_LOCK_VERSION,
            "comsol_mcp.operation_arbiter",
            artifact_kind="durable_artifact",
        ),
        _entry(
            OBJECTIVE_SCORE_SCHEMA_NAME,
            OBJECTIVE_SCORE_SCHEMA_VERSION,
            "comsol_mcp.research.objectives",
        ),
        _entry(
            OPTIMIZER_CHECKPOINT_SCHEMA_NAME,
            OPTIMIZER_CHECKPOINT_SCHEMA_VERSION,
            "comsol_mcp.research.state",
            artifact_kind="durable_artifact",
        ),
        _entry(
            OPTIMIZER_PROPOSAL_SCHEMA_NAME,
            OPTIMIZER_PROPOSAL_SCHEMA_VERSION,
            "comsol_mcp.research.optimizers",
        ),
        _entry(
            OPTIMIZER_STATE_SCHEMA_NAME,
            OPTIMIZER_STATE_SCHEMA_VERSION,
            "comsol_mcp.research.optimizers",
        ),
        _entry(
            OPTIMIZER_EXPLANATION_SCHEMA_NAME,
            OPTIMIZER_EXPLANATION_SCHEMA_VERSION,
            "comsol_mcp.research.optimizers",
        ),
        _entry(
            STRUCTURE_ADAPTER_MANIFEST_SCHEMA_NAME,
            STRUCTURE_ADAPTER_MANIFEST_SCHEMA_VERSION,
            "comsol_mcp.research.adapters",
        ),
        _entry(
            STRUCTURE_ADAPTER_APPLICATION_SCHEMA_NAME,
            STRUCTURE_ADAPTER_APPLICATION_SCHEMA_VERSION,
            "comsol_mcp.research.adapters",
        ),
        _entry(
            STRUCTURE_TREE_AUDIT_SCHEMA_NAME,
            STRUCTURE_TREE_AUDIT_SCHEMA_VERSION,
            "comsol_mcp.research.adapters",
        ),
        _entry(
            PATH_POLICY_SCHEMA,
            PATH_POLICY_VERSION,
            "comsol_mcp.path_policy",
            readable_versions=("1.0.0", "1.1.0"),
        ),
        _entry(
            "comsol_mcp.physical_evidence",
            "1.1.0",
            "comsol_mcp.evidence.contracts",
            readable_versions=("1.0.0", "1.1.0"),
            migration_sources=(legacy_point_audit,),
        ),
        _entry(
            "comsol_mcp.portfolio_evidence_request",
            "1.0.0",
            "comsol_mcp.evidence.portfolio_verifier",
        ),
        _entry(
            PORTFOLIO_SCHEMA_NAME,
            PORTFOLIO_SCHEMA_VERSION,
            "comsol_mcp.research.state",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.portfolio_evidence_verification",
            "1.0.0",
            "comsol_mcp.evidence.portfolio_verifier",
        ),
        _entry(
            SPECTRAL_DECISION_SCHEMA,
            SPECTRAL_SCHEMA_VERSION,
            "comsol_mcp.evidence.spectral_characterization",
        ),
        _entry(
            SPECTRAL_BUNDLE_SCHEMA,
            SPECTRAL_SCHEMA_VERSION,
            "comsol_mcp.evidence.spectral_characterization",
        ),
        _entry(
            SPECTRAL_CHARACTERIZATION_SCHEMA,
            SPECTRAL_SCHEMA_VERSION,
            "comsol_mcp.evidence.spectral_characterization",
        ),
        _entry(
            SPECTRAL_MODEL_COMPARISON_SCHEMA_NAME,
            SPECTRAL_MODEL_COMPARISON_SCHEMA_VERSION,
            "comsol_mcp.evidence.spectral_model_comparison",
        ),
        _entry(
            SIMULATION_CONFIGURATION_SCHEMA_NAME,
            CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.simulation_configuration",
            artifact_kind="configuration",
        ),
        _entry(
            SIMULATION_CONFIGURATION_DIFF_SCHEMA_NAME,
            CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.simulation_configuration",
        ),
        _entry(
            JOB_SPEC_PREVIEW_SCHEMA_NAME,
            CONFIGURATION_SCHEMA_VERSION,
            "comsol_mcp.tools.jobs",
        ),
        _entry(
            KIRCHHOFF_ASSESSMENT_SCHEMA_NAME,
            THERMAL_RADIATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.thermal_radiation",
        ),
        _entry(
            THERMAL_RADIATION_REQUEST_SCHEMA_NAME,
            THERMAL_RADIATION_SCHEMA_VERSION,
            "comsol_mcp.contracts.thermal_radiation",
        ),
        _entry(
            THERMAL_RADIATION_EVIDENCE_SCHEMA_NAME,
            THERMAL_RADIATION_SCHEMA_VERSION,
            "comsol_mcp.evidence.thermal_radiation",
        ),
        _entry(
            THERMAL_MATERIAL_LEDGER_SCHEMA_NAME,
            THERMAL_MATERIAL_SCHEMA_VERSION,
            "comsol_mcp.evidence.thermal_material",
            artifact_kind="configuration",
        ),
        _entry(
            THERMAL_MATERIAL_EVALUATION_SCHEMA_NAME,
            THERMAL_MATERIAL_SCHEMA_VERSION,
            "comsol_mcp.evidence.thermal_material",
        ),
        _entry(
            SPECTRAL_PROGRESS_SCHEMA_NAME,
            SPECTRAL_PROGRESS_SCHEMA_VERSION,
            "comsol_mcp.jobs.spectral_progress",
            artifact_kind="durable_artifact",
        ),
        _entry(
            SPECTRAL_ROW_SCHEMA_NAME,
            SPECTRAL_ROW_SCHEMA_VERSION,
            "comsol_mcp.jobs.spectral_rows",
            artifact_kind="durable_artifact",
        ),
        _entry(
            SPECTRAL_STAGE_SCHEMA_NAME,
            SPECTRAL_STAGE_SCHEMA_VERSION,
            "comsol_mcp.jobs.spectral_stages",
            artifact_kind="durable_artifact",
        ),
        _entry(
            SPECTRAL_SUMMARY_SCHEMA_NAME,
            SPECTRAL_SUMMARY_SCHEMA_VERSION,
            "comsol_mcp.jobs.spectral_runner",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.resource_calibration_report",
            "1.0.0",
            "comsol_mcp.jobs.resource_admission",
        ),
        _entry(
            RESEARCH_GOAL_SCHEMA_NAME,
            RESEARCH_GOAL_SCHEMA_VERSION,
            "comsol_mcp.research.contracts",
            artifact_kind="configuration",
        ),
        _entry(
            RESEARCH_JOURNAL_RECORD_SCHEMA_NAME,
            RESEARCH_JOURNAL_RECORD_SCHEMA_VERSION,
            "comsol_mcp.research.journal",
            artifact_kind="durable_artifact",
        ),
        _entry(
            "comsol_mcp.resource_journal_entry",
            "1.0.0",
            "comsol_mcp.jobs.resource_admission",
        ),
        _entry(
            "comsol_mcp.resource_journal_replay",
            "1.0.0",
            "comsol_mcp.jobs.resource_admission",
        ),
        _entry("comsol_mcp.resource_policy", "1.0.0", "comsol_mcp.jobs.resource_admission"),
        _entry(
            "comsol_mcp.resource_telemetry_sample",
            "1.0.0",
            "comsol_mcp.jobs.resource_admission",
        ),
        _entry("comsol_mcp.runtime_compatibility", "1.0.0", "comsol_mcp.compatibility"),
        _entry(
            SETTINGS_SCHEMA,
            SETTINGS_VERSION,
            "comsol_mcp.settings",
            artifact_kind="configuration",
            readable_versions=("1.0.0", "1.1.0", "1.2.0", SETTINGS_VERSION),
        ),
        _entry(
            HANDSHAKE_SCHEMA,
            HANDSHAKE_VERSION,
            "comsol_mcp.settings_gui_handshake",
        ),
        _entry(_REGISTRY_SCHEMA, _REGISTRY_VERSION, "comsol_mcp.schema_registry"),
        _entry(
            "comsol_mcp.session_startup_state",
            "1.0.0",
            "comsol_mcp.tools.session",
            artifact_kind="durable_artifact",
        ),
        *(
            _entry(
                schema_name,
                STANDALONE_SCHEMA_VERSION,
                "comsol_mcp.standalone",
                artifact_kind="durable_artifact",
            )
            for schema_name in STANDALONE_SCHEMAS
        ),
        _entry(
            SHARED_MODEL_LOCK_SCHEMA,
            SHARED_MODEL_LOCK_VERSION,
            "comsol_mcp.shared_session.locking",
            artifact_kind="durable_artifact",
        ),
        _entry(
            SHARED_MODEL_SNAPSHOT_SCHEMA,
            SHARED_MODEL_SNAPSHOT_VERSION,
            "comsol_mcp.shared_session.lifecycle",
            artifact_kind="durable_artifact",
        ),
        _entry(
            SHARED_SERVER_PREFLIGHT_SCHEMA,
            SHARED_SERVER_PREFLIGHT_VERSION,
            "comsol_mcp.shared_session.preflight",
        ),
        _entry(
            "comsol_mcp.validation_matrix_collector",
            "1.0.0",
            "comsol_mcp.jobs.validation_collectors",
        ),
        _entry(
            "comsol_mcp.validation_matrix_field_collector",
            "1.0.0",
            "comsol_mcp.jobs.validation_collectors",
        ),
        _entry(
            "comsol_mcp.validation_matrix_field_review",
            "1.0.0",
            "comsol_mcp.jobs.field_review",
        ),
        _entry("comsol_mcp.validation_policy", "1.0.0", "comsol_mcp.evidence.contracts"),
        _entry(
            "comsol_mcp.visual_dual_review",
            "1.0.0",
            "comsol_mcp.evidence.visual_review",
        ),
        _entry(
            "comsol_mcp.visual_review_receipt",
            "1.0.0",
            "comsol_mcp.evidence.visual_review",
        ),
        _entry(
            "comsol_mcp.visual_review_request",
            "1.0.0",
            "comsol_mcp.evidence.visual_review",
        ),
        _entry(
            "comsol_mcp.visual_reviewer_capability",
            "1.0.0",
            "comsol_mcp.evidence.visual_review",
        ),
        _entry(
            WORKFLOW_CAPSULE_SCHEMA_NAME,
            WORKFLOW_CAPSULE_SCHEMA_VERSION,
            "comsol_mcp.research.workflow",
            artifact_kind="configuration",
        ),
        _entry(
            legacy_point_audit,
            "1",
            "comsol_mcp.tools.wave_optics_audit",
            artifact_kind="legacy_artifact",
            writable=False,
        ),
    ]
    return sorted(entries, key=lambda item: item["schema_name"])


def _entries_body(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the exact hashed body shared by the full and summarized views."""
    return {
        "schema_name": _REGISTRY_SCHEMA,
        "schema_version": _REGISTRY_VERSION,
        "producer": {"package": "comsol-mcp", "version": __version__},
        "entries": entries,
        "entry_count": len(entries),
    }


def get_schema_registry() -> dict[str, Any]:
    """Return the complete deterministic schema support registry."""
    body = _entries_body(_entries())
    return deepcopy({**body, "registry_sha256": canonical_sha256_v1(body)})


def summarize_schema_registry() -> dict[str, Any]:
    """Return the compact discovery view of the schema support registry.

    The complete registry is ~60 kB and does not belong in cold discovery: it
    grows by roughly 300 B with every new public artifact schema, so embedding it
    makes the startup payload scale with the artifact surface instead of with the
    tool surface. This view keeps the parts a client actually needs at startup --
    the identity (``registry_sha256``, computed over exactly the same body the
    full view hashes, so the two views can never disagree), the entry count, the
    producer, and bounded count breakdowns -- and names the solver-free operation
    that returns one entry or the full registry on demand.

    It is not a truncation: no entry is partially represented, and the counts
    below always describe the whole registry. A caller that needs an entry asks
    for it by name through ``catalog``.
    """
    entries = _entries()
    body = _entries_body(entries)
    by_kind: dict[str, int] = {}
    for entry in entries:
        kind = entry["artifact_kind"]
        by_kind[kind] = by_kind.get(kind, 0) + 1
    readable_version_counts: dict[str, int] = {}
    for entry in entries:
        count = len(entry["readable_versions"])
        key = str(count)
        readable_version_counts[key] = readable_version_counts.get(key, 0) + 1
    return deepcopy(
        {
            "schema_name": _REGISTRY_SCHEMA,
            "schema_version": _REGISTRY_VERSION,
            "view": "summary",
            "producer": body["producer"],
            "entry_count": body["entry_count"],
            "registry_sha256": canonical_sha256_v1(body),
            "full_registry_available": True,
            "on_demand_operation": "catalog",
            "on_demand_selectors": ["schema", "domain", "tool"],
            "artifact_kind_counts": dict(sorted(by_kind.items())),
            "readable_version_count_histogram": dict(sorted(readable_version_counts.items())),
            "writable_entry_count": sum(
                1 for entry in entries if entry["writable_version"] is not None
            ),
            "migration_capable_entry_count": sum(
                1 for entry in entries if entry["migration"]["available"]
            ),
        }
    )


def select_schema_entry(schema_name: object) -> dict[str, Any]:
    """Return exactly one registry entry, or a bounded refusal.

    The refusal is explicit and never substitutes a different schema: a caller
    that asked for an unknown name must not receive a plausible-looking entry.
    """
    if not isinstance(schema_name, str) or not schema_name.strip():
        return {
            "found": False,
            "reason_code": "invalid_schema_name",
            "schema_name": schema_name if isinstance(schema_name, str) else None,
        }
    requested = schema_name.strip()
    for entry in _entries():
        if entry["schema_name"] == requested:
            return {
                "found": True,
                "reason_code": "found",
                "entry": deepcopy(entry),
                "registry_sha256": get_schema_registry()["registry_sha256"],
            }
    return {
        "found": False,
        "reason_code": "unknown_schema_name",
        "schema_name": requested,
    }


def check_schema_support(
    schema_name: object,
    schema_version: object,
    *,
    for_write: bool = False,
) -> dict[str, Any]:
    """Return a machine-readable support result without modifying an artifact."""
    if not isinstance(schema_name, str) or not schema_name:
        return {"supported": False, "reason_code": "invalid_schema_name"}
    if not isinstance(schema_version, str) or not schema_version:
        return {"supported": False, "reason_code": "invalid_schema_version"}
    migration_available = any(
        (schema_name, schema_version) in source_contracts
        for source_contracts in _MIGRATION_SOURCE_CONTRACTS.values()
    )
    by_name = {item["schema_name"]: item for item in _entries()}
    entry = by_name.get(schema_name)
    if entry is None:
        return {
            "supported": False,
            "reason_code": "unknown_schema_name",
            "schema_name": schema_name,
            "schema_version": schema_version,
        }
    supported_versions = (
        ([entry["writable_version"]] if for_write and entry["writable_version"] else [])
        if for_write
        else entry["readable_versions"]
    )
    if schema_version not in supported_versions:
        return {
            "supported": False,
            "reason_code": "unsupported_schema_version",
            "schema_name": schema_name,
            "schema_version": schema_version,
            "supported_versions": supported_versions,
            "migration_available": migration_available,
        }
    return {
        "supported": True,
        "reason_code": "supported",
        "schema_name": schema_name,
        "schema_version": schema_version,
        "access": "write" if for_write else "read",
        "producer": entry["producer"],
        "producer_version": entry["producer_version"],
    }


__all__ = [
    "check_schema_support",
    "get_schema_registry",
    "select_schema_entry",
    "summarize_schema_registry",
]
