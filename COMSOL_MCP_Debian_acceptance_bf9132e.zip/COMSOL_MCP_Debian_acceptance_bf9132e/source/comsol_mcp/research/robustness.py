"""Deterministic finalist perturbation and robustness-summary contracts."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from statistics import fmean
from typing import Any

from comsol_mcp.durable import domain_sha256_v2

from .contracts import normalize_design_space


def _float_or_none(value: object) -> float | None:
    """Return a finite-capable float or None for non-numeric or overflowing input."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        return float(value)
    except OverflowError:
        return None


def axis_perturbation_matrix(
    design_space: object, candidate_values: object, *, relative_fraction: float
) -> dict[str, Any]:
    space = normalize_design_space(design_space)
    fraction_value = _float_or_none(relative_fraction)
    if (
        fraction_value is None
        or not math.isfinite(fraction_value)
        or not 0.0 < fraction_value <= 0.25
    ):
        raise ValueError("relative_fraction must be finite and in (0, 0.25]")
    variables = list(space["variables"])
    if any(item["kind"] != "continuous" for item in variables):
        raise ValueError("axis perturbation requires continuous variables")
    expected = {item["variable_id"] for item in variables}
    if not isinstance(candidate_values, Mapping) or set(candidate_values) != expected:
        raise ValueError("candidate_values must exactly cover the frozen space")
    center: dict[str, float] = {}
    for variable in variables:
        variable_id = variable["variable_id"]
        raw = candidate_values[variable_id]
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError("candidate values must be finite numbers")
        value = float(raw)
        if not math.isfinite(value) or not float(variable["lower"]) <= value <= float(
            variable["upper"]
        ):
            raise ValueError("candidate values are outside the frozen space")
        center[variable_id] = value
    points = [{"point_id": "center", "values": dict(sorted(center.items()))}]
    for variable in variables:
        variable_id = variable["variable_id"]
        delta = abs(center[variable_id]) * float(relative_fraction)
        if delta == 0.0:
            delta = (float(variable["upper"]) - float(variable["lower"])) * float(relative_fraction)
        for direction, sign in (("minus", -1.0), ("plus", 1.0)):
            perturbed = dict(center)
            perturbed[variable_id] += sign * delta
            if not float(variable["lower"]) <= perturbed[variable_id] <= float(variable["upper"]):
                raise ValueError("candidate lacks the declared perturbation margin")
            points.append(
                {
                    "point_id": f"{variable_id}:{direction}",
                    "values": dict(sorted(perturbed.items())),
                }
            )
    body = {
        "schema_name": "research.robustness.matrix",
        "schema_version": "1.0.0",
        "space_fingerprint": space["space_fingerprint"],
        "relative_fraction": float(relative_fraction),
        "points": points,
    }
    return {**body, "matrix_fingerprint": domain_sha256_v2(body["schema_name"], body)}


def summarize_robustness(
    matrix: object, rows: object, *, maximum_total_loss: float | None
) -> dict[str, Any]:
    if not isinstance(matrix, Mapping) or not isinstance(rows, Sequence):
        raise ValueError("matrix and rows must be structured values")
    matrix_points = matrix.get("points")
    matrix_fingerprint = matrix.get("matrix_fingerprint")
    if (
        not isinstance(matrix_points, list)
        or not matrix_points
        or any(
            not isinstance(item, Mapping) or not isinstance(item.get("point_id"), str)
            for item in matrix_points
        )
        or len({item["point_id"] for item in matrix_points}) != len(matrix_points)
        or not isinstance(matrix_fingerprint, str)
        or len(matrix_fingerprint) != 64
    ):
        raise ValueError("robustness matrix structure is invalid")
    expected = [item["point_id"] for item in matrix_points]
    losses: dict[str, float] = {}
    evidence: dict[str, str] = {}
    for row in rows:
        if not isinstance(row, Mapping) or set(row) != {
            "point_id",
            "total_loss",
            "evidence_fingerprint",
        }:
            raise ValueError("robustness row shape is unsupported")
        point_id, raw, fingerprint = row["point_id"], row["total_loss"], row["evidence_fingerprint"]
        if point_id not in expected or point_id in losses:
            raise ValueError("robustness rows contain unknown or duplicate points")
        loss_value = _float_or_none(raw)
        if loss_value is None or not math.isfinite(loss_value) or loss_value < 0.0:
            raise ValueError("robustness loss must be finite and nonnegative")
        if not isinstance(fingerprint, str) or len(fingerprint) != 64:
            raise ValueError("robustness evidence fingerprint is invalid")
        losses[point_id], evidence[point_id] = float(raw), fingerprint
    if set(losses) != set(expected):
        raise ValueError("robustness rows must exactly cover the matrix")
    threshold = None
    if maximum_total_loss is not None:
        threshold_value = _float_or_none(maximum_total_loss)
        if threshold_value is None or not math.isfinite(threshold_value) or threshold_value < 0.0:
            raise ValueError("maximum_total_loss must be finite and nonnegative")
        threshold = float(maximum_total_loss)
    values = [losses[point_id] for point_id in expected]
    try:
        mean_total_loss = fmean(values)
    except OverflowError as error:
        raise ValueError("robustness mean total loss overflows the finite range") from error
    if not math.isfinite(mean_total_loss):
        raise ValueError("robustness mean total loss must be finite")
    body = {
        "schema_name": "research.robustness.summary",
        "schema_version": "1.0.0",
        "matrix_fingerprint": matrix["matrix_fingerprint"],
        "evidence_fingerprints": dict(sorted(evidence.items())),
        "minimum_total_loss": min(values),
        "mean_total_loss": mean_total_loss,
        "maximum_total_loss": max(values),
        "required_maximum_total_loss": threshold,
        "threshold_outcome": "not_declared"
        if threshold is None
        else ("pass" if max(values) <= threshold else "fail"),
    }
    return {**body, "summary_fingerprint": domain_sha256_v2(body["schema_name"], body)}


def summarize_optional_fidelity_bridge(
    *,
    applicable: bool,
    primary: object,
    independent: object | None,
    maximum_absolute_differences: object | None,
) -> dict[str, Any]:
    """Compare exact observables only when an independent adapter is declared applicable."""
    if not isinstance(applicable, bool) or not isinstance(primary, Mapping):
        raise ValueError("applicability and primary evidence are required")
    if not applicable:
        if independent is not None or maximum_absolute_differences is not None:
            raise ValueError("non-applicable fidelity cannot contain comparison evidence")
        body = {
            "schema_name": "research.fidelity.bridge",
            "schema_version": "1.0.0",
            "applicability": "not_applicable",
            "outcome": "not_applicable",
            "differences": {},
        }
        return {**body, "bridge_fingerprint": domain_sha256_v2(body["schema_name"], body)}
    if not isinstance(independent, Mapping):
        raise ValueError("applicable fidelity requires matching observable sets")
    if any(not isinstance(key, str) for key in primary) or any(
        not isinstance(key, str) for key in independent
    ):
        raise ValueError("fidelity observables must be finite numeric mappings")
    if set(independent) != set(primary):
        raise ValueError("applicable fidelity requires matching observable sets")
    differences: dict[str, float] = {}
    for key in sorted(primary):
        left, right = primary[key], independent[key]
        left_value = _float_or_none(left)
        right_value = _float_or_none(right)
        if (
            left_value is None
            or right_value is None
            or not math.isfinite(left_value)
            or not math.isfinite(right_value)
        ):
            raise ValueError("fidelity observables must be finite numeric mappings")
        difference = abs(left_value - right_value)
        if not math.isfinite(difference):
            raise ValueError("fidelity observable differences must remain finite")
        differences[key] = difference
    thresholds = None
    outcome = "not_declared"
    if maximum_absolute_differences is not None:
        if not isinstance(maximum_absolute_differences, Mapping) or set(
            maximum_absolute_differences
        ) != set(differences):
            raise ValueError("fidelity thresholds must exactly cover compared observables")
        thresholds = {}
        for key, raw in maximum_absolute_differences.items():
            threshold_raw = _float_or_none(raw)
            if threshold_raw is None or not math.isfinite(threshold_raw) or threshold_raw < 0.0:
                raise ValueError("fidelity thresholds must be finite and nonnegative")
            thresholds[key] = float(raw)
        outcome = (
            "pass" if all(differences[key] <= thresholds[key] for key in differences) else "fail"
        )
    body = {
        "schema_name": "research.fidelity.bridge",
        "schema_version": "1.0.0",
        "applicability": "applicable",
        "outcome": outcome,
        "differences": differences,
        "maximum_absolute_differences": thresholds,
    }
    return {**body, "bridge_fingerprint": domain_sha256_v2(body["schema_name"], body)}


__all__ = [
    "axis_perturbation_matrix",
    "summarize_optional_fidelity_bridge",
    "summarize_robustness",
]
