"""Run the ratcheted lint, type, test, coverage, license, and budget gates."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
import tempfile
import uuid
from datetime import date
from pathlib import Path
from typing import Any

if __package__:
    from .dependency_license_gate import build_license_receipt
    from .paired_coverage import source_identity
else:
    from dependency_license_gate import build_license_receipt  # type: ignore[no-redef]
    from paired_coverage import source_identity  # type: ignore[no-redef]


ROOT = Path(__file__).resolve().parents[2]
POLICY_PATH = ROOT / "development_kit" / "release" / "coverage_policy.json"
LICENSE_REVIEW_PATH = ROOT / "development_kit" / "release" / "dependency_license_review.json"
LINT_TARGETS = (
    "development_kit/scripts/paired_coverage.py",
    "development_kit/tests/test_paired_coverage.py",
    "comsol_mcp/adapter/wavelength_controls.py",
    "comsol_mcp/jobs/tasks_public_engine.py",
    "comsol_mcp/platform_support.py",
    "comsol_mcp/posix_lock.py",
    "comsol_mcp/strict_wavelength.py",
    "comsol_mcp/xdg_paths.py",
    "settings_gui/posix_ownership.py",
    "settings_gui/xdg_shortcut.py",
    "development_kit/tests/platform_fixtures.py",
    "development_kit/tests/test_tasks_stdio_conformance.py",
    "development_kit/tests/tasks_stdio_fixture.py",
    "development_kit/tests/test_platform_support.py",
    "development_kit/tests/test_posix_platform.py",
    "development_kit/tests/test_strict_wavelength.py",
    "comsol_mcp/compatibility.py",
    "comsol_mcp/contracts",
    "comsol_mcp/durable",
    "comsol_mcp/contracts/simulation_configuration.py",
    "comsol_mcp/contracts/thermal_radiation.py",
    "comsol_mcp/contracts/thermal_material.py",
    "comsol_mcp/contracts/thermo_optomechanical.py",
    "comsol_mcp/evidence/simulation_configuration.py",
    "comsol_mcp/evidence/thermal_radiation.py",
    "comsol_mcp/evidence/thermal_material.py",
    "comsol_mcp/evidence/spectral_model_comparison.py",
    "comsol_mcp/evidence/model_identity.py",
    "comsol_mcp/evidence/inspection",
    # S10: the surrogate surface is lint-clean and stays covered.
    "comsol_mcp/evidence/surrogate_evidence.py",
    "comsol_mcp/surrogate",
    "comsol_mcp/jobs/surrogate_training.py",
    "comsol_mcp/jobs/surrogate_training_worker.py",
    # S4A: the project-owned COMSOL adapter seam is lint-clean and stays covered.
    "comsol_mcp/adapter",
    "comsol_mcp/native_runtime.py",
    # The separated SDK/protocol/extension identity surface and the Tasks
    # adapter are lint- and strict-typing-clean and stay covered.
    "comsol_mcp/protocol_identity.py",
    "comsol_mcp/jobs/tasks_bridge.py",
    "comsol_mcp/jobs/tasks_extension.py",
    "comsol_mcp/shared_session/dbmodel_operations.py",
    "comsol_mcp/shared_session/model_manager.py",
    "comsol_mcp/shared_session/solver_owners.py",
    "comsol_mcp/durable/operation_ledger.py",
    "comsol_mcp/tools/model_manager.py",
    # P0: the progressive-discovery surface is lint-clean and stays covered.
    "comsol_mcp/tools/discovery.py",
    "comsol_mcp/tools/discovery_tools.py",
    "comsol_mcp/tools/tools_list_pagination.py",
    "comsol_mcp/schema_registry.py",
    "comsol_mcp/settings_gui_handshake.py",
    "comsol_mcp/settings_gui_launcher.py",
    "comsol_mcp/jobs/bounded_steps.py",
    "comsol_mcp/jobs/observation.py",
    "comsol_mcp/jobs/thermo_optomechanical_replay.py",
    "comsol_mcp/jobs/thermo_optomechanical_replay_execution.py",
    "comsol_mcp/jobs/thermo_optomechanical_replay_rows.py",
    "comsol_mcp/jobs/thermo_optomechanical_replay_runner.py",
    "comsol_mcp/jobs/thermo_optomechanical_replay_worker.py",
    "comsol_mcp/jobs/adjoint_optimization.py",
    "comsol_mcp/jobs/adjoint_optimization_worker.py",
    "comsol_mcp/jobs/native_adjoint_runtime.py",
    "comsol_mcp/jobs/robust_finalist_runtime.py",
    "comsol_mcp/jobs/robust_gradient_runtime.py",
    "comsol_mcp/jobs/robust_shape_optimization.py",
    "comsol_mcp/jobs/robust_shape_rows.py",
    "comsol_mcp/jobs/robust_shape_worker.py",
    "comsol_mcp/jobs/robust_wall_watchdog.py",
    "comsol_mcp/knowledge/lexical_build_worker.py",
    "comsol_mcp/research",
    "comsol_mcp/standalone",
    "comsol_mcp/tools/acoustics_pde.py",
    "comsol_mcp/tools/electro_chemistry.py",
    "comsol_mcp/tools/catalog.py",
    "comsol_mcp/tools/configuration.py",
    "comsol_mcp/tools/compatibility_registry.py",
    "comsol_mcp/tools/offline_export.py",
    "comsol_mcp/tools/mph_inspection.py",
    "comsol_mcp/tools/model_identity.py",
    # S10: the bounded public surrogate tools are lint-clean and stay covered.
    "comsol_mcp/tools/surrogate.py",
    "comsol_mcp/tools/thermal_radiation.py",
    "comsol_mcp/tools/thermal_material.py",
    "comsol_mcp/tools/geometry_selections.py",
    "comsol_mcp/tools/research.py",
    "comsol_mcp/tools/robust_shape.py",
    "comsol_mcp/tools/session_status.py",
    "comsol_mcp/tools/settings_gui.py",
    "comsol_mcp/tools/standalone.py",
    "src/__init__.py",
    "development_kit/scripts/dependency_license_gate.py",
    "development_kit/scripts/quality_gate.py",
    "development_kit/scripts/robust_gradient_ladder_licensed_gate.py",
    "development_kit/scripts/verify_robust_gradient_ladder_receipt.py",
    "development_kit/scripts/standalone_licensed_gate.py",
    # 0.7.6: the controlled engineering fixture builder is lint-clean and covered.
    "development_kit/scripts/build_engineering_fixture.py",
    "development_kit/tests/test_engineering_fixture_builder.py",
    "development_kit/benchmarks/research_campaign.py",
    "development_kit/tests/conftest.py",
    "development_kit/tests/test_alpha73_public_surface.py",
    "development_kit/tests/test_bounded_steps.py",
    "development_kit/tests/test_compatibility_registry.py",
    "development_kit/tests/test_offline_export.py",
    "development_kit/tests/test_observation.py",
    "development_kit/tests/test_control_plane_startup.py",
    "development_kit/tests/test_dependency_license_gate.py",
    "development_kit/tests/test_durable_primitives.py",
    "development_kit/tests/test_namespace_compatibility.py",
    "development_kit/tests/test_native_runtime.py",
    "development_kit/tests/test_public_input_contracts.py",
    "development_kit/tests/test_quality_gate.py",
    "development_kit/tests/test_quality_properties.py",
    "development_kit/tests/test_research_benchmarks.py",
    "development_kit/tests/test_research_contracts.py",
    "development_kit/tests/test_research_workflow.py",
    "development_kit/tests/test_research_materials.py",
    "development_kit/tests/test_research_candidates.py",
    "development_kit/tests/test_research_decisions.py",
    "development_kit/tests/test_research_state.py",
    "development_kit/tests/test_research_journal.py",
    "development_kit/tests/test_research_evaluations.py",
    "development_kit/tests/test_research_coordinator.py",
    "development_kit/tests/test_research_objectives.py",
    "development_kit/tests/test_research_adapters.py",
    "development_kit/tests/test_research_optimizers.py",
    "development_kit/tests/test_research_tools.py",
    "development_kit/tests/test_robust_conditions.py",
    "development_kit/tests/test_robust_gradient_acceptance.py",
    "development_kit/tests/test_robust_gradient_ladder_licensed_gate.py",
    "development_kit/tests/test_robust_gradient_runtime.py",
    "development_kit/tests/test_robust_objectives.py",
    "development_kit/tests/test_robust_optimizer_policy.py",
    "development_kit/tests/test_shape_support.py",
    "development_kit/tests/test_external_validation.py",
    "development_kit/tests/test_robust_startup_admission.py",
    "development_kit/tests/test_robust_shape_optimization.py",
    "development_kit/tests/test_robust_shape_adapter.py",
    "development_kit/tests/test_robust_shape_adapter_licensed_gate.py",
    "development_kit/tests/test_robust_shape_rows.py",
    "development_kit/tests/test_robust_shape_tools.py",
    "development_kit/tests/test_robust_shape_worker.py",
    "development_kit/tests/test_robust_wall_watchdog.py",
    "development_kit/tests/test_adapter_protocol.py",
    "development_kit/tests/test_schema_registry.py",
    "development_kit/tests/test_standalone_acceptance_runner.py",
    "development_kit/tests/test_standalone_executable.py",
    "development_kit/tests/test_standalone_tools.py",
    "development_kit/tests/test_surrogate_public_tools.py",
    "development_kit/tests/test_tool_catalog.py",
)
MYPY_GROUPS = (
    (
        "--follow-imports=skip",
        "development_kit/scripts/paired_coverage.py",
        "comsol_mcp/adapter/wavelength_controls.py",
        "comsol_mcp/platform_support.py",
        "comsol_mcp/posix_lock.py",
        "comsol_mcp/strict_wavelength.py",
        "comsol_mcp/xdg_paths.py",
        "settings_gui/posix_ownership.py",
        "settings_gui/xdg_shortcut.py",
    ),
    (
        "comsol_mcp/contracts/wavelength_policy.py",
        "comsol_mcp/contracts/job_submission.py",
        "comsol_mcp/contracts/mph_inspection.py",
        "comsol_mcp/contracts/model_identity.py",
        "comsol_mcp/contracts/offline_export.py",
        "comsol_mcp/contracts/simulation_configuration.py",
        "comsol_mcp/contracts/thermal_radiation.py",
        "comsol_mcp/contracts/thermal_material.py",
        "comsol_mcp/contracts/thermo_optomechanical.py",
        "comsol_mcp/contracts/structural.py",
        # S10: bounded public surrogate input contracts.
        "comsol_mcp/contracts/surrogate.py",
    ),
    (
        "comsol_mcp/durable/canonical.py",
        "comsol_mcp/durable/io.py",
    ),
    (
        "--follow-imports=skip",
        "comsol_mcp/evidence/spectral_model_comparison.py",
        "comsol_mcp/evidence/simulation_configuration.py",
        "comsol_mcp/evidence/thermal_radiation.py",
        "comsol_mcp/evidence/thermal_material.py",
        "comsol_mcp/evidence/inspection",
        "comsol_mcp/evidence/model_identity.py",
        "comsol_mcp/tools/mph_inspection.py",
        "comsol_mcp/tools/model_identity.py",
        "comsol_mcp/evidence/compatibility_registry.py",
        "comsol_mcp/tools/compatibility_registry.py",
        "comsol_mcp/evidence/offline_export.py",
        "comsol_mcp/tools/offline_export.py",
        # S10: the surrogate surface is fully typed under --strict.
        "comsol_mcp/evidence/surrogate_evidence.py",
        "comsol_mcp/tools/surrogate.py",
        "comsol_mcp/surrogate",
        "comsol_mcp/jobs/surrogate_training.py",
        "comsol_mcp/jobs/surrogate_training_worker.py",
        # S4A: the adapter seam is fully typed under --strict.
        "comsol_mcp/adapter",
        "comsol_mcp/jobs/bounded_steps.py",
        "comsol_mcp/jobs/observation.py",
        "comsol_mcp/jobs/thermo_optomechanical_replay.py",
        "comsol_mcp/jobs/thermo_optomechanical_replay_execution.py",
        "comsol_mcp/jobs/thermo_optomechanical_replay_rows.py",
        "comsol_mcp/jobs/thermo_optomechanical_replay_runner.py",
        "comsol_mcp/jobs/thermo_optomechanical_replay_worker.py",
        "comsol_mcp/jobs/adjoint_optimization.py",
        "comsol_mcp/jobs/adjoint_optimization_worker.py",
        "comsol_mcp/jobs/native_adjoint_runtime.py",
        "comsol_mcp/jobs/robust_finalist_runtime.py",
        "comsol_mcp/jobs/robust_gradient_runtime.py",
        "comsol_mcp/jobs/robust_shape_optimization.py",
        "comsol_mcp/jobs/robust_shape_rows.py",
        "comsol_mcp/jobs/robust_shape_worker.py",
        "comsol_mcp/jobs/robust_wall_watchdog.py",
        "comsol_mcp/tools/acoustics_pde.py",
        "comsol_mcp/tools/electro_chemistry.py",
        "comsol_mcp/tools/catalog.py",
        "comsol_mcp/tools/configuration.py",
        "comsol_mcp/tools/thermal_radiation.py",
        "comsol_mcp/tools/thermal_material.py",
        "comsol_mcp/tools/geometry_selections.py",
        "comsol_mcp/tools/research.py",
        "comsol_mcp/tools/robust_shape.py",
        "comsol_mcp/schema_registry.py",
        "comsol_mcp/settings_gui_handshake.py",
        "comsol_mcp/settings_gui_launcher.py",
        "comsol_mcp/compatibility.py",
        "comsol_mcp/protocol_identity.py",
        "comsol_mcp/tools/session_status.py",
        "comsol_mcp/tools/settings_gui.py",
        "comsol_mcp/knowledge/lexical_build_worker.py",
        "comsol_mcp/native_runtime.py",
        "comsol_mcp/standalone",
        "comsol_mcp/research",
        "src/__init__.py",
    ),
    (
        # The Tasks adapter subclasses SDK base classes and pydantic models whose
        # types resolve only when imports are followed as far as the checker
        # needs. `silent` type-checks these files strictly while not reporting
        # diagnostics for transitively imported modules, so the modules stay
        # fully covered without weakening any rule for the rest of the tree.
        "--follow-imports=silent",
        "comsol_mcp/jobs/tasks_public_engine.py",
        "comsol_mcp/jobs/tasks_bridge.py",
        "comsol_mcp/jobs/tasks_extension.py",
    ),
    (
        "--follow-imports=silent",
        "comsol_mcp/shared_session/dbmodel_operations.py",
        "comsol_mcp/shared_session/model_manager.py",
        "comsol_mcp/shared_session/solver_owners.py",
        "comsol_mcp/durable/operation_ledger.py",
        "comsol_mcp/tools/model_manager.py",
        # P0: the discovery surface handles SDK result shapes whose types resolve
        # only when imports are followed as far as the checker needs.
        "comsol_mcp/tools/discovery.py",
        "comsol_mcp/tools/discovery_tools.py",
        "comsol_mcp/tools/tools_list_pagination.py",
    ),
)
PRODUCTION_ROOTS = ("comsol_mcp", "src")
LINT_EXCLUSIONS_SHA256 = "2ad57c6658d4d0da9f2df0eb3256da088a1540c23631aea8327ea8fde68bc1cc"
MYPY_EXCLUSIONS_SHA256 = "0ee71edbf253ed405fd397ce377ae5b2202e4913d6e8c5863ee01485ae64a402"
PARALLEL_TEST_WORKERS = 4
SERIAL_TEST_TARGETS = ("development_kit/tests/test_control_plane_startup.py",)
WINDOWS_GATE_ROOT_MAX_CHARS = 32
WINDOWS_GATE_ROOT_MAX_LEAF_CHARS = 12


class QualityCommandError(RuntimeError):
    """One named quality command failed without exposing its command line."""

    def __init__(self, stage: str, returncode: int) -> None:
        super().__init__(stage)
        self.stage = stage
        self.returncode = returncode


def _targeted_production_modules(targets: tuple[str, ...], modules: set[str]) -> set[str]:
    configured = [target for target in targets if target.split("/", 1)[0] in PRODUCTION_ROOTS]
    return {
        module
        for module in modules
        if any(
            module == target or module.startswith(target.rstrip("/") + "/") for target in configured
        )
    }


def _exclusion_digest(modules: set[str]) -> str:
    payload = json.dumps(sorted(modules), separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload, usedforsecurity=False).hexdigest()


def validate_quality_target_inventory(root: Path = ROOT) -> dict[str, Any]:
    """Fail when a production module bypasses the frozen lint/type classification."""
    modules = {
        path.relative_to(root).as_posix()
        for production_root in PRODUCTION_ROOTS
        for path in (root / production_root).rglob("*.py")
    }
    mypy_targets = tuple(
        target for group in MYPY_GROUPS for target in group if not target.startswith("-")
    )
    lint_exclusions = modules - _targeted_production_modules(LINT_TARGETS, modules)
    mypy_exclusions = modules - _targeted_production_modules(mypy_targets, modules)
    observed = {
        "lint": _exclusion_digest(lint_exclusions),
        "typing": _exclusion_digest(mypy_exclusions),
    }
    expected = {
        "lint": LINT_EXCLUSIONS_SHA256,
        "typing": MYPY_EXCLUSIONS_SHA256,
    }
    if observed != expected:
        raise ValueError("production quality-target classification changed")
    return {
        "production_module_count": len(modules),
        "lint_targeted_count": len(modules - lint_exclusions),
        "typing_targeted_count": len(modules - mypy_exclusions),
        "exclusion_digests": observed,
    }


def _main_pytest_command(pytest_root: Path, *, hosted_ci: bool) -> list[str]:
    """Build the main-suite command, keeping hosted Python 3.14 execution serial."""
    command = [sys.executable, "-m", "pytest", "-q"]
    if not hosted_ci:
        command.extend(["-n", str(PARALLEL_TEST_WORKERS), "--dist", "loadscope"])
    command.extend(
        [
            "--basetemp",
            str(pytest_root),
            *(argument for target in SERIAL_TEST_TARGETS for argument in ("--ignore", target)),
            "--cov=comsol_mcp",
            "--cov-branch",
            "--cov-report=",
        ]
    )
    return command


def _serial_pytest_command(pytest_root: Path) -> list[str]:
    """Serial startup/process-inventory tail whose coverage joins the same
    measurement as the parallel suite."""
    return [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        *SERIAL_TEST_TARGETS,
        "--basetemp",
        str(pytest_root),
        "--cov=comsol_mcp",
        "--cov-branch",
        "--cov-report=",
    ]


def _hosted_serial_shard_command(basetemp_root: Path, coverage_root: Path) -> list[str]:
    """Build the no-xdist hosted runner command for isolated serial shards."""
    return [
        sys.executable,
        "development_kit/scripts/serial_test_shards.py",
        "--basetemp-root",
        str(basetemp_root),
        "--coverage-root",
        str(coverage_root),
        "--shards",
        "2",
        "--ignore",
        SERIAL_TEST_TARGETS[0],
    ]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes(), usedforsecurity=False).hexdigest()


def _default_artifact_root() -> Path:
    configured = os.environ.get("COMSOL_MCP_QUALITY_ROOT")
    if configured:
        return Path(configured)
    runner_temp = os.environ.get("RUNNER_TEMP")
    if runner_temp:
        return Path(runner_temp) / "qgate"
    if os.name == "nt" and Path("D:/mcp_tests").exists():
        return Path("D:/mcp_tests/qgate")
    return Path(tempfile.gettempdir()) / "qgate"


def validate_windows_gate_root(
    value: str | Path,
    *,
    label: str,
    platform_name: str | None = None,
    hosted_ci: bool | None = None,
) -> Path:
    """Reject local Windows gate roots that leave too little generated-path budget."""
    root = Path(value).expanduser().resolve()
    current_platform = os.name if platform_name is None else platform_name
    current_hosted_ci = (
        os.environ.get("GITHUB_ACTIONS", "").casefold() == "true"
        if hosted_ci is None
        else hosted_ci
    )
    if current_platform != "nt" or current_hosted_ci:
        return root
    text = str(root)
    if not text.isascii():
        raise ValueError(f"{label} must be ASCII on local Windows")
    approved_parent = Path("D:/mcp_tests").resolve()
    if str(root.parent).casefold() != str(approved_parent).casefold():
        raise ValueError(f"{label} must be a direct child of D:\\mcp_tests on local Windows")
    if len(text) > WINDOWS_GATE_ROOT_MAX_CHARS or len(root.name) > WINDOWS_GATE_ROOT_MAX_LEAF_CHARS:
        raise ValueError(
            f"{label} leaves insufficient Windows generated-path budget; "
            f"use a short root such as D:\\mcp_tests\\a65b13q"
        )
    return root


def _run(
    arguments: list[str],
    *,
    stage: str,
    environment: dict[str, str] | None = None,
) -> None:
    try:
        subprocess.run(  # noqa: S603
            arguments,
            cwd=ROOT,
            env=environment,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        raise QualityCommandError(stage, exc.returncode) from None


def _create_quality_run_root(artifact_root: Path) -> Path:
    """Create one collision-free evidence directory below a caller-owned root."""
    if os.name == "nt" and not str(artifact_root).isascii():
        raise ValueError("quality artifact root must be ASCII on Windows")
    artifact_root.mkdir(parents=True, exist_ok=True)
    for _ in range(8):
        candidate = artifact_root / f"run-{os.getpid()}-{uuid.uuid4().hex}"
        try:
            candidate.mkdir()
        except FileExistsError:
            continue
        return candidate
    raise RuntimeError("could not allocate a unique quality evidence directory")


def _create_short_pytest_roots() -> tuple[Path, Path]:
    """Allocate isolated main/serial roots within the validated Windows budget."""
    configured = os.environ.get("COMSOL_MCP_TEST_ASCII_ROOT")
    if configured:
        configured_root = Path(configured).expanduser().resolve()
        if os.name == "nt" and os.environ.get("GITHUB_ACTIONS", "").casefold() != "true":
            configured_root = validate_windows_gate_root(
                configured_root, label="quality pytest root seed"
            )
        safe_prefix = "".join(
            character for character in configured_root.name if character.isalnum()
        )
        safe_prefix = (safe_prefix[:2] or "q").casefold()
        token = uuid.uuid4().hex[:8]
        main_root = configured_root.with_name(f"{safe_prefix}{token}m")
        serial_root = configured_root.with_name(f"{safe_prefix}{token}s")
        if os.name == "nt" and os.environ.get("GITHUB_ACTIONS", "").casefold() != "true":
            main_root = validate_windows_gate_root(main_root, label="quality main pytest root")
            serial_root = validate_windows_gate_root(
                serial_root, label="quality serial pytest root"
            )
        candidates = [(main_root, serial_root)]
    elif os.name == "nt" and Path("D:/mcp_tests").exists():
        token = uuid.uuid4().hex[:8]
        parent = Path("D:/mcp_tests")
        candidates = [
            (
                validate_windows_gate_root(parent / f"q{token}m", label="quality main pytest root"),
                validate_windows_gate_root(
                    parent / f"q{token}s", label="quality serial pytest root"
                ),
            )
        ]
    else:
        parent = Path(tempfile.gettempdir()) / f"q-{os.getpid()}-{uuid.uuid4().hex[:8]}"
        candidates = [(parent / "main", parent / "serial")]
    for main_root, serial_root in candidates:
        try:
            main_root.parent.mkdir(parents=True, exist_ok=True)
            main_root.mkdir()
            serial_root.mkdir()
        except OSError:
            continue
        return main_root, serial_root
    raise OSError("no isolated short ASCII pytest roots are available")


def _write_quality_receipt(run_root: Path, receipt: dict[str, Any]) -> None:
    output = run_root / "quality-receipt.json"
    with output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(receipt, handle, indent=2, sort_keys=True)
        handle.write("\n")


def load_coverage_policy(path: str | Path) -> dict[str, Any]:
    """Load one exact coverage floor and per-file safety target policy."""
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict) or set(value) != {
        "schema_name",
        "schema_version",
        "global",
        "targets",
    }:
        raise ValueError("coverage policy fields are invalid")
    if value["schema_name"] != "comsol_mcp.coverage_policy" or value["schema_version"] != "1.0.0":
        raise ValueError("coverage policy schema is unsupported")
    if not isinstance(value["global"], dict) or set(value["global"]) != {
        "minimum_percent_covered",
        "owner",
        "rationale",
        "removal_gate",
    }:
        raise ValueError("global coverage policy is invalid")
    targets = value["targets"]
    if not isinstance(targets, list) or not targets:
        raise ValueError("coverage targets are missing")
    paths = []
    for item in [value["global"], *targets]:
        if not isinstance(item, dict):
            raise ValueError("coverage policy item is invalid")
        threshold = item.get("minimum_percent_covered")
        if (
            isinstance(threshold, bool)
            or not isinstance(threshold, (int, float))
            or not math.isfinite(float(threshold))
            or not 0.0 <= float(threshold) <= 100.0
            or not isinstance(item.get("owner"), str)
            or not item["owner"].strip()
            or not isinstance(item.get("rationale"), str)
            or not item["rationale"].strip()
            or not isinstance(item.get("removal_gate"), str)
            or not item["removal_gate"].strip()
        ):
            raise ValueError("coverage policy item values are invalid")
        if item is value["global"]:
            continue
        if set(item) != {
            "path",
            "minimum_percent_covered",
            "owner",
            "rationale",
            "removal_gate",
        }:
            raise ValueError("coverage target fields are invalid")
        path_text = item["path"]
        if (
            not isinstance(path_text, str)
            or not path_text.startswith("comsol_mcp/")
            or "\\" in path_text
            or ".." in Path(path_text).parts
        ):
            raise ValueError("coverage target path is invalid")
        paths.append(path_text)
    if len(paths) != len(set(paths)):
        raise ValueError("coverage target paths must be unique")
    return value


def evaluate_coverage(
    report: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    """Evaluate branch-aware global and safety-file coverage floors."""
    totals = report.get("totals") if isinstance(report, dict) else None
    files = report.get("files") if isinstance(report, dict) else None
    if not isinstance(totals, dict) or not isinstance(files, dict):
        raise ValueError("coverage report is invalid")
    global_percent = totals.get("percent_covered")
    if (
        isinstance(global_percent, bool)
        or not isinstance(global_percent, (int, float))
        or not math.isfinite(float(global_percent))
    ):
        raise ValueError("global coverage percentage is missing")
    normalized_files = {path.replace("\\", "/"): value for path, value in files.items()}
    failures = []
    global_minimum = float(policy["global"]["minimum_percent_covered"])
    if float(global_percent) < global_minimum:
        failures.append(
            {
                "reason_code": "global_coverage_regressed",
                "observed": float(global_percent),
                "minimum": global_minimum,
            }
        )
    target_receipts = []
    for target in policy["targets"]:
        path = target["path"]
        file_record = normalized_files.get(path)
        summary = file_record.get("summary") if isinstance(file_record, dict) else None
        observed = summary.get("percent_covered") if isinstance(summary, dict) else None
        minimum = float(target["minimum_percent_covered"])
        if (
            isinstance(observed, bool)
            or not isinstance(observed, (int, float))
            or not math.isfinite(float(observed))
        ):
            failures.append({"path": path, "reason_code": "coverage_target_missing"})
        elif float(observed) < minimum:
            failures.append(
                {
                    "path": path,
                    "reason_code": "coverage_target_regressed",
                    "observed": float(observed),
                    "minimum": minimum,
                }
            )
        target_receipts.append(
            {
                "path": path,
                "observed": observed,
                "minimum": minimum,
                "owner": target["owner"],
                "rationale": target["rationale"],
                "removal_gate": target["removal_gate"],
            }
        )
    return {
        "status": "passed" if not failures else "failed",
        "global": {
            "observed": float(global_percent),
            "minimum": global_minimum,
            "covered_lines": totals.get("covered_lines"),
            "num_statements": totals.get("num_statements"),
            "covered_branches": totals.get("covered_branches"),
            "num_branches": totals.get("num_branches"),
        },
        "targets": target_receipts,
        "failures": failures,
    }


def run_quality_gate(
    artifact_root: Path, *, as_of: date, defer_platform_coverage: bool = False
) -> dict[str, Any]:
    """Run every quality command and return one path-free receipt."""
    run_root = _create_quality_run_root(artifact_root)
    coverage_data = run_root / ".coverage"
    coverage_json = run_root / "coverage.json"
    main_pytest_root, serial_pytest_root = _create_short_pytest_roots()
    environment = dict(os.environ)
    environment["COVERAGE_FILE"] = str(coverage_data)
    run_id = run_root.name

    try:
        validate_quality_target_inventory()
        _run([sys.executable, "-m", "ruff", "check", *LINT_TARGETS], stage="lint")
        initial_source = source_identity(ROOT)
        _run(
            [sys.executable, "-m", "ruff", "format", "--check", *LINT_TARGETS],
            stage="format",
        )
        for index, group in enumerate(MYPY_GROUPS, start=1):
            _run(
                [
                    sys.executable,
                    "-m",
                    "mypy",
                    "--strict",
                    "--ignore-missing-imports",
                    "--no-error-summary",
                    *group,
                ],
                stage=f"typing_{index}",
            )
        _run(
            [sys.executable, "-m", "coverage", "erase"],
            stage="coverage_erase",
            environment=environment,
        )
        hosted_ci = os.environ.get("GITHUB_ACTIONS", "").casefold() == "true"
        if hosted_ci:
            shard_coverage_root = run_root / "shard-coverage"
            _run(
                _hosted_serial_shard_command(main_pytest_root, shard_coverage_root),
                stage="hosted_serial_shards",
                environment=environment,
            )
            coverage_inputs = [
                shard_coverage_root / ".coverage-shard-0",
                shard_coverage_root / ".coverage-shard-1",
            ]
        else:
            _run(
                _main_pytest_command(main_pytest_root, hosted_ci=False),
                stage="parallel_tests",
                environment=environment,
            )
            coverage_inputs = [coverage_data]
        serial_coverage_data = run_root / ".coverage-serial"
        serial_environment = dict(environment)
        serial_environment["COVERAGE_FILE"] = str(serial_coverage_data)
        _run(
            _serial_pytest_command(serial_pytest_root),
            stage="serial_tests",
            environment=serial_environment,
        )
        # Merge the serial tail into the same measurement instead of letting
        # the coverage policy silently evaluate only the parallel suite.
        # Combine both suites into one fresh measurement file. coverage
        # combine rebuilds its output from the listed inputs, so the target
        # must be distinct from the parallel-suite data being merged in.
        combined_coverage_data = run_root / ".coverage-combined"
        combine_inputs = [str(path) for path in coverage_inputs]
        if serial_coverage_data.exists():
            combine_inputs.append(str(serial_coverage_data))
        combine_environment = dict(environment)
        combine_environment["COVERAGE_FILE"] = str(combined_coverage_data)
        if len(combine_inputs) >= 2:
            _run(
                [
                    sys.executable,
                    "-m",
                    "coverage",
                    "combine",
                    "--keep",
                    *combine_inputs,
                ],
                stage="coverage_combine",
                environment=combine_environment,
            )
            report_environment = combine_environment
        else:
            # The serial tail collected nothing measurable; report the
            # parallel-suite data directly instead of failing the gate.
            report_environment = environment
        _run(
            [sys.executable, "-m", "coverage", "json", "-o", str(coverage_json)],
            stage="coverage_report",
            environment=report_environment,
        )
    except QualityCommandError as exc:
        receipt = {
            "schema_name": "comsol_mcp.quality_gate_receipt",
            "schema_version": "1.0.0",
            "as_of": as_of.isoformat(),
            "run_id": run_id,
            "status": "failed",
            "failures": ["command"],
            "command_failure": {
                "stage": exc.stage,
                "returncode": exc.returncode,
            },
            "coverage": None,
            "dependency_licenses": None,
            "coverage_policy_sha256": _sha256(POLICY_PATH),
            "solver_started": False,
        }
        _write_quality_receipt(run_root, receipt)
        return receipt
    except (ValueError, OSError, RuntimeError) as exc:
        # Configuration drift (classification ratchet, coverage policy,
        # license review) must produce the same structured failed receipt as
        # command failures instead of escaping with a raw traceback.
        receipt = {
            "schema_name": "comsol_mcp.quality_gate_receipt",
            "schema_version": "1.0.0",
            "as_of": as_of.isoformat(),
            "run_id": run_id,
            "status": "failed",
            "failures": ["configuration"],
            "configuration_failure": {
                "type": type(exc).__name__,
                "error": str(exc)[:512],
            },
            "coverage": None,
            "dependency_licenses": None,
            "coverage_policy_sha256": _sha256(POLICY_PATH),
            "solver_started": False,
        }
        _write_quality_receipt(run_root, receipt)
        return receipt

    try:
        if source_identity(ROOT) != initial_source:
            raise ValueError("source changed during the quality gate")
        policy = load_coverage_policy(POLICY_PATH)
        coverage_receipt = evaluate_coverage(
            json.loads(coverage_json.read_text(encoding="utf-8")),
            policy,
        )
        license_receipt = build_license_receipt(
            ROOT / "pyproject.toml",
            LICENSE_REVIEW_PATH,
            as_of=as_of,
        )
    except (ValueError, OSError, RuntimeError) as exc:
        receipt = {
            "schema_name": "comsol_mcp.quality_gate_receipt",
            "schema_version": "1.0.0",
            "as_of": as_of.isoformat(),
            "run_id": run_id,
            "status": "failed",
            "failures": ["configuration"],
            "configuration_failure": {
                "type": type(exc).__name__,
                "error": str(exc)[:512],
            },
            "coverage": None,
            "dependency_licenses": None,
            "coverage_policy_sha256": _sha256(POLICY_PATH),
            "solver_started": False,
        }
        _write_quality_receipt(run_root, receipt)
        return receipt
    failures = []
    deferred = False
    if coverage_receipt["status"] != "passed":
        failures.append("coverage")
    if license_receipt["status"] != "passed":
        failures.append("dependency_licenses")
    if defer_platform_coverage and failures == ["coverage"]:
        deferred = all(
            item.get("path") == "comsol_mcp/durable/io.py"
            and item.get("reason_code") == "coverage_target_regressed"
            for item in coverage_receipt["failures"]
        )
    receipt = {
        "schema_name": "comsol_mcp.quality_gate_receipt",
        "schema_version": "1.0.0",
        "as_of": as_of.isoformat(),
        "run_id": run_id,
        "status": "awaiting_cross_platform_coverage"
        if deferred
        else ("passed" if not failures else "failed"),
        "failures": failures,
        "coverage": coverage_receipt,
        "platform": sys.platform,
        "source_tree_sha256": source_identity(ROOT),
        "coverage_json_sha256": _sha256(coverage_json),
        "dependency_licenses": license_receipt,
        "coverage_policy_sha256": _sha256(POLICY_PATH),
        "solver_started": False,
    }
    _write_quality_receipt(run_root, receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact-root", type=Path, default=_default_artifact_root())
    parser.add_argument("--defer-platform-coverage", action="store_true")
    parser.add_argument("--as-of", type=date.fromisoformat, default=date.today())
    args = parser.parse_args()

    artifact_root = validate_windows_gate_root(args.artifact_root, label="quality artifact root")
    configured_pytest_root = os.environ.get("COMSOL_MCP_TEST_ASCII_ROOT")
    if configured_pytest_root:
        validate_windows_gate_root(configured_pytest_root, label="quality pytest root")
    receipt = run_quality_gate(
        artifact_root, as_of=args.as_of, defer_platform_coverage=args.defer_platform_coverage
    )
    print(json.dumps(receipt, sort_keys=True))
    return 0 if receipt["status"] in {"passed", "awaiting_cross_platform_coverage"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
