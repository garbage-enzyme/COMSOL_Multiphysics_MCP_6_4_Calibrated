"""Solver-free cleanup accounting shared by licensed acceptance scripts."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any


def _default_cleanup_passed(value: Any) -> bool:
    if value is False:
        return False
    if isinstance(value, dict) and "success" in value:
        return value.get("success") is True
    return True


class CleanupRecorder:
    """Run independent cleanup steps and make their outcome part of success."""

    def __init__(self, result: dict[str, Any]):
        self.result = result
        self.steps: dict[str, dict[str, Any]] = {}

    def run(
        self,
        name: str,
        operation: Callable[[], Any],
        *,
        passed: Callable[[Any], bool] = _default_cleanup_passed,
        expose_result: bool = True,
    ) -> Any:
        try:
            value = operation()
        except Exception as exc:  # cleanup must continue through independent steps
            value = {
                "success": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
            detail = {
                "passed": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
        else:
            # A predicate bug is not an operation failure: keep the real
            # operation result exposed while still failing the step.
            try:
                step_passed = bool(passed(value))
                detail = {"passed": step_passed}
            except Exception as exc:
                detail = {
                    "passed": False,
                    "predicate_error": True,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                }
        self.steps[name] = detail
        if expose_result:
            self.result[name] = value
        return value

    def finalize(self) -> int:
        cleanup_passed = all(step.get("passed") is True for step in self.steps.values())
        self.result["cleanup"] = {
            "passed": cleanup_passed,
            "steps": dict(self.steps),
        }
        self.result["success"] = self.result.get("success") is True and cleanup_passed
        return 0 if self.result["success"] else 1


def lease_released(value: Any) -> bool:
    """Require an owned lease to report both successful and actual release."""
    return (
        isinstance(value, dict) and value.get("success") is True and value.get("released") is True
    )


__all__ = ["CleanupRecorder", "lease_released"]
