"""Run the dependency-only release and clean-wheel discovery gates."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile
import uuid
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

if __package__:
    from .planning_code_gate import (
        TEXT_SUFFIXES,
        load_planning_code_allowlist,
        verify_planning_code_texts,
    )
    from .quality_gate import validate_windows_gate_root
else:
    from planning_code_gate import (  # type: ignore[no-redef]
        TEXT_SUFFIXES,
        load_planning_code_allowlist,
        verify_planning_code_texts,
    )
    from quality_gate import validate_windows_gate_root  # type: ignore[no-redef]


ROOT = Path(__file__).resolve().parents[2]
PLANNING_CODE_ALLOWLIST = ROOT / "development_kit" / "release" / "planning_code_allowlist.json"
_FORBIDDEN_PARTS = {
    ".claude",
    "comsol_models",
    "development_kit",
    "knowledge_base",
    "knowledge_base_v2",
    "pdf",
}
_FORBIDDEN_SUFFIXES = {".class", ".lock", ".mph", ".pyc", ".recovery", ".status"}
_FORBIDDEN_NAMES = {".env", "credentials", "credentials.json", "id_rsa", "secrets.json"}


def _run(
    command: list[str],
    *,
    cwd: Path = ROOT,
    env: dict[str, str] | None = None,
) -> None:
    subprocess.run(
        command,
        cwd=cwd,
        env=env,
        check=True,
        creationflags=(getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0),
    )


def _sanitized_probe_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment.pop("PYTHONPATH", None)
    return environment


def _git_status() -> list[str]:
    completed = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
        creationflags=(getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0),
    )
    return [line for line in completed.stdout.splitlines() if line]


def _default_artifact_root() -> Path:
    configured = os.environ.get("COMSOL_MCP_RELEASE_ROOT")
    if configured:
        return Path(configured)
    if os.name == "nt" and Path("D:/mcp_tests").exists():
        return Path("D:/mcp_tests/rgate")
    return Path(tempfile.gettempdir()) / "rgate"


def _venv_python(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _venv_console_entry(venv_dir: Path) -> Path:
    if os.name == "nt":
        return venv_dir / "Scripts" / "comsol-mcp.exe"
    return venv_dir / "bin" / "comsol-mcp"


def _lock_lane(path: Path) -> str:
    prefix = "# Python-Lane:"
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"cannot read dependency lock {path}: {exc}") from exc
    values = [line[len(prefix) :].strip() for line in lines if line.startswith(prefix)]
    if len(values) != 1:
        raise ValueError(f"dependency lock must declare exactly one {prefix} header")
    return values[0]


def _validated_dependency_lock(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    expected_lane = f"{sys.version_info.major}.{sys.version_info.minor}"
    actual_lane = _lock_lane(resolved)
    if actual_lane != expected_lane:
        raise ValueError(
            f"dependency lock targets Python {actual_lane}, current interpreter is {expected_lane}"
        )
    return resolved


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalized_archive_path(
    name: str,
    *,
    sdist_root: str | None = None,
) -> str:
    raw = name.replace("\\", "/")
    pure = PurePosixPath(raw)
    windows = PureWindowsPath(raw)
    if (
        pure.is_absolute()
        or windows.is_absolute()
        or windows.drive
        or any(":" in part for part in pure.parts)
        or ".." in pure.parts
    ):
        raise RuntimeError(f"distribution contains unsafe path: {name}")
    parts = list(pure.parts)
    if sdist_root is not None:
        if not parts or parts[0] != sdist_root:
            raise RuntimeError(
                "sdist member is outside the exact archive root: "
                f"expected={sdist_root}, member={name}"
            )
        parts = parts[1:]
    return "/".join(parts)


def _normalized_archive_members(
    names: list[str],
    *,
    sdist_root: str | None,
) -> list[str]:
    normalized = [_normalized_archive_path(name, sdist_root=sdist_root) for name in names]
    # Windows is the declared install target: names that collide only by
    # case would overwrite each other during installation, so deduplicate
    # on the case-folded form.
    folded = [name.casefold() for name in normalized]
    if len(folded) != len(set(folded)):
        raise RuntimeError("distribution contains duplicate normalized paths")
    return normalized


def _distribution_files(path: Path) -> tuple[list[str], dict[str, bytes]]:
    if path.suffix.casefold() == ".whl":
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            members = [info.filename for info in infos]
            normalized = _normalized_archive_members(members, sdist_root=None)
            for info in infos:
                unix_mode = (info.external_attr >> 16) & 0o170000
                if unix_mode == 0o120000:
                    raise RuntimeError(f"distribution contains link member: {info.filename}")
            files = {
                normalized_name: archive.read(info)
                for info, normalized_name in zip(infos, normalized, strict=True)
                if not info.is_dir()
            }
    elif path.name.endswith(".tar.gz"):
        sdist_root = path.name.removesuffix(".tar.gz")
        with tarfile.open(path, "r:gz") as archive:
            archive_members = archive.getmembers()
            members = [member.name for member in archive_members]
            normalized = _normalized_archive_members(
                members,
                sdist_root=sdist_root,
            )
            files = {}
            for member, normalized_name in zip(
                archive_members,
                normalized,
                strict=True,
            ):
                if member.issym() or member.islnk():
                    raise RuntimeError(f"distribution contains link member: {member.name}")
                if not member.isfile() and not member.isdir():
                    raise RuntimeError(f"distribution contains special member: {member.name}")
                if not member.isfile():
                    continue
                stream = archive.extractfile(member)
                if stream is None:
                    raise RuntimeError(f"cannot read distribution member: {member.name}")
                files[normalized_name] = stream.read()
    else:
        raise ValueError(f"unsupported distribution artifact: {path.name}")
    return normalized, files


def _distribution_artifacts(dist_dir: Path) -> list[Path]:
    artifacts = sorted(path for path in dist_dir.iterdir() if path.is_file())
    wheels = [path for path in artifacts if path.suffix.casefold() == ".whl"]
    sdists = [path for path in artifacts if path.name.endswith(".tar.gz")]
    if len(wheels) != 1 or len(sdists) != 1 or len(artifacts) != 2:
        raise RuntimeError(
            "expected exactly one wheel and one sdist, "
            f"found wheels={len(wheels)}, sdists={len(sdists)}, artifacts={len(artifacts)}"
        )
    return [wheels[0], sdists[0]]


def _reject_private_user_text(name: str, text: str) -> None:
    """Fail any distribution text embedding a private user profile path.

    Windows paths are case-insensitive and every other forbidden-name check
    here case-folds, so this scan must too.
    """
    folded = text.casefold()
    if "c:\\users\\" in folded or "c:/users/" in folded or "陆星" in text:
        raise RuntimeError(f"distribution text contains a private user path: {name}")


def _distribution_inventory(path: Path) -> dict:
    normalized, files = _distribution_files(path)
    offenders = []
    for name in normalized:
        pure = PurePosixPath(name)
        lowered_parts = {part.casefold() for part in pure.parts}
        if (
            lowered_parts & _FORBIDDEN_PARTS
            or pure.suffix.casefold() in _FORBIDDEN_SUFFIXES
            or pure.name.casefold() in _FORBIDDEN_NAMES
        ):
            offenders.append(name)
    if offenders:
        raise RuntimeError(f"ordinary distribution contains forbidden members: {offenders[:5]}")
    texts = {}
    for name, payload in files.items():
        if PurePosixPath(name).suffix.casefold() not in TEXT_SUFFIXES:
            continue
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise RuntimeError(f"distribution text member is not UTF-8: {name}") from exc
        _reject_private_user_text(name, text)
        texts[name] = text
    planning_receipt = verify_planning_code_texts(
        texts,
        allowlist=load_planning_code_allowlist(PLANNING_CODE_ALLOWLIST),
        require_all_allowlisted=False,
    )
    return {
        "filename": path.name,
        "sha256": _sha256(path),
        "member_count": len(normalized),
        "development_kit_excluded": True,
        "forbidden_entries_absent": True,
        "private_user_paths_absent": True,
        "planning_code_gate": planning_receipt,
    }


def _dependency_lock_location(path: Path) -> dict[str, str]:
    try:
        relative = path.relative_to(ROOT)
    except ValueError:
        return {"path": str(path), "path_scope": "absolute_external"}
    return {"path": str(relative), "path_scope": "repository_relative"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--skip-install", action="store_true")
    parser.add_argument(
        "--build-python",
        type=Path,
        default=None,
        help="interpreter used only for isolated package building (defaults to the gate interpreter)",
    )
    parser.add_argument(
        "--build-no-isolation",
        action="store_true",
        help="use the selected interpreter's installed build backend when the isolated index is unavailable",
    )
    parser.add_argument("--artifact-root", type=Path, default=_default_artifact_root())
    parser.add_argument(
        "--dependency-lock",
        type=Path,
        default=None,
        help="complete hash-pinned runtime dependency lock for this Python lane",
    )
    args = parser.parse_args()

    dirty = _git_status()
    if dirty and not args.allow_dirty:
        raise SystemExit("release gate requires a clean git tree")

    artifact_root = validate_windows_gate_root(args.artifact_root, label="release artifact root")
    artifact_root.mkdir(parents=True, exist_ok=True)
    run_root = Path(tempfile.mkdtemp(prefix="gate-", dir=artifact_root))
    dist_dir = run_root / "dist"
    probe_result = run_root / "installed_probe.json"
    sbom_result = run_root / "sbom.cdx.json"
    stdio_probe_result = run_root / "installed_stdio_probe.json"
    dependency_lock = (
        _validated_dependency_lock(args.dependency_lock)
        if args.dependency_lock is not None
        else None
    )

    _run(
        [
            sys.executable,
            "-m",
            "compileall",
            "-q",
            "comsol_mcp",
            "src",
            "development_kit",
        ]
    )
    if not args.skip_tests:
        pytest_root = artifact_root.parent / f"rpt{uuid.uuid4().hex[:6]}"
        pytest_root.mkdir()
        try:
            _run([sys.executable, "-m", "pytest", "-q", "--basetemp", str(pytest_root)])
        finally:
            shutil.rmtree(pytest_root, ignore_errors=True)
    build_python = args.build_python.resolve() if args.build_python is not None else Path(sys.executable)
    if not build_python.is_file():
        raise SystemExit(f"build interpreter does not exist: {build_python}")
    build_command = [str(build_python), "-m", "build", "--outdir", str(dist_dir)]
    if args.build_no_isolation:
        build_command.append("--no-isolation")
    _run(build_command)
    distribution_paths = _distribution_artifacts(dist_dir)
    distributions = [_distribution_inventory(path) for path in distribution_paths]

    if not args.skip_install:
        venv_dir = run_root / "venv"
        _run([sys.executable, "-m", "venv", str(venv_dir)])
        python = _venv_python(venv_dir)
        wheels = [path for path in distribution_paths if path.suffix.casefold() == ".whl"]
        environment = _sanitized_probe_environment()
        if dependency_lock is not None:
            _run(
                [
                    str(python),
                    "-m",
                    "pip",
                    "install",
                    "--require-hashes",
                    "-r",
                    str(dependency_lock),
                ],
                cwd=run_root,
                env=environment,
            )
            _run(
                [str(python), "-m", "pip", "install", "--no-deps", str(wheels[0])],
                cwd=run_root,
                env=environment,
            )
        else:
            _run(
                [str(python), "-m", "pip", "install", str(wheels[0])],
                cwd=run_root,
                env=environment,
            )
        _run([str(python), "-m", "pip", "check"], cwd=run_root, env=environment)
        probe_workdir = run_root / "probe_workdir"
        probe_workdir.mkdir()
        _run(
            [
                str(python),
                str(ROOT / "development_kit" / "scripts" / "installed_package_probe.py"),
                "--snapshot-dir",
                str(ROOT / "development_kit" / "tests" / "snapshots"),
                "--output",
                str(probe_result),
            ],
            cwd=probe_workdir,
            env=environment,
        )
        if dependency_lock is not None:
            _run(
                [
                    str(python),
                    str(ROOT / "development_kit" / "scripts" / "sbom_probe.py"),
                    "--lock",
                    str(dependency_lock),
                    "--output",
                    str(sbom_result),
                ],
                cwd=probe_workdir,
                env=environment,
            )
        _run(
            [
                str(python),
                str(ROOT / "development_kit" / "scripts" / "installed_stdio_probe.py"),
                "--command",
                str(_venv_console_entry(venv_dir)),
                "--workdir",
                str(run_root / "stdio_probe_workdir"),
                "--output",
                str(stdio_probe_result),
            ],
            cwd=probe_workdir,
            env=environment,
        )

    installed_probe = (
        json.loads(probe_result.read_text(encoding="utf-8")) if probe_result.is_file() else None
    )
    sbom = json.loads(sbom_result.read_text(encoding="utf-8")) if sbom_result.is_file() else None
    stdio_probe = (
        json.loads(stdio_probe_result.read_text(encoding="utf-8"))
        if stdio_probe_result.is_file()
        else None
    )
    report = {
        "schema_name": "comsol_mcp.release_gate_receipt",
        "schema_version": "2.0.0",
        "environment": {
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
            "machine": platform.machine(),
            "platform": platform.platform(),
        },
        "build_interpreter": str(build_python),
        "build_isolation": not args.build_no_isolation,
        "clean_tree_required": not args.allow_dirty,
        "dirty_entry_count": len(dirty),
        "compile_passed": True,
        "tests_run": not args.skip_tests,
        "package_build_passed": True,
        "distribution_artifacts": distributions,
        "non_editable_install_run": not args.skip_install,
        "dependency_lock": (
            {
                **_dependency_lock_location(dependency_lock),
                "sha256": _sha256(dependency_lock),
                "python_lane": _lock_lane(dependency_lock),
                "require_hashes": True,
            }
            if dependency_lock is not None
            else None
        ),
        "installed_probe": installed_probe,
        "installed_stdio_probe": stdio_probe,
        "inventory_hashes": (installed_probe["release_inventories"] if installed_probe else None),
        "sbom": (
            {
                "filename": sbom_result.name,
                "sha256": _sha256(sbom_result),
                "format": sbom["bomFormat"],
                "spec_version": sbom["specVersion"],
                "component_count": len(sbom["components"]),
                "root_package_version": sbom["metadata"]["component"]["version"],
            }
            if sbom is not None
            else None
        ),
    }
    report["receipt_sha256"] = hashlib.sha256(
        json.dumps(report, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    (run_root / "release_gate_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(run_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
