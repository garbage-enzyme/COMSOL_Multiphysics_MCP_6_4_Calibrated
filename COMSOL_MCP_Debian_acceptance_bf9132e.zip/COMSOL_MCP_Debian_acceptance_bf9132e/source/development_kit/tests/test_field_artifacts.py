from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path

import numpy as np
import pytest
from src.evidence import field_artifacts as field_artifacts_module
from src.evidence.field_artifacts import write_field_evidence_artifacts
from src.evidence.field_bundle import normalize_field_evidence_request
from src.evidence.field_manifest import validate_field_evidence_manifest

from development_kit.tests.test_field_bundle import _request


def _inputs(tmp_path, *, missing: bool = False, png: bool = False):
    request = normalize_field_evidence_request(_request(paired=False, png=png))
    rows, columns = request["grid"]["shape"]
    x = np.linspace(-0.9, 0.9, columns)
    y = np.linspace(-1.4, 1.4, rows)
    xx, yy = np.meshgrid(x, y)
    electric = xx**2 + yy**2
    magnetic = np.sqrt(electric + 1.0)
    if missing:
        electric[0, 0] = np.nan
        magnetic[0, 0] = np.nan
    return request, {
        "request": request,
        "view_id": "on",
        "artifact_root": tmp_path,
        "axis_coordinates": {"x": x, "y": y},
        "quantity_grids": {
            "electric_norm": electric,
            "magnetic_norm": magnetic,
        },
        "raw_point_count": 50_000,
        "selected_point_count": 12_000,
    }


def _sha256(path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_writer_creates_compressed_arrays_and_hash_bound_manifest(tmp_path):
    request, kwargs = _inputs(tmp_path)
    result = write_field_evidence_artifacts(**kwargs)
    array_path = tmp_path / result["array_artifact"]["relative_path"]
    manifest_path = tmp_path / result["manifest_artifact"]["relative_path"]

    assert array_path.is_file() and manifest_path.is_file()
    assert result["array_artifact"]["sha256"] == _sha256(array_path)
    assert result["manifest_artifact"]["sha256"] == _sha256(manifest_path)
    assert result["missing_grid_point_count"] == 0
    assert result["visual_review_state"] == "visual_review_required"
    assert "arrays" not in result and "values" not in result

    with np.load(array_path, allow_pickle=False) as archive:
        assert set(archive.files) == {
            "coordinate_x",
            "coordinate_y",
            "quantity_electric_norm",
            "quantity_magnetic_norm",
        }
        assert archive["quantity_electric_norm"].shape == tuple(request["grid"]["shape"])
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    array_bytes = array_path.read_bytes()
    assert manifest["artifacts"]["array"] == result["array_artifact"]
    assert manifest["artifacts"]["array"]["sha256"] == hashlib.sha256(array_bytes).hexdigest()
    assert manifest["artifacts"]["array"]["byte_count"] == len(array_bytes)
    assert validate_field_evidence_manifest(manifest, request=request) == manifest


def test_png_signature_size_and_hash_come_from_one_bounded_snapshot(tmp_path, monkeypatch):
    _, kwargs = _inputs(tmp_path, png=True)
    png_path = tmp_path / "render.png"
    png_bytes = b"\x89PNG\r\n\x1a\ncomplete-image"
    png_path.write_bytes(png_bytes)
    kwargs["png_path"] = png_path
    real_read = field_artifacts_module.read_file_bytes_bounded
    calls = []

    def observed_read(path, **options):
        calls.append((Path(path), options))
        return real_read(path, **options)

    monkeypatch.setattr(
        field_artifacts_module,
        "read_file_bytes_bounded",
        observed_read,
    )

    result = write_field_evidence_artifacts(**kwargs)

    png_calls = [item for item in calls if item[0] == png_path]
    assert len(png_calls) == 1
    assert result["png_artifact"]["byte_count"] == len(png_bytes)
    assert result["png_artifact"]["sha256"] == hashlib.sha256(png_bytes).hexdigest()
    assert result["png_artifact"]["relative_path"].endswith("/field_render.png")
    assert png_path.read_bytes() == png_bytes


def test_writer_preserves_shared_missing_mask_as_partial_evidence(tmp_path):
    _, kwargs = _inputs(tmp_path, missing=True)
    result = write_field_evidence_artifacts(**kwargs)
    manifest_path = tmp_path / result["manifest_artifact"]["relative_path"]
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    assert result["missing_grid_point_count"] == 1
    assert manifest["measurement_status"] == "partial"
    assert all(item["missing_count"] == 1 for item in result["quantity_summaries"])


def test_writer_rejects_shape_infinity_and_mismatched_missing_masks(tmp_path):
    _, kwargs = _inputs(tmp_path)
    wrong_shape = deepcopy(kwargs)
    wrong_shape["quantity_grids"]["electric_norm"] = np.ones((2, 2))
    infinity = deepcopy(kwargs)
    infinity["quantity_grids"]["electric_norm"][0, 0] = np.inf
    mismatched = deepcopy(kwargs)
    mismatched["quantity_grids"]["electric_norm"][0, 0] = np.nan

    with pytest.raises(ValueError, match="must have shape"):
        write_field_evidence_artifacts(**wrong_shape)
    with pytest.raises(ValueError, match="without infinity"):
        write_field_evidence_artifacts(**infinity)
    with pytest.raises(ValueError, match="same missing-cell mask"):
        write_field_evidence_artifacts(**mismatched)


def test_writer_computes_finite_rms_for_large_finite_values_before_publication(tmp_path):
    _, kwargs = _inputs(tmp_path)
    for name in kwargs["quantity_grids"]:
        kwargs["quantity_grids"][name].fill(1.0e200)

    result = write_field_evidence_artifacts(**kwargs)

    assert all(item["rms"] == pytest.approx(1.0e200) for item in result["quantity_summaries"])
    assert list(tmp_path.rglob("field_arrays.npz"))
    assert list(tmp_path.rglob("field_manifest.json"))


def test_writer_rejects_bad_coordinates_and_expression_set(tmp_path):
    _, kwargs = _inputs(tmp_path)
    wrong_length = deepcopy(kwargs)
    wrong_length["axis_coordinates"]["x"] = np.arange(3)
    nonmonotonic = deepcopy(kwargs)
    nonmonotonic["axis_coordinates"]["x"] = nonmonotonic["axis_coordinates"]["x"][::-1]
    escaping = deepcopy(kwargs)
    escaping["axis_coordinates"]["x"] = np.linspace(-2.0, 0.9, 96)
    missing_expression = deepcopy(kwargs)
    missing_expression["quantity_grids"].pop("magnetic_norm")

    for value, message in (
        (wrong_length, "must have length"),
        (nonmonotonic, "strictly increasing"),
        (escaping, "escapes the requested bounds"),
        (missing_expression, "exactly the requested expressions"),
    ):
        with pytest.raises(ValueError, match=message):
            write_field_evidence_artifacts(**value)


def test_writer_is_immutable_and_refuses_existing_view_artifacts(tmp_path):
    _, kwargs = _inputs(tmp_path)
    write_field_evidence_artifacts(**kwargs)
    before = {
        path.relative_to(tmp_path): path.read_bytes()
        for path in tmp_path.rglob("*")
        if path.is_file()
    }

    with pytest.raises(FileExistsError, match="already exist"):
        write_field_evidence_artifacts(**kwargs)

    after = {
        path.relative_to(tmp_path): path.read_bytes()
        for path in tmp_path.rglob("*")
        if path.is_file()
    }
    assert after == before


def test_writer_cleans_owned_partial_files_when_manifest_build_fails(tmp_path):
    request, kwargs = _inputs(tmp_path)
    kwargs["raw_point_count"] = request["limits"]["max_raw_points"] + 1

    with pytest.raises(ValueError, match="raw_point_count exceeds"):
        write_field_evidence_artifacts(**kwargs)

    assert not list(tmp_path.rglob("field_arrays.npz"))
    assert not list(tmp_path.rglob("field_manifest.json"))
    assert not list(tmp_path.rglob("*.tmp"))


def test_staging_array_collision_leaves_no_partial_bundle_or_neighbor_damage(tmp_path, monkeypatch):
    _, kwargs = _inputs(tmp_path)
    neighbor = tmp_path / "unrelated.txt"
    neighbor.write_bytes(b"unrelated")
    real_publish = field_artifacts_module.publish_file_exclusive

    def competing_publish(temporary, destination):
        if destination.name == "field_arrays.npz":
            destination.write_bytes(b"competitor")
        return real_publish(temporary, destination)

    monkeypatch.setattr(
        field_artifacts_module,
        "publish_file_exclusive",
        competing_publish,
    )

    with pytest.raises(FileExistsError):
        write_field_evidence_artifacts(**kwargs)

    assert neighbor.read_bytes() == b"unrelated"
    assert not list(tmp_path.rglob("field_arrays.npz"))
    assert not list(tmp_path.rglob("field_manifest.json"))
    assert not list(tmp_path.rglob("*.tmp"))


def test_staging_manifest_collision_cleans_the_complete_owned_staging_bundle(tmp_path, monkeypatch):
    _, kwargs = _inputs(tmp_path)
    real_publish = field_artifacts_module.atomic_write_json_exclusive

    def competing_manifest(destination, value):
        destination.write_bytes(b"competitor")
        return real_publish(destination, value)

    monkeypatch.setattr(
        field_artifacts_module,
        "atomic_write_json_exclusive",
        competing_manifest,
    )

    with pytest.raises(FileExistsError):
        write_field_evidence_artifacts(**kwargs)

    assert not list(tmp_path.rglob("field_manifest.json"))
    assert not list(tmp_path.rglob("field_arrays.npz"))
    assert not list(tmp_path.rglob("*.tmp"))


def test_bundle_commit_collision_preserves_the_competing_directory(tmp_path, monkeypatch):
    request, kwargs = _inputs(tmp_path)
    destination = tmp_path / request["views"][0]["view_fingerprint"]
    real_rename = field_artifacts_module.publish_directory_exclusive

    def competing_commit(source, target):
        assert Path(target) == destination
        destination.mkdir()
        (destination / "competitor.txt").write_bytes(b"competitor")
        return real_rename(source, target)

    monkeypatch.setattr(field_artifacts_module, "publish_directory_exclusive", competing_commit)

    with pytest.raises(FileExistsError, match="already exist"):
        write_field_evidence_artifacts(**kwargs)

    assert (destination / "competitor.txt").read_bytes() == b"competitor"
    assert not list(tmp_path.glob(".*.tmp"))


def test_writer_supports_unicode_artifact_root_for_portable_development(tmp_path):
    _, kwargs = _inputs(tmp_path)
    kwargs["artifact_root"] = tmp_path / "可复用证据"

    result = write_field_evidence_artifacts(**kwargs)

    assert (kwargs["artifact_root"] / result["array_artifact"]["relative_path"]).is_file()


def test_exclusive_directory_commit_preserves_empty_competitor(tmp_path):
    from comsol_mcp.durable.io import publish_directory_exclusive
    source = tmp_path / "source"
    destination = tmp_path / "destination"
    source.mkdir()
    destination.mkdir()
    (source / "receipt").write_bytes(b"owned")
    identity = (destination.stat().st_dev, destination.stat().st_ino)
    with pytest.raises(FileExistsError):
        publish_directory_exclusive(source, destination)
    assert (destination.stat().st_dev, destination.stat().st_ino) == identity
    assert not list(destination.iterdir())
    assert (source / "receipt").read_bytes() == b"owned"
