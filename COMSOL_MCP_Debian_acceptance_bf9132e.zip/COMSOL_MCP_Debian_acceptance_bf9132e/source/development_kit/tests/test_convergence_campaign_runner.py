"""Solver-free convergence campaign composition, stopping, and resume tests."""

from __future__ import annotations

from copy import deepcopy
import os
from pathlib import Path

import pytest
from src.jobs.convergence_campaign import normalize_convergence_campaign_spec
from src.jobs.convergence_campaign_rows import read_convergence_campaign_levels
from src.jobs.convergence_campaign_runner import (
    convergence_level_directory,
    run_convergence_campaign,
)
from src.jobs.spectral_runner import run_spectral_characterization

from development_kit.tests.spectral_job_fixtures import write_fake_point_audit
from development_kit.tests.test_convergence_campaign_job import _raw_campaign


def _spec(tmp_path, *, early: bool, cap: bool = False, tolerance: float = 10e-9):
    raw = _raw_campaign(tmp_path / "sources")
    raw["convergence_policy"]["minimum_level_count"] = 2
    raw["convergence_policy"]["metrics"] = [
        {
            "metric": "peak_wavelength_m",
            "unit": "m",
            "absolute_tolerance": tolerance,
            "relative_tolerance": None,
        }
    ]
    raw["convergence_policy"]["declared_cap_reached"] = cap
    raw["stop_policy"] = {
        "allow_early_acceptance": early,
        "minimum_completed_levels": 2,
    }
    for level in raw["levels"]:
        level["spectral_job"]["measurement_configuration"]["peak_method"] = (
            "quadratic_interpolation"
        )
    return normalize_convergence_campaign_spec(raw)


def _executor(centers: list[float], *, boundary_ordinal: int | None = None):
    def execute_level(level, directory):
        child = level["spectral_job"]
        ordinal = level["ordinal"]

        def execute_point(point, artifact_dir):
            wavelength = point["wavelength"]["value"]
            if ordinal == boundary_ordinal:
                absorption = 0.1 + 0.1 * wavelength / 1e-6
            else:
                coordinate = (wavelength - centers[ordinal]) / 0.4e-6
                absorption = 0.1 + 0.8 / (1.0 + coordinate * coordinate)
            return write_fake_point_audit(artifact_dir, child, point, absorption=absorption)

        return run_spectral_characterization(
            child, directory, attempt=1, point_executor=execute_point
        )

    return execute_level


def test_declared_early_acceptance_stops_without_starting_later_level(tmp_path):
    spec = _spec(tmp_path, early=True, tolerance=20e-9)
    root = tmp_path / "campaign"
    result = run_convergence_campaign(
        spec,
        root,
        attempt=1,
        level_executor=_executor([5.0e-6, 5.001e-6, 5.002e-6]),
    )

    assert result["completed"] is True
    assert result["progress"]["scientific_disposition"] == "accepted"
    assert result["progress"]["reason_code"] == "early_acceptance_allowed"
    assert result["summary"]["completed_level_count"] == 2
    assert result["summary"]["declared_level_count"] == 3
    assert not convergence_level_directory(root, 2).exists()


def test_without_early_stop_every_declared_level_runs(tmp_path):
    spec = _spec(tmp_path, early=False, tolerance=20e-9)
    result = run_convergence_campaign(
        spec,
        tmp_path / "campaign",
        attempt=1,
        level_executor=_executor([5.0e-6, 5.001e-6, 5.002e-6]),
    )

    assert result["summary"]["completed_level_count"] == 3
    assert result["summary"]["scientific_disposition"] == "accepted"
    assert result["progress"]["evaluation"]["undeclared_configuration_started"] is False


def test_excessive_own_peak_shift_completes_with_residual(tmp_path):
    spec = _spec(tmp_path, early=False, tolerance=1e-9)
    result = run_convergence_campaign(
        spec,
        tmp_path / "campaign",
        attempt=1,
        level_executor=_executor([5.0e-6, 5.05e-6, 5.10e-6]),
    )

    assert result["completed"] is True
    assert result["summary"]["execution_state"] == "completed"
    assert result["summary"]["scientific_disposition"] == "residual"
    evaluation = result["progress"].get("evaluation")
    assert isinstance(evaluation, dict), "campaign progress omitted convergence evaluation"
    pairs = evaluation.get("pair_comparisons")
    assert isinstance(pairs, list) and pairs, "campaign evaluation omitted pair comparisons"
    comparisons = pairs[-1].get("comparisons")
    assert isinstance(comparisons, list) and comparisons, "latest pair omitted metric comparisons"
    comparison = comparisons[0]
    assert comparison["absolute_change"] > 1e-9
    assert comparison["passed"] is False


def test_fault_after_level_row_resumes_without_duplicate_spectrum(tmp_path):
    spec = _spec(tmp_path, early=False, tolerance=20e-9)
    root = tmp_path / "campaign"
    calls = []

    def execute(level, directory):
        calls.append(level["level_id"])
        return _executor([5.0e-6, 5.001e-6, 5.002e-6])(level, directory)

    def fault(phase, payload):
        if phase == "after_level_row":
            raise RuntimeError("injected campaign interruption")

    with pytest.raises(RuntimeError, match="injected"):
        run_convergence_campaign(spec, root, attempt=1, level_executor=execute, fault_hook=fault)
    assert calls == ["mesh-0"]

    result = run_convergence_campaign(spec, root, attempt=2, level_executor=execute)
    assert result["completed"] is True
    assert calls == ["mesh-0", "mesh-1", "mesh-2"]
    rows = read_convergence_campaign_levels(
        root / "convergence_levels.jsonl", spec, artifact_root=root
    )
    assert [row["level_id"] for row in rows] == ["mesh-0", "mesh-1", "mesh-2"]


def test_resume_replays_durable_level_notification_before_new_execution(tmp_path):
    spec = _spec(tmp_path, early=False, tolerance=20e-9)
    root = tmp_path / "campaign-callback-gap"
    calls = []
    notifications = []

    def execute(level, directory):
        calls.append(level["level_id"])
        return _executor([5.0e-6, 5.001e-6, 5.002e-6])(level, directory)

    def fail_notification(row):
        raise RuntimeError(f"lost notification for {row['level_id']}")

    with pytest.raises(RuntimeError, match="lost notification"):
        run_convergence_campaign(
            spec,
            root,
            attempt=1,
            level_executor=execute,
            on_durable_level=fail_notification,
        )

    result = run_convergence_campaign(
        spec,
        root,
        attempt=2,
        level_executor=execute,
        on_durable_level=lambda row: notifications.append(row["level_id"]),
    )

    assert result["completed"] is True
    assert notifications[0] == "mesh-0"
    assert notifications == ["mesh-0", "mesh-1", "mesh-2"]
    assert calls.count("mesh-0") == 1
    assert result["summary"]["completed_level_count"] == 3


def test_unresolved_level_is_scientific_completion_not_execution_failure(tmp_path):
    spec = _spec(tmp_path, early=False, cap=False, tolerance=1e-9)
    root = tmp_path / "campaign"
    result = run_convergence_campaign(
        spec,
        root,
        attempt=1,
        level_executor=_executor([5.0e-6, 5.0e-6, 5.0e-6], boundary_ordinal=0),
    )

    assert result["completed"] is True
    assert result["summary"]["completed_level_count"] == 1
    assert result["summary"]["scientific_disposition"] == "unresolved_at_declared_cap"
    assert result["summary"]["reason_code"].startswith("level_spectrum_")
    assert not convergence_level_directory(root, 1).exists()


def test_changed_stop_policy_has_a_distinct_campaign_identity(tmp_path):
    raw = _raw_campaign(tmp_path / "sources")
    raw["convergence_policy"]["declared_cap_reached"] = False
    first = normalize_convergence_campaign_spec(deepcopy(raw))
    changed_raw = deepcopy(raw)
    changed_raw["stop_policy"]["allow_early_acceptance"] = True
    changed = normalize_convergence_campaign_spec(changed_raw)
    assert changed_raw["levels"] == raw["levels"]
    assert changed_raw["convergence_policy"] == raw["convergence_policy"]
    assert changed["spec_fingerprint"] != first["spec_fingerprint"]


@pytest.mark.skipif(os.name != "nt", reason="Windows legacy path budget")
def test_level_directory_stays_inside_the_windows_legacy_path_budget():
    root = Path("D:/comsol_runtime/jobs") / ("job-" + "a" * 32)
    directory = convergence_level_directory(root, 99)
    suffix = (
        "point_artifacts/"
        + "b" * 64
        + "/"
        + "b" * 64
        + "/1784320847805-afba0aeb/manifest.json.tmp-33728"
    )
    assert directory.name == "l99"
    assert len(str(directory / suffix)) <= 259


def test_transient_append_failure_quarantines_level_and_notifies_fault_hook(tmp_path, monkeypatch):
    import src.jobs.convergence_campaign_runner as runner_module

    spec = _spec(tmp_path, early=False, tolerance=20e-9)
    root = tmp_path / "campaign-quarantine"
    calls = []
    real_append = runner_module.append_convergence_campaign_level
    events = []

    def execute(level, directory):
        calls.append(level["level_id"])
        return _executor([5.0e-6, 5.001e-6, 5.002e-6])(level, directory)

    def fault(phase, payload):
        events.append((phase, payload))

    def gap_append(*_args, **_kwargs):
        raise RuntimeError("injected row gap")

    monkeypatch.setattr(runner_module, "append_convergence_campaign_level", gap_append)
    with pytest.raises(RuntimeError, match="row gap"):
        run_convergence_campaign(spec, root, attempt=1, level_executor=execute)
    assert calls == ["mesh-0"]

    invocations = []

    def transient_oserror(*_args, **_kwargs):
        invocations.append(1)
        if len(invocations) == 1:
            raise OSError("transient windows file lock")
        return real_append(*_args, **_kwargs)

    monkeypatch.setattr(runner_module, "append_convergence_campaign_level", transient_oserror)
    result = run_convergence_campaign(
        spec, root, attempt=2, level_executor=execute, fault_hook=fault
    )
    assert result["completed"] is True
    quarantined = [payload for phase, payload in events if phase == "level_row_quarantined"]
    assert len(quarantined) == 1
    assert quarantined[0]["level_id"] == "mesh-0"
    assert quarantined[0]["error"].startswith("OSError:")
    assert calls.count("mesh-0") == 2

    monkeypatch.setattr(runner_module, "append_convergence_campaign_level", real_append)
    resumed = run_convergence_campaign(spec, root, attempt=3, level_executor=execute)
    assert resumed["completed"] is True
    assert calls.count("mesh-0") == 2


def test_truthy_non_true_level_completion_is_accepted(tmp_path):
    spec = _spec(tmp_path, early=False, tolerance=20e-9)
    inner = _executor([5.0e-6, 5.001e-6, 5.002e-6])

    def execute_level(level, directory):
        result = inner(level, directory)
        # Truthy but not the True singleton: equivalent completion evidence
        # (for example numpy.bool_) must not be misread as an incomplete level.
        result["completed"] = 1
        return result

    result = run_convergence_campaign(
        spec,
        tmp_path / "campaign",
        attempt=1,
        level_executor=execute_level,
    )

    assert result["completed"] is True
    assert result["summary"]["completed_level_count"] == 3
