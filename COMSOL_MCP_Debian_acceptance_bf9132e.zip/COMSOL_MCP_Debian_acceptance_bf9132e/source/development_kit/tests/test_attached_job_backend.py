"""Solver-free contracts for immutable durable attached execution targets."""

from __future__ import annotations

import csv
import hashlib
import os
import shutil
import subprocess
import sys
import types
from copy import deepcopy
from dataclasses import replace
from pathlib import Path

import pytest
import src.jobs.worker as production_worker
from src.jobs import cancel_worker
from src.jobs.attached_backend import (
    normalize_attached_execution_backend,
    normalize_attached_execution_request,
)
from src.jobs.attached_runtime import (
    normalize_attached_execution_target,
    verify_attached_model_inventory,
    verify_attached_model_revision,
    verify_attached_process_preservation,
)
from src.jobs.manager import JobLaunchError, JobManager, validate_staged_sweep_spec
from src.jobs.store import JobStore, process_identity
from src.shared_session.identity import normalize_attached_server_identity
from src.shared_session.locking import (
    build_shared_model_revision,
    normalize_shared_model_identity,
)
from src.tools.jobs import _submit_job

from development_kit.tests.conftest import _create_ascii_temp_dir


@pytest.fixture
def ascii_job_root():
    root = _create_ascii_temp_dir()
    try:
        yield root
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _backend() -> dict:
    server = normalize_attached_server_identity(
        {
            "endpoint": {"host": "127.0.0.1", "port": 2036},
            "server_pid": 4200,
            "server_process_create_time": 1234.5,
            "server_command_signature": "a" * 64,
            "listener_bind_scope": "wildcard",
            "listener_observed_at_epoch": 2345.6,
        }
    )
    model = normalize_shared_model_identity(
        {
            "tag": "Model1",
            "label": "working.mph",
            "file_path": "D:/models/working.mph",
            "unsaved": False,
        }
    )
    revision = build_shared_model_revision(
        model,
        sequence=0,
        structural_readback={
            "components": ["comp1"],
            "studies": ["std1"],
            "datasets": [],
        },
        state_readback={"parameters": {"gap": "10[nm]"}},
    )
    return {
        "kind": "attached_shared_server",
        "user_confirmed_automation_exclusive": True,
        "source_model_lock_sha256": "b" * 64,
        "attached_server": server.to_dict(),
        "model": model.to_dict(),
        "expected_revision": revision.to_dict(),
    }


def test_attached_backend_is_deterministic_idempotent_and_non_owned():
    first = normalize_attached_execution_backend(_backend())
    second = normalize_attached_execution_backend(deepcopy(first))

    assert first == second
    assert first["attached_server"]["ownership"] == "external_user_owned"
    assert first["attached_server"]["listener_bind_scope"] == "wildcard"
    assert first["model"]["tag"] == "Model1"
    assert len(first["backend_identity_sha256"]) == 64


def test_attached_target_nested_snapshots_are_immutable():
    target = normalize_attached_execution_target(_backend())

    with pytest.raises(TypeError, match="frozen"):
        target.backend["model"]["tag"] = "changed"
    with pytest.raises(TypeError, match="frozen"):
        target.expected_revision["sequence"] = 9


@pytest.mark.parametrize(
    "mutation",
    [
        lambda value: value.update(user_confirmed_automation_exclusive=False),
        lambda value: value.update(kind="standalone_owned"),
        lambda value: value.update(source_model_lock_sha256="short"),
        lambda value: value.update(secret="not-allowed"),
        lambda value: value["attached_server"].update(ownership="owned"),
        lambda value: value["attached_server"].update(identity_sha256="0" * 64),
        lambda value: value["model"].update(identity_sha256="0" * 64),
        lambda value: value["expected_revision"].update(model_identity_sha256="0" * 64),
        lambda value: value["expected_revision"].update(revision_sha256="0" * 64),
    ],
)
def test_attached_backend_rejects_ambiguous_or_tampered_identity(mutation):
    raw = _backend()
    mutation(raw)

    with pytest.raises(ValueError):
        normalize_attached_execution_backend(raw)


def test_attached_backend_rejects_tampered_aggregate_identity():
    normalized = normalize_attached_execution_backend(_backend())
    normalized["backend_identity_sha256"] = "0" * 64

    with pytest.raises(ValueError, match="backend identity SHA-256"):
        normalize_attached_execution_backend(normalized)


def test_public_attached_request_is_short_strict_and_hash_bound():
    request = normalize_attached_execution_request(
        {
            "kind": "attached_shared_server",
            "expected_lock_sha256": "A" * 64,
            "expected_revision_sha256": "B" * 64,
            "user_confirmed_automation_exclusive": True,
        }
    )

    assert request == {
        "kind": "attached_shared_server",
        "expected_lock_sha256": "a" * 64,
        "expected_revision_sha256": "b" * 64,
        "user_confirmed_automation_exclusive": True,
    }
    with pytest.raises(ValueError, match="unknown"):
        normalize_attached_execution_request(_backend())


def test_attached_backend_contract_import_does_not_import_mph():
    code = """
import sys
from development_kit.tests.test_attached_job_backend import _backend
from src.jobs.attached_backend import normalize_attached_execution_backend
assert 'mph' not in sys.modules
assert normalize_attached_execution_backend(_backend())['kind'] == 'attached_shared_server'
assert 'mph' not in sys.modules
"""
    completed = subprocess.run(
        [sys.executable, "-c", code],
        cwd=Path(__file__).parents[2],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )

    assert completed.returncode == 0, completed.stderr


def test_staged_sweep_fingerprint_binds_normalized_attached_backend(tmp_path):
    source = tmp_path / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    raw = {
        "job_type": "staged_sweep",
        "source_model_path": str(source),
        "parameter_name": "gap",
        "parameter_values": [10.0, 11.0],
        "expressions": ["A"],
        "execution_backend": _backend(),
    }
    spec = validate_staged_sweep_spec(raw)

    assert spec["execution_backend"]["kind"] == "attached_shared_server"
    assert len(spec["execution_backend"]["backend_identity_sha256"]) == 64
    assert spec["spec_fingerprint"] == validate_staged_sweep_spec(deepcopy(raw))["spec_fingerprint"]
    changed = deepcopy(raw)
    changed["execution_backend"]["source_model_lock_sha256"] = "c" * 64
    changed_spec = validate_staged_sweep_spec(changed)
    assert (
        changed_spec["execution_backend"]["backend_identity_sha256"]
        != spec["execution_backend"]["backend_identity_sha256"]
    )
    assert changed_spec["spec_fingerprint"] != spec["spec_fingerprint"]


def test_attached_runtime_restores_exact_target_and_accepts_unchanged_readback():
    target = normalize_attached_execution_target(_backend())

    selected = verify_attached_model_inventory(
        target,
        [
            target.model.to_dict(),
            {
                "tag": "Other",
                "label": "other.mph",
                "file_path": "D:/models/other.mph",
                "unsaved": False,
            },
        ],
    )
    revision = verify_attached_model_revision(
        target,
        structural_readback={
            "components": ["comp1"],
            "studies": ["std1"],
            "datasets": [],
        },
        state_readback={"parameters": {"gap": "10[nm]"}},
    )

    assert selected == target.model.to_dict()
    assert revision == target.expected_revision
    assert target.server.listener_bind_scope == "wildcard"


@pytest.mark.parametrize(
    "inventory",
    [
        [],
        [
            {
                "tag": "Model1",
                "label": "different.mph",
                "file_path": "D:/models/different.mph",
                "unsaved": False,
            }
        ],
        [
            {
                "tag": "Model1",
                "label": "working.mph",
                "file_path": "D:/models/working.mph",
                "unsaved": False,
            },
            {
                "tag": "Model1",
                "label": "working-copy.mph",
                "file_path": "D:/models/working-copy.mph",
                "unsaved": False,
            },
        ],
    ],
)
def test_attached_runtime_rejects_missing_changed_or_duplicate_model(inventory):
    target = normalize_attached_execution_target(_backend())

    with pytest.raises(ValueError, match="server model|matching"):
        verify_attached_model_inventory(target, inventory)


def test_attached_runtime_rejects_external_revision_change():
    target = normalize_attached_execution_target(_backend())

    with pytest.raises(ValueError, match="revision changed.*readback_sha256"):
        verify_attached_model_revision(
            target,
            structural_readback={
                "components": ["comp1"],
                "studies": ["std1"],
                "datasets": [],
            },
            state_readback={"parameters": {"gap": "11[nm]"}},
        )


@pytest.mark.parametrize("sequence", [True, "0", 0.5])
def test_attached_revision_verifier_rejects_coercive_sequence_values(sequence):
    target = normalize_attached_execution_target(_backend())
    target = replace(
        target,
        expected_revision={**target.expected_revision, "sequence": sequence},
    )

    with pytest.raises(ValueError, match="expected_revision.sequence must be an integer"):
        verify_attached_model_revision(
            target,
            structural_readback={
                "components": ["comp1"],
                "studies": ["std1"],
                "datasets": [],
            },
            state_readback={"parameters": {"gap": "10[nm]"}},
        )


@pytest.mark.parametrize("projection_gap", [False, True])
def test_attached_production_worker_uses_existing_model_and_never_clears_server(
    ascii_job_root, monkeypatch, projection_gap
):
    import src.tools.ownership as ownership_module
    import src.tools.workflow as workflow_module

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0, 11.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    store = JobStore(ascii_job_root / "runtime" / "jobs")
    identity = process_identity(os.getpid())
    job_id = store.create(
        spec,
        {
            "schema_version": "1",
            "status": "submitted",
            "attempt": 1,
            "worker_pid": identity["pid"],
            "worker_process_create_time": identity["process_create_time"],
            "worker_command_signature": identity["command_signature"],
            "progress": {"completed": 0, "total": 2},
        },
    )
    events = []
    runner_save_copy = []
    projection_gap_injected = False

    class FakeOwnership:
        def __init__(self, *_args, **_kwargs):
            pass

        def acquire_attached(self, server):
            events.append(("acquire_attached", server.identity_sha256))
            return {
                "success": True,
                "lease": {"acquisition_id": "c" * 32},
            }

        def preflight(self, **_kwargs):
            raise AssertionError("attached worker must not run standalone preflight")

        def acquire(self, **_kwargs):
            raise AssertionError("attached worker must not acquire owned resources")

        def heartbeat(self, **kwargs):
            events.append(("heartbeat", kwargs))
            return True

        def release(self):
            events.append(("release", None))
            return {"success": True, "released": True}

    class FakeJava:
        def tag(self):
            return "Model1"

        def label(self):
            return "working.mph"

        def getFilePath(self):
            return "D:/models/working.mph"

    class FakeModel:
        java = FakeJava()

        def components(self):
            return ["comp1"]

        def studies(self):
            return ["std1"]

        def datasets(self):
            return []

        def parameters(self):
            return {"gap": "10[nm]"}

    class FakeClient:
        def __init__(self, **kwargs):
            events.append(("client", kwargs))
            self.port = kwargs["port"]
            self.model = FakeModel()

        def models(self):
            return [self.model]

        def clear(self):
            raise AssertionError("attached worker must never clear server models")

        def disconnect(self):
            events.append(("disconnect", None))

    def fake_runner(_model, _parameter, values, _expressions, **kwargs):
        nonlocal projection_gap_injected
        runner_save_copy.append(kwargs["save_model_copy"])
        output = Path(kwargs["csv_path"])
        existing = []
        if output.is_file() and output.stat().st_size:
            with output.open(newline="", encoding="utf-8") as handle:
                existing = list(csv.DictReader(handle))
        completed = {row["parameter_value"] for row in existing if row.get("status") == "ok"}
        added = 0
        limit = kwargs.get("max_new_points")
        for value in values:
            token = str(value)
            if token in completed or (limit is not None and added >= limit):
                continue
            before_point_hook = kwargs.get("before_point_hook")
            if before_point_hook is not None:
                decision = before_point_hook(
                    {
                        "stage": "pre_solve",
                        "point_id": f"point:{token}",
                        "config_id": spec["spec_fingerprint"],
                    }
                )
                if decision.get("action") != "start_point":
                    return {
                        "success": True,
                        "stop_reason": "before_point_checkpoint_no_start",
                    }
            row = {
                "config_id": spec["spec_fingerprint"],
                "parameter_value": token,
                "status": "ok",
            }
            with output.open("a", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(row))
                if handle.tell() == 0:
                    writer.writeheader()
                writer.writerow(row)
                handle.flush()
                os.fsync(handle.fileno())
            if projection_gap and not projection_gap_injected:
                projection_gap_injected = True
                raise RuntimeError("injected row-to-projection gap")
            kwargs["on_durable_row"](row)
            completed.add(token)
            added += 1
        return {"success": True, "stop_reason": None}

    monkeypatch.setattr(ownership_module, "SolverOwnership", FakeOwnership)
    monkeypatch.setattr(workflow_module, "run_staged_parametric_sweep", fake_runner)
    monkeypatch.setitem(sys.modules, "mph", types.SimpleNamespace(Client=FakeClient))
    monkeypatch.setattr(
        production_worker,
        "_collect_attached_process_preservation",
        lambda _target: {
            "success": True,
            "state": "attached_external_resources_preserved",
            "listener_active": True,
            "desktop_ready": True,
        },
    )

    code = production_worker.run(str(store.root), job_id)

    if projection_gap:
        failed = store.read_state(job_id)
        assert code == 1
        assert failed["status"] == "failed"
        assert failed["progress"] == {"completed": 0, "total": 2}
        assert failed["attached_execution"]["current_revision"]["sequence"] == 0
        store.update_state(
            job_id,
            "starting",
            patch={
                "attempt": 2,
                "worker_pid": identity["pid"],
                "worker_process_create_time": identity["process_create_time"],
                "worker_command_signature": identity["command_signature"],
                "last_error": None,
            },
            event="test_resume",
        )
        code = production_worker.run(str(store.root), job_id)

    state = store.read_state(job_id)
    assert code == 0
    assert state["status"] == "completed"
    assert state["progress"] == {"completed": 2, "total": 2}
    assert state["attached_execution"]["resource_ownership"] == ("external_user_owned_server")
    assert state["attached_cleanup"]["success"] is True
    assert state["attached_cleanup"]["model_identity_preserved"] is True
    assert state["attached_cleanup"]["model_clear_attempted"] is False
    assert state["attached_cleanup"]["external_server_termination_attempted"] is False
    assert state["attached_execution"]["current_revision"]["sequence"] == 2
    assert runner_save_copy == ([True, True, True] if projection_gap else [True, True])
    assert events[0][0] == "acquire_attached"
    assert ("client", {"host": "127.0.0.1", "port": 2036}) in events
    assert events[-2:] == [("disconnect", None), ("release", None)]
    assert hashlib.sha256(source.read_bytes()).hexdigest() == spec["source_model_sha256"]


def _attached_process_snapshot(
    *,
    server_pid=4200,
    server_created=1234.5,
    observed=3000.0,
):
    return {
        "inventory_complete": True,
        "observed_at_epoch": observed,
        "processes": [
            {
                "pid": 4100,
                "parent_pid": 0,
                "kind": "comsol_desktop",
                "create_time": 1200.0,
                "command_signature": "d" * 64,
                "file_version": "6.4.0.293",
                "window_count": 1,
                "responding": True,
            },
            {
                "pid": server_pid,
                "parent_pid": 0,
                "kind": "comsol_server",
                "create_time": server_created,
                "command_signature": "a" * 64,
                "file_version": "6.4.0.293",
                "window_count": 0,
                "responding": True,
            },
        ],
        "listeners": [{"host": "0.0.0.0", "port": 2036, "pid": server_pid}],
    }


def _attached_process_provider(**kwargs):
    observed = 3000.0

    def provider():
        nonlocal observed
        snapshot = _attached_process_snapshot(observed=observed, **kwargs)
        observed += 1.0
        return snapshot

    return provider


def test_attached_process_preservation_requires_same_server_listener_and_desktop():
    target = normalize_attached_execution_target(_backend())

    preserved = verify_attached_process_preservation(
        target,
        first_probe=_attached_process_snapshot(),
        second_probe=_attached_process_snapshot(observed=3001.0),
    )
    changed = verify_attached_process_preservation(
        target,
        first_probe=_attached_process_snapshot(server_pid=4300),
        second_probe=_attached_process_snapshot(server_pid=4300, observed=3001.0),
    )

    assert preserved["success"] is True
    assert preserved["state"] == "attached_external_resources_preserved"
    assert preserved["listener_active"] is True
    assert preserved["desktop_ready"] is True
    assert changed["success"] is False
    assert changed["state"] == "attached_server_identity_changed_after_detach"


def test_attached_model_selection_accepts_last_durable_revision_on_resume():
    target = normalize_attached_execution_target(_backend())
    expected = build_shared_model_revision(
        target.model,
        sequence=1,
        structural_readback={
            "components": ["comp1"],
            "studies": ["std1"],
            "datasets": [],
        },
        state_readback={"parameters": {"gap": "11[nm]"}},
    ).to_dict()

    class Java:
        def tag(self):
            return "Model1"

        def label(self):
            return "working.mph"

        def getFilePath(self):
            return "D:/models/working.mph"

    class Model:
        java = Java()

        def components(self):
            return ["comp1"]

        def studies(self):
            return ["std1"]

        def datasets(self):
            return []

        def parameters(self):
            return {"gap": "11[nm]"}

    class Client:
        def models(self):
            return [Model()]

    selected = production_worker._select_attached_model(Client(), target, expected)

    assert selected.java.tag() == "Model1"


@pytest.mark.parametrize(
    ("changed_part", "components", "gap"),
    [
        ("stale", ["comp1"], "10[nm]"),
        ("advanced", ["comp1"], "12[nm]"),
        ("structural", ["comp1", "comp2"], "11[nm]"),
    ],
)
def test_attached_resume_rejects_stale_advanced_or_structural_revision(
    changed_part, components, gap
):
    target = normalize_attached_execution_target(_backend())
    expected = build_shared_model_revision(
        target.model,
        sequence=1,
        structural_readback={
            "components": ["comp1"],
            "studies": ["std1"],
            "datasets": [],
        },
        state_readback={"parameters": {"gap": "11[nm]"}},
    ).to_dict()

    class Java:
        def tag(self):
            return "Model1"

        def label(self):
            return "working.mph"

        def getFilePath(self):
            return "D:/models/working.mph"

    class Model:
        java = Java()

        def components(self):
            return components

        def studies(self):
            return ["std1"]

        def datasets(self):
            return []

        def parameters(self):
            return {"gap": gap}

    class Client:
        def models(self):
            return [Model()]

    with pytest.raises(ValueError, match="attached model revision changed"):
        production_worker._select_attached_model(Client(), target, expected)


def test_attached_resume_skips_unrelated_local_owned_lease_recovery(ascii_job_root, monkeypatch):
    import src.tools.ownership as ownership_module

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    store = JobStore(ascii_job_root / "resume-runtime" / "jobs")
    job_id = store.create(
        spec,
        {
            "schema_version": "2",
            "status": "interrupted",
            "attempt": 1,
            "worker_pid": None,
            "worker_process_create_time": None,
            "worker_command_signature": None,
            "progress": {"completed": 0, "total": 1},
        },
    )
    manager = JobManager(store.root, reconcile_on_start=False)
    monkeypatch.setattr(manager, "_run_preflight", lambda _spec: {"ready": True})
    monkeypatch.setattr(manager, "_launch_worker", lambda *_args: process_identity(os.getpid()))
    monkeypatch.setattr(
        ownership_module,
        "SolverOwnership",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(
            AssertionError("attached resume inspected an unrelated local owned lease")
        ),
    )

    resumed = manager.resume(job_id)

    assert resumed["success"] is True
    assert resumed["attempt"] == 2


def test_attached_cleanup_retains_release_failure_and_preservation_evidence(monkeypatch):
    import src.shared_session.lifecycle as lifecycle_module

    target = normalize_attached_execution_target(_backend())
    disconnected = []

    class Client:
        def disconnect(self):
            disconnected.append(True)

    class Ownership:
        lease_path = None

        def release(self):
            raise RuntimeError("injected attached release failure")

    monkeypatch.setattr(
        lifecycle_module,
        "_default_model_inventory_reader",
        lambda _client: [
            {
                "tag": "Model1",
                "label": "working.mph",
                "file_path": "D:/models/working.mph",
                "unsaved": False,
            }
        ],
    )
    monkeypatch.setattr(
        production_worker,
        "_collect_attached_process_preservation",
        lambda _target: {"success": True, "state": "preserved"},
    )

    cleanup = production_worker._cleanup_attached_execution(
        client=Client(),
        ownership=Ownership(),
        lease_acquired=True,
        target=target,
    )

    assert disconnected == [True]
    assert cleanup["success"] is False
    assert cleanup["lease_absent"] is False
    assert cleanup["lease_release"] == {
        "success": False,
        "released": False,
        "error": "RuntimeError: injected attached release failure",
    }
    assert cleanup["external_resources"] == {"success": True, "state": "preserved"}


def test_attached_manager_preflight_is_process_only_and_binds_server_identity(
    ascii_job_root, monkeypatch
):
    import src.shared_session.process_probe as process_probe

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    monkeypatch.setattr(
        process_probe,
        "collect_shared_preflight_snapshot",
        _attached_process_provider(),
    )

    store = JobStore(ascii_job_root / "runtime" / "jobs")
    manager = JobManager(
        store.root,
        reconcile_on_start=False,
    )
    preflight = manager._run_preflight(spec)

    assert preflight["success"] is True
    assert preflight["ready"] is True
    assert preflight["state"] == "ready_for_attached_worker"
    assert (
        preflight["server_identity_sha256"]
        == spec["execution_backend"]["attached_server"]["identity_sha256"]
    )
    assert preflight["mph_imported"] is False
    assert preflight["client_constructed"] is False


def test_attached_manager_preflight_rejects_changed_server_process(ascii_job_root, monkeypatch):
    import src.shared_session.process_probe as process_probe

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    monkeypatch.setattr(
        process_probe,
        "collect_shared_preflight_snapshot",
        _attached_process_provider(server_pid=4300),
    )
    manager = JobManager(
        ascii_job_root / "runtime" / "jobs",
        reconcile_on_start=False,
    )

    preflight = manager._run_preflight(spec)

    assert preflight["success"] is False
    assert preflight["ready"] is False
    assert preflight["state"] == "attached_server_identity_changed"


def test_public_job_submit_resolves_live_handoff_before_manager_submit(
    ascii_job_root,
):
    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    calls = []

    class FakeSessionManager:
        def prepare_attached_job_handoff(self, **kwargs):
            calls.append(("handoff", kwargs))
            return {
                "success": True,
                "state": "attached_job_handoff_ready",
                "execution_backend": normalize_attached_execution_backend(_backend()),
                "detach": {
                    "state": "detached",
                    "external_resources_preserved": True,
                },
            }

    class FakeJobManager:
        def submit(self, spec):
            calls.append(("submit", spec))
            return {"success": True, "job_id": "job-attached", "status": "starting"}

    result = _submit_job(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": {
                "kind": "attached_shared_server",
                "expected_lock_sha256": "a" * 64,
                "expected_revision_sha256": "b" * 64,
                "user_confirmed_automation_exclusive": True,
            },
        },
        profile_name="wave_optics",
        shared_enabled=True,
        manager=FakeJobManager(),
        session_manager=FakeSessionManager(),
    )

    assert result["success"] is True
    assert result["job_id"] == "job-attached"
    assert result["attached_handoff"]["external_resources_preserved"] is True
    assert calls[0][0] == "handoff"
    assert calls[0][1]["source_model_path"] == str(source.resolve())
    assert calls[1][0] == "submit"
    assert (
        calls[1][1]["execution_backend"]["backend_identity_sha256"]
        == (result["attached_handoff"]["backend_identity_sha256"])
    )


def test_public_job_submit_does_not_launch_after_handoff_failure(ascii_job_root):
    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")

    class RejectingSessionManager:
        def prepare_attached_job_handoff(self, **_kwargs):
            return {"success": False, "state": "handoff_precondition_failed"}

    class UnexpectedJobManager:
        def submit(self, _spec):
            raise AssertionError("failed handoff must not submit a worker")

    result = _submit_job(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": {
                "kind": "attached_shared_server",
                "expected_lock_sha256": "a" * 64,
                "expected_revision_sha256": "b" * 64,
                "user_confirmed_automation_exclusive": True,
            },
        },
        profile_name="wave_optics",
        shared_enabled=True,
        manager=UnexpectedJobManager(),
        session_manager=RejectingSessionManager(),
    )

    assert result == {
        "success": False,
        "state": "attached_handoff_failed",
        "attached_handoff": {
            "state": "handoff_precondition_failed",
            "backend_identity_sha256": None,
            "server_identity_sha256": None,
            "model_identity_sha256": None,
            "external_resources_preserved": None,
            "detach_state": None,
        },
    }


def test_public_job_submit_recovers_handoff_after_prelaunch_failure(ascii_job_root):
    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    backend = normalize_attached_execution_backend(_backend())
    recovered = []

    class RecoveringSessionManager:
        def prepare_attached_job_handoff(self, **_kwargs):
            return {
                "success": True,
                "state": "attached_job_handoff_ready",
                "execution_backend": backend,
                "detach": {
                    "state": "detached",
                    "external_resources_preserved": True,
                },
            }

        def recover_attached_job_handoff(
            self,
            execution_backend,
            *,
            profile,
            feature_enabled,
        ):
            recovered.append((execution_backend, profile, feature_enabled))
            return {
                "success": True,
                "state": "attached_handoff_reclaimed_pending_lock",
            }

    class PreflightFailingJobManager:
        def submit(self, _spec):
            raise RuntimeError("preflight refused")

    result = _submit_job(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": {
                "kind": "attached_shared_server",
                "expected_lock_sha256": "a" * 64,
                "expected_revision_sha256": "b" * 64,
                "user_confirmed_automation_exclusive": True,
            },
        },
        profile_name="wave_optics",
        shared_enabled=True,
        manager=PreflightFailingJobManager(),
        session_manager=RecoveringSessionManager(),
    )

    assert result["success"] is False
    assert result["state"] == "job_submit_failed_after_attached_handoff"
    assert result["handoff_recovery"]["success"] is True
    assert recovered == [(backend, "wave_optics", True)]


def test_public_job_submit_rejects_invalid_handoff_recovery_result(ascii_job_root):
    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    backend = normalize_attached_execution_backend(_backend())

    class InvalidRecoverySessionManager:
        def prepare_attached_job_handoff(self, **_kwargs):
            return {
                "success": True,
                "state": "attached_job_handoff_ready",
                "execution_backend": backend,
                "detach": {"state": "detached", "external_resources_preserved": True},
            }

        def recover_attached_job_handoff(self, *_args, **_kwargs):
            return None

    class PreflightFailingJobManager:
        def submit(self, _spec):
            raise RuntimeError("preflight refused")

    result = _submit_job(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": {
                "kind": "attached_shared_server",
                "expected_lock_sha256": "a" * 64,
                "expected_revision_sha256": "b" * 64,
                "user_confirmed_automation_exclusive": True,
            },
        },
        profile_name="wave_optics",
        shared_enabled=True,
        manager=PreflightFailingJobManager(),
        session_manager=InvalidRecoverySessionManager(),
    )

    assert result["success"] is False
    assert result["handoff_recovery"] == {
        "success": False,
        "state": "attached_handoff_recovery_returned_invalid_result",
    }


def test_public_job_submit_reconciles_durable_launch_failure_without_reclaim(
    ascii_job_root,
):
    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    backend = normalize_attached_execution_backend(_backend())

    class UnreachableRecoverySessionManager:
        def prepare_attached_job_handoff(self, **_kwargs):
            return {
                "success": True,
                "state": "attached_job_handoff_ready",
                "execution_backend": backend,
                "detach": {
                    "state": "detached",
                    "external_resources_preserved": True,
                },
            }

        def recover_attached_job_handoff(
            self,
            _execution_backend,
            *,
            profile,
            feature_enabled,
        ):
            raise AssertionError("durable launch failures must not reclaim the session")

    class DurableFailingJobManager:
        def submit(self, _spec):
            raise JobLaunchError("job-durable", RuntimeError("launch refused"))

    result = _submit_job(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": {
                "kind": "attached_shared_server",
                "expected_lock_sha256": "a" * 64,
                "expected_revision_sha256": "b" * 64,
                "user_confirmed_automation_exclusive": True,
            },
        },
        profile_name="wave_optics",
        shared_enabled=True,
        manager=DurableFailingJobManager(),
        session_manager=UnreachableRecoverySessionManager(),
    )

    assert result["success"] is False
    assert result["handoff_recovery"] == {
        "success": False,
        "state": "durable_job_requires_reconciliation",
        "job_id": "job-durable",
        "action": "inspect_job_status_before_reclaiming_attached_session",
    }


def test_attached_cancel_cleanup_requires_external_server_preservation(ascii_job_root, monkeypatch):
    import src.shared_session.process_probe as process_probe

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    store = JobStore(ascii_job_root / "runtime" / "jobs")
    state = {
        "schema_version": "1",
        "status": "cancelling",
        "attempt": 1,
        "progress": {"completed": 0, "total": 1},
        "attached_cleanup": {
            "success": True,
            "model_identity_preserved": True,
        },
    }
    job_id = store.create(spec, state)
    monkeypatch.setattr(
        process_probe,
        "collect_shared_preflight_snapshot",
        _attached_process_provider(),
    )

    preserved = cancel_worker._verify_solver_cleanup(store, job_id)
    monkeypatch.setattr(
        process_probe,
        "collect_shared_preflight_snapshot",
        _attached_process_provider(server_pid=4300),
    )
    changed = cancel_worker._verify_solver_cleanup(store, job_id)

    assert preserved["ok"] is True
    assert preserved["lease_state"] == "absent"
    assert preserved["attached_external_resources"]["success"] is True
    assert preserved["attached_external_resources"]["model_preservation_status"] == (
        "verified_before_cooperative_disconnect"
    )
    assert (
        preserved["attached_external_resources"]["external_server_termination_attempted"] is False
    )
    assert changed["ok"] is False
    assert changed["attached_external_resources"]["success"] is False


def test_attached_cancel_cleanup_requires_recorded_model_preservation(ascii_job_root, monkeypatch):
    import src.shared_session.process_probe as process_probe

    source = ascii_job_root / "immutable-source.mph"
    source.write_bytes(b"immutable source")
    spec = validate_staged_sweep_spec(
        {
            "job_type": "staged_sweep",
            "source_model_path": str(source),
            "parameter_name": "gap",
            "parameter_values": [10.0],
            "expressions": ["A"],
            "execution_backend": _backend(),
        }
    )
    store = JobStore(ascii_job_root / "runtime" / "jobs")
    job_id = store.create(
        spec,
        {
            "schema_version": "1",
            "status": "cancelling",
            "attempt": 1,
            "progress": {"completed": 0, "total": 1},
            "attached_cleanup": {
                "success": True,
                "model_identity_preserved": False,
            },
        },
    )
    monkeypatch.setattr(
        process_probe,
        "collect_shared_preflight_snapshot",
        _attached_process_provider(),
    )

    result = cancel_worker._verify_solver_cleanup(store, job_id)

    assert result["ok"] is False
    assert result["attached_external_resources"]["success"] is True
    assert result["attached_external_resources"]["model_preservation_status"] == (
        "not_automatically_rechecked_after_worker_exit"
    )
