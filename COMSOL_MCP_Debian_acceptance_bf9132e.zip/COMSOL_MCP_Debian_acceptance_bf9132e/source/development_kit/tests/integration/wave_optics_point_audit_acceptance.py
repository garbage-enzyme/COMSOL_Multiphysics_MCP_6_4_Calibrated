"""Controlled COMSOL 6.4 matrix for the one-point Wave Optics evidence audit."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import traceback
from pathlib import Path

import mph

ROOT = Path(__file__).parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.evidence.real_fixture import controlled_fixture_from_environment
from src.tools.ownership import SolverOwnership
from src.tools.wave_optics_audit import run_wave_optics_point_audit

from development_kit.tests.integration.acceptance_resources import required_acceptance_cores


def _require(condition: object, detail: object) -> None:
    if not condition:
        raise RuntimeError(str(detail))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _first_tag(container, preferred):
    tags = [str(value) for value in list(container.tags())]
    if not tags:
        raise ValueError(f"empty clientapi container for {preferred}")
    if preferred not in tags:
        raise ValueError(f"required clientapi tag is absent: {preferred}")
    return preferred


def _study_step(study):
    tags = [str(value) for value in list(study.feature().tags())]
    if not tags:
        raise ValueError("study contains no steps")
    inspection_errors = []
    for tag in tags:
        feature = study.feature().get(tag)
        try:
            if "wavelength" in str(feature.getType()).casefold():
                return tag
        except Exception as exc:
            inspection_errors.append(f"{tag}:{type(exc).__name__}")
    suffix = f"; inspection errors: {inspection_errors}" if inspection_errors else ""
    raise ValueError(f"study contains no identifiable Wavelength step{suffix}")


def _bound_source_sha256(case: dict) -> str:
    expected = case.get("expected_source_sha256")
    if not isinstance(expected, str) or len(expected) != 64:
        raise ValueError("controlled fixture expected source SHA-256 is missing")
    if _sha256(case["source"]) != expected:
        raise AssertionError("controlled fixture hash differs from caller-bound identity")
    return expected


def main() -> None:
    default_artifact_dir = (
        Path(os.environ.get("COMSOL_MCP_RUNTIME_DIR", "D:/comsol_runtime"))
        / "wave_optics_point_audit"
    )
    artifact_dir = Path(
        os.environ.get("COMSOL_POINT_AUDIT_ARTIFACT_DIR", str(default_artifact_dir))
    )
    artifact_dir.mkdir(parents=True, exist_ok=True)
    result_path = artifact_dir / "point_audit_gate_result.json"
    owner = SolverOwnership(owner="wave-optics-point-audit")
    client = None
    active_cases = ()
    output = {"success": False, "solve_count": 0, "selected_cases": [], "cases": []}
    exit_code = 1
    try:
        fixture = controlled_fixture_from_environment()
        fixture["policy"] = {
            "assumptions": {"passive": True, "port_power_normalized": True},
            "required_evidence": [
                "wavelength_controls",
                "flux_RTA",
                "top_air_region",
                "source_integrity",
            ],
            "tolerances": {
                "closure_abs": 1e-3,
                "quantity_bounds_margin": 1e-3,
                "wavelength_abs_m": 1e-12,
            },
        }
        active_cases = (fixture,)
        output["selected_cases"] = [case["name"] for case in active_cases]
        for case in active_cases:
            if not case["source"].is_file():
                raise FileNotFoundError(case["source"])
            _bound_source_sha256(case)
        claim = owner.acquire(
            mode="wave_optics_point_audit_matrix", model_path=str(active_cases[0]["source"])
        )
        if not claim.get("success"):
            raise RuntimeError(f"solver lease unavailable: {claim}")
        client = mph.Client(cores=required_acceptance_cores(), version="6.4")
        for case in active_cases:
            source = case["source"]
            source_hash = _bound_source_sha256(case)
            source_stat = source.stat()
            model = client.load(str(source))
            jm = model.java
            component_tag = _first_tag(jm.component(), "comp1")
            component = jm.component().get(component_tag)
            physics_tag = _first_tag(component.physics(), "ewfd")
            study_tag = _first_tag(jm.study(), "std1")
            study = jm.study().get(study_tag)
            step_tag = _study_step(study)
            r_expression = t_expression = a_expression = None
            loss_map = None
            power_provenance = {
                "normalization": (
                    "COMSOL PeriodicStructure total port powers normalized "
                    "to the excited periodic port."
                ),
                "R_direction": "Outgoing power through the excited periodic port.",
                "T_direction": "Outgoing power through the opposite periodic port.",
                "A_definition": "COMSOL ewfd.Atotal for the PeriodicStructure solution.",
            }
            domains = case["top_air_domain_ids"]
            coordinate_range = case["top_air_coordinate_range"]
            audit = run_wave_optics_point_audit(
                model,
                model_name=model.name(),
                component_tag=component_tag,
                physics_tag=physics_tag,
                study_tag=study_tag,
                wavelength_value=case["wavelength_um"],
                wavelength_unit="um",
                wavelength_parameter="wl",
                study_step_tag=step_tag,
                study_step_property="plist",
                expected_source_sha256=source_hash,
                config_id=f"point-audit-{case['name']}",
                artifact_dir=str(artifact_dir / "audits"),
                r_expression=r_expression,
                t_expression=t_expression,
                a_expression=a_expression,
                top_air_domain_ids=domains,
                top_air_coordinate_range=coordinate_range,
                loss_map=loss_map,
                power_provenance=power_provenance,
                air_reference_artifact_path=None,
                air_reference_config_id=None,
                validation_policy=case["policy"],
                session_state={"connected": True, "models": [model.name()]},
                active_profile="wave_optics",
                # The preflight behind this audit early-returns with
                # `integrity_blocked` when the caller declares an expected source
                # but does not attest the bytes that were loaded. This probe
                # loads `source` itself in this process, so it can attest that
                # identity honestly; `model_registration` is the capture label
                # the session manager uses for a file loaded from disk.
                loaded_source_identity={
                    "source_path": str(source),
                    "source_sha256": source_hash,
                    "capture": "model_registration",
                },
                ownership_preflight={"ready": True},
            )
            output["solve_count"] += int(
                audit.get("measurement", {}).get("solve", {}).get("ran", False)
            )
            _require(audit["success"], audit)
            # This probe always supplies a validation policy, and a policy-bearing
            # audit legitimately reports `policy_evaluated` rather than
            # `measurement_complete` (see wave_optics_audit.py, where the status is
            # set to "policy_evaluated" whenever a policy is evaluated). Both mean
            # "the measurement completed"; the rest of the codebase already treats
            # them as equivalent (_COMPLETE_AUDIT_STATES in jobs/validation_rows.py,
            # jobs/validation_runner.py, and jobs/spectral_audit.py). Asserting only
            # `measurement_complete` made a passing audit look like a failure.
            _require(
                audit.get("audit_status") in {"measurement_complete", "policy_evaluated"},
                audit,
            )
            # `evaluate_validation_policy` reports the legacy point-audit verdict
            # as the string "pass" (it also uses "missing" and "fail"), while the
            # strict physical-evidence policy path reports a boolean. Accept the
            # documented legacy spelling rather than only the strict-path type;
            # previously this assertion could never hold for a legacy policy.
            _require(
                audit.get("assessment", {}).get("project_verdict") in (True, "pass"),
                audit,
            )
            _require(Path(audit["artifacts"]["csv"]).is_file(), "audit CSV is missing")
            _require(Path(audit["artifacts"]["manifest"]).is_file(), "audit manifest is missing")
            _require(_sha256(source) == source_hash, "controlled source hash changed")
            final_stat = source.stat()
            _require(final_stat.st_mtime_ns == source_stat.st_mtime_ns, "source mtime changed")
            _require(final_stat.st_size == source_stat.st_size, "source size changed")
            output["cases"].append(
                {
                    "name": case["name"],
                    "source": str(source),
                    "source_sha256": source_hash,
                    "audit_status": audit["audit_status"],
                    "policy_overall": audit["assessment"].get("project_verdict"),
                    "power": audit["measurement"]["power"],
                    "wavelength": audit["measurement"]["wavelength"],
                    "polarization_evidence_level": audit["measurement"]["polarization"][
                        "evidence_level"
                    ],
                    "field_statistics": audit["measurement"]["polarization"].get(
                        "structure_total_field"
                    ),
                    "measurement_errors": audit["measurement"]["measurement_errors"],
                    "integrity_errors": audit["measurement"]["integrity_errors"],
                    "artifacts": audit["artifacts"],
                }
            )
            client.remove(model)
        _require(output["solve_count"] == len(active_cases), "solve count mismatch")
        output["success"] = True
        exit_code = 0
    except Exception as exc:
        output["error"] = str(exc)
        output["traceback"] = traceback.format_exc(limit=12)
    finally:
        if client is not None:
            try:
                client.clear()
            except Exception:
                pass
        output["lease_release"] = owner.release()
        result_path.write_text(
            json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        print(json.dumps(output, ensure_ascii=False), flush=True)
        os._exit(exit_code)


if __name__ == "__main__":
    main()
