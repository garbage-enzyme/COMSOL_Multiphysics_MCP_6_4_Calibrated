"""Default-on evidence-integrity settings and disclosure tests."""

from __future__ import annotations

import json

import pytest
from src.evidence.integrity_controls import (
    DISABLED_CHECK_WARNING,
    DISABLED_CHECK_WARNING_CODE,
    EVIDENCE_CHECKS,
    EVIDENCE_INTEGRITY_VERSION,
    EVIDENCE_SETTINGS_ENV,
    EVIDENCE_SETTINGS_SCHEMA,
    INVALID_SETTINGS_WARNING_CODE,
    evidence_integrity_capability,
    load_evidence_integrity_status,
    warning_fields,
)
from src.operation_arbiter import guard_tool_call
from src.tools.capabilities import get_capabilities
from src.tools.profiles import ProfileSelection


def _selection() -> ProfileSelection:
    return ProfileSelection(
        name="core",
        source="evidence-integrity-test",
        environment_variable="COMSOL_MCP_PROFILE",
        default_used=False,
    )


def _write_settings(path, checks: dict[str, bool]) -> None:
    path.write_text(
        json.dumps(
            {
                "schema_name": EVIDENCE_SETTINGS_SCHEMA,
                "schema_version": EVIDENCE_INTEGRITY_VERSION,
                "checks": checks,
            }
        ),
        encoding="utf-8",
    )


def test_absent_settings_enable_every_check_by_default():
    status = load_evidence_integrity_status({})

    assert status["success"] is True
    assert status["settings_source"] == "default"
    assert status["strict_verification_active"] is True
    assert status["disabled_checks"] == []
    assert status["warning_codes"] == []
    assert set(status["checks"]) == set(EVIDENCE_CHECKS)
    assert all(item == {"enabled": True, "source": "default"} for item in status["checks"].values())
    assert len(status["settings_fingerprint_sha256"]) == 64
    assert status["settings_path_included"] is False


@pytest.mark.parametrize("disabled_check", EVIDENCE_CHECKS)
def test_each_check_can_be_explicitly_disabled_without_changing_other_checks(
    tmp_path, disabled_check
):
    path = tmp_path / "evidence-settings.json"
    _write_settings(path, {disabled_check: False})

    status = load_evidence_integrity_status({EVIDENCE_SETTINGS_ENV: str(path)})

    assert status["success"] is True
    assert status["strict_verification_active"] is False
    assert status["disabled_checks"] == [disabled_check]
    assert status["checks"][disabled_check] == {
        "enabled": False,
        "source": "explicit_settings",
    }
    for name in set(EVIDENCE_CHECKS) - {disabled_check}:
        assert status["checks"][name] == {"enabled": True, "source": "default"}
    assert status["warning_codes"] == [DISABLED_CHECK_WARNING_CODE]
    assert status["warning_messages"] == [DISABLED_CHECK_WARNING]
    assert warning_fields(status)["strictly_verified"] is False
    # The attestation fingerprint hashes canonical effective settings, not raw
    # file bytes: cosmetic reformatting must not invalidate attested results.
    from src.evidence.integrity_controls import _canonical_bytes, _normalize_settings, _sha256

    effective, _checks = _normalize_settings(json.loads(path.read_text(encoding="utf-8")))
    assert status["settings_fingerprint_sha256"] == _sha256(_canonical_bytes(effective))


def test_explicit_settings_fingerprint_ignores_cosmetic_reformatting(tmp_path):
    path = tmp_path / "evidence-settings.json"
    _write_settings(path, {"summary_claim_verification": False})
    first = load_evidence_integrity_status({EVIDENCE_SETTINGS_ENV: str(path)})

    document = json.loads(path.read_text(encoding="utf-8"))
    reordered = {
        "schema_version": document["schema_version"],
        "checks": document["checks"],
        "schema_name": document["schema_name"],
    }
    path.write_text(json.dumps(reordered, indent=3), encoding="utf-8")
    second = load_evidence_integrity_status({EVIDENCE_SETTINGS_ENV: str(path)})

    assert second["success"] is True
    assert first["settings_fingerprint_sha256"] == second["settings_fingerprint_sha256"]


@pytest.mark.parametrize(
    ("payload", "reason_code"),
    [
        ('{"schema_name":"comsol_mcp.evidence_integrity_settings",', "settings_json_invalid"),
        (
            '{"schema_name":"comsol_mcp.evidence_integrity_settings",'
            '"schema_version":"1.0.0","checks":{"artifact_chain_verification":true,'
            '"artifact_chain_verification":false}}',
            "settings_json_invalid",
        ),
        (
            '{"schema_name":"comsol_mcp.evidence_integrity_settings",'
            '"schema_version":"1.0.0","checks":{"artifact_chain_verification":"false"}}',
            "settings_rejected",
        ),
        (
            '{"schema_name":"comsol_mcp.evidence_integrity_settings",'
            '"schema_version":"1.0.0","checks":{},"unknown":true}',
            "settings_rejected",
        ),
        (
            '{"schema_name":"comsol_mcp.evidence_integrity_settings",'
            '"schema_version":"1.0.0","checks":{"unknown_check":false}}',
            "settings_rejected",
        ),
    ],
)
def test_malformed_ambiguous_or_unknown_settings_fail_closed(tmp_path, payload, reason_code):
    path = tmp_path / "bad-settings.json"
    path.write_text(payload, encoding="utf-8")

    status = load_evidence_integrity_status({EVIDENCE_SETTINGS_ENV: str(path)})

    assert status["success"] is False
    assert status["configuration_state"] == "invalid"
    assert status["strict_verification_active"] is False
    assert status["reason_code"] == reason_code
    assert status["warning_codes"] == [INVALID_SETTINGS_WARNING_CODE]
    assert status["settings_path_included"] is False


def test_missing_settings_path_is_not_disclosed_in_failure_content(tmp_path):
    path = tmp_path / "private-missing-evidence-settings.json"

    status = load_evidence_integrity_status({EVIDENCE_SETTINGS_ENV: str(path)})

    serialized = json.dumps(status, ensure_ascii=False, sort_keys=True)
    escaped_path = json.dumps(str(path), ensure_ascii=False)[1:-1]
    assert status["success"] is False
    assert status["settings_path_included"] is False
    assert escaped_path not in serialized
    assert path.name not in serialized


def test_degraded_project_settings_disable_strict_verification_and_emit_warning(monkeypatch):
    import src.evidence.integrity_controls as integrity_controls_module

    project = integrity_controls_module.load_settings({})
    monkeypatch.delenv(EVIDENCE_SETTINGS_ENV, raising=False)
    monkeypatch.setattr(
        integrity_controls_module,
        "load_settings_report",
        lambda: {
            "settings": project,
            "errors": [{"reason_code": "settings_invalid"}],
        },
    )

    status = load_evidence_integrity_status()

    assert status["success"] is False
    assert status["configuration_state"] == "degraded"
    assert status["strict_verification_active"] is False
    assert status["warning_codes"] == [INVALID_SETTINGS_WARNING_CODE]
    assert warning_fields(status)["strictly_verified"] is False


def test_project_settings_are_read_once_for_status_and_checks(monkeypatch):
    import src.evidence.integrity_controls as controls

    project = controls.load_settings({})
    calls = []

    def report():
        calls.append(True)
        assert len(calls) == 1
        return {"settings": project, "errors": []}

    monkeypatch.delenv(EVIDENCE_SETTINGS_ENV, raising=False)
    monkeypatch.setattr(controls, "load_settings_report", report)
    assert load_evidence_integrity_status()["strict_verification_active"] is True
    assert calls == [True]


def test_capabilities_report_effective_checks_without_exposing_settings_path(tmp_path, monkeypatch):
    path = tmp_path / "private-name-settings.json"
    _write_settings(path, {"summary_claim_verification": False})
    monkeypatch.setenv(EVIDENCE_SETTINGS_ENV, str(path))

    capability = evidence_integrity_capability()
    assert set(capability) == {
        "success",
        "schema_name",
        "schema_version",
        "configuration_state",
        "settings_source",
        "settings_environment_variable",
        "settings_fingerprint_sha256",
        "settings_path_included",
        "default_enabled",
        "strict_verification_active",
        "checks",
        "disabled_checks",
        "warning_codes",
        "warning_messages",
        "solver_free",
        "tools",
        "formal_verification_scope",
        "hashes_prove_physical_correctness",
    }
    assert capability["success"] is True
    assert capability["configuration_state"] == "valid"
    assert capability["settings_source"] == "explicit_settings"
    assert capability["solver_free"] is True
    assert capability["tools"] == ["evidence_integrity_status", "evidence_integrity_verify"]
    assert capability["strict_verification_active"] is False
    assert capability["disabled_checks"] == ["summary_claim_verification"]
    assert capability["settings_path_included"] is False
    assert str(path) not in json.dumps(capability)
    assert capability["hashes_prove_physical_correctness"] is False


def test_disabled_check_warning_propagates_to_affected_tool_responses(tmp_path, monkeypatch):
    path = tmp_path / "evidence-settings.json"
    _write_settings(path, {"artifact_chain_verification": False})
    monkeypatch.setenv(EVIDENCE_SETTINGS_ENV, str(path))

    def exploratory_summary() -> dict:
        return {"success": True, "summary": {"peak": 1.0}}

    guarded = guard_tool_call(
        exploratory_summary,
        tool_name="spectral_characterize",
        side_effect_class="read_only",
        concurrency_class="solver_free",
        profile_name="core",
    )
    result = guarded()

    assert result["success"] is True
    assert result["strictly_verified"] is False
    assert result["disabled_evidence_checks"] == ["artifact_chain_verification"]
    assert result["evidence_integrity_warning_codes"] == [DISABLED_CHECK_WARNING_CODE]
    assert result["evidence_integrity_warnings"] == [DISABLED_CHECK_WARNING]
    assert result["path_policy"]["accepted"] is True


def test_capabilities_and_status_keep_their_structured_discovery_contract(tmp_path, monkeypatch):
    path = tmp_path / "evidence-settings.json"
    _write_settings(path, {"artifact_chain_verification": False})
    monkeypatch.setenv(EVIDENCE_SETTINGS_ENV, str(path))

    guarded = guard_tool_call(
        lambda: get_capabilities(_selection()),
        tool_name="capabilities",
        side_effect_class="read_only",
        concurrency_class="control_plane",
        profile_name="core",
    )
    result = guarded()

    assert result["evidence_integrity"]["disabled_checks"] == ["artifact_chain_verification"]
    assert "disabled_evidence_checks" not in result
