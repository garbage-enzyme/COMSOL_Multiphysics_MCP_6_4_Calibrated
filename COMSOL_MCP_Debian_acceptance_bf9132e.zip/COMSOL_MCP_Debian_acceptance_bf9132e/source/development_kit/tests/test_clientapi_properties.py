"""Mock gates for constrained existing-object clientapi property access."""

from __future__ import annotations

import math

import pytest
from src.tools.properties import get_existing_property, set_existing_property


class FakeFeature:
    def __init__(self, values, value_types):
        self.values = dict(values)
        self.value_types = dict(value_types)
        self.set_calls = []

    def properties(self):
        return list(self.values)

    def getValueType(self, name):
        return self.value_types[name]

    def getString(self, name):
        return self.values[name]

    def getStringArray(self, name):
        return self.values[name]

    def getStringMatrix(self, name):
        return self.values[name]

    def getDouble(self, name):
        return self.values[name]

    def getDoubleArray(self, name):
        return self.values[name]

    def getInt(self, name):
        return self.values[name]

    def getIntArray(self, name):
        return self.values[name]

    def getBoolean(self, name):
        return self.values[name]

    def getBooleanArray(self, name):
        return self.values[name]

    def set(self, name, value):
        self.set_calls.append((name, value))
        self.values[name] = value


class FakeFeatureList:
    def __init__(self, feature):
        self.feature = feature

    def get(self, tag):
        return self.feature if tag == "child1" else None


class FakeParent:
    def __init__(self, feature):
        self.features = FakeFeatureList(feature)

    def feature(self):
        return self.features


class FakeContainerList:
    def __init__(self, feature):
        self.feature = feature

    def __call__(self, tag):
        return FakeParent(self.feature) if tag == "parent1" else None


class FakeComponent:
    def __init__(self, feature):
        self.feature = feature

    def geom(self, tag):
        return FakeParent(self.feature) if tag == "parent1" else None

    def physics(self, tag):
        return FakeParent(self.feature) if tag == "parent1" else None

    def mesh(self, tag):
        return FakeParent(self.feature) if tag == "parent1" else None


class FakeJava:
    def __init__(self, feature):
        self.feature = feature
        self.component_node = FakeComponent(feature)
        self.study = FakeContainerList(feature)
        self.result = FakeContainerList(feature)

    def component(self, tag):
        return self.component_node if tag == "comp1" else None


class FakeModel:
    def __init__(self, feature):
        self.java = FakeJava(feature)


@pytest.fixture
def feature():
    return FakeFeature(
        {
            "label": "old",
            "size": ["1", "2", "3"],
            "basis": [["1", "0"], ["0", "1"]],
            "scale": 0.25,
            "indices": [1, 2],
            "active": True,
        },
        {
            "label": "String",
            "size": "StringArray",
            "basis": "StringMatrix",
            "scale": "Double",
            "indices": "IntArray",
            "active": "Boolean",
        },
    )


@pytest.mark.parametrize(
    "container",
    ["geometry_feature", "physics_feature", "mesh_feature", "study_step", "result_feature"],
)
def test_property_get_resolves_each_allowlisted_container(feature, container):
    result = get_existing_property(FakeModel(feature), "comp1", container, "parent1/child1", "size")

    assert result["success"] is True
    assert result["value"] == ["1", "2", "3"]
    assert result["target"].endswith("parent1/child1/size")


@pytest.mark.parametrize("container", ["study_step", "result_feature"])
def test_model_level_property_targets_do_not_require_an_unrelated_component(feature, container):
    result = get_existing_property(
        FakeModel(feature), "missing_component", container, "parent1/child1", "size"
    )

    assert result["success"] is True
    assert result["value"] == ["1", "2", "3"]


@pytest.mark.parametrize(
    "property_name, new_value",
    [
        ("label", "new"),
        ("size", ["4", "5", "6"]),
        ("basis", [["0", "1"], ["1", "0"]]),
        ("scale", 0.5),
        ("indices", [3, 4]),
        ("active", False),
    ],
)
def test_property_set_returns_normalized_old_and_new_values(feature, property_name, new_value):
    old_value = feature.values[property_name]

    result = set_existing_property(
        FakeModel(feature),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        property_name,
        new_value,
    )

    assert result["success"] is True
    assert result["old_value"] == old_value
    assert result["new_value"] == new_value
    assert feature.set_calls == [(property_name, new_value)]


def test_property_set_readback_failure_restores_old_value():
    class OneShotReadbackFailure(FakeFeature):
        def __init__(self):
            super().__init__({"label": "old"}, {"label": "String"})
            self.read_count = 0

        def getString(self, name):
            self.read_count += 1
            if self.read_count == 2:
                raise RuntimeError("injected readback failure")
            return super().getString(name)

    target = OneShotReadbackFailure()

    result = set_existing_property(
        FakeModel(target),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "label",
        "new",
    )

    assert result["success"] is False
    assert result["rolled_back"] is True
    assert target.values["label"] == "old"
    assert target.set_calls == [("label", "new"), ("label", "old")]


def test_property_set_exception_restores_and_verifies_old_value():
    class PartialSetFailure(FakeFeature):
        def set(self, name, value):
            super().set(name, value)
            if value == "new":
                raise RuntimeError("partial clientapi mutation")

    target = PartialSetFailure({"label": "old"}, {"label": "String"})

    result = set_existing_property(
        FakeModel(target),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "label",
        "new",
    )

    assert result == {
        "success": False,
        "error": "clientapi property set failed",
        "old_value": "old",
        "rolled_back": True,
    }
    assert target.values["label"] == "old"
    assert target.set_calls == [("label", "new"), ("label", "old")]


def test_property_set_coercion_is_not_reported_as_success_and_rolls_back():
    class CoercingFeature(FakeFeature):
        def set(self, name, value):
            self.set_calls.append((name, value))
            self.values[name] = "coerced" if value == "new" else value

    target = CoercingFeature({"label": "old"}, {"label": "String"})

    result = set_existing_property(
        FakeModel(target),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "label",
        "new",
    )

    assert result["success"] is False
    assert result["observed_value"] == "coerced"
    assert result["rolled_back"] is True
    assert target.values["label"] == "old"


def test_property_access_rejects_unknown_targets_and_properties(feature):
    model = FakeModel(feature)

    assert (
        get_existing_property(model, "comp1", "arbitrary_java", "parent1/child1", "label")[
            "success"
        ]
        is False
    )
    assert (
        get_existing_property(model, "comp1", "geometry_feature", "parent1/child1/run", "label")[
            "success"
        ]
        is False
    )
    result = get_existing_property(model, "comp1", "geometry_feature", "parent1/child1", "missing")
    assert result["success"] is False
    assert "unknown property" in result["error"]


@pytest.mark.parametrize("container", ["geometry_feature", "physics_feature", "mesh_feature"])
def test_property_access_rejects_missing_parent_tag(feature, container):
    result = get_existing_property(
        FakeModel(feature), "comp1", container, "missing/child1", "label"
    )

    assert result["success"] is False
    assert result["error"] == f"clientapi parent does not exist: {container}:missing"


@pytest.mark.parametrize("container", ["study_step", "result_feature"])
def test_property_access_rejects_missing_model_level_parent_tag(feature, container):
    result = get_existing_property(
        FakeModel(feature), "comp1", container, "missing/child1", "label"
    )

    assert result == {
        "success": False,
        "error": f"clientapi parent does not exist: {container}:missing",
    }


@pytest.mark.parametrize(
    "value",
    [
        math.nan,
        math.inf,
        -math.inf,
        [1.0, math.inf],
        [1.0, -math.inf],
        [[1.0, math.nan]],
        [[math.inf], [-math.inf]],
    ],
)
def test_property_set_rejects_nonfinite_before_resolving_clientapi(value):
    class UntouchableModel:
        @property
        def java(self):
            raise AssertionError("clientapi must not be touched")

    result = set_existing_property(
        UntouchableModel(),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "scale",
        value,
    )

    assert result["success"] is False
    assert "finite" in result["error"]


def test_property_access_rejects_file_and_callable_property_names(feature):
    for property_name in ("filename", "method", "run()"):
        result = get_existing_property(
            FakeModel(feature),
            "comp1",
            "geometry_feature",
            "parent1/child1",
            property_name,
        )
        assert result["success"] is False
        assert not feature.set_calls


def test_property_set_independently_rejects_file_and_callable_names(feature):
    for property_name in ("filename", "method", "run()"):
        result = set_existing_property(
            FakeModel(feature),
            "comp1",
            "geometry_feature",
            "parent1/child1",
            property_name,
            "unsafe",
        )
        assert result["success"] is False
        assert not feature.set_calls


class NumericMatrixFeature:
    def __init__(self):
        self.values = {"kernel": [[1.0, 2.0], [3.0, 4.0]]}
        self.set_calls = []

    def properties(self):
        return list(self.values)

    def getValueType(self, name):
        return {"kernel": "DoubleMatrix"}[name]

    def getDoubleMatrix(self, name):
        return [list(row) for row in self.values[name]]

    def set(self, name, value):
        self.set_calls.append((name, value))
        self.values[name] = value


def test_double_matrix_properties_read_as_numbers_and_round_trip():
    feature = NumericMatrixFeature()

    read = get_existing_property(
        FakeModel(feature), "comp1", "geometry_feature", "parent1/child1", "kernel"
    )

    assert read["success"] is True
    assert read["value_type"] == "DoubleMatrix"
    assert read["value"] == [[1.0, 2.0], [3.0, 4.0]]

    result = set_existing_property(
        FakeModel(feature),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "kernel",
        [[1, 2], [3, 4]],
    )

    assert result["success"] is True
    assert result["new_value"] == [[1.0, 2.0], [3.0, 4.0]]


def test_selection_properties_read_through_the_array_reader():
    """A geometry ``Block`` carries ``Selection`` properties that ``getString`` rejects.

    Measured on COMSOL 6.4: an ordinary Block's ``input`` property is declared
    ``Selection`` and ``getString`` raises FlException ("property 'input' cannot be
    converted to a string"), while ``getStringArray`` succeeds. That exception used
    to abort every geometry feature snapshot, so ``derived_geometry_clone``/
    ``apply`` could not snapshot any geometry containing a Block.
    """

    class SelectionFeature(FakeFeature):
        def getString(self, name):
            raise RuntimeError("property 'input' cannot be converted to a string")

    feature = SelectionFeature({"input": ["geom1_b_air_dom"]}, {"input": "Selection"})

    read = get_existing_property(
        FakeModel(feature), "comp1", "geometry_feature", "parent1/child1", "input"
    )

    assert read["success"] is True
    assert read["value_type"] == "Selection"
    assert read["value"] == ["geom1_b_air_dom"]


def test_selection_properties_report_an_empty_selection_honestly():
    """An unset selection reads back as an empty list, not a failure or a guess."""

    class SelectionFeature(FakeFeature):
        def getString(self, name):
            raise RuntimeError("property 'posvertex' cannot be converted to a string")

    feature = SelectionFeature({"posvertex": []}, {"posvertex": "Selection"})

    read = get_existing_property(
        FakeModel(feature), "comp1", "geometry_feature", "parent1/child1", "posvertex"
    )

    assert read["success"] is True
    assert read["value_type"] == "Selection"
    assert read["value"] == []


def test_set_failure_payload_includes_old_value_and_restore_detail():
    class LockedFeature(FakeFeature):
        def set(self, name, value):
            if name == "locked" and value != self.values.get("locked"):
                raise RuntimeError("backend rejects the assignment")
            super().set(name, value)

    feature = LockedFeature({"locked": "safe"}, {"locked": "String"})
    result = set_existing_property(
        FakeModel(feature),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "locked",
        "unsafe",
    )

    assert result["success"] is False
    assert result["error"] == "clientapi property set failed"
    assert result["old_value"] == "safe"
    assert result["rolled_back"] is True
    assert "rollback_error" not in result

    class UnrestorableFeature(LockedFeature):
        def set(self, name, _value):
            if name == "locked":
                raise RuntimeError("backend rejects every assignment")
            super().set(name, _value)

    stuck = UnrestorableFeature({"locked": "safe"}, {"locked": "String"})
    failed = set_existing_property(
        FakeModel(stuck),
        "comp1",
        "geometry_feature",
        "parent1/child1",
        "locked",
        "unsafe",
    )

    assert failed["success"] is False
    assert failed["old_value"] == "safe"
    assert failed["rolled_back"] is False
    assert failed["rollback_error"].startswith("RuntimeError:")
