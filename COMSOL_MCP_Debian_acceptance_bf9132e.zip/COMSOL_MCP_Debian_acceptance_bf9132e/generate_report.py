"""Render evidence-backed acceptance conclusions from the retained receipts."""
import hashlib
import importlib.metadata
import json
import re
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/COMSOL_MCP_debian_fix_acceptance')
BASELINE=Path('/workspace/COMSOL_Multiphysics_MCP_6_4_Calibrated')
TARGET='bf9132e6a7b567853c2b89d7e5d1087891a4d4bd'
OLD='da9f168baedfcca28d04d93369ef711240011d73'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==TARGET
cases=json.loads((ROOT/'independent-results.json').read_text())
assert len(cases)==24 and not any(r['outer_timeout'] for r in cases)
failed=[r['case'] for r in cases if not r['result']['passed']]
assert failed==['BUG-004__concurrent','BUG-005__concurrent',
               'BUG-041__parent_replacement','BUG-041__ancestor_replacement'],failed
commands=json.loads((ROOT/'target-command-results.json').read_text())
ci=json.loads((ROOT/'ci-local-results.json').read_text())
environment=json.loads((ROOT/'environment-and-revision.json').read_text())
environment.update(target_repository=str(REPO),target_commit=TARGET,
                   requested_branch_name='alpha7-8',confirmed_branch='origin/alpha7-7',
                   repository_url='https://github.com/garbage-enzyme/COMSOL_Multiphysics_MCP_6_4_Calibrated',
                   target_note='User explicitly confirmed these 13 commits after branch-name discrepancy was explained.',
                   revision_count=int(subprocess.check_output(['git','rev-list','--count',OLD+'..'+TARGET],cwd=REPO)),
                   package_versions={name:importlib.metadata.version(name) for name in
                     ['mcp','MPh','numpy','scipy','pydantic','psutil','ruff','pytest','coverage']})
(ROOT/'environment-and-revision.json').write_text(json.dumps(environment,ensure_ascii=False,indent=2)+'\n')
stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S +08:00')
shard_rows=[]
for file in sorted((ROOT/'ci-dependency-shards').glob('shard*.log')):
    text=file.read_text(errors='replace')
    summaries=[line for line in text.splitlines() if re.search(r'\b\d+ (?:failed|passed).* in \d',line)]
    failures=re.findall(r'^FAILED (.+)$',text,flags=re.M)
    shard_rows.append({'log':file.name,'summary':summaries[-1] if summaries else '进行中',
                       'failures':failures})
shard_receipt=ROOT/'ci-dependency-shards-result.json'
shard_text='两分片完整重跑仍进行中；以下为草稿，不能当最终结论。'
if shard_receipt.exists():
    sr=json.loads(shard_receipt.read_text())
    shard_text=f"实际两分片命令完成，耗时 {sr['seconds']} 秒，返回 {sr['returncode']}，外层超时 {sr['outer_timeout']}。"
    shard_text+='\n\n'+ '\n'.join('- '+r['log']+'：'+r['summary'] for r in shard_rows)
    shard_text+='\n\n失败节点：\n\n'+'\n'.join('- '+f for r in shard_rows for f in r['failures'])
(ROOT/'ci-shard-failure-summary.json').write_text(json.dumps(shard_rows,ensure_ascii=False,indent=2)+'\n')
command_rows=[]
for row in commands:
    if row['name'].startswith('ci_ruff') or row['name'].endswith('original_probe'): continue
    output=(ROOT/'target-command-results'/(row['name']+'__stdout.log')).read_text()
    summary=next((line for line in reversed(output.splitlines()) if ' passed' in line),'见日志')
    command_rows.append(f"| {row['name']} | {summary} | {row['seconds']} 秒 |")
report=f'''# Debian 独立验收与 CI 失败分析报告

生成时间：{stamp}。本次结论：**原始五项复现已修复；扩展验收有四项失败，本批不能作为完整验收通过。CI 也未通过。**

## 版本与范围

- 仓库：garbage-enzyme/COMSOL_Multiphysics_MCP_6_4_Calibrated。
- 基线：`{OLD}`；原 203 条 buglist 保持原样。
- 用户确认目标：`{TARGET}`，实际远端分支 `alpha7-7`。
- 用户最初称 alpha7-8；仓库无该分支，已确认验收上述 13 个提交。
- 两提交间有 13 个提交、51 个修改文件。验收范围是 BUG-001/002、004/005、041 及当前 CI 阻塞项。
- 独立 worktree：`/workspace/COMSOL_MCP_debian_fix_acceptance`。未修复代码，未启动 COMSOL。
- 宿主 Debian 13 x86_64，Python 3.14.7、Ruff 0.16.10、pytest 9.1.1；完整版本见 environment-and-revision.json。
- Python 验收显式导入目标 worktree，未将旧安装包当作修复版本。

## 每项验收结论

| 原 BUG | 原始场景 | 扩展验收 | 结论 |
| --- | --- | --- | --- |
| BUG-001 | 原始 AttributeError 已消失 | 冷进程单测、平台/POSIX 两种顺序、无 native 导入/回调的现有测试通过 | 本范围通过 |
| BUG-002 | 无写端 FIFO 清理不再阻塞 | identity/content、打开前换成 FIFO、末端/直接父级链接拒绝、正常身份删除、替换恢复均通过 | 本范围通过 |
| BUG-004 | 完整行+半行+正常追加后保留 first/second；新进程重开仍可读 | 另一进程已确认 B 后，A 用过期边界恢复会删除 B | 串行通过；并发耐久性不通过（ACC-001） |
| BUG-005 | 跨 owner 串行重复提交返回 task_owner_conflict，原 owner 保持查询/取消权 | A 查询为空后，独立进程 B 确认 task-b，A 仍可确认 task-a；同一 job 由两 owner 控制 | 串行通过；并发隔离不通过（ACC-002） |
| BUG-041 | inspect/acquire/release 的 FIFO、大文件与末端链接拒绝通过；发布验证遇 FIFO 有界拒绝 | 父目录链接被读取接受；release 可能抛异常。祖先链接替换可删除外部锁并返回 verified=true | 原始 IO 范围通过；路径扩展不通过（ACC-003/004） |

原始脚本 BUG-005 在目标版本退出 1，原因是它把 owner-b 成功复用作为后续动作；新版本按预期抛出 owner conflict。
新独立探针另行证明冲突不写 journal、owner-a 仍可访问、owner-b 查询/取消被拒绝。
不能将这个退出码单独当作修复失败。

原始 BUG-041 的 8 MiB 输入测量：基线峰值 16,778,916 字节；目标峰值 1,967 字节。
新增探针对异常文件验证 buffered read 句柄数为 0，确认在读取之前拒绝。
FIFO 场景没有写者；探针使用独立有界进程，全部未触发 12 秒上界。
所有替换、链接、FIFO 和日志文件均在验收临时目录；外部目标是本次创建的有限测试文件。

## 四项扩展失败证据

1. **ACC-001 / BUG-004**：B 的独立进程返回 acknowledged=true；随后 journal 从 first/B 变成 first/A。
   真实前后字节见 fixtures/BUG-004__concurrent。A 的调度 hook 只在真实读取之后暂停；B 使用真实存储。
2. **ACC-002 / BUG-005**：B 的独立进程持久化 task-b 后，A 根据旧快照持久化 task-a。
   同一 job-fixed 两条真实映射分别属于 owner-a/b；两个 owner 的取消都到达确定性引擎替身。
3. **ACC-003 / BUG-041**：直接父目录替换后，inspect 返回 active；release 抛 NotADirectoryError。
   首次未捕获异常与随后结构化捕获的输出均保留；外部文件未被删除。
4. **ACC-004 / BUG-041**：祖先目录被替换后，inspect 接受外部锁；release 返回 released=true/verified=true，外部锁被删。
   最终探针从构造时就使用嵌套 runtime 路径，只修改文件系统，未改 arbiter 的路径字段。

复现入口：`python independent_checks.py --case <BUG-NNN__case>`。
完整四项六字段报告及可能解决办法见 [acceptance_buglist.md](acceptance_buglist.md)。
每个实际结果都有 checks、回执、耗时、stdout/stderr；见 independent-results.json 和 independent-results/。

## 定向测试记录

| 新进程命令组 | 实际结果 | 包含启动开销的耗时 |
| --- | --- | --- |
{chr(10).join(command_rows)}

独立行为检查：24 项，20 项通过，4 项失败，0 外层超时。
额外 JobStore 路径链接检查通过：job_dir/read_state 均拒绝链接目录，外部 state.json 字节和文件列表未变。
原始失败日志、此次基线重放、目标重放各自保留，未用成功日志覆盖原失败。

## CI 状态与确定阻塞项

对应 [solver-free-ci #509](https://github.com/garbage-enzyme/COMSOL_Multiphysics_MCP_6_4_Calibrated/actions/runs/37904487424)，head SHA 与验收目标一致。
最终公开状态为 Failure：7 jobs failed，2 succeeded，1 skipped；总时长 13m41s。
GitHub 页面和 annotation 原件保存在 ci-*.html；文本提取与结构化摘要分别保存。

| Job | 公开失败步骤 | 本地证据 / 判断 |
| --- | --- | --- |
| Windows unit-and-package | ratcheted quality gate | 同一 gate 在 format 阶段失败，2 文件不合格式 |
| Ubuntu backend | declared quality gate | 同一 gate 在 format 阶段失败；未进入 coverage/license/budget/installed wheel |
| Windows Settings GUI | GUI formatting and lint | workflow 原样格式范围有 1 文件不合格式 |
| integration-contracts | test_release_engineering.py | 56 passed / 1 failed：planning-code fingerprint mismatch |
| current-compatible dependencies | dependency/process suite | 同一静态 planning-code 断言在该套件中；Debian 两分片复现见下文 |
| minimum-supported dependencies | dependency/process suite | Debian 复现 planning-code、schema、semantic worker 三组失败；未重建 Windows minimum lane |
| Python 3.15 preview | preview regression/GUI suite | 上述三组代码同样进入该套件；本机未运行 Python 3.15，远端失败对应关系需完整日志 |
| Ubuntu Tk GUI | succeeded | 公开页面通过；该 job 没有运行 Windows GUI 的格式门禁 |
| locked runtime vulnerability policy | succeeded | 公开页面通过；本次未重复该平台 gate |
| paired coverage | skipped | 两个 prerequisite backend job 失败，未产出成功的 paired coverage 验收 |

### CI 阻塞 1：quality format

`comsol_mcp/durable/io.py:365` 的 read_flags 多行表达式需由格式器折叠。
`comsol_mcp/tools/model_identity.py:61` 的 next/generator 表达式需重新排版。
对应引入提交为 1ce4cce、131eef8。精确 quality gate 的 lint 步骤先通过，随后 format 失败。
保存的 quality-receipt.json 明确记载 command_failure.stage=format、coverage=null、solver_started=false。
修复方向：按当前 Ruff 格式修正这两处，再重跑原 gate。

### CI 阻塞 2：GUI format

`settings_gui/tests/test_discovery.py:71` 的 write_text 参数折行不符合格式器输出。
对应引入提交 1ce4cce。workflow 相同参数的格式检查返回 1，提示 1 file would be reformatted。
修复方向：仅整理该调用的格式，保留测试断言，再重跑 GUI 格式与 lint。

### CI 阻塞 3：planning-code 白名单指纹

fc5da9a 在 test_durable_job_control_plane.py 的前部新增 17 行链接拒绝测试。
原有唯一 h1 token 的字符偏移从 11335 变为 11923；token 与数量未变。
指纹包含 start，因此由 ff7f57cc… 变为 811bb52b…，白名单仍保存旧指纹。
release test 在 test_release_engineering.py:676 调用 verifier 后，报 mismatched=['development_kit/tests/test_durable_job_control_plane.py']。
完整旧/新 matches 和 hash 见 ci-planning-fingerprint.json。
修复方向：确认该 token 的兼容语义未变后，审阅并更新这一条精确指纹，保持现有数量与白名单要求。

### CI 阻塞 4：schema 快照与兼容期望未同步

ad184cf 修复了动态 map 被 additionalProperties=false 错误封闭的原 BUG-031。
181 个实际注册工具中有 25 个 schema 与 current snapshot 不同；逐 JSON 路径对照全部属于 additionalProperties。
3 个 schema 测试在独立基线进程均通过，在独立目标进程均失败；两分片也记录同样失败。
这是刻意修正 map 契约后缺少快照/兼容基线迁移，而不是增加 deadline 可以修复的故障。
完整差异见 CI__BUG-031__schema_comparison.json，实际 schema 另行冻结。
修复方向：审阅 map 契约变更，更新当前 snapshot、deployment identity 和 release facts，并明确历史兼容测试的允许变更。
历史 baseline 保留原件，公共对象/集合上界继续验证。

### CI 阻塞 5：semantic worker 正常短握手读取回归

131eef8 新增 _read_startup_line 使用 BufferedReader.read(4096)。
真实短管道写者已 flush 完整 ready 换行并保持运行，目标 reader 仍不返回，直到 EOF 才读出该行。
对照基线 readline 在相同场景立即返回。
实际 SemanticWorkerManager/fake worker 也做了前后对照：基线 start/health 成功，目标 startup_failed/startup deadline exceeded，清理回执 absent=true。
两分片有 14 个 semantic worker 失败，与这个确定性读取回归一致。
故障证据见 CI__BUG-053__baseline.json / target.json；探针的 exit=0 表示成功记录了行为，目标 functional_acceptance_passed=false。
修复方向：使用有界、按换行及时返回的读取原语，并保留超长行拒绝及短行正向测试。
增加 startup deadline 无法改变 read(4096) 等待缓冲区填满或 EOF 的行为。

### Debian 两分片重放

{shard_text}

该命令按 CI 的 serial_test_shards.py 使用两个独立 serial pytest 分片，排除 control_plane_startup。
缓存、覆盖数据和临时目录迁出源码；保留了 CI 两分片共享 coverage base 的行为。
原始 shard0.log/shard1.log 及 helper 的失败尾输出各自保存。
合计 4969 passed、18 failed、57 skipped、14 deselected，用时约 292 秒。
18 个失败分组为：planning-code 1、schema 3、semantic worker 14。
三组均已结合代码对照、实际数据或独立新进程复验定位。
Debian 结果不能替代 Windows 两个 dependency lane 或 Python 3.15 的实际运行。

### CI 日志访问边界

GitHub 页面可读，明确显示失败 job 和失败步骤。
Actions API/gh 请求被网络代理返回 Forbidden；已申请网络读取权限，结果未改变。
访问失败原输出见 ci-api-access-failure.log。
因此，以上五组阻塞项有本地确定复现；远端完整原始 stdout、traceback、依赖版本与所有额外失败未取得。
没有将公开 annotation 的 exit code 1 写成远端完整根因证据。
Node.js 20 迁移消息是公开 warning；对应 upload-artifact action 也出现在成功 job 中。

## 修复与复验顺序

1. 处理 ACC-001/002 的跨进程临界区；要求另一进程已确认的行和 owner 约束在恢复/重试后仍成立。
2. 处理 ACC-003/004 的目录与文件身份固定；要求链接替换后不读取/删除外部目标，并返回未验证回执。
3. 修复 semantic 短握手读取回归，核对正常 worker 能及时进入 ready 状态。
4. 整理 current schema 与历史兼容期望，修正三处格式，审阅并更新单条 planning-code 指纹。
5. 重跑四个失败行为探针、五项原始复现、schema/semantic 定向复验、定向单测和 exact CI gates；保留所有失败/成功输出。
6. 在相同提交上重跑 Windows、Ubuntu、dependency lanes 和 Python 3.15；取得远端完整日志后核对额外失败。

本报告不声明 13 个提交的其余修复、完整 release gate、paired coverage 或原生 Linux 求解已验收通过。
验收补充问题共 8 条：4 条扩展行为问题、2 条 CI 功能/契约回归、格式和白名单维护问题各 1 条。
证据完整性和工作树核验见 final-verification.json；文件级执行记录见 plan.md。
'''
(ROOT/'acceptance-report.md').write_text(report,encoding='utf-8')
summary={'target_commit':TARGET,'original_reproductions':'all five original scenarios corrected',
         'independent_cases':24,'independent_passed':20,'independent_failed':4,
         'failed_cases':failed,'independent_timeouts':0,
         'batch_acceptance':'not_passed','ci_run':37904487424,'ci_status':'failure',
         'remote_raw_ci_logs_available':False,'report':str(ROOT/'acceptance-report.md')}
(ROOT/'acceptance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
