# BUG-002

- **编号**：BUG-002
- **标题**：POSIX 身份清理可被 FIFO 无限阻塞
- **严重性/优先级**：中 / P2；鲁棒性与拒绝服务问题。
- **位置**：`comsol_mcp/durable/io.py`，`_posix_unlink_opened_file_if()` 的 `read_flags` 和 `os.open(path.name, ...)`。
- **内容/复现方法**：待清理路径是 FIFO，或普通文件在打开前被替换为 FIFO，且没有写端时，阻塞式 `O_RDONLY` 打开无限等待，尚未执行 `fstat()` 普通文件检查。失败回滚、取消或所有权清理可能卡住。前提是有权限创建或替换该路径。复现：`python /workspace/code-review/repro_fifo_cleanup.py`。该脚本在 `/tmp` 建立 FIFO，并在三秒后终止、回收子进程。实测输出 `CONFIRMED: unlink_if_identity blocks on a FIFO before regular-file validation`。
- **可能的解决办法**：使用非阻塞描述符打开，再验证文件类型和身份；保留现有隔离恢复语义，增加 FIFO 与文件替换回归测试。

