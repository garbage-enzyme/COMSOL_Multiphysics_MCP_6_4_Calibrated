# BUG-004

- **编号**：BUG-004
- **标题**：Tasks 日志遇到中断尾行后，下一次追加会丢失全部可读映射
- **严重性/优先级**：高 / P1；崩溃恢复与持久状态可用性问题。
- **位置**：`comsol_mcp/jobs/tasks_bridge.py:235` 的 `append()`，以及 `rows()`；关联 `comsol_mcp/durable/io.py` 的 `read_complete_jsonl()`。
- **内容/复现方法**：任务映射日志末尾存在未完成 JSON 行时，读取暂时保留此前完整映射。但 `append()` 未截断不完整尾行便追加新 JSON，新行与旧残片粘连成非法 JSON。随后解析器将日志整体归为 corrupt 并返回空记录，此前已确认的任务也全部变为 unknown。与模块声称“崩溃只损失最新行，不抹除已有映射”不符。运行 `python /workspace/code-review/repro_tasks_journal.py`：中断追加后读到 `['first']`，下一次正常追加后变为 `[]`，`first mapping survived: False`。复现只使用 `/tmp` 中的测试日志。
- **可能的解决办法**：在配合进程锁内，检查日志恢复状态，截断到已确认的完整行边界后再追加；对损坏行和恢复操作保留证据。增加“完整行 + 半行 + 正常追加 + 重启读取”的回归测试。

