# BUG-005

- **编号**：BUG-005
- **标题**：重复提交可以转移另一个 owner 的 Tasks 映射所有权
- **严重性/优先级**：中 / P2；多 owner 隔离与任务可控性问题。
- **位置**：`comsol_mcp/jobs/tasks_bridge.py:409` 附近，`submit_task()` 中 `latest_for_job()`、既有 taskId 复用及新 row 的 `owner=self._owner`。
- **内容/复现方法**：两个不同 owner 共用映射目录，底层引擎对相同规格返回同一作业。owner-b 最初无法读取 owner-a 的 taskId，但提交相同规格后，bridge 无所有者检查地复用旧 taskId 并追加 owner-b 的映射行。owner-b 获得读/控制权限，owner-a 反而被拒绝。复现：`python /workspace/code-review/repro_tasks_owner.py`；输出 `owner-b initially refused`、`owner-b reused owner-a task id: True`、`owner-a lost access after identical owner-b submission`。这是配置层 owner 隔离失效，不能据此声称突破操作系统用户权限。
- **可能的解决办法**：复用映射前检查 owner；拒绝跨 owner 复用，或按 `(job_id, owner)` 建立独立映射并保持原 owner 的可访问性。增加双 owner 重复提交和取消测试。

