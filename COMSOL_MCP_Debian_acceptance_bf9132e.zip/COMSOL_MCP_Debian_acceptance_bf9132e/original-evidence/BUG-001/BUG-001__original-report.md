# BUG-001

- **编号**：BUG-001
- **标题**：Linux 平台测试依赖导入顺序，独立运行失败
- **严重性/优先级**：中 / P2；测试可靠性问题。
- **位置**：`development_kit/tests/test_platform_support.py:100`；关联 `comsol_mcp/tools/session.py:126`。
- **内容/复现方法**：新进程中独立运行平台测试时，测试用只有 `preflight()` 方法的 `Forbidden` 替换 `ownership_manager`。`create_server()` 首次导入 `session` 并创建单例，读取替身不存在的 `runtime_dir`，抛出 `AttributeError`。测试没有到达平台拒绝逻辑。其他测试预先导入模块时可能掩盖缺陷。复现命令：`python -m pytest -q development_kit/tests/test_platform_support.py development_kit/tests/test_posix_platform.py --basetemp /tmp/a77posix`。证据：`/workspace/.cloud-onboarding/a77-posix.log`，20 passed / 1 failed，异常为 `'Forbidden' object has no attribute 'runtime_dir'`。安装后的 stdio 探针正确拒绝原生 preflight，此条是测试缺陷。
- **可能的解决办法**：使替身满足初始化接口，或在替换对象前显式完成无求解器初始化；增加独立新进程运行的测试验证。

