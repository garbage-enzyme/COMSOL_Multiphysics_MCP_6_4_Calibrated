# BUG-041

- **编号**：BUG-041
- **标题**：operation lock 普通读取没有类型和字节上界，Debian FIFO 使 fail-fast 状态永久阻塞
- **严重性/优先级**：中 / P2；控制面与 COMSOL 操作门禁的可用性风险。
- **位置**：`comsol_mcp/operation_arbiter.py`，_read_lock()、发布验证与 release() 的 lock_path.read_bytes()。
- **内容/复现方法**：inspect()/既有锁的 try_acquire() 直接 read_bytes；锁路径是没有写者的 FIFO 时，打开就无限阻塞，无法返回所宣称 fail-fast 的 uncertain/busy 回执。普通大文件则全部读入、解码后才拒绝。复现：`python /workspace/code-review/repro_operation_linux.py` 隔离子进程的 inspect 在 2 秒后仍阻塞，随后杀死并回收；8 MiB malformed lock 的内存峰值约 16.78 MB。需要能替换运行目录内锁路径或出现异常残留；与 BUG-002 的 unlink 和 BUG-032 的 JobLock 是独立入口。
- **可能的解决办法**：在打开时使用非阻塞、拒绝链接的描述符，验证普通文件并有界读取；inspect/acquire/publication/release 复用同一安全快照原语；对异常路径即时返回 uncertain，测试 FIFO 与巨型文件。

