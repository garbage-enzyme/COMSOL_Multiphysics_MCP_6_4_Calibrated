"""Replace an initial exploratory schedule with the untouched-arbiter probe."""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
root = Path(__file__).resolve().parent
case = 'BUG-041__ancestor_replacement'
logs = root/'independent-results'
archive = root/'exploratory-ancestor-schedule'
archive.mkdir()
for suffix in ('stdout','stderr'):
    name = case+'__'+suffix+'.log'
    shutil.copyfile(logs/name,archive/name)
(archive/'README.txt').write_text(
    'Exploratory schedule changed arbiter path fields. Excluded from final evidence.\n'
    'Final probe constructs the arbiter at the nested runtime path and only mutates filesystem ancestors.\n')
result = subprocess.run([sys.executable,str(root/'independent_checks.py'),'--case',case],
                        cwd=root,capture_output=True,timeout=12,
                        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',
                                 PYTHONPATH='/workspace/COMSOL_MCP_debian_fix_acceptance'))
(logs/(case+'__stdout.log')).write_bytes(result.stdout)
(logs/(case+'__stderr.log')).write_bytes(result.stderr)
outcomes = json.loads((root/'independent-results.json').read_text())
entry = next(r for r in outcomes if r['case']==case)
entry.update(returncode=result.returncode,result=json.loads(result.stdout),outer_timeout=False)
(root/'independent-results.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2)+'\n')
print(result.stdout.decode())
